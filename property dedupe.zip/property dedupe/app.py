import os
import uuid
from flask import Flask, request, render_template, jsonify
import pytesseract
from pdf2image import convert_from_path
import PyPDF2
import requests
from PIL import Image
import json

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def is_text_parsable_pdf(file_path):
    """Check if PDF contains extractable text"""
    try:
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ""
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text.strip():
                    text += page_text
            return len(text.strip()) > 0
    except Exception as e:
        print(f"Error checking PDF: {e}")
        return False

def extract_text_from_pdf(file_path):
    """Extract text from PDF using appropriate method"""
    if is_text_parsable_pdf(file_path):
        # Extract text directly from PDF
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
        return text
    else:
        # Use OCR to extract text from PDF images
        text = ""
        images = convert_from_path(file_path)
        for i, image in enumerate(images):
            # Save temporary image
            temp_img_path = os.path.join(app.config['UPLOAD_FOLDER'], f"temp_img_{i}.png")
            image.save(temp_img_path, 'PNG')
            
            # Extract text using pytesseract
            img_text = pytesseract.image_to_string(Image.open(temp_img_path), lang='eng+hin+tam+tel+kan+mal+ben+guj+mar+ori+pan+urd')
            text += img_text + "\n"
            
            # Clean up temporary image
            os.remove(temp_img_path)
        
        return text

def compare_documents_with_ollama(doc1_text, doc2_text):
    """Send documents to Ollama for comparison"""
    prompt = f"""
    I have two property documents. Please analyze and compare them to find any mismatches or discrepancies in key information such as:
    - Owner name
    - Property dimensions
    - Boundary details
    - Survey numbers
    - Location details
    - Any other important property information
    
    Document 1:
    {doc1_text}
    
    Document 2:
    {doc2_text}
    
    Please identify and list all mismatches between these documents. If the documents are in different languages, please translate and compare them.
    """
    
    try:
        response = requests.post('http://localhost:11434/api/generate', 
                                json={
                                    "model": "gemma3:4b",
                                    "prompt": prompt,
                                    "stream": False
                                })
        
        if response.status_code == 200:
            result = response.json()
            return result.get('response', 'No response from Ollama')
        else:
            return f"Error from Ollama API: {response.status_code} - {response.text}"
    except Exception as e:
        return f"Error connecting to Ollama: {str(e)}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    if 'documents' not in request.files:
        return jsonify({'error': 'No files uploaded'}), 400
    
    files = request.files.getlist('documents')
    
    if len(files) < 2:
        return jsonify({'error': 'Please upload at least two documents for comparison'}), 400
    
    document_texts = []
    
    for file in files:
        if file.filename == '':
            continue
        
        # Generate unique filename
        filename = str(uuid.uuid4()) + os.path.splitext(file.filename)[1]
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Save the file
        file.save(file_path)
        
        # Extract text from the file
        try:
            text = extract_text_from_pdf(file_path)
            document_texts.append(text)
            
            # Clean up the file after processing
            os.remove(file_path)
        except Exception as e:
            return jsonify({'error': f'Error processing file {file.filename}: {str(e)}'}), 500
    
    # Compare documents using Ollama
    if len(document_texts) >= 2:
        comparison_result = compare_documents_with_ollama(document_texts[0], document_texts[1])
        return jsonify({'result': comparison_result})
    else:
        return jsonify({'error': 'Not enough valid documents were processed'}), 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
