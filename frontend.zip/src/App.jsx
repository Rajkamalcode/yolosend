import React from "react";
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import ShowTable from "./components/showTable";
import Search from "./components/searchResume";
import AdminDashboard from "./components/adminPage";
import Login from "./components/login";
import Upload from "./components/upload";
import LogViewer from "./components/logViewer";
import Navbar from "./components/topBar";
import DeletedRoles from "./components/deletedRoles";
import "./App.css";
 
function App() {
  const user = JSON.parse(sessionStorage.getItem("user")); // Retrieve user from sessionStorage
  const role = user?.role || null; // Extract role, default to null if no user
 
  return (
    <Router>
      {role && <Navbar role={role} />} {/* Render Navbar only if user is logged in */}
      <Routes>
        <Route path="/" element={<Login />} />
        <Route
          path="/user_creation"
          element={role === "admin" ? <AdminDashboard /> : <Navigate to="/" />}
        />
        <Route
          path="/deleted_roles"
          element={role ? <DeletedRoles /> : <Navigate to="/" />}
        />
        <Route
          path="/search"
          element={role ? <Search /> : <Navigate to="/" />}
        />
        <Route
          path="/upload"
          element={role ? <Upload /> : <Navigate to="/" />}
        />
        <Route
          path="/logs"
          element={role ? <LogViewer /> : <Navigate to="/" />}
        />
        <Route
          path="/job_role/:role"
          element={role ? <ShowTable /> : <Navigate to="/" />}
        />
      </Routes>
    </Router>
  );
}
 
export default App