'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import documentService, { SessionResponse } from '../../../services/documentService';
import DocumentAnalysis from '../../../components/document-analysis';
import DocumentChat from '../../../components/document-chat';

export default function SessionDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const [sessionData, setSessionData] = useState<SessionResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadSession();
  }, [params.id]);

  const loadSession = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const result = await documentService.getSession(params.id);
      setSessionData(result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'An error occurred while loading the session');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteSession = async () => {
    if (!confirm('Are you sure you want to delete this session?')) {
      return;
    }
    
    try {
      await documentService.deleteSession(params.id);
      router.push('/sessions');
    } catch (err: any) {
      setError(err.response?.data?.error || 'An error occurred while deleting the session');
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-8 px-4 text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto mb-4"></div>
        <p className="text-gray-700">Loading session data...</p>
      </div>
    );
  }

  if (error || !sessionData) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded">
          {error || 'Session not found'}
        </div>
        <div className="mt-4">
          <Link 
            href="/sessions"
            className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded"
          >
            Back to Sessions
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Session Details</h1>
        
        <div className="space-x-2">
        <Link 
            href="/sessions"
            className="py-2 px-4 bg-gray-200 hover:bg-gray-300 font-medium rounded"
          >
            Back to Sessions
          </Link>
          
          <button
            onClick={handleDeleteSession}
            className="py-2 px-4 bg-red-600 hover:bg-red-700 text-white font-bold rounded"
          >
            Delete Session
          </button>
        </div>
      </div>
      
      <div className="space-y-8">
        {sessionData.analysis_result && (
          <DocumentAnalysis sessionData={sessionData} />
        )}
        
        <DocumentChat 
          sessionId={sessionData.session_id}
          initialChatHistory={sessionData.chat_history || []}
        />
        
        <div className="w-full max-w-4xl mx-auto p-4 bg-white rounded-lg shadow">
          <h2 className="text-xl font-bold mb-4">Document Details</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(sessionData.processed_files).map(([filename, fileData]) => (
              <div key={filename} className="border rounded p-4">
                <h3 className="font-bold text-lg mb-2">{filename}</h3>
                
                {fileData.error ? (
                  <p className="text-red-600">{fileData.error}</p>
                ) : (
                  <>
                    <p>
                      <span className="font-semibold">Language:</span> {fileData.detected_language.name || 'Unknown'}
                    </p>
                    {fileData.notes && fileData.notes.length > 0 && (
                      <div className="mt-2">
                        <p className="font-semibold">Notes:</p>
                        <ul className="list-disc list-inside">
                          {fileData.notes.map((note, i) => (
                            <li key={i} className="text-sm">{note}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                    <a 
                      href={documentService.getDownloadUrl(sessionData.session_id, filename)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-block text-sm text-blue-600 hover:underline"
                    >
                      Download Processed Text
                    </a>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
