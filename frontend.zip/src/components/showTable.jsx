import React, { useEffect, useState } from "react";
import { useParams } from 'react-router-dom';
import { AgGridReact } from 'ag-grid-react';
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import '../styles/styles.css';
import Navbar from "./topBar";

const fetchResumes = async (role, setRowData) => {
    try {
        const res = await fetch(`${import.meta.env.VITE_API}/job_role/${role}`);
        const data = await res.json();
        console.log("fetchresume",data)
        setRowData(data);
    } catch (error) {
        console.error("Error fetching resumes:", error);
    }
};

const ShowTable = () => {
    const { role } = useParams();
    const [rowData, setRowData] = useState([]);
    const [jobRoleInfo, setJobRoleInfo] = useState(null);
    const [userInfo, setUserInfo] = useState(JSON.parse(sessionStorage.getItem('user')));
    const [uploadStatus, setUploadStatus] = useState(null);
    const [showShortlisted, setShowShortlisted] = useState(false);
    const [showStatus, setShowStatus] = useState(true);
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [showDateRange, setShowDateRange] = useState(false);

    const skillLengthComparator = (a, b) => {
        return a.length - b.length;
    };

    const columnDefs = [
        {
            field: "resume_location",
            headerName: "Resume", 
            width: 115,
            cellRenderer: (params) => {
                const resumeLocation = params.value.replace(/\\/g, '/');
                return (
                    <a
                        href={`${import.meta.env.VITE_API}/${resumeLocation}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="resume-link-button"
                    >
                        Open
                    </a>
                );
            }
        },
        { field: "filename", headerName: "FileName"},
        { field: "name", headerName: "Name", filter: true },
        {
            field: "matched_skills",
            headerName: "Matched Skills",
            cellRenderer: (params) => params.value.filter(skill => skill).join(", "),
            filter: 'agSetColumnFilter',
            comparator: skillLengthComparator,
        },
        {
            field: "secondary_skills",
            headerName: "Secondary Skills",
            cellRenderer: (params) => params.value.filter(skill => skill).join(", "),
            filter: 'agSetColumnFilter',
            comparator: skillLengthComparator,
        },
        {
            field: "umbrella_skills",
            headerName: "Expanded Skills",
            cellRenderer: (params) => params.value.filter(skill => skill).join(", "),
            filter: 'agSetColumnFilter',
            comparator: skillLengthComparator,
        },
        { field: "location", headerName: "Location", filter: true },
        { field: "email", headerName: "Email", filter: true },
        {
            field: "phone",
            headerName: "Phone",
            filter: true,
            valueFormatter: (params) => {
                if (!params.value) return params.value;
                let phoneNumber = params.value.toString();
                if(phoneNumber.length>10){
                    if (phoneNumber.startsWith('+91')) {
                        phoneNumber = phoneNumber.slice(3);
                    } else if (phoneNumber.startsWith('91')) {
                        phoneNumber = phoneNumber.slice(2);
                    }
                }    
                if (phoneNumber.length > 10) {
                    phoneNumber = phoneNumber.slice(0, 10);
                }
                return phoneNumber;
            }
        },
        {
            field: "date_of_upload",
            headerName: "Days since upload",
            valueGetter: (params) => {
                const uploadDate = new Date(params.data.date_of_upload);
                const currentDate = new Date();
                const diffTime = Math.abs(currentDate - uploadDate);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                return diffDays === 1 ? 'Today' : `${diffDays-1} days ago`;
            },
            filter: true,
            sortable: true
        },
        {
            field: "date_of_upload",
            headerName: "Date of Upload"
        },
        {
            field: "score",  
            headerName: "Score",
            filter: 'agNumberColumnFilter',
            sortable: true,
            sort: 'desc',
        },
    ];

    const handleDateRangeFilter = (params) => {
        if (!startDate || !endDate || !showDateRange) return true;
        
        const uploadDate = new Date(params.data.date_of_upload);
        const rangeStart = new Date(startDate);
        const rangeEnd = new Date(endDate);
        rangeEnd.setHours(23, 59, 59);
        
        return uploadDate >= rangeStart && uploadDate <= rangeEnd;
    };

    const handleFileUpload = async (event) => {
        setShowStatus(true);
        const file = event.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);
        formData.append('username', userInfo.username);

        try {
            const response = await fetch(`${import.meta.env.VITE_API}/upload_shortlist/${role}`, {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            setUploadStatus(result);
            fetchResumes(role, setRowData);
            
            event.target.value = '';
            
        } catch (error) {
            setUploadStatus({ success: false, message: error.message });
            event.target.value = '';
        }
    };

    const toggleShortlistedView = () => {
        setShowShortlisted(!showShortlisted);
        const endpoint = showShortlisted ?
            `/job_role/${role}` :
            `/job_role/${role}/shortlisted`;
        
        fetch(`${import.meta.env.VITE_API}${endpoint}`)
            .then(res => res.json())
            .then(data => setRowData(data));
    };

    useEffect(() => {
        setUserInfo(JSON.parse(sessionStorage.getItem('user')));

        fetch(`${import.meta.env.VITE_API}/job_roles`)
            .then(res => res.json())
            .then(data => {
                const roleInfo = data.find(r => r.serial_number === parseInt(role));
                setJobRoleInfo(roleInfo);
            });
        
        fetchResumes(role, setRowData);
    }, [role]);

    return (
        <div>
            <div className="container">
                <header>
                    <h1 className="role-header">
                        Resumes for {jobRoleInfo ? jobRoleInfo.job_role : 'Loading...'}
                    </h1>
                    <div className="controls-section">
                        <input
                            type="file"
                            accept=".xlsx,.xls"
                            onChange={handleFileUpload}
                            style={{ display: 'none' }}
                            id="shortlist-upload"
                        />
                        <label htmlFor="shortlist-upload" className="upload-button">
                            Upload Shortlist
                        </label>
                        <button
                            onClick={toggleShortlistedView}
                            className={`toggle-button ${showShortlisted ? 'active' : ''}`}
                        >
                            {showShortlisted ? 'Show All' : 'Show Shortlisted'}
                        </button>
                        <button
                            onClick={() => setShowDateRange(!showDateRange)}
                            className={`toggle-button ${showDateRange ? 'active' : ''}`}
                        >
                            {showDateRange ? 'Hide Date Range' : 'Filter by Date'}
                        </button>
                        {showDateRange && (
                            <div className="date-range-controls">
                                <input
                                    type="date"
                                    value={startDate}
                                    onChange={(e) => setStartDate(e.target.value)}
                                    className="date-input"
                                />
                                <span>to</span>
                                <input
                                    type="date"
                                    value={endDate}
                                    onChange={(e) => setEndDate(e.target.value)}
                                    className="date-input"
                                />
                            </div>
                        )}
                    </div>
                    {uploadStatus && showStatus && (
                        <div className={`status-message ${uploadStatus.success ? 'success' : 'error'}`}>
                            <div className="status-header">
                                <div className="header-content">
                                    <span>{uploadStatus.message}</span>
                                    <button
                                        className="close-button"
                                        onClick={() => setShowStatus(false)}
                                    >
                                        Close
                                    </button>
                                </div>
                                <div className="counts">
                                    <span>Processed: {uploadStatus.processed}</span>
                                    <span>Success: {uploadStatus.successCount}</span>
                                    <span>Failed: {uploadStatus.failedCount}</span>
                                </div>
                            </div>
                            <div className="status-details">
                                {uploadStatus.details?.success.map((item, index) => (
                                    <div key={`success-${index}`} className="status-item success">
                                        <span className="status-icon">✓</span>
                                        <span>{item.name} ({item.identifier})</span>
                                    </div>
                                ))}
                                {uploadStatus.details?.failed.map((item, index) => (
                                    <div key={`failed-${index}`} className="status-item failed">
                                        <span className="status-icon">✗</span>
                                        <span>{item.name} ({item.identifier})</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </header>
                
                <div className="content">
                    {rowData.length > 0 && (
                        <div className="ag-theme-alpine" style={{
                            height: 'calc(100vh - 90px)',
                            width: '100%',
                            marginBottom: '20px'
                        }}>
                            <AgGridReact
                                rowData={rowData}
                                columnDefs={columnDefs}
                                pagination={true}
                                defaultColDef={{
                                    sortable: true
                                }}
                                isExternalFilterPresent={() => showDateRange}
                                doesExternalFilterPass={handleDateRangeFilter}
                            />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ShowTable;
