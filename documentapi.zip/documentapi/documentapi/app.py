import cv2
import numpy as np
import pytesseract
from skimage.metrics import structural_similarity as ssim
# from pdf2image import convert_from_path # Keep using this
# Need fitz *only* if pdf2image fails or for direct rendering within analysis funcs
# import fitz
from Levenshtein import ratio as levenshtein_ratio
from sklearn.metrics.pairwise import cosine_similarity
import os
import uuid
import shutil
import logging
from pathlib import Path
import asyncio # For running blocking IO in threads
from pdf2image import convert_from_path, pdfinfo_from_path # Import pdfinfo

from fastapi import FastAPI, File, UploadFile, HTTPException, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import aiofiles

pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe' # Windows Example


# --- Setup Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Global Variables & Paths ---
BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True) # Ensure upload dir exists

# Default Thresholds
DEFAULT_SIMILARITY_THRESHOLD = 0.65
DEFAULT_SHARPNESS_THRESHOLD = 100.0 # Tune this based on your tests
DEFAULT_CONTRAST_THRESHOLD = 55.0   # Tune this based on your tests

# --- FastAPI App Setup ---
app = FastAPI(title="Document Comparison API")

app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")

# --- Scan vs. Photocopy Analysis Functions ---

def calculate_sharpness(image_gray):
    """Calculates sharpness using Laplacian variance."""
    if image_gray is None or image_gray.size == 0:
        return 0.0
    # Use CV_64F for higher precision, prevent overflow/underflow
    laplacian = cv2.Laplacian(image_gray, cv2.CV_64F)
    variance = laplacian.var()
    # Handle potential NaN results if the image is perfectly flat
    return 0.0 if np.isnan(variance) else variance

def calculate_contrast_stddev(image_gray):
    """Calculates contrast using standard deviation of pixel intensities."""
    if image_gray is None or image_gray.size == 0:
        return 0.0
    std_dev = image_gray.std()
    return 0.0 if np.isnan(std_dev) else std_dev


def analyze_page_image_type(image_cv2, page_num, doc_id, sharpness_threshold, contrast_threshold):
    """
    Analyzes a single page image (as a NumPy array BGR) and guesses its type.
    Returns features dictionary and classification string ("Original Scan" / "Photocopy of Scan" / "Error").
    """
    if image_cv2 is None or image_cv2.size == 0:
        logger.warning(f"Invalid image data provided for page {page_num} of {doc_id}")
        return {"sharpness": 0.0, "contrast": 0.0}, "Error (No Image Data)"

    # Convert to grayscale for analysis
    try:
        if len(image_cv2.shape) == 3 and image_cv2.shape[2] >= 3: # Handle BGR or BGRA
             gray = cv2.cvtColor(image_cv2, cv2.COLOR_BGR2GRAY)
        elif len(image_cv2.shape) == 2:
             gray = image_cv2 # Already grayscale
        else:
             logger.warning(f"Unexpected image shape {image_cv2.shape} for page {page_num} of {doc_id}. Cannot analyze type.")
             return {"sharpness": 0.0, "contrast": 0.0}, "Error (Unsupported Format)"
    except cv2.error as e:
         logger.error(f"Error converting page {page_num} of {doc_id} to grayscale for type analysis: {e}")
         return {"sharpness": 0.0, "contrast": 0.0}, "Error (Conversion Failed)"

    # --- Calculate Features ---
    sharpness = calculate_sharpness(gray)
    contrast_std = calculate_contrast_stddev(gray)

    features = {
        "sharpness": round(sharpness, 2),
        "contrast": round(contrast_std, 2),
    }

    # --- Decision Logic ---
    is_likely_photocopy = False
    decision_reason = "N/A" # Keep for internal logic if needed

    # Prioritize sharpness
    if sharpness < sharpness_threshold:
        is_likely_photocopy = True
        decision_reason = f"Low sharpness ({sharpness:.2f} < {sharpness_threshold})"
    # Optional: Add contrast check (e.g., if sharpness is borderline)
    # elif sharpness < (sharpness_threshold * 1.1) and contrast_std < contrast_threshold:
    #     is_likely_photocopy = True
    #     decision_reason = f"Borderline sharpness and Low contrast"
    else: # Default to original if sharp enough
         is_likely_photocopy = False
         decision_reason = f"Sufficient sharpness ({sharpness:.2f} >= {sharpness_threshold})"

    result_type = "Photocopy of Scan" if is_likely_photocopy else "Original Scan"

    logger.debug(f"Type Analysis - Page {page_num} ({doc_id}): Sharp={sharpness:.2f}, Contr={contrast_std:.2f} -> Likely {result_type}")

    return features, result_type


# --- Similarity Comparison Logic (Functions largely unchanged, ensure logging) ---

def preprocess_image(img_path):
    """Load image and apply enhanced document-specific preprocessing"""
    try:
        # Read image using OpenCV - handles various formats robustly
        img = cv2.imread(img_path)
        if img is None:
            logger.error(f"Failed to load image: {img_path}")
            raise ValueError(f"Could not read image file: {img_path}")

        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # Adaptive thresholding with noise reduction
        # GaussianBlur is generally faster and often sufficient for noise removal before thresholding
        # blurred = cv2.bilateralFilter(gray, 9, 75, 75) # Can be slow
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)

        # Adjust adaptive thresholding parameters if needed (block size, C value)
        thresh = cv2.adaptiveThreshold(blurred, 255,
                                      cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                      cv2.THRESH_BINARY_INV, 15, 5) # Slightly larger block, adjust C

        # Morphological cleanup (Closing followed by Opening - "Close-Open")
        # Use a slightly larger kernel for document noise
        kernel = np.ones((2,2), np.uint8)
        # Closing first to fill small gaps/holes in text
        closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel, iterations=1)
        # Opening then to remove small speckles/noise
        cleaned = cv2.morphologyEx(closed, cv2.MORPH_OPEN, kernel, iterations=1)

        return cleaned # Return the binary (black & white) preprocessed image

    except cv2.error as e:
        logger.error(f"OpenCV error during preprocessing {img_path}: {e}")
        raise ValueError(f"OpenCV error processing image: {e}")
    except Exception as e:
        logger.error(f"Unexpected error during preprocessing {img_path}: {e}")
        raise

def document_sift_alignment(base_img, img_to_align):
    """Document-optimized alignment using SIFT/ORB features (expects grayscale)"""
    try:
        # Ensure images are 8-bit single-channel (grayscale)
        if len(base_img.shape) == 3: base_img = cv2.cvtColor(base_img, cv2.COLOR_BGR2GRAY)
        if len(img_to_align.shape) == 3: img_to_align = cv2.cvtColor(img_to_align, cv2.COLOR_BGR2GRAY)

        # --- Use ORB as a SIFT alternative (Patent-free) ---
        orb = cv2.ORB_create(nfeatures=1500) # Increase features for documents
        kp1, des1 = orb.detectAndCompute(base_img, None)
        kp2, des2 = orb.detectAndCompute(img_to_align, None)

        if des1 is None or des2 is None or len(kp1) < 10 or len(kp2) < 10:
            logger.warning("Not enough keypoints found for ORB alignment.")
            return img_to_align # Return unaligned image

        # --- Use BFMatcher (Brute-Force Matcher) with Hamming distance for ORB ---
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True) # crossCheck=True provides good matches
        matches = bf.match(des1, des2)

        # Sort matches by distance (best first)
        matches = sorted(matches, key=lambda x: x.distance)

        # Select top N matches (e.g., top 50 or 10%)
        num_good_matches = min(len(matches), 50) # Use a fixed number or percentage
        good_matches = matches[:num_good_matches]

        MIN_MATCH_COUNT = 10 # Minimum required matches for homography
        if len(good_matches) >= MIN_MATCH_COUNT:
            src_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
            dst_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)

            # Find Homography using RANSAC
            M, mask = cv2.findHomography(dst_pts, src_pts, cv2.RANSAC, 5.0)

            if M is None or mask is None: # Check if findHomography failed
                logger.warning("Homography matrix could not be computed with RANSAC.")
                return img_to_align # Return unaligned if homography fails

            # Check number of inliers from RANSAC mask
            inlier_count = np.sum(mask)
            logger.debug(f"Homography Inliers: {inlier_count} / {len(good_matches)}")
            if inlier_count < MIN_MATCH_COUNT: # Ensure enough inliers support the homography
                 logger.warning(f"Not enough inliers ({inlier_count}) for reliable homography.")
                 return img_to_align

            # Warp image
            h, w = base_img.shape[:2]
            aligned_img = cv2.warpPerspective(img_to_align, M, (w, h),
                                             flags=cv2.INTER_LINEAR, # Use linear interpolation
                                             borderMode=cv2.BORDER_CONSTANT,
                                             borderValue=(255)) # White border for grayscale
            logger.debug("Alignment successful.")
            return aligned_img
        else:
            logger.warning(f"Not enough good ORB matches found ({len(good_matches)}/{MIN_MATCH_COUNT}) for alignment.")
            return img_to_align # Return unaligned

    except cv2.error as e:
        logger.error(f"OpenCV error during ORB alignment: {e}")
        return img_to_align # Fallback
    except Exception as e:
        logger.error(f"Unexpected error during ORB alignment: {e}")
        return img_to_align # Fallback


def calculate_document_similarity(orig_img, scan_img, orig_raw_img_path, scan_raw_img_path):
    """Optimized document similarity calculation (expects preprocessed binary images + raw paths for OCR)"""
    # Ensure images have the same dimensions for SSIM
    h, w = orig_img.shape
    try:
        scan_img_resized = cv2.resize(scan_img, (w, h), interpolation=cv2.INTER_NEAREST) # Use NEAREST for binary
    except cv2.error as e:
        logger.error(f"Error resizing scan image for SSIM: {e}. Skipping similarity calc.")
        return 0.0, 0.0, 0.0, 0.0 # Return zero scores

    # 1. Structural similarity (on preprocessed & resized images)
    ssim_score = 0.0
    try:
        # For binary images, data_range is 255. Ensure win_size is appropriate.
        win_size = min(7, h, w) # Window size must be odd and <= image dimensions
        if win_size % 2 == 0: win_size -= 1 # Ensure odd
        if win_size >= 3:
            ssim_score, _ = ssim(orig_img, scan_img_resized, data_range=255, win_size=win_size, full=True)
            ssim_score = max(0, min(1, ssim_score)) # Clamp between 0 and 1
        else:
             logger.warning("Image too small for SSIM calculation.")

    except ValueError as e:
         logger.warning(f"SSIM calculation failed: {e}. Setting score to 0.")
         ssim_score = 0.0
    except Exception as e:
         logger.error(f"Unexpected error during SSIM: {e}")
         ssim_score = 0.0

    # 2. OCR-based text similarity (Run OCR on ORIGINAL *RAW* images for better quality)
    text_score = 0.0
    orig_text_clean = ""
    scan_text_clean = ""
    try:
        # Use PSM 3 (Auto page segmentation) or 6 (Assume single block) - 11 can be noisy
        config = r'--oem 3 --psm 3 -l eng' # Default to English, auto segmentation
        # Run OCR in parallel if possible (though Tesseract calls might block here)
        # Consider running these OCR calls also in run_blocking_io if they are slow
        orig_text = pytesseract.image_to_string(orig_raw_img_path, config=config)
        scan_text = pytesseract.image_to_string(scan_raw_img_path, config=config)

        # Basic text cleaning
        orig_text_clean = ' '.join(orig_text.split()).strip()
        scan_text_clean = ' '.join(scan_text.split()).strip()

        if len(orig_text_clean) > 0 or len(scan_text_clean) > 0:
            # Levenshtein ratio is good for overall similarity
            text_score = levenshtein_ratio(orig_text_clean, scan_text_clean)
        elif len(orig_text_clean) == 0 and len(scan_text_clean) == 0:
             text_score = 1.0 # Both empty, identical text content (none)
        else:
            text_score = 0.0 # One empty, one not

    except pytesseract.TesseractError as e:
        logger.error(f"Pytesseract OCR error: {e}")
        text_score = 0.0
    except FileNotFoundError as e:
        logger.error(f"OCR Error: Image file not found: {e}")
        text_score = 0.0
    except Exception as e:
        logger.error(f"Error during text extraction or comparison: {e}")
        text_score = 0.0

    # 3. Layout-based similarity using ORB keypoint matching (on PREPROCESSED images)
    layout_score = 0.0
    try:
        # Reuse ORB detector
        orb = cv2.ORB_create(nfeatures=500) # Fewer features might suffice for layout check
        kp1, des1 = orb.detectAndCompute(orig_img, None) # Use preprocessed images
        kp2, des2 = orb.detectAndCompute(scan_img_resized, None) # Use preprocessed images

        if des1 is not None and des2 is not None and len(des1) > 0 and len(des2) > 0:
            # Use BFMatcher with Hamming distance
            bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False) # crossCheck=False for knnMatch
            matches = bf.knnMatch(des1, des2, k=2)

            # Apply Lowe's ratio test
            good_matches = []
            for m, n in matches:
                if m.distance < 0.75 * n.distance:
                    good_matches.append(m)

            # Layout score based on the ratio of good matches to potential matches
            # Use the minimum number of keypoints as the denominator base
            min_kps = min(len(kp1), len(kp2))
            if min_kps > 0:
                layout_score = len(good_matches) / float(min_kps)
                layout_score = min(1.0, layout_score) # Cap at 1.0
            else:
                layout_score = 0.0

        elif (des1 is None or len(des1) == 0) and (des2 is None or len(des2) == 0):
            layout_score = 1.0 # Both have no keypoints, layout could be considered similar (e.g., blank pages)
        else:
            layout_score = 0.0 # One has keypoints, the other doesn't - layout differs

    except cv2.error as e:
        logger.error(f"OpenCV error during ORB for layout similarity: {e}")
        layout_score = 0.0
    except Exception as e:
        logger.error(f"Unexpected error during layout similarity: {e}")
        layout_score = 0.0


    # Weighted combination (Adjust weights as needed)
    w_ssim = 0.25 # Visual structure
    w_text = 0.50 # Content is often most important
    w_layout = 0.25 # Keypoint-based layout
    combined_score = (
        w_ssim * ssim_score +
        w_text * text_score +
        w_layout * layout_score
    )

    logger.info(f"Similarity Scores -> SSIM: {ssim_score:.3f}, Text: {text_score:.3f} (Orig chars: {len(orig_text_clean)}, Scan chars: {len(scan_text_clean)}), Layout: {layout_score:.3f} | Combined: {combined_score:.3f}")

    return combined_score, ssim_score, text_score, layout_score


# --- Async Helper ---
async def run_blocking_io(func, *args, **kwargs):
    """Runs blocking function in a separate thread."""
    return await asyncio.to_thread(func, *args, **kwargs)


# --- Main Comparison Task (Modified) ---
async def compare_documents_task(
    original_pdf_path: Path,
    scanned_pdf_path: Path,
    similarity_threshold: float,
    sharpness_threshold: float, # New threshold
    contrast_threshold: float  # New threshold
):
    """Async wrapper for the main comparison logic including type analysis"""
    results = {
        "overall_similarity_match": False, # Renamed for clarity
        "message": "",
        "page_comparisons": [],
        "page_count_match": False,
        "original_pages": 0,
        "scanned_pages": 0,
        "original_doc_type_analysis": {"summary": "Not Analyzed", "pages": {}}, # New section
        "scanned_doc_type_analysis": {"summary": "Not Analyzed", "pages": {}}, # New section
        "error": None
    }
    temp_dirs = []
    original_image_paths = []
    scanned_image_paths = []

    try:
        logger.info(f"Starting comparison: {original_pdf_path.name} vs {scanned_pdf_path.name}")
        logger.info(f"Thresholds -> Similarity: {similarity_threshold}, Sharpness: {sharpness_threshold}, Contrast: {contrast_threshold}")

        # --- Get PDF Info (Page Count) Efficiently ---
        try:
             orig_info = await run_blocking_io(pdfinfo_from_path, original_pdf_path, userpw=None, poppler_path=None)
             scan_info = await run_blocking_io(pdfinfo_from_path, scanned_pdf_path, userpw=None, poppler_path=None)
             results["original_pages"] = orig_info.get('Pages', 0)
             results["scanned_pages"] = scan_info.get('Pages', 0)
             logger.info(f"Page counts: Original={results['original_pages']}, Scanned={results['scanned_pages']}")
        except Exception as e:
             logger.warning(f"Could not get page count via pdfinfo: {e}. Will rely on pdf2image conversion count.")
             # Proceed, counts will be updated after conversion

        # --- PDF to Image Conversion ---
        logger.info("Converting PDFs to images...")
        try:
            orig_img_dir = UPLOAD_DIR / f"orig_{uuid.uuid4()}"
            scan_img_dir = UPLOAD_DIR / f"scan_{uuid.uuid4()}"
            orig_img_dir.mkdir(exist_ok=True)
            scan_img_dir.mkdir(exist_ok=True)
            temp_dirs.extend([orig_img_dir, scan_img_dir])

            # Run conversions concurrently if possible
            task_orig = run_blocking_io(
                convert_from_path,
                original_pdf_path,
                dpi=300, output_folder=orig_img_dir, fmt='png', thread_count=4
            )
            task_scan = run_blocking_io(
                convert_from_path,
                scanned_pdf_path,
                dpi=300, output_folder=scan_img_dir, fmt='png', thread_count=4
            )
            # Wait for both conversions to complete
            await asyncio.gather(task_orig, task_scan)

            # Get sorted paths after conversion
            original_image_paths = sorted([p for p in orig_img_dir.glob('*.png')], key=lambda x: int(x.stem.split('-')[-1]))
            scanned_image_paths = sorted([p for p in scan_img_dir.glob('*.png')], key=lambda x: int(x.stem.split('-')[-1]))

            # Update page counts based on actual files created
            results["original_pages"] = len(original_image_paths)
            results["scanned_pages"] = len(scanned_image_paths)
            logger.info(f"PDFs converted: {results['original_pages']} original pages, {results['scanned_pages']} scanned pages.")

        except Exception as e:
            logger.exception("Error during PDF to image conversion")
            results["error"] = f"PDF Conversion Error: {e}"
            results["message"] = "Failed to convert one or both PDFs to images."
            # Cleanup in finally block
            return results

        # --- Page Count Check ---
        results["page_count_match"] = (results["original_pages"] == results["scanned_pages"])
        if not results["page_count_match"]:
            results["message"] = f"Page count mismatch: Original ({results['original_pages']}), Scanned ({results['scanned_pages']}). Comparing common pages."
        else:
            results["message"] = "Page counts match."

        min_pages = min(results["original_pages"], results["scanned_pages"])
        if min_pages == 0:
             results["message"] += " No pages found to compare."
             results["overall_similarity_match"] = (results["original_pages"] == 0 and results["scanned_pages"] == 0)
             # Cleanup in finally block
             return results

        # --- Per-Page Comparison ---
        all_similarity_match = True
        orig_photocopy_votes = 0
        scan_photocopy_votes = 0
        analyzed_type_pages = 0 # Count pages successfully analyzed for type

        for i in range(min_pages):
            page_num = i + 1
            logger.info(f"--- Processing Page {page_num} ---")
            page_result = {
                "page": page_num,
                "similarity_match": False, # Renamed
                "similarity_score": 0.0,
                "ssim_score": 0.0,
                "text_score": 0.0,
                "layout_score": 0.0,
                "original_page_type": "Not Analyzed", # New field
                "original_page_features": {},         # New field
                "scanned_page_type": "Not Analyzed",   # New field
                "scanned_page_features": {},           # New field
                "error": None
            }

            orig_raw_img_path = original_image_paths[i]
            scan_raw_img_path = scanned_image_paths[i]
            orig_raw_img_path_str = str(orig_raw_img_path)
            scan_raw_img_path_str = str(scan_raw_img_path)

            try:
                # --- 1. Load Original Color Images for Type Analysis ---
                # Use run_blocking_io for cv2.imread
                img_orig_color = await run_blocking_io(cv2.imread, orig_raw_img_path_str)
                img_scan_color = await run_blocking_io(cv2.imread, scan_raw_img_path_str)

                if img_orig_color is None or img_scan_color is None:
                    logger.error(f"Page {page_num}: Failed to load one or both raw images.")
                    page_result["error"] = "Image Loading Error"
                    all_similarity_match = False # Mark as mismatch if error
                    results["page_comparisons"].append(page_result)
                    continue # Skip to next page

                # --- 2. Analyze Page Type (Original Scan vs Photocopy) ---
                # Run analysis concurrently for both pages
                task_analyze_orig = run_blocking_io(
                    analyze_page_image_type,
                    img_orig_color, page_num, f"OrigDoc({original_pdf_path.name})",
                    sharpness_threshold, contrast_threshold
                )
                task_analyze_scan = run_blocking_io(
                    analyze_page_image_type,
                    img_scan_color, page_num, f"ScanDoc({scanned_pdf_path.name})",
                    sharpness_threshold, contrast_threshold
                )
                # Wait for analysis results
                orig_features, orig_type = await task_analyze_orig
                scan_features, scan_type = await task_analyze_scan

                # Store type analysis results
                page_result["original_page_type"] = orig_type
                page_result["original_page_features"] = orig_features
                page_result["scanned_page_type"] = scan_type
                page_result["scanned_page_features"] = scan_features

                # Update overall type analysis votes
                if "Error" not in orig_type:
                    analyzed_type_pages += 0.5
                    if orig_type == "Photocopy of Scan":
                        orig_photocopy_votes += 1
                    # Store page-specific type analysis
                    results["original_doc_type_analysis"]["pages"][page_num] = {"type": orig_type, "features": orig_features}


                if "Error" not in scan_type:
                    analyzed_type_pages += 0.5
                    if scan_type == "Photocopy of Scan":
                        scan_photocopy_votes += 1
                    # Store page-specific type analysis
                    results["scanned_doc_type_analysis"]["pages"][page_num] = {"type": scan_type, "features": scan_features}


                # --- 3. Preprocess for Similarity ---
                task_preprocess_orig = run_blocking_io(preprocess_image, orig_raw_img_path_str)
                task_preprocess_scan = run_blocking_io(preprocess_image, scan_raw_img_path_str)
                orig_preprocessed, scan_preprocessed = await asyncio.gather(task_preprocess_orig, task_preprocess_scan)

                if orig_preprocessed is None or scan_preprocessed is None:
                    logger.error(f"Page {page_num}: Failed to preprocess one or both images.")
                    page_result["error"] = "Preprocessing Error"
                    all_similarity_match = False
                    results["page_comparisons"].append(page_result)
                    continue

                # --- 4. Align Preprocessed Image ---
                # Alignment helps similarity comparison, especially SSIM and layout
                aligned_scan_preprocessed = await run_blocking_io(
                    document_sift_alignment, # Use ORB internally now
                    orig_preprocessed,
                    scan_preprocessed
                )
                if aligned_scan_preprocessed is None: # Check if alignment returned None (error)
                     logger.warning(f"Page {page_num}: Alignment failed, proceeding with unaligned image for similarity.")
                     aligned_scan_preprocessed = scan_preprocessed # Use unaligned as fallback

                # --- 5. Calculate Similarity ---
                # Pass preprocessed images for SSIM/Layout, raw paths for OCR
                combined_score, ssim_score, text_score, layout_score = await run_blocking_io(
                    calculate_document_similarity,
                    orig_preprocessed,
                    aligned_scan_preprocessed, # Use aligned image here
                    orig_raw_img_path_str,     # Pass raw path for OCR
                    scan_raw_img_path_str      # Pass raw path for OCR
                )

                page_result["similarity_score"] = float(round(combined_score, 3))
                page_result["ssim_score"] = float(round(ssim_score, 3))
                page_result["text_score"] = float(round(text_score, 3))
                page_result["layout_score"] = float(round(layout_score, 3))

                if combined_score >= similarity_threshold:
                    page_result["similarity_match"] = True
                    logger.info(f"✅ Page {page_num} Similarity Match (Score: {combined_score:.3f})")
                else:
                    page_result["similarity_match"] = False
                    all_similarity_match = False # If any page mismatches similarity, overall is mismatch
                    logger.warning(f"❌ Page {page_num} Similarity Mismatch (Score: {combined_score:.3f})")

            except Exception as e:
                logger.exception(f"Error processing page {page_num}")
                page_result["error"] = f"Page Processing Error: {e}"
                all_similarity_match = False # Consider errored page a mismatch

            results["page_comparisons"].append(page_result)

        # --- Determine Overall Similarity Match ---
        if all_similarity_match and results["page_count_match"]:
            results["overall_similarity_match"] = True
            results["message"] = "Documents match based on content similarity and page count."
            logger.info("Overall similarity result: MATCH")
        elif not results["page_count_match"]:
             results["overall_similarity_match"] = False
             # Message already set for page count mismatch
             logger.warning("Overall similarity result: MISMATCH (Page Count)")
        else: # Page counts matched, but content didn't on at least one page
            results["overall_similarity_match"] = False
            results["message"] = "Documents mismatch: Content difference found on one or more pages."
            logger.warning("Overall similarity result: MISMATCH (Content)")

        # --- Summarize Document Type Analysis ---
        analyzed_type_pages_int = int(analyzed_type_pages) # For clearer reporting
        if analyzed_type_pages_int > 0:
             orig_photocopy_percent = (orig_photocopy_votes / analyzed_type_pages_int) * 100
             scan_photocopy_percent = (scan_photocopy_votes / analyzed_type_pages_int) * 100

             results["original_doc_type_analysis"]["summary"] = (
                 f"Likely Photocopy ({orig_photocopy_votes}/{analyzed_type_pages_int} pages = {orig_photocopy_percent:.1f}%)"
                 if orig_photocopy_percent > 50.0 # Simple majority rule
                 else f"Likely Original Scan ({analyzed_type_pages_int - orig_photocopy_votes}/{analyzed_type_pages_int} pages)"
             )
             results["scanned_doc_type_analysis"]["summary"] = (
                 f"Likely Photocopy ({scan_photocopy_votes}/{analyzed_type_pages_int} pages = {scan_photocopy_percent:.1f}%)"
                 if scan_photocopy_percent > 50.0
                 else f"Likely Original Scan ({analyzed_type_pages_int - scan_photocopy_votes}/{analyzed_type_pages_int} pages)"
             )
             logger.info(f"Original Doc Type Analysis: {results['original_doc_type_analysis']['summary']}")
             logger.info(f"Scanned Doc Type Analysis: {results['scanned_doc_type_analysis']['summary']}")
        else:
             results["original_doc_type_analysis"]["summary"] = "Type analysis could not be performed."
             results["scanned_doc_type_analysis"]["summary"] = "Type analysis could not be performed."


    except Exception as e:
        logger.exception("An unexpected error occurred during the comparison task.")
        results["error"] = f"Unexpected Server Error: {e}"
        results["message"] = "An internal error occurred during comparison."
        results["overall_similarity_match"] = False

    finally:
        # --- Cleanup ---
        logger.info("Cleaning up temporary files...")
        # Remove the originally uploaded PDFs first
        for pdf_path in [original_pdf_path, scanned_pdf_path]:
            try:
                if pdf_path and pdf_path.exists():
                   await run_blocking_io(pdf_path.unlink)
                   logger.debug(f"Deleted uploaded PDF: {pdf_path.name}")
            except Exception as e: # Catch broader exceptions during cleanup
                logger.error(f"Error deleting uploaded PDF {pdf_path}: {e}")

        # Remove temporary image directories
        for temp_dir in temp_dirs:
            try:
                if temp_dir and temp_dir.exists() and temp_dir.is_dir():
                    await run_blocking_io(shutil.rmtree, temp_dir)
                    logger.debug(f"Deleted temp dir: {temp_dir.name}")
            except Exception as e:
                logger.error(f"Error deleting temporary directory {temp_dir}: {e}")
        logger.info("Cleanup complete.")

    return results


# --- API Endpoints ---

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    """Serves the main HTML page."""
    return templates.TemplateResponse("index.html", {
        "request": request,
        "default_similarity_threshold": DEFAULT_SIMILARITY_THRESHOLD,
        "default_sharpness_threshold": DEFAULT_SHARPNESS_THRESHOLD
        })


@app.post("/compare", response_class=JSONResponse)
async def compare_pdf_files(
    request: Request,
    original_pdf: UploadFile = File(...),
    scanned_pdf: UploadFile = File(...),
    similarity_threshold: float = Form(DEFAULT_SIMILARITY_THRESHOLD), # Renamed Form field
    sharpness_threshold: float = Form(DEFAULT_SHARPNESS_THRESHOLD), # New Form field
    # contrast_threshold: float = Form(DEFAULT_CONTRAST_THRESHOLD) # Contrast currently secondary, maybe omit from UI
):
    """
    Receives two PDF files, compares them for similarity, analyzes their type (scan vs photocopy),
    and returns combined results.
    """
    # --- Input Validation ---
    if not original_pdf.filename or not original_pdf.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Original file must be a PDF and have a filename.")
    if not scanned_pdf.filename or not scanned_pdf.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Scanned file must be a PDF and have a filename.")

    if not (0.0 <= similarity_threshold <= 1.0):
         raise HTTPException(status_code=400, detail="Similarity threshold must be between 0.0 and 1.0.")
    if not (0.0 < sharpness_threshold): # Sharpness should be positive
         raise HTTPException(status_code=400, detail="Sharpness threshold must be a positive value.")

    # --- Save Uploaded Files Temporarily ---
    original_pdf_path = UPLOAD_DIR / f"orig_{uuid.uuid4()}_{original_pdf.filename}"
    scanned_pdf_path = UPLOAD_DIR / f"scan_{uuid.uuid4()}_{scanned_pdf.filename}"
    saved_paths = [] # Keep track of successfully saved files for cleanup on error

    try:
        async with aiofiles.open(original_pdf_path, 'wb') as out_file:
            while content := await original_pdf.read(1024 * 1024): await out_file.write(content)
        saved_paths.append(original_pdf_path)
        logger.info(f"Original file saved: {original_pdf_path}")

        async with aiofiles.open(scanned_pdf_path, 'wb') as out_file:
            while content := await scanned_pdf.read(1024 * 1024): await out_file.write(content)
        saved_paths.append(scanned_pdf_path)
        logger.info(f"Scanned file saved: {scanned_pdf_path}")

    except Exception as e:
        logger.exception("Failed to save uploaded files.")
        # Clean up any files that were saved before the error
        for p in saved_paths:
            if p.exists(): p.unlink(missing_ok=True)
        raise HTTPException(status_code=500, detail=f"Failed to save uploaded files: {e}")
    finally:
        # Ensure file handles are closed even if errors occur during read/write
        await original_pdf.close()
        await scanned_pdf.close()


    # --- Run Comparison Logic ---
    # Pass all thresholds to the task
    # Using DEFAULT_CONTRAST_THRESHOLD internally as it's not exposed in UI for now
    comparison_results = await compare_documents_task(
        original_pdf_path,
        scanned_pdf_path,
        similarity_threshold,
        sharpness_threshold,
        DEFAULT_CONTRAST_THRESHOLD # Pass the internal default contrast threshold
    )

    # --- Return Results ---
    # Cleanup is handled within compare_documents_task's finally block now
    if comparison_results.get("error"):
        # Distinguish client errors (like bad PDF) from server errors
        status_code = 400 if "PDF Conversion Error" in comparison_results["error"] else 500
        # Don't raise HTTPException here if cleanup already happened in the task
        # Return a JSON response indicating the error
        return JSONResponse(
            status_code=status_code,
            content={
                "detail": comparison_results["message"], # User-friendly message
                "error_details": comparison_results["error"] # More technical details (optional)
            }
        )

    logger.info(f"Comparison finished for {original_pdf.filename} vs {scanned_pdf.filename}. Sending results.")
    # Ensure all results are JSON serializable (floats, ints, strings, bools, lists, dicts)
    # The results dict structure should already be compliant
    return JSONResponse(content=comparison_results)


# --- Run the app (for local development) ---
if __name__ == "__main__":
    import uvicorn
    # Check if Tesseract is configured before starting
    if not pytesseract.pytesseract.tesseract_cmd or not Path(pytesseract.pytesseract.tesseract_cmd).exists():
         logger.critical("Tesseract is not configured or not found. The application may not function correctly.")
         # Optionally, exit here:
         # import sys
         # sys.exit("Tesseract configuration error.")

    logger.info("Starting Uvicorn server...")
    # Consider adjusting workers based on CPU cores if deploying
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True, workers=1)