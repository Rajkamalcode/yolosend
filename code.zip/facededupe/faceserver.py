import os
import io
import re
import time
import base64
import numpy as np
import cv2
from PIL import Image
from datetime import datetime
from flask import Flask, request, jsonify, render_template, send_from_directory, Response
from flask_cors import CORS
from insightface.app import FaceAnalysis
from pymongo import MongoClient
import logging
from bson import ObjectId
import json
from workflow import FaceDeduplicationSystem
from search import FaceSearchSystem
from flask import redirect
import uuid
from dms import upload_to_dms, get_image_from_dms, delete_from_dms

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
# More permissive CORS for debugging
CORS(app, resources={r"/*": {"origins": "*"}})

# Configuration for search system
CONFIG = {
    "MILVUS_HOST": "10.9.52.21",
    "MILVUS_PORT": "19530",
    "COLLECTION_NAME": "faces_test",
    "USE_GPU": True,
    "DETECTION_THRESHOLD": 0.4,
    "ANGULAR_MARGIN": 0.1,
    "FACE_DETECTION_THRESHOLD": 0.5,
    "MONGO_URI": "mongodb://bridgedevwrite:BridgedevWrite890@10.9.50.43:10050/",
    "MONGO_DB": "chola_face_db",
    "MONGO_COLLECTION": "face_images",
    "DUPLICATE_THRESHOLD": 0.65,  # Add this line
    "DUPLICATE_RADIUS": 0.4       # Add this line if needed
}

# Initialize face model
def init_face_model():
    """Initialize InsightFace model"""
    logger.info("Initializing face model")
    model_dir = os.path.expanduser("~/.insightface/models/buffalo_m")
    
    face_app = FaceAnalysis(name='buffalo_m', model_dir=model_dir)
    # Use GPU if available, otherwise CPU
    ctx_id = 0  # Change to -1 for CPU
    face_app.prepare(ctx_id=ctx_id, det_size=(640, 640), det_thresh=0.5)
    logger.info("Face model initialized")
    return face_app

# Process image bytes and extract face embedding
def process_image(face_app, image_bytes):
    """Process image bytes and extract face embedding"""
    try:
        img = Image.open(io.BytesIO(image_bytes))
        img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        faces = face_app.get(img)
        if not faces:
            raise ValueError("No faces detected")
        return faces[0].normed_embedding
    except Exception as e:
        logger.error(f"Image processing failed: {str(e)}")
        return None

# Calculate similarity between two face embeddings
def calculate_similarity(emb1, emb2, margin=0.1):
    """Calculate similarity between two face embeddings with margin adjustment"""
    # Compute cosine similarity
    cosine_sim = np.dot(emb1, emb2)
    
    # Convert to angular distance
    angle = np.arccos(np.clip(cosine_sim, -1.0, 1.0))
    
    # Apply margin adjustment
    adjusted_angle = angle + margin
    
    # Convert back to similarity score
    final_score = np.cos(adjusted_angle)
    
    return float(cosine_sim)

# Initialize the face model
face_app = init_face_model()

# Initialize the search system
search_system = None
try:
    search_system = FaceSearchSystem(CONFIG)
    logger.info("Face Search System initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize Face Search System: {str(e)}")


@app.route('/compare', methods=['POST'])
def compare_faces():
    """Compare two face images and return similarity scores"""
    logger.info("Received /compare request")
    
    if 'image1' not in request.files or 'image2' not in request.files:
        logger.warning("Missing required images in request")
        return jsonify({"error": "Two images required"}), 400
    
    try:
        # Get image bytes
        logger.info("Reading image files from request")
        image1_bytes = request.files['image1'].read()
        image2_bytes = request.files['image2'].read()
        logger.info(f"Received image1: {len(image1_bytes)} bytes, image2: {len(image2_bytes)} bytes")
        
        # Process images
        logger.info("Processing image1")
        emb1 = process_image(face_app, image1_bytes)
        logger.info("Processing image2")
        emb2 = process_image(face_app, image2_bytes)
        
        if emb1 is None or emb2 is None:
            logger.warning("Face detection failed")
            return jsonify({"error": "Face detection failed on one or both images"}), 400
        
        # Calculate similarity
        margin = float(request.form.get('margin', 0.1))
        logger.info(f"Calculating similarity with margin {margin}")
        similarity = calculate_similarity(emb1, emb2, margin)
        logger.info(f"Similarity results: {similarity}")
        
        return jsonify({
            "status": "success",
            "similarity": similarity
        })
    
    except Exception as e:
        logger.error(f"Comparison failed: {str(e)}")
        return jsonify({"error": str(e)}), 500
@app.route('/compare_dms', methods=['POST'])
def compare_dms_images():
    """Compare face images using DMS IDs"""
    logger.info("Received /compare_dms request")
    
    data = request.json
    if not data or 'primary_dms_id' not in data:
        logger.warning("Missing primary DMS ID in request")
        return jsonify({"error": "Primary DMS ID required"}), 400
    
    try:
        # Get primary image (usually liveness)
        primary_dms_id = data['primary_dms_id']
        logger.info(f"Primary DMS ID: {primary_dms_id}")
        
        # Get comparison images
        comparison_dms_ids = data.get('comparison_dms_ids', [])
        logger.info(f"Comparison DMS IDs: {comparison_dms_ids}")
        
        if not comparison_dms_ids:
            logger.warning("No comparison DMS IDs provided")
            return jsonify({"error": "At least one comparison DMS ID required"}), 400
        
        # Fetch primary image from DMS
        primary_image_bytes = get_image_from_dms(primary_dms_id)
        if not primary_image_bytes:
            logger.error(f"Failed to retrieve primary image from DMS: {primary_dms_id}")
            return jsonify({"error": "Primary image not found in DMS"}), 404
        
        # Process primary image
        primary_embedding = process_image(face_app, primary_image_bytes)
        if primary_embedding is None:
            logger.error("Face detection failed on primary image")
            return jsonify({"error": "Face detection failed on primary image"}), 400
        
        # Process each comparison image and calculate similarity
        results = []
        for dms_id in comparison_dms_ids:
            try:
                # Fetch comparison image from DMS
                comparison_image_bytes = get_image_from_dms(dms_id)
                if not comparison_image_bytes:
                    logger.warning(f"Failed to retrieve comparison image from DMS: {dms_id}")
                    results.append({
                        "dms_id": dms_id,
                        "success": False,
                        "error": "Image not found in DMS"
                    })
                    continue
                
                # Process comparison image
                comparison_embedding = process_image(face_app, comparison_image_bytes)
                if comparison_embedding is None:
                    logger.warning(f"Face detection failed on comparison image: {dms_id}")
                    results.append({
                        "dms_id": dms_id,
                        "success": False,
                        "error": "Face detection failed"
                    })
                    continue
                
                # Calculate similarity
                margin = float(data.get('margin', 0.1))
                similarity = calculate_similarity(primary_embedding, comparison_embedding, margin)
                
                # Add result
                results.append({
                    "dms_id": dms_id,
                    "success": True,
                    "similarity": similarity,
                    "match_status": "MATCH" if similarity >= 0.3 else "NO MATCH"
                })
                
            except Exception as e:
                logger.error(f"Error processing comparison image {dms_id}: {str(e)}")
                results.append({
                    "dms_id": dms_id,
                    "success": False,
                    "error": str(e)
                })
        
        return jsonify({
            "status": "success",
            "primary_dms_id": primary_dms_id,
            "results": results
        })
    
    except Exception as e:
        logger.error(f"Comparison failed: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Add this class to handle ObjectId serialization
class JSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        return super(JSONEncoder, self).default(obj)

@app.route('/search', methods=['POST'])
def search_database():
    """Search for a face in the database"""
    logger.info("Received /search request")
    
    # Check if we have either an image file or a DMS ID
    if 'image' not in request.files and ('dms_id' not in request.form and 'dms_id' not in request.json):
        logger.warning("Missing required image or DMS ID in request")
        return jsonify({"error": "Either image file or DMS ID is required"}), 400
    
    if search_system is None:
        logger.error("Search system not initialized")
        return jsonify({"error": "Search system not available"}), 500
    
    try:
        # Get image bytes either from uploaded file or DMS
        image_bytes = None
        
        # Check if we have a DMS ID in form data or JSON
        dms_id = None
        if request.form and 'dms_id' in request.form:
            dms_id = request.form.get('dms_id')
        elif request.json and 'dms_id' in request.json:
            dms_id = request.json.get('dms_id')
        
        if dms_id:
            # Get image from DMS
            logger.info(f"Getting image from DMS with ID: {dms_id}")
            image_bytes = get_image_from_dms(dms_id)
            if not image_bytes:
                logger.error(f"Failed to retrieve image from DMS with ID: {dms_id}")
                return jsonify({"error": f"Image not found in DMS with ID: {dms_id}"}), 404
            logger.info(f"Retrieved image from DMS: {len(image_bytes)} bytes")
        else:
            # Get image from uploaded file
            logger.info("Reading image file from request")
            image_bytes = request.files['image'].read()
            logger.info(f"Received image: {len(image_bytes)} bytes")
        
        # Set threshold from request or use default
        threshold = 0.6  # Default threshold
        
        if request.form and 'threshold' in request.form:
            threshold = float(request.form.get('threshold'))
        elif request.json and 'threshold' in request.json:
            threshold = float(request.json.get('threshold'))
        
        # Perform search
        logger.info(f"Searching database with threshold {threshold}")
        results, metrics = search_system.search(image_bytes, threshold)
        
        # Connect to MongoDB to fetch DMS IDs
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Add image data for each result
        for result in results:
            try:
                # Get the ucic_id from the result
                ucic_id = result.get('ucic_id')
                
                if ucic_id:
                    # Look up the document in MongoDB using ucic_id
                    user_doc = mongo_db['users'].find_one({'ucic_id': ucic_id})
                    
                    if user_doc and 'dms_id' in user_doc:
                        # Add the dms_id to the result
                        result['dms_id'] = user_doc['dms_id']
                        logger.info(f"Added DMS ID {user_doc['dms_id']} for user {ucic_id}")
                    else:
                        logger.warning(f"No DMS ID found for user {ucic_id}")
            except Exception as img_err:
                logger.error(f"Error processing result {result}: {str(img_err)}")

        # Determine message based on results
        message = "No matches found."
        if results:
            # Check if any potential matches
            potential_matches = [r for r in results if r.get('match_type') == 'potential']
            if potential_matches:
                message = "Potential match found. Further scrutiny required."
            else:
                message = "Confident match found."
        
        # Format response
        response = {
            "status": "success",
            "message": message,
            "results": results,
            "metrics": {
                "total_time": metrics.get('total_time', 0),
                "processing_time": metrics.get('processing_time', 0),
                "search_time": metrics.get('search_time', 0),
                "mongo_time": metrics.get('mongo_time', 0),
                "candidates_found": metrics.get('candidates_found', 0),
                "verified_matches": metrics.get('verified_matches', 0),
                "metadata_retrieved": metrics.get('metadata_retrieved', 0)
            },
            "system_metrics": search_system.get_system_metrics()
        }
        
        # If search was done using DMS ID, include it in the response
        if dms_id:
            response["dms_id"] = dms_id
        
        logger.info(f"Search completed with {len(results)} results. Message: {message}")
        # Use the custom JSON encoder
        return app.response_class(
            response=json.dumps(response, cls=JSONEncoder),
            status=200,
            mimetype='application/json'
        )
    
    except Exception as e:
        logger.error(f"Search failed: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Add a new endpoint to serve images from DMS
@app.route('/get_dms_image/<dms_id>', methods=['GET'])
def get_dms_image(dms_id):
    """Serve an image from DMS by its ID"""
    try:
        # Get image from DMS
        image_bytes = get_image_from_dms(dms_id)
        
        if not image_bytes:
            return jsonify({"error": "Image not found in DMS"}), 404
        
        # Return the image with proper content type
        return Response(
            image_bytes,
            mimetype='image/jpeg',
            headers={
                'Content-Disposition': f'inline; filename=image_{dms_id}.jpg'
            }
        )
    
    except Exception as e:
        logger.error(f"Error retrieving image from DMS {dms_id}: {str(e)}")
        return jsonify({"error": str(e)}), 500

########################NEW CHANGES ##################################

@app.route('/create_application', methods=['POST'])
def create_application():
    """Create a new application with applicants"""
    try:
        # Get application data from request
        data = request.json
        
        if not data:
            return jsonify({"error": "Missing application data"}), 400
        
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Create collections if they don't exist
        if 'kyc_applications' not in mongo_db.list_collection_names():
            mongo_db.create_collection('kyc_applications')
        
        if 'kyc_applicants' not in mongo_db.list_collection_names():
            mongo_db.create_collection('kyc_applicants')
        
        # Generate application ID
        application_id = f"APP{int(time.time())}{uuid.uuid4().hex[:6]}"
        
        # Create application document
        application = {
            "application_id": application_id,
            "type": data.get('type', 'individual'),
            "loan_type": data.get('loanType', ''),
            "branch_code": data.get('branchCode', ''),
            "status": "pending",
            "created_at": datetime.now(),
            "applicant_ids": []
        }
        
        # Insert application
        mongo_db.kyc_applications.insert_one(application)
        
        # Process applicants
        applicant_ids = []
        applicants_data = []
        
        for applicant_data in data.get('applicants', []):
            # Generate applicant ID
            applicant_id = f"APL{int(time.time())}{uuid.uuid4().hex[:6]}"
            
            # Create applicant document
            applicant = {
                "applicant_id": applicant_id,
                "application_id": application_id,
                "name": applicant_data.get('name', ''),
                "phone": applicant_data.get('phone', ''),
                "address": applicant_data.get('address', ''),
                "is_primary_applicant": applicant_data.get('isPrimary', False),
                "kyc_status": "not_started",
                "kyc_steps": {
                    "liveness": False,
                    "dedupe": False
                },
                "created_at": datetime.now()
            }
            
            # Handle KYC images if present
            if 'kycImages' in applicant_data and isinstance(applicant_data['kycImages'], list):
                kyc_images = []
                for image in applicant_data['kycImages']:
                    if 'dmsId' in image and 'type' in image:
                        kyc_images.append({
                            "dms_id": image['dmsId'],
                            "type": image['type'],
                            "added_at": datetime.now()
                        })
                
                if kyc_images:
                    applicant["kyc_images"] = kyc_images
                    logger.info(f"Added {len(kyc_images)} KYC images for applicant {applicant_id}")
            
            # Insert applicant
            mongo_db.kyc_applicants.insert_one(applicant)
            applicant_ids.append(applicant_id)
            
            # Generate KYC link
            kyc_link = f"{request.host_url.rstrip('/')}/kyc?appId={application_id}&applicantId={applicant_id}"
            
            # Add to applicants data for response
            applicants_data.append({
                "applicant_id": applicant_id,
                "name": applicant.get('name'),
                "kyc_link": kyc_link,
                "is_primary_applicant": applicant.get('is_primary_applicant', False)
            })
        
        # Update application with applicant IDs
        mongo_db.kyc_applications.update_one(
            {"application_id": application_id},
            {"$set": {"applicant_ids": applicant_ids}}
        )
        
        logger.info(f"Created application {application_id} with {len(applicant_ids)} applicants")
        
        return jsonify({
            "success": True,
            "application_id": application_id,
            "type": application["type"],
            "loan_type": application["loan_type"],
            "applicants": applicants_data
        })
    
    except Exception as e:
        logger.error(f"Application creation failed: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/applications', methods=['GET'])
def get_applications():
    """Get all applications"""
    try:
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Get all applications
        applications = list(mongo_db.kyc_applications.find().sort("created_at", -1))
        
        # Process applications for response
        result = []
        for app in applications:
            # Count applicants
            applicant_count = len(app.get('applicant_ids', []))
            
            # Convert ObjectId to string and format dates
            app_data = {
                "application_id": app.get('application_id'),
                "type": app.get('type'),
                "loan_type": app.get('loan_type'),
                "branch_code": app.get('branch_code'),
                "status": app.get('status'),
                "applicant_count": applicant_count,
                "created_at": app.get('created_at').isoformat() if app.get('created_at') else None
            }
            result.append(app_data)
        
        return jsonify({
            "success": True,
            "applications": result
        })
        
    except Exception as e:
        logger.error(f"Failed to get applications: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/get_application/<application_id>', methods=['GET'])
def get_application(application_id):
    """Get application details by ID"""
    try:
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Find application
        application = mongo_db.kyc_applications.find_one({"application_id": application_id})
        
        if not application:
            return jsonify({"error": "Application not found", "success": False}), 404
        
        # Get applicants
        applicants = list(mongo_db.kyc_applicants.find({"application_id": application_id}))
        
        # Format applicants data
        applicants_data = []
        for applicant in applicants:
            # Generate KYC link
            kyc_link = f"{request.host_url.rstrip('/')}/kyc?appId={application_id}&applicantId={applicant.get('applicant_id')}"
            
            applicant_data = {
                "applicant_id": applicant.get('applicant_id'),
                "name": applicant.get('name'),
                "phone": applicant.get('phone'),
                "address": applicant.get('address'),
                "kyc_status": applicant.get('kyc_status'),
                "kyc_steps": applicant.get('kyc_steps'),
                "kyc_link": kyc_link
            }
            applicants_data.append(applicant_data)
        
        # Format response
        result = {
            "application_id": application.get('application_id'),
            "type": application.get('type'),
            "loan_type": application.get('loan_type'),
            "branch_code": application.get('branch_code'),
            "status": application.get('status'),
            "created_at": application.get('created_at').isoformat() if application.get('created_at') else None,
            "applicants": applicants_data
        }
        
        return jsonify({
            "success": True,
            **result
        })
        
    except Exception as e:
        logger.error(f"Failed to get application details: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/get_applicant/<applicant_id>', methods=['GET'])
def get_applicant(applicant_id):
    """Get applicant details by ID"""
    try:
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Find applicant
        applicant = mongo_db.kyc_applicants.find_one({"applicant_id": applicant_id})
        
        if not applicant:
            return jsonify({"error": "Applicant not found", "success": False}), 404
        
        # Get application
        application = mongo_db.kyc_applications.find_one({"application_id": applicant.get('application_id')})
        
        if not application:
            return jsonify({"error": "Application not found", "success": False}), 404
        
        # Format response
        result = {
            "applicant_id": applicant.get('applicant_id'),
            "application_id": applicant.get('application_id'),
            "name": applicant.get('name'),
            "phone": applicant.get('phone'),
            "address": applicant.get('address'),
            "kyc_status": applicant.get('kyc_status'),
            "kyc_steps": applicant.get('kyc_steps'),
            "application_type": application.get('type'),
            "loan_type": application.get('loan_type'),
            "is_primary_applicant": applicant.get('is_primary_applicant', False)
        }
        
        # Add KYC images if available
        # In the get_kyc_details function
        if 'kyc_images' in applicant and applicant['kyc_images']:
            kyc_image_dms_ids = []
            for image in applicant['kyc_images']:
                kyc_image_dms_ids.append({
                    "dmsId": image.get('dms_id'),
                    "type": image.get('type')
                })
            
            result["kycImageDmsIds"] = kyc_image_dms_ids
            logger.info(f"Added {len(kyc_image_dms_ids)} KYC image DMS IDs for applicant {applicant_id}")

        
        # If it's a group application, get co-applicants
        if application.get('type') == 'group':
            co_applicants = list(mongo_db.kyc_applicants.find({
                "application_id": applicant.get('application_id'),
                "applicant_id": {"$ne": applicant_id}
            }))
            
            co_applicants_data = []
            for co_applicant in co_applicants:
                co_applicant_data = {
                    "applicant_id": co_applicant.get('applicant_id'),
                    "name": co_applicant.get('name'),
                    "kyc_status": co_applicant.get('kyc_status'),
                    "is_primary_applicant": co_applicant.get('is_primary_applicant', False)
                }
                co_applicants_data.append(co_applicant_data)
            
            result["co_applicants"] = co_applicants_data
        
        return jsonify({
            "success": True,
            **result
        })
    
    except Exception as e:
        logger.error(f"Failed to get applicant details: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/update_kyc_status', methods=['POST'])
def update_kyc_status():
    """Update KYC status for an applicant"""
    try:
        data = request.json
        
        if not data or 'applicant_id' not in data:
            return jsonify({"error": "Missing applicant ID", "success": False}), 400
        
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Find applicant
        applicant = mongo_db.kyc_applicants.find_one({"applicant_id": data.get('applicant_id')})
        
        if not applicant:
            return jsonify({"error": "Applicant not found", "success": False}), 404
        
        # Update fields
        update_data = {}
        
        if 'kyc_status' in data:
            update_data['kyc_status'] = data.get('kyc_status')
        
        if 'kyc_steps' in data:
            # Merge existing steps with new steps
            kyc_steps = applicant.get('kyc_steps', {})
            kyc_steps.update(data.get('kyc_steps', {}))
            update_data['kyc_steps'] = kyc_steps
        
        # Handle liveness data
        if 'liveness_data' in data:
            liveness_data = data.get('liveness_data')
            
            # Check for DMS ID in liveness_data
            if 'dms_id' in liveness_data:
                # Store the DMS ID directly in the liveness_data
                logger.info(f"Found DMS ID in liveness_data: {liveness_data['dms_id']}")
                update_data['liveness_data'] = liveness_data
                
                # Also store it at the top level for easier access
                update_data['liveness_image_dms_id'] = liveness_data['dms_id']
            elif 'livenessImageDmsId' in liveness_data:
                # Alternative field name
                logger.info(f"Found DMS ID as livenessImageDmsId: {liveness_data['livenessImageDmsId']}")
                update_data['liveness_data'] = liveness_data
                update_data['liveness_image_dms_id'] = liveness_data['livenessImageDmsId']
            else:
                # If there's an image in base64 format, upload it to DMS
                if 'livenessImage' in liveness_data and isinstance(liveness_data['livenessImage'], str):
                    try:
                        # If it's a URL, fetch and convert to bytes
                        if liveness_data['livenessImage'].startswith('http'):
                            import requests
                            response = requests.get(liveness_data['livenessImage'])
                            if response.status_code == 200:
                                image_bytes = response.content
                        
                        # If it's already base64, decode it to bytes
                        elif liveness_data['livenessImage'].startswith('data:image'):
                            # Extract base64 data
                            image_data = liveness_data['livenessImage'].split(',')[1]
                            image_bytes = base64.b64decode(image_data)
                        else:
                            logger.error(f"Unsupported image format for applicant {data.get('applicant_id')}")
                            return jsonify({"error": "Unsupported image format", "success": False}), 400
                        
                        # Upload to DMS
                        metadata = {
                            "applicant_id": data.get('applicant_id'),
                            "session_id": liveness_data.get('session_id', str(uuid.uuid4())),
                            "type": "liveness"
                        }
                        
                        dms_id = upload_to_dms(image_bytes, metadata)
                        
                        if dms_id:
                            # Replace base64 image with DMS ID
                            liveness_data['livenessImage'] = None  # Remove base64 data
                            liveness_data['livenessImageDmsId'] = dms_id
                            update_data['liveness_data'] = liveness_data
                            update_data['liveness_image_dms_id'] = dms_id
                            logger.info(f"Uploaded liveness image to DMS for applicant {data.get('applicant_id')}, DMS ID: {dms_id}")
                        else:
                            logger.error(f"Failed to upload liveness image to DMS for applicant {data.get('applicant_id')}")
                            return jsonify({"error": "Failed to upload image to DMS", "success": False}), 500
                        
                    except Exception as e:
                        logger.error(f"Failed to process liveness image: {str(e)}")
                        return jsonify({"error": f"Failed to process liveness image: {str(e)}", "success": False}), 500
                else:
                    update_data['liveness_data'] = liveness_data
        
        # Handle direct liveness_image_dms_id field
        if 'liveness_image_dms_id' in data:
            logger.info(f"Found direct liveness_image_dms_id: {data['liveness_image_dms_id']}")
            update_data['liveness_image_dms_id'] = data['liveness_image_dms_id']
        
        # Handle masked Aadhaar image
        if 'masked_aadhaar_image' in data:
            masked_aadhaar_image = data.get('masked_aadhaar_image')
            
            # If it's a URL or base64, upload to DMS
            if isinstance(masked_aadhaar_image, str):
                try:
                    # If it's a URL, fetch and convert to bytes
                    if masked_aadhaar_image.startswith('http'):
                        import requests
                        response = requests.get(masked_aadhaar_image)
                        if response.status_code == 200:
                            image_bytes = response.content
                    
                    # If it's already base64, decode it to bytes
                    elif masked_aadhaar_image.startswith('data:image'):
                        # Extract base64 data
                        image_data = masked_aadhaar_image.split(',')[1]
                        image_bytes = base64.b64decode(image_data)
                    else:
                        logger.error(f"Unsupported image format for masked Aadhaar for applicant {data.get('applicant_id')}")
                        return jsonify({"error": "Unsupported image format for masked Aadhaar", "success": False}), 400
                    
                    # Upload to DMS
                    metadata = {
                        "applicant_id": data.get('applicant_id'),
                        "session_id": str(uuid.uuid4()),
                        "type": "masked_aadhaar"
                    }
                    
                    dms_id = upload_to_dms(image_bytes, metadata)
                    
                    if dms_id:
                        # Replace base64/URL with DMS ID
                        update_data['masked_aadhaar_image'] = None  # Remove original data
                        update_data['masked_aadhaar_dms_id'] = dms_id
                        logger.info(f"Uploaded masked Aadhaar image to DMS for applicant {data.get('applicant_id')}, DMS ID: {dms_id}")
                    else:
                        logger.error(f"Failed to upload masked Aadhaar image to DMS for applicant {data.get('applicant_id')}")
                        return jsonify({"error": "Failed to upload masked Aadhaar image to DMS", "success": False}), 500
                    
                except Exception as e:
                    logger.error(f"Failed to process masked Aadhaar image: {str(e)}")
                    return jsonify({"error": f"Failed to process masked Aadhaar image: {str(e)}", "success": False}), 500
        
        # Handle direct masked_aadhaar_dms_id field
        if 'masked_aadhaar_dms_id' in data:
            logger.info(f"Found direct masked_aadhaar_dms_id: {data['masked_aadhaar_dms_id']}")
            update_data['masked_aadhaar_dms_id'] = data['masked_aadhaar_dms_id']
        
        # Handle comparison result
        if 'comparison_result' in data:
            update_data['comparison_result'] = data.get('comparison_result')
        
        # Handle dedupe data
        if 'dedupe_data' in data:
            dedupe_data = data.get('dedupe_data')
            
            # Check if scrutiny is required
            requires_scrutiny = dedupe_data.get('requiresScrutiny', False)
            verification_status = dedupe_data.get('verificationStatus', 'pending')
            
            # If similarity is between 0.4 and 0.5, mark for scrutiny
            if dedupe_data.get('dedupeResults') and dedupe_data['dedupeResults'].get('results'):
                for result in dedupe_data['dedupeResults']['results']:
                    if result.get('similarity', 0) >= 0.4 and result.get('similarity', 0) < 0.5:
                        requires_scrutiny = True
                        verification_status = 'requires_scrutiny'
                        break
                    elif result.get('similarity', 0) >= 0.5:
                        verification_status = 'duplicate_found'
                        break
            
            update_data['dedupe_data'] = dedupe_data
            update_data['requires_scrutiny'] = requires_scrutiny
            update_data['verification_status'] = verification_status
        
        # Log the update data for debugging
        logger.info(f"Update data for applicant {data.get('applicant_id')}: {update_data}")
        
        # Update applicant
        if update_data:
            mongo_db.kyc_applicants.update_one(
                {"applicant_id": data.get('applicant_id')},
                {"$set": update_data}
            )
            
            logger.info(f"Updated KYC status for applicant {data.get('applicant_id')}")
            
            # Check if all steps are completed
            all_steps_completed = False
            kyc_steps = applicant.get('kyc_steps', {})
            if 'kyc_steps' in update_data:
                kyc_steps = update_data['kyc_steps']
                
            if kyc_steps.get('liveness') and kyc_steps.get('dedupe'):
                all_steps_completed = True
                
                # Update status to completed
                mongo_db.kyc_applicants.update_one(
                    {"applicant_id": data.get('applicant_id')},
                    {"$set": {"kyc_status": "completed"}}
                )
                
                logger.info(f"All KYC steps completed for applicant {data.get('applicant_id')}")
                
                # Get the application ID for this applicant
                application_id = applicant.get('application_id')
                if application_id:
                    # Update the application status if all applicants have completed KYC
                    all_applicants = list(mongo_db.kyc_applicants.find({"application_id": application_id}))
                    all_completed = all(app.get('kyc_status') == 'completed' for app in all_applicants)
                    
                    if all_completed:
                        # All applicants have completed KYC, update application status
                        mongo_db.kyc_applications.update_one(
                            {"application_id": application_id},
                            {"$set": {"status": "completed"}}
                        )
                        logger.info(f"Updated application {application_id} status to completed")
                    
                    # If any applicant has duplicates or requires scrutiny, update application status
                    any_duplicate = any(app.get('verification_status') == 'duplicate_found' for app in all_applicants)
                    any_scrutiny = any(app.get('verification_status') == 'requires_scrutiny' for app in all_applicants)
                    
                    if any_duplicate:
                        mongo_db.kyc_applications.update_one(
                            {"application_id": application_id},
                            {"$set": {"status": "duplicate_found"}}
                        )
                        logger.info(f"Updated application {application_id} status to duplicate_found")
                    elif any_scrutiny:
                        mongo_db.kyc_applications.update_one(
                            {"application_id": application_id},
                            {"$set": {"status": "requires_scrutiny"}}
                        )
                        logger.info(f"Updated application {application_id} status to requires_scrutiny")
        
        return jsonify({
            "success": True,
            "message": "KYC status updated successfully",
            "all_steps_completed": all_steps_completed if 'all_steps_completed' in locals() else False
        })
        
    except Exception as e:
        logger.error(f"Failed to update KYC status: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500


@app.route('/kyc', methods=['GET'])
def kyc_page_redirect():
    """Redirect to the React app with query parameters preserved"""
    app_id = request.args.get('appId')
    applicant_id = request.args.get('applicantId')
    
    # Replace with your actual React app URL
    react_app_url = "http://10.66.0.243:5173"  # Your React dev server
    redirect_url = f"{react_app_url}/kyc?appId={app_id}&applicantId={applicant_id}"
    
    return redirect(redirect_url)

@app.route('/kyc/<application_id>/<applicant_id>', methods=['GET'])
def kyc_redirect(application_id, applicant_id):
    """Redirect to the React app with application and applicant IDs"""
    # Replace this URL with your actual React app URL
    react_app_url = "http://10.66.0.243:5173"  # Assuming this is your React dev server
    redirect_url = f"{react_app_url}/kyc?appId={application_id}&applicantId={applicant_id}"
    return redirect(redirect_url)

@app.route('/get_kyc_details/<applicant_id>', methods=['GET'])
def get_kyc_details(applicant_id):
    """Get KYC details for an applicant"""
    try:
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Find applicant
        applicant = mongo_db.kyc_applicants.find_one({"applicant_id": applicant_id})
        
        if not applicant:
            return jsonify({"error": "Applicant not found", "success": False}), 404
        
        # Get application
        application = mongo_db.kyc_applications.find_one({"application_id": applicant.get('application_id')})
        
        if not application:
            return jsonify({"error": "Application not found", "success": False}), 404
        
        # Prepare KYC details
        kyc_details = {
            "name": applicant.get('name'),
            "phone": applicant.get('phone'),
            "address": applicant.get('address'),
            "application_type": application.get('type'),
            "loan_type": application.get('loan_type'),
            "kyc_status": applicant.get('kyc_status'),
            "kyc_steps": applicant.get('kyc_steps'),
            "verification_status": applicant.get('verification_status', 'pending'),
            "requires_scrutiny": applicant.get('requires_scrutiny', False)
        }
        
        # In the get_kyc_details function
        logger.info(f"Applicant data: {applicant}")
        if 'kyc_images' in applicant and applicant['kyc_images']:
            logger.info(f"Found kyc_images: {applicant['kyc_images']}")
            kyc_image_dms_ids = []
            for image in applicant['kyc_images']:
                kyc_image_dms_ids.append({
                    "dmsId": image.get('dms_id'),
                    "type": image.get('type')
                })
            
            kyc_details["kycImageDmsIds"] = kyc_image_dms_ids
            logger.info(f"Added {len(kyc_image_dms_ids)} KYC image DMS IDs for applicant {applicant_id}")
        else:
            logger.info(f"No kyc_images found for applicant {applicant_id}")

                
        # Add liveness data if available
        if 'liveness_data' in applicant:
            kyc_details["livenessData"] = applicant.get('liveness_data')
            
            # Check for DMS ID in liveness data
            if 'livenessImageDmsId' in applicant.get('liveness_data', {}):
                dms_id = applicant.get('liveness_data').get('livenessImageDmsId')
                kyc_details["livenessImageDmsId"] = dms_id
                # Generate URL for frontend to fetch image
                kyc_details["livenessImageUrl"] = f"{request.host_url.rstrip('/')}/get_dms_image/{dms_id}"
                logger.info(f"Added liveness image DMS URL for applicant {applicant_id}")
        
        # Add dedupe data if available
        if 'dedupe_data' in applicant:
            kyc_details["dedupeData"] = applicant.get('dedupe_data')
        
        # Add comparison result if available
        if 'comparison_result' in applicant:
            kyc_details["comparisonResult"] = applicant.get('comparison_result')
        
        # Add masked Aadhaar image DMS ID if available
        if 'masked_aadhaar_dms_id' in applicant:
            dms_id = applicant.get('masked_aadhaar_dms_id')
            kyc_details["maskedAadhaarDmsId"] = dms_id
            # Generate URL for frontend to fetch image
            kyc_details["maskedAadhaarImageUrl"] = f"{request.host_url.rstrip('/')}/get_dms_image/{dms_id}"
            logger.info(f"Added masked Aadhaar image DMS URL for applicant {applicant_id}")
        
        # Add admin decision if available
        if 'admin_decision' in applicant:
            kyc_details["adminDecision"] = applicant.get('admin_decision')
        
        # Add UCIC ID if available
        if 'ucic_id' in applicant:
            kyc_details["ucic_id"] = applicant.get('ucic_id')
        
        # If it's a group application, get co-applicants
        if application.get('type') == 'group':
            co_applicants = list(mongo_db.kyc_applicants.find({
                "application_id": applicant.get('application_id'),
                "applicant_id": {"$ne": applicant_id}
            }))
            
            co_applicants_data = []
            for co_applicant in co_applicants:
                # Generate KYC link for co-applicant
                kyc_link = f"{request.host_url.rstrip('/')}/kyc?appId={applicant.get('application_id')}&applicantId={co_applicant.get('applicant_id')}"
                
                co_applicant_data = {
                    "applicant_id": co_applicant.get('applicant_id'),
                    "name": co_applicant.get('name'),
                    "phone": co_applicant.get('phone', ''),
                    "kyc_status": co_applicant.get('kyc_status'),
                    "verification_status": co_applicant.get('verification_status', 'pending'),
                    "kyc_link": kyc_link  # Add the KYC link
                }
                co_applicants_data.append(co_applicant_data)
            
            kyc_details["co_applicants"] = co_applicants_data
        
        return jsonify({
            "success": True,
            "kyc_details": kyc_details
        })
        
    except Exception as e:
        logger.error(f"Failed to get KYC details: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/approve_kyc', methods=['POST'])
def approve_kyc():
    """Approve KYC for an applicant after manual review"""
    try:
        data = request.json
        
        if not data or 'applicant_id' not in data:
            return jsonify({"error": "Missing applicant ID", "success": False}), 400
        
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Find applicant
        applicant = mongo_db.kyc_applicants.find_one({"applicant_id": data.get('applicant_id')})
        
        if not applicant:
            return jsonify({"error": "Applicant not found", "success": False}), 404
        
        # Update verification status
        mongo_db.kyc_applicants.update_one(
            {"applicant_id": data.get('applicant_id')},
            {"$set": {
                "verification_status": "approved",
                "admin_decision": {
                    "decision": "approved",
                    "notes": data.get('admin_notes', ''),
                    "timestamp": datetime.now()
                }
            }}
        )
        
        logger.info(f"KYC approved for applicant {data.get('applicant_id')}")
        
        return jsonify({
            "success": True,
            "message": "KYC approved successfully"
        })
        
    except Exception as e:
        logger.error(f"Failed to approve KYC: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/reject_kyc', methods=['POST'])
def reject_kyc():
    """Reject KYC for an applicant after manual review"""
    try:
        data = request.json
        
        if not data or 'applicant_id' not in data:
            return jsonify({"error": "Missing applicant ID", "success": False}), 400
        
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        
        # Find applicant
        applicant = mongo_db.kyc_applicants.find_one({"applicant_id": data.get('applicant_id')})
        
        if not applicant:
            return jsonify({"error": "Applicant not found", "success": False}), 404
        
        # Update verification status
        mongo_db.kyc_applicants.update_one(
            {"applicant_id": data.get('applicant_id')},
            {"$set": {
                "verification_status": "rejected",
                "admin_decision": {
                    "decision": "rejected",
                    "notes": data.get('admin_notes', ''),
                    "timestamp": datetime.now()
                }
            }}
        )
        
        logger.info(f"KYC rejected for applicant {data.get('applicant_id')}")
        
        return jsonify({
            "success": True,
            "message": "KYC rejected successfully"
        })
        
    except Exception as e:
        logger.error(f"Failed to reject KYC: {str(e)}")
        return jsonify({"error": str(e), "success": False}), 500


################ NEW CHANGES #################################

@app.route('/submit_application', methods=['POST'])
def submit_application():
    """
    Submit verified user application to MongoDB and process face embedding
    """
    logger.info("Received /submit_application request")
    
    try:
        # Extract data from request
        if not request.json:
            return jsonify({"error": "Missing JSON data"}), 400
            
        name = request.json.get('name')
        dob = request.json.get('dob')
        image_data = request.json.get('image')
        applicant_id = request.json.get('applicant_id')
        application_id = request.json.get('application_id')
        phone = request.json.get('phone', '')
        address = request.json.get('address', '')
        
        if not name or not dob or not image_data:
            return jsonify({"error": "Missing required fields (name, dob, image)"}), 400
        
        # Convert base64 image to bytes
        try:
            # Remove data URL prefix if present
            if "base64," in image_data:
                image_data = image_data.split("base64,")[1]
            image_bytes = base64.b64decode(image_data)
        except Exception as e:
            logger.error(f"Failed to decode image: {str(e)}")
            return jsonify({"error": "Invalid image data"}), 400
        
        # Connect to MongoDB
        try:
            mongo_client = MongoClient(CONFIG['MONGO_URI'])
            mongo_db = mongo_client[CONFIG['MONGO_DB']]
            mongo_collection = mongo_db[CONFIG['MONGO_COLLECTION']]
        except Exception as e:
            logger.error(f"MongoDB connection failed: {str(e)}")
            return jsonify({"error": "Database connection failed"}), 500
        
        # Find the highest existing UCIC ID in the database
        highest_ucic = mongo_collection.find_one(sort=[("ucic_id", -1)])
        if highest_ucic and "ucic_id" in highest_ucic:
            # Extract the numeric part from the UCIC ID (format: UCIC#00000123)
            match = re.search(r'UCIC#(\d+)', highest_ucic["ucic_id"])
            if match:
                counter = int(match.group(1)) + 1
            else:
                counter = 1
        else:
            counter = 1
        
        # Generate new UCIC ID
        ucic_id = f"UCIC#{counter:08d}"
        
        # Upload image to DMS
        metadata = {
            "applicant_id": applicant_id,
            "ucic_id": ucic_id,
            "name": name,
            "type": "profile"
        }
        
        dms_id = upload_to_dms(image_bytes, metadata)
        
        if not dms_id:
            logger.error(f"Failed to upload image to DMS for applicant {applicant_id}")
            return jsonify({"error": "Failed to upload image to DMS"}), 500
        
        # Create MongoDB document
        document = {
            "ucic_id": ucic_id,
            "name": name,
            "dob": dob,
            "phone": phone,
            "address": address,
            "dms_id": dms_id,  # Store DMS ID instead of GridFS ID
            "original_filename": f"{name.replace(' ', '_')}_{int(time.time())}.jpg",
            "processed": False,
            "created_at": datetime.now(),
            "application_id": application_id,
            "applicant_id": applicant_id
        }
        
        # Insert document
        result = mongo_collection.insert_one(document)
        
        # Update the applicant record with UCIC ID
        if applicant_id:
            try:
                mongo_db.kyc_applicants.update_one(
                    {"applicant_id": applicant_id},
                    {"$set": {
                        "ucic_id": ucic_id,
                        "application_completed": True,
                        "application_timestamp": datetime.now(),
                        "profile_dms_id": dms_id  # Store DMS ID in applicant record
                    }}
                )
                logger.info(f"Updated applicant {applicant_id} with UCIC ID {ucic_id}")
            except Exception as e:
                logger.error(f"Failed to update applicant record: {str(e)}")
        
        # Process embedding using workflow
        try:
            # Initialize the workflow system
            dedup_system = FaceDeduplicationSystem(CONFIG)
            
            # Process the single image
            embedding = dedup_system.process_image(image_bytes)
            
            if embedding is not None:
                # Check if this is a duplicate before adding
                if dedup_system.collection.num_entities > 0 and dedup_system.is_duplicate(embedding):
                    logger.warning(f"Duplicate face detected for UCIC ID: {ucic_id}")
                    # We still continue but note the duplicate
                    mongo_collection.update_one(
                        {"_id": result.inserted_id},
                        {"$set": {"duplicate_detected": True}}
                    )
                else:
                    # Insert the embedding into Milvus
                    try:
                        insert_result = dedup_system.collection.insert([[ucic_id], [embedding]])
                        dedup_system.collection.flush()
                        logger.info(f"Successfully inserted embedding for UCIC ID: {ucic_id}, insert_result: {insert_result}")
                    except Exception as insert_err:
                        logger.error(f"Failed to insert embedding: {str(insert_err)}")
                        # Continue anyway since we've already stored the image in DMS and MongoDB
                
                # Mark as processed in MongoDB
                mongo_collection.update_one(
                    {"_id": result.inserted_id},
                    {"$set": {"processed": True}}
                )
                
                return jsonify({
                    "status": "success",
                    "message": "Application submitted and processed successfully",
                    "ucic_id": ucic_id
                })
            else:
                logger.error(f"Failed to generate embedding for UCIC ID: {ucic_id}")
                return jsonify({
                    "status": "partial_success",
                    "message": "Application submitted but face processing failed",
                    "ucic_id": ucic_id
                }), 206
                
        except Exception as e:
            logger.error(f"Embedding processing failed: {str(e)}")
            return jsonify({
                "status": "partial_success",
                "message": "Application submitted but face processing failed",
                "ucic_id": ucic_id,
                "error": str(e)
            }), 206
            
    except Exception as e:
        logger.error(f"Application submission failed: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/delete_record', methods=['DELETE'])
def delete_record():
    """Delete a record from MongoDB, Milvus, and DMS by UCIC ID"""
    logger.info("Received /delete_record request")
    
    try:
        # Get UCIC ID from request
        request_data = request.get_json()
        if not request_data or 'ucic_id' not in request_data:
            return jsonify({"error": "Missing UCIC ID in request"}), 400
            
        ucic_id = request_data['ucic_id']
        logger.info(f"Attempting to delete record with UCIC ID: {ucic_id}")
        
        # Connect to MongoDB
        mongo_client = MongoClient(CONFIG['MONGO_URI'])
        mongo_db = mongo_client[CONFIG['MONGO_DB']]
        mongo_collection = mongo_db[CONFIG['MONGO_COLLECTION']]
        
        # Find the document in MongoDB
        document = mongo_collection.find_one({"ucic_id": ucic_id})
        if not document:
            return jsonify({"error": f"No record found with UCIC ID: {ucic_id}"}), 404
        
        # Delete image from DMS if DMS ID exists
        dms_deleted = False
        if 'dms_id' in document:
            try:
                dms_id = document['dms_id']
                dms_deleted = delete_from_dms(dms_id)
                if dms_deleted:
                    logger.info(f"Deleted image from DMS with ID: {dms_id}")
                else:
                    logger.warning(f"Failed to delete image from DMS with ID: {dms_id}")
            except Exception as e:
                logger.warning(f"Failed to delete image from DMS: {str(e)}")
        
        # Delete document from MongoDB
        delete_result = mongo_collection.delete_one({"ucic_id": ucic_id})
        if delete_result.deleted_count == 0:
            logger.warning(f"MongoDB document not deleted for UCIC ID: {ucic_id}")
        else:
            logger.info(f"Deleted MongoDB document for UCIC ID: {ucic_id}")
        
        # Initialize Milvus connection
        dedup_system = FaceDeduplicationSystem(CONFIG)
        
        # Delete from Milvus
        expr = f"ucic_id == '{ucic_id}'"
        delete_milvus_result = dedup_system.collection.delete(expr)
        
        # Check if delete was successful
        if delete_milvus_result.delete_count > 0:
            logger.info(f"Successfully deleted {delete_milvus_result.delete_count} records from Milvus")
            return jsonify({
                "status": "success",
                "message": f"Record with UCIC ID {ucic_id} deleted successfully",
                "mongo_deleted": delete_result.deleted_count,
                "milvus_deleted": delete_milvus_result.delete_count,
                "dms_deleted": dms_deleted
            })
        else:
            logger.warning(f"No records deleted from Milvus for UCIC ID: {ucic_id}")
            return jsonify({
                "status": "partial_success",
                "message": f"MongoDB record deleted but no matching record found in Milvus",
                "mongo_deleted": delete_result.deleted_count,
                "milvus_deleted": 0,
                "dms_deleted": dms_deleted
            }), 206
            
    except Exception as e:
        logger.error(f"Error deleting record: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy"})

# Serve static files
@app.route('/', methods=['GET'])
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
