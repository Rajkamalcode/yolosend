import os
import io
import base64
import argparse
from PIL import Image
from datetime import datetime
from collections import defaultdict
from search import FaceSearchSystem, CONFIG, logger

class FaceSearchReporter:
    def __init__(self, config):
        self.search_system = FaceSearchSystem(config)
        self.results_by_ucic = defaultdict(list)
        self.total_images = 0
        self.processed_images = 0
        self.matched_images = 0
        self.start_time = None
        self.end_time = None
        self.root_dir = None  # Store the root directory for relative paths

    def process_directory(self, root_dir, threshold=0.5):
        """Process all images in the directory and its subdirectories"""
        self.start_time = datetime.now()
        self.root_dir = root_dir  # Store the root directory
        logger.info(f"Starting to process images in {root_dir}")
        
        for root, dirs, files in os.walk(root_dir):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
                    self.total_images += 1
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, root_dir)
                    logger.info(f"Processing image {self.processed_images + 1}/{self.total_images}: {relative_path}")
                    
                    try:
                        results, metrics = self.search_system.search_from_file(file_path, threshold)
                        self.processed_images += 1
                        
                        if results:
                            self.matched_images += 1
                            
                            for result in results:
                                ucic_id = result['ucic_id']
                                self.results_by_ucic[ucic_id].append({
                                    'file_path': relative_path,
                                    'absolute_path': file_path,
                                    'similarity': result['similarity'],
                                    'name': result.get('name', 'Unknown')
                                })
                    except Exception as e:
                        logger.error(f"Error processing {file_path}: {str(e)}")
        
        self.end_time = datetime.now()
        logger.info(f"Finished processing {self.processed_images} images with {self.matched_images} matches")

    def _get_db_image_path(self, ucic_id):
        """Save the database image for a given UCIC ID to a temporary file and return the path"""
        try:
            # Find the first result for this UCIC ID to get the image_id
            doc = self.search_system.mongo_collection.find_one(
                {"ucic_id": ucic_id},
                projection=["image_id"]
            )
            
            if doc and 'image_id' in doc:
                image_file = self.search_system.fs.get(doc['image_id'])
                image_bytes = image_file.read()
                
                # Create a directory for DB images if it doesn't exist
                db_images_dir = os.path.join(os.path.dirname(self.root_dir), "db_images")
                os.makedirs(db_images_dir, exist_ok=True)
                
                # Save the image to a file
                image_path = os.path.join(db_images_dir, f"{ucic_id}.jpg")
                with open(image_path, 'wb') as f:
                    f.write(image_bytes)
                
                # Return the relative path
                return os.path.relpath(image_path, os.path.dirname(self.root_dir))
        except Exception as e:
            logger.error(f"Failed to fetch DB image for {ucic_id}: {str(e)}")
        
        return None

    def generate_html_report(self, output_file="face_search_report.html"):
        """Generate an HTML report with the search results"""
        logger.info("Generating HTML report...")
        
        # Get the directory where the report will be saved
        output_dir = os.path.dirname(os.path.abspath(output_file))
        
        css = """
        <style>
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                margin: 0;
                padding: 20px;
                background-color: #f5f5f5;
                color: #333;
            }
            .header {
                background-color: #2c3e50;
                color: white;
                padding: 20px;
                margin-bottom: 20px;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            .summary {
                background-color: #ecf0f1;
                padding: 15px;
                margin-bottom: 20px;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            .ucic-group {
                background-color: white;
                margin-bottom: 30px;
                border-radius: 5px;
                overflow: hidden;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            .ucic-header {
                background-color: #3498db;
                color: white;
                padding: 15px;
                font-size: 18px;
                font-weight: bold;
            }
            .db-image-container {
                padding: 15px;
                background-color: #f9f9f9;
                border-bottom: 1px solid #eee;
                display: flex;
                align-items: center;
            }
            .db-image {
                max-width: 200px;
                max-height: 200px;
                margin-right: 20px;
                border: 1px solid #ddd;
            }
            .db-info {
                flex-grow: 1;
            }
            .matches-container {
                padding: 15px;
            }
            .match-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }
            .match-table th {
                background-color: #f2f2f2;
                padding: 10px;
                text-align: left;
                border: 1px solid #ddd;
            }
            .match-table td {
                padding: 10px;
                border: 1px solid #ddd;
                vertical-align: middle;
            }
            .match-image {
                max-width: 200px;
                max-height: 200px;
                border: 1px solid #ddd;
                display: block;
                margin: 0 auto;
            }
            .similarity-high {
                color: #27ae60;
                font-weight: bold;
            }
            .similarity-medium {
                color: #f39c12;
                font-weight: bold;
            }
            .similarity-low {
                color: #e74c3c;
                font-weight: bold;
            }
            .no-matches {
                padding: 20px;
                text-align: center;
                color: #7f8c8d;
                font-style: italic;
            }
        </style>
        """
        
        html = f"""<!DOCTYPE html>
        <html>
        <head>
            <title>Face Search Report</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            {css}
        </head>
        <body>
            <div class="header">
                <h1>Face Search Report</h1>
                <p>Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            
            <div class="summary">
                <h2>Summary</h2>
                <p>Total images scanned: {self.total_images}</p>
                <p>Images processed successfully: {self.processed_images}</p>
                <p>Images with matches: {self.matched_images}</p>
                <p>Unique UCIC IDs matched: {len(self.results_by_ucic)}</p>
                <p>Processing time: {(self.end_time - self.start_time).total_seconds():.2f} seconds</p>
            </div>
        """
        
        if not self.results_by_ucic:
            html += """
            <div class="no-matches">
                <h2>No matches found</h2>
                <p>No images matched with the database at the specified threshold.</p>
            </div>
            """
        else:
            for ucic_id, matches in self.results_by_ucic.items():
                # Sort matches by similarity score in descending order
                matches.sort(key=lambda x: x['similarity'], reverse=True)
                
                # Get the database image for this UCIC ID
                db_image_path = self._get_db_image_path(ucic_id)
                
                html += f"""
                <div class="ucic-group">
                    <div class="ucic-header">
                        UCIC ID: {ucic_id}
                    </div>
                    
                    <div class="db-image-container">
                """
                
                if db_image_path:
                    html += f"""
                        <img class="db-image" src="{db_image_path}" alt="Database Image">
                    """
                
                # Use the first match's metadata for the DB info
                first_match = matches[0]
                html += f"""
                        <div class="db-info">
                            <p><strong>Name:</strong> {first_match['name']}</p>
                            <p><strong>Total Matches:</strong> {len(matches)}</p>
                        </div>
                    </div>
                    
                    <div class="matches-container">
                        <h3>Matched Images</h3>
                        <table class="match-table">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>File Path</th>
                                    <th>Similarity</th>
                                </tr>
                            </thead>
                            <tbody>
                """
                
                for match in matches:
                    similarity = match['similarity']
                    similarity_class = "similarity-high" if similarity >= 0.6 else \
                                      "similarity-medium" if similarity >= 0.3 else \
                                      "similarity-low"
                    
                    # Use relative path for the image
                    image_path = match['file_path']
                    
                    html += f"""
                                <tr>
                                    <td><img class="match-image" src="{image_path}" alt="Matched Image"></td>
                                    <td>{match['file_path']}</td>
                                    <td><span class="{similarity_class}">{similarity:.4f}</span></td>
                                </tr>
                    """
                
                html += """
                            </tbody>
                        </table>
                    </div>
                </div>
                """
        
        html += """
            </body>
            </html>
        """
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html)
        
        logger.info(f"HTML report generated: {output_file}")
        return output_file
        
def main():
    # Define variables directly instead of using command-line arguments
    input_directory = "faces"  # Change this to your image directory
    similarity_threshold = 0.5  # Adjust threshold as needed
    output_file = "face_search_report.html"  # Output file name
    
    if not os.path.isdir(input_directory):
        print(f"Error: {input_directory} is not a valid directory")
        return
    
    try:
        reporter = FaceSearchReporter(CONFIG)
        reporter.process_directory(input_directory, similarity_threshold)
        report_path = reporter.generate_html_report(output_file)
        print(f"Report generated successfully: {report_path}")
    except Exception as e:
        print(f"Error generating report: {str(e)}")
    finally:
        # Disconnect from Milvus
        from pymilvus import connections
        connections.disconnect("default")

if __name__ == "__main__":
    main()
