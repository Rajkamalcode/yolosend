document.addEventListener('DOMContentLoaded', () => {
    const uploadForm = document.getElementById('uploadForm');
    const originalPdfInput = document.getElementById('originalPdf');
    const scannedPdfInput = document.getElementById('scannedPdf');
    const similarityThresholdInput = document.getElementById('similarityThreshold'); // Renamed ID
    const sharpnessThresholdInput = document.getElementById('sharpnessThreshold'); // New ID
    const submitBtn = document.getElementById('submitBtn');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const resultsDiv = document.getElementById('results');
    const errorDisplayDiv = document.getElementById('errorDisplay');

    // Result display elements
    const overallSimilarityStatusDiv = document.getElementById('overallSimilarityStatus');
    const pageCountInfoP = document.getElementById('pageCountInfo');
    const doc1TypeAnalysisSpan = document.querySelector('#doc1TypeAnalysis span');
    const doc2TypeAnalysisSpan = document.querySelector('#doc2TypeAnalysis span');
    const pageDetailsSectionDiv = document.getElementById('pageDetailsSection');
    const pageListUl = document.getElementById('pageList');


    uploadForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        // --- Basic Frontend Validation ---
        if (!originalPdfInput.files || originalPdfInput.files.length === 0) {
            displayError("Please select Document 1 (e.g., Original PDF)."); // Updated placeholder text
            return;
        }
        if (!scannedPdfInput.files || scannedPdfInput.files.length === 0) {
            displayError("Please select Document 2 (e.g., Scanned PDF)."); // Updated placeholder text
            return;
        }
        if (!similarityThresholdInput.checkValidity()) {
            displayError("Please enter a valid Similarity Threshold (0.0 to 1.0).");
            return;
        }
        if (!sharpnessThresholdInput.checkValidity()) {
             displayError("Please enter a valid positive Sharpness Threshold.");
             return;
        }


        // --- UI Reset and Loading State ---
        submitBtn.disabled = true;
        submitBtn.textContent = 'Processing...';
        loadingIndicator.style.display = 'block';
        resultsDiv.style.display = 'none';
        errorDisplayDiv.style.display = 'none';
        clearResults(); // Clear previous results text/classes

        // --- Prepare Form Data ---
        const formData = new FormData();
        formData.append('original_pdf', originalPdfInput.files[0]);
        formData.append('scanned_pdf', scannedPdfInput.files[0]);
        formData.append('similarity_threshold', similarityThresholdInput.value); // Pass similarity threshold
        formData.append('sharpness_threshold', sharpnessThresholdInput.value); // Pass sharpness threshold

        // --- API Call ---
        try {
            const response = await fetch('/compare', {
                method: 'POST',
                body: formData,
            });

            const responseData = await response.json(); // Always try to parse JSON

            if (!response.ok) {
                // Use detail from FastAPI's HTTPException if available, else generic message
                const errorMsg = responseData.detail || `HTTP Error: ${response.status} ${response.statusText}`;
                throw new Error(errorMsg);
            }

            displayResults(responseData);

        } catch (error) {
            console.error('Comparison Error:', error);
            displayError(error.message || 'An unknown error occurred during the request.');
        } finally {
            // --- Reset UI ---
            submitBtn.disabled = false;
            submitBtn.textContent = 'Compare & Analyze';
            loadingIndicator.style.display = 'none';
        }
    });

    function clearResults() {
        overallSimilarityStatusDiv.textContent = '';
        overallSimilarityStatusDiv.className = '';
        pageCountInfoP.textContent = '';
        doc1TypeAnalysisSpan.textContent = '';
        doc1TypeAnalysisSpan.className = ''; // Clear type class
        doc2TypeAnalysisSpan.textContent = '';
        doc2TypeAnalysisSpan.className = ''; // Clear type class
        pageListUl.innerHTML = '';
        pageDetailsSectionDiv.style.display = 'none';
    }

    function displayResults(results) {
        clearResults(); // Clear any previous state
        resultsDiv.style.display = 'block';
        errorDisplayDiv.style.display = 'none';

        // --- Display Overall Similarity Status ---
        overallSimilarityStatusDiv.textContent = results.message || (results.overall_similarity_match ? 'Documents Match (Similarity)' : 'Documents Mismatch (Similarity)');
        overallSimilarityStatusDiv.className = results.overall_similarity_match ? 'status-match' : 'status-mismatch';

        // --- Display Page Count Info ---
        if (results.original_pages !== undefined && results.scanned_pages !== undefined) {
             pageCountInfoP.textContent = `(Doc 1 pages: ${results.original_pages}, Doc 2 pages: ${results.scanned_pages})`;
        }

        // --- Display Document Type Analysis ---
        doc1TypeAnalysisSpan.textContent = results.original_doc_type_analysis?.summary || 'N/A';
        doc2TypeAnalysisSpan.textContent = results.scanned_doc_type_analysis?.summary || 'N/A';
        // Add styling based on type result
        doc1TypeAnalysisSpan.className = results.original_doc_type_analysis?.summary?.includes('Photocopy') ? 'type-photocopy' : 'type-original';
        doc2TypeAnalysisSpan.className = results.scanned_doc_type_analysis?.summary?.includes('Photocopy') ? 'type-photocopy' : 'type-original';


        // --- Display Page Details ---
        if (results.page_comparisons && results.page_comparisons.length > 0) {
            pageDetailsSectionDiv.style.display = 'block';
            results.page_comparisons.forEach(page => {
                const li = document.createElement('li');
                li.classList.add('page-item');

                // Page Number Header
                const pageHeader = document.createElement('div');
                pageHeader.classList.add('page-header');
                pageHeader.textContent = `Page ${page.page}`;
                li.appendChild(pageHeader);

                // Page Content Div
                const pageContent = document.createElement('div');
                pageContent.classList.add('page-content');

                // Error Display (if any)
                 if (page.error) {
                     const errorSpan = document.createElement('span');
                     errorSpan.className = 'page-error';
                     errorSpan.textContent = `Error: ${page.error}`;
                     pageContent.appendChild(errorSpan);
                 } else {
                    // --- Start of Similarity Details Update ---

                    // Similarity Details Div (Container)
                    const similarityDiv = document.createElement('div');
                    similarityDiv.classList.add('page-detail', 'similarity-details'); // Add specific class

                    // Similarity Status (Match/Mismatch)
                    const simStatusSpan = document.createElement('strong');
                    simStatusSpan.textContent = `Similarity: ${page.similarity_match ? 'Match' : 'Mismatch'}`;
                    simStatusSpan.className = page.similarity_match ? 'page-match' : 'page-mismatch';
                    similarityDiv.appendChild(simStatusSpan);

                    // Create a container span for all score text to manage spacing
                    const scoreTextContainer = document.createElement('span');
                    scoreTextContainer.classList.add('score-text-container');

                    // Main Score Span (Highlighted)
                    const mainScoreSpan = document.createElement('span');
                    mainScoreSpan.classList.add('main-score'); // Class for primary styling
                    // Use nullish coalescing ?? to handle potential undefined/null scores gracefully
                    mainScoreSpan.textContent = `Score: ${page.similarity_score?.toFixed(3) ?? 'N/A'}`;
                    scoreTextContainer.appendChild(mainScoreSpan);

                    // Component Scores Span (Less prominent)
                    const componentScoresSpan = document.createElement('span');
                    componentScoresSpan.classList.add('component-scores'); // Class for secondary styling
                    componentScoresSpan.textContent = ` (SSIM: ${page.ssim_score?.toFixed(3) ?? 'N/A'}, Text: ${page.text_score?.toFixed(3) ?? 'N/A'}, Layout: ${page.layout_score?.toFixed(3) ?? 'N/A'})`;
                    scoreTextContainer.appendChild(componentScoresSpan);

                    // Add the score container to the similarity div
                    similarityDiv.appendChild(scoreTextContainer);

                    // Add the whole similarity div to the page content
                    pageContent.appendChild(similarityDiv);

                    // --- End of Similarity Details Update ---


                    // Type Analysis Details
                    const typeDiv = document.createElement('div');
                    typeDiv.classList.add('page-detail');
                    // Use slightly more specific classes for page-level type spans
                    typeDiv.innerHTML = `
                        <strong>Type Analysis:</strong>
                        <span class="type-label">Doc 1:</span> <span class="page-type-indicator ${page.original_page_type?.includes('Photocopy') ? 'type-photocopy' : 'type-original'}">${page.original_page_type || 'N/A'} (S: ${page.original_page_features?.sharpness ?? 'N/A'})</span> |
                        <span class="type-label">Doc 2:</span> <span class="page-type-indicator ${page.scanned_page_type?.includes('Photocopy') ? 'type-photocopy' : 'type-original'}">${page.scanned_page_type || 'N/A'} (S: ${page.scanned_page_features?.sharpness ?? 'N/A'})</span>
                    `;
                    pageContent.appendChild(typeDiv);
                 }

                li.appendChild(pageContent);
                pageListUl.appendChild(li);
            });
        } else {
             pageDetailsSectionDiv.style.display = 'none'; // Hide section if no page details
             if(!results.error) { // Add a message if no pages but also no error
                 const noPagesMsg = document.createElement('p');
                 noPagesMsg.style.textAlign = 'center'; // Center the message
                 noPagesMsg.style.marginTop = '15px';
                 noPagesMsg.textContent = "No pages were compared (check page count or PDF content).";
                 // Append it to the main results div instead of the hidden page details section
                 resultsDiv.appendChild(noPagesMsg);
             }
        }
    }

    function displayError(errorMessage) {
        resultsDiv.style.display = 'none'; // Hide results section
        errorDisplayDiv.style.display = 'block';
        // Sanitize error message slightly before display? (Optional)
        // Basic approach: just display it
        errorDisplayDiv.textContent = `Error: ${errorMessage}`;
    }
});