import React, { useState, useEffect } from 'react';
import './FaceDedupe.css';

const FaceDedupe = ({ kycData, updateKycData, nextStep, prevStep }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [dedupeResults, setDedupeResults] = useState(null);
  const [searchCompleted, setSearchCompleted] = useState(false);
  
  // Server URLs
  const serverUrl = 'http://10.9.52.21:5001';
  const searchUrl = `${serverUrl}/search`;
  const dmsUrl = `${serverUrl}/get_dms_image`;
  
  // Run dedupe search on component mount if not already done
  useEffect(() => {
    if (kycData.dedupeResults) {
      // If we already have dedupe results, use them
      setDedupeResults(kycData.dedupeResults);
      setSearchCompleted(true);
    } else if (kycData.livenessImage || kycData.livenessImageDmsId) {
      // Otherwise, run the search if we have a liveness image
      runDedupeSearch();
    }
  }, []);
  
  // Run face deduplication search
  const runDedupeSearch = async () => {
    if (!kycData.livenessImage && !kycData.livenessImageDmsId) {
      setError('No liveness image available for deduplication');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Determine the image source - either direct base64 or DMS ID
      let imageSource = kycData.livenessImage;
      
      // If we have a DMS ID, use that instead
      if (kycData.livenessImageDmsId) {
        imageSource = `${dmsUrl}/${kycData.livenessImageDmsId}`;
      }
      
      // Convert image to blob
      const response = await fetch(imageSource);
      if (!response.ok) {
        throw new Error(`Failed to fetch liveness image: ${response.status} ${response.statusText}`);
      }
      
      const blob = await response.blob();
      
      // Create form data
      const formData = new FormData();
      formData.append('image', blob, 'liveness.jpg');
      
      // Set threshold from kycData or use default
      const threshold = kycData.dedupeThreshold || 0.65;
      formData.append('threshold', threshold.toString());
      
      // Add applicant ID if available
      if (kycData.applicantId) {
        formData.append('applicant_id', kycData.applicantId);
      }
      
      // Send search request
      const result = await fetch(searchUrl, {
        method: 'POST',
        body: formData
      });
      
      if (!result.ok) {
        const errorData = await result.json().catch(() => null);
        throw new Error(errorData?.error || `Server error: ${result.status} ${result.statusText}`);
      }
      
      const searchData = await result.json();
      
      if (searchData.status === 'success') {
        // Process the search results
        const processedResults = {
          results: searchData.results || [],
          message: searchData.message || 'Search completed',
          metrics: searchData.metrics || {},
          requiresScrutiny: false,
          verificationStatus: 'pending'
        };
        
        // Determine if scrutiny is required based on results
        if (processedResults.results.length > 0) {
          // Check for high similarity matches
          const highSimilarityMatches = processedResults.results.filter(
            result => result.similarity >= 0.65
          );
          
          if (highSimilarityMatches.length > 0) {
            processedResults.requiresScrutiny = true;
            processedResults.verificationStatus = 'duplicate_found';
          } else {
            // Check for medium similarity matches
            const mediumSimilarityMatches = processedResults.results.filter(
              result => result.similarity >= 0.4 && result.similarity < 0.65
            );
            
            if (mediumSimilarityMatches.length > 0) {
              processedResults.requiresScrutiny = true;
              processedResults.verificationStatus = 'requires_scrutiny';
            }
          }
        }
        
        setDedupeResults(processedResults);
        setSearchCompleted(true);
        
        // Update KYC data
        updateKycData({
          dedupeResults: processedResults,
          requiresScrutiny: processedResults.requiresScrutiny,
          verificationStatus: processedResults.verificationStatus
        });
      } else {
        throw new Error(searchData.error || 'Search failed');
      }
    } catch (err) {
      setError(err.message || 'Failed to run deduplication search');
      console.error('Error running dedupe search:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Format similarity as percentage
  const formatSimilarity = (similarity) => {
    return `${(similarity * 100).toFixed(2)}%`;
  };
  
  // Determine match status class
  const getMatchStatusClass = (similarity) => {
    if (similarity >= 0.65) return 'high-match';
    if (similarity >= 0.4) return 'medium-match';
    return 'low-match';
  };
  
  // Determine match status text
  const getMatchStatusText = (similarity) => {
    if (similarity >= 0.65) return 'HIGH MATCH';
    if (similarity >= 0.4) return 'POTENTIAL MATCH';
    return 'LOW SIMILARITY';
  };
  
  // Handle continue to next step
  const handleContinue = () => {
    if (!searchCompleted) {
      setError('Please complete the deduplication search first');
      return;
    }
    
    nextStep();
  };
  
  return (
    <div className="face-dedupe">
      <h2>Face Deduplication</h2>
      <p className="instructions">
        Checking if your face matches with any existing records in our database.
      </p>
      
      {isLoading && (
        <div className="loading">
          <div className="spinner"></div>
          <p>Running deduplication search...</p>
        </div>
      )}
      
      {error && <div className="error-message">{error}</div>}
      
      <div className="dedupe-container">
        <div className="search-image">
          <h3>Your Image</h3>
          {kycData.livenessImage ? (
            <img src={kycData.livenessImage} alt="Liveness" className="liveness-image" />
          ) : kycData.livenessImageDmsId ? (
            <img 
              src={`${dmsUrl}/${kycData.livenessImageDmsId}`} 
              alt="Liveness" 
              className="liveness-image"
              onError={(e) => {
                console.error('Failed to load liveness image from DMS');
                e.target.src = 'placeholder-image.jpg'; // Fallback image
              }}
            />
          ) : (
            <div className="placeholder">No liveness image</div>
          )}
        </div>
        
        <div className="search-results">
          <h3>Search Results</h3>
          
          {!searchCompleted && !isLoading && (
            <button 
              className="search-btn" 
              onClick={runDedupeSearch}
              disabled={!kycData.livenessImage && !kycData.livenessImageDmsId}
            >
              Run Deduplication Search
            </button>
          )}
          
          {searchCompleted && dedupeResults && (
            <>
              <div className="result-summary">
                <p className="result-message">{dedupeResults.message}</p>
                
                {dedupeResults.requiresScrutiny && (
                  <div className="scrutiny-warning">
                    <i className="fas fa-exclamation-triangle"></i>
                    <span>
                      {dedupeResults.verificationStatus === 'duplicate_found' 
                        ? 'Duplicate found! Further verification required.' 
                        : 'Potential match found. Further scrutiny required.'}
                    </span>
                  </div>
                )}
                
                {dedupeResults.results.length === 0 && (
                  <div className="no-matches">
                    <i className="fas fa-check-circle"></i>
                    <span>No matching records found</span>
                  </div>
                )}
              </div>
              
              {dedupeResults.results.length > 0 && (
                <div className="matches-list">
                  <h4>Matching Records</h4>
                  <div className="matches-container">
                    {dedupeResults.results.map((result, index) => (
                      <div className="match-item" key={index}>
                        <div className="match-image">
                          {result.image_data ? (
                            <img src={result.image_data} alt={`Match ${index + 1}`} />
                          ) : result.image_id ? (
                            <img 
                              src={`${serverUrl}/image/${result.image_id}`} 
                              alt={`Match ${index + 1}`}
                              onError={(e) => {
                                console.error('Failed to load match image');
                                e.target.src = 'placeholder-image.jpg'; // Fallback image
                              }}
                            />
                          ) : (
                            <div className="no-image">No image</div>
                          )}
                        </div>
                        <div className="match-details">
                          <div className="match-info">
                            <span className="match-label">UCIC ID:</span>
                            <span className="match-value">{result.ucic_id || 'Unknown'}</span>
                          </div>
                          <div className="match-info">
                            <span className="match-label">Name:</span>
                            <span className="match-value">{result.name || 'Unknown'}</span>
                          </div>
                          <div className="match-info">
                            <span className="match-label">Similarity:</span>
                            <span className="match-value">{formatSimilarity(result.similarity)}</span>
                          </div>
                          <div className="match-info">
                            <span className="match-label">Status:</span>
                            <span className={`match-status ${getMatchStatusClass(result.similarity)}`}>
                              {getMatchStatusText(result.similarity)}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {dedupeResults.metrics && (
                <div className="search-metrics">
                  <h4>Search Metrics</h4>
                  <div className="metrics-info">
                    <span className="metric-label">Search Time:</span>
                    <span className="metric-value">{dedupeResults.metrics.search_time?.toFixed(2) || 0} ms</span>
                  </div>
                  <div className="metrics-info">
                    <span className="metric-label">Total Time:</span>
                    <span className="metric-value">{dedupeResults.metrics.total_time?.toFixed(2) || 0} ms</span>
                  </div>
                  <div className="metrics-info">
                    <span className="metric-label">Candidates Found:</span>
                    <span className="metric-value">{dedupeResults.metrics.candidates_found || 0}</span>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
      
      <div className="navigation-buttons">
        <button className="back-btn" onClick={prevStep}>
          Back
        </button>
        <button 
          className="continue-btn" 
          onClick={handleContinue}
          disabled={!searchCompleted}
        >
          Continue
        </button>
      </div>
    </div>
  );
};

export default FaceDedupe;
