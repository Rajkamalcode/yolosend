/**
 * Liveness Check Embed Script
 * Include this script in your website to easily integrate with the liveness check service
 */
(function() {
  // Configuration
  const DEFAULT_SERVER_URL = 'http://10.9.52.21:5003'; // Update with your server URL
  const DEFAULT_FRONTEND_URL = 'http://localhost:5173'; // Update with your frontend URL
  
  // Create global object
  window.LivenessCheck = {
    /**
     * Open liveness check in a popup window
     * @param {Object} options - Configuration options
     * @param {string} options.callbackUrl - URL to receive the liveness result
     * @param {string} options.requestId - Optional request ID to track this verification
     * @param {string} options.token - Optional authentication token
     * @param {string} options.serverUrl - Optional custom server URL
     * @param {string} options.frontendUrl - Optional custom frontend URL
     * @param {Function} options.onResult - Optional callback function for result
     */
    openPopup: function(options) {
      if (!options || !options.callbackUrl) {
        console.error('LivenessCheck: callbackUrl is required');
        return null;
      }
      
      const serverUrl = options.serverUrl || DEFAULT_SERVER_URL;
      const frontendUrl = options.frontendUrl || DEFAULT_FRONTEND_URL;
      const origin = window.location.origin;
      
      // Build URL with parameters
      const url = new URL(`${frontendUrl}/standalone-liveness`);
      url.searchParams.append('origin', origin);
      url.searchParams.append('callbackUrl', options.callbackUrl);
      
      if (options.requestId) {
        url.searchParams.append('requestId', options.requestId);
      }
      
      if (options.token) {
        url.searchParams.append('token', options.token);
      }
      
      // Open popup
      const popup = window.open(
        url.toString(),
        'LivenessCheck',
        'width=800,height=600,resizable=yes,scrollbars=yes,status=yes'
      );
      
      // Set up message listener for result
      if (options.onResult && typeof options.onResult === 'function') {
        window.addEventListener('message', function(event) {
          // Verify origin
          if (event.origin !== frontendUrl) return;
          
          // Check if it's our message
          if (event.data && event.data.type === 'LIVENESS_RESULT') {
            options.onResult(event.data.data);
          }
        }, false);
      }
      
      return popup;
    },
    
    /**
     * Embed liveness check in an iframe
     * @param {string} containerId - ID of the container element
     * @param {Object} options - Configuration options (same as openPopup)
     */
    embedIframe: function(containerId, options) {
      const container = document.getElementById(containerId);
      if (!container) {
        console.error(`LivenessCheck: Container element with ID "${containerId}" not found`);
        return null;
      }
      
      if (!options || !options.callbackUrl) {
        console.error('LivenessCheck: callbackUrl is required');
        return null;
      }
      
      const serverUrl = options.serverUrl || DEFAULT_SERVER_URL;
      const frontendUrl = options.frontendUrl || DEFAULT_FRONTEND_URL;
      const origin = window.location.origin;
      
      // Build URL with parameters
      const url = new URL(`${frontendUrl}/standalone-liveness`);
      url.searchParams.append('origin', origin);
      url.searchParams.append('callbackUrl', options.callbackUrl);
      
      if (options.requestId) {
        url.searchParams.append('requestId', options.requestId);
      }
      
      if (options.token) {
        url.searchParams.append('token', options.token);
      }
      
      // Create iframe
      const iframe = document.createElement('iframe');
      iframe.src = url.toString();
      iframe.width = '100%';
      iframe.height = '600px';
      iframe.style.border = 'none';
      iframe.allow = 'camera; microphone; geolocation';
      
      // Clear container and add iframe
      container.innerHTML = '';
      container.appendChild(iframe);
      
      // Set up message listener for result
      if (options.onResult && typeof options.onResult === 'function') {
        window.addEventListener('message', function(event) {
          // Verify origin
          if (event.origin !== frontendUrl) return;
          
          // Check if it's our message
          if (event.data && event.data.type === 'LIVENESS_RESULT') {
            options.onResult(event.data.data);
          }
        }, false);
      }
      
      return iframe;
    }
  };
})();
