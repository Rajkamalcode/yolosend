import Link from 'next/link';

export default function Home() {
  return (
    <div className="container mx-auto py-16 px-4 text-center">
      <h1 className="text-4xl font-bold mb-6">Property Document Comparison</h1>
      <p className="text-xl mb-8 max-w-2xl mx-auto">
        Upload multiple property documents to compare them and check for similarities. 
        Our system analyzes boundaries, owner names, addresses, and more.
      </p>
      
      <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
        <Link 
          href="/document-comparison"
          className="py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-lg"
        >
          Start New Comparison
        </Link>
        <Link 
          href="/sessions"
          className="py-3 px-6 bg-gray-200 hover:bg-gray-300 font-medium rounded-lg text-lg"
        >
          View Past Sessions
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-3">Document Processing</h2>
          <p>
            Upload PDF and TXT files for analysis. Our system extracts text using OCR if needed and translates non-English content.
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-3">Property Comparison</h2>
          <p>
            Compare key details like boundaries, owner names, addresses, and square footage across multiple documents.
          </p>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-bold mb-3">Interactive Analysis</h2>
          <p>
            Ask follow-up questions about the documents to get more specific information about the properties.
          </p>
        </div>
      </div>
    </div>
  );
}
