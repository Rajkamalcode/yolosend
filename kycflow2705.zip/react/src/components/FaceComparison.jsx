import React, { useState, useEffect, useRef } from 'react';
import './FaceComparison.css';

const FaceComparison = ({ kycData, updateKycData, nextStep, prevStep }) => {
  const [extractedFace, setExtractedFace] = useState(null);
  const [livenessImage, setLivenessImage] = useState(null);
  const [comparisonResult, setComparisonResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [kycImages, setKycImages] = useState([]);
  const [multiComparisonResults, setMultiComparisonResults] = useState([]);
  
  // Use refs to track if images have been loaded to prevent repeated API calls
  const imagesLoadedRef = useRef(false);
  
  // Server URLs
  const comparisonServerUrl = 'http://10.9.52.21:5001';
  
  // Load images from DMS on component mount - only once
  useEffect(() => {
    console.log('FaceComparison - kycData:', kycData);
    
    // Only load images if they haven't been loaded yet
    if (!imagesLoadedRef.current) {
      loadImagesFromDms();
    }
  }, []);
  
  // Load images from DMS using the stored DMS IDs
  const loadImagesFromDms = async () => {
    // Skip if we already have both images
    if (extractedFace && livenessImage && kycImages.length > 0) {
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Check if we have the necessary DMS IDs
      // Try multiple possible property names for the DMS IDs
      const aadhaarDmsId = kycData.maskedAadhaarDmsId || kycData.aadhaarDmsId;
      const livenessDmsId = kycData.livenessImageDmsId || kycData.livenessDmsId;
      
      console.log('DMS IDs:', { aadhaarDmsId, livenessDmsId });
      
      // Check if the DMS IDs are valid UUIDs or at least non-empty strings
      const isValidDmsId = (id) => {
        return id && typeof id === 'string' && id.trim() !== '';
      };
      
      if (!isValidDmsId(aadhaarDmsId)) {
        throw new Error('No Aadhaar image DMS ID available. Please go back and recapture your Aadhaar card.');
      }
      
      if (!isValidDmsId(livenessDmsId)) {
        throw new Error('No liveness image DMS ID available. Please go back and complete the liveness check.');
      }
      
      console.log('Loading images from DMS with IDs:', { aadhaarDmsId, livenessDmsId });
      
      // Fetch the Aadhaar image from DMS - only if not already loaded
      if (!extractedFace) {
        const aadhaarImageUrl = `${comparisonServerUrl}/get_dms_image/${aadhaarDmsId}`;
        setExtractedFace(aadhaarImageUrl);
      }
      
      // Fetch the liveness image from DMS - only if not already loaded
      if (!livenessImage) {
        const livenessImageUrl = `${comparisonServerUrl}/get_dms_image/${livenessDmsId}`;
        setLivenessImage(livenessImageUrl);
      }
      
      console.log('KYC Image DMS IDs:', kycData.kycImageDmsIds || 'Not available');

      // Load additional KYC images if available
      if (kycData.kycImageDmsIds && kycData.kycImageDmsIds.length > 0 && kycImages.length === 0) {
        const loadedImages = [];
        
        for (const item of kycData.kycImageDmsIds) {
          if (isValidDmsId(item.dmsId)) {
            const imageUrl = `${comparisonServerUrl}/get_dms_image/${item.dmsId}`;
            loadedImages.push({
              dmsId: item.dmsId,
              type: item.type || 'KYC Document',
              url: imageUrl
            });
          }
        }
        
        setKycImages(loadedImages);
        console.log('Loaded additional KYC images:', loadedImages);
      }
      
      // Mark images as loaded to prevent repeated API calls
      imagesLoadedRef.current = true;
      
      // Update KYC data with the image URLs - only do this once
      updateKycData({
        extractedFaceImage: extractedFace || `${comparisonServerUrl}/get_dms_image/${aadhaarDmsId}`,
        livenessImage: livenessImage || `${comparisonServerUrl}/get_dms_image/${livenessDmsId}`,
        // Ensure the DMS IDs are stored in the standard properties
        maskedAadhaarDmsId: aadhaarDmsId,
        livenessImageDmsId: livenessDmsId
      });
      
    } catch (err) {
      setError(err.message || 'Failed to load images from DMS');
      console.error('Error loading images from DMS:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Compare faces - only when the button is clicked
  const compareFaces = async () => {
    if (!extractedFace || !livenessImage) {
      setError('Both face images are required for comparison');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Fetch the images as blobs
      const response1 = await fetch(extractedFace);
      const blob1 = await response1.blob();
      
      const response2 = await fetch(livenessImage);
      const blob2 = await response2.blob();
      
      const formData = new FormData();
      formData.append('image1', blob1, 'aadhaar_face.jpg');
      formData.append('image2', blob2, 'liveness_face.jpg');
      
      const result = await fetch(`${comparisonServerUrl}/compare`, {
        method: 'POST',
        body: formData
      });
      
      if (!result.ok) {
        const errorData = await result.json().catch(() => null);
        throw new Error(errorData?.error || `Server error: ${result.status} ${result.statusText}`);
      }
      
      const comparisonData = await result.json();
      setComparisonResult(comparisonData);
      console.log('Comparison result:', comparisonData);
      
      // Update KYC data
      updateKycData({
        comparisonResult: comparisonData
      });
      
      // If we have additional KYC images, compare with those as well
      if (kycImages.length > 0 && kycData.livenessImageDmsId) {
        await compareWithDmsIds();
      }
      
    } catch (err) {
      setError(err.message || 'Failed to compare faces');
      console.error('Error comparing faces:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Compare liveness image with multiple KYC images using DMS IDs
// Compare liveness image with multiple KYC images using DMS IDs
const compareWithDmsIds = async () => {
  if (!kycData.livenessImageDmsId || kycImages.length === 0) {
    return;
  }
  
  setIsLoading(true);
  
  try {
    console.log('Comparing liveness image with KYC images...');
    console.log('Liveness DMS ID:', kycData.livenessImageDmsId);
    console.log('KYC Image DMS IDs:', kycImages.map(img => img.dmsId));
    
    // Fix: Change the endpoint from 'compare_multiple_dms' to 'compare_dms'
    const response = await fetch(`${comparisonServerUrl}/compare_dms`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        primary_dms_id: kycData.livenessImageDmsId,
        comparison_dms_ids: kycImages.map(img => img.dmsId)
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      console.error('Error response:', errorData);
      throw new Error(errorData?.error || `Server error: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    console.log('Multiple DMS comparison results:', data);
    
    // Fix: Check for data.status === "success" instead of data.success
    if (data.status === "success") {
      // Map the results to include the image type from kycImages
      const resultsWithType = data.results.map(result => {
        const matchingImage = kycImages.find(img => img.dmsId === result.dms_id);
        return {
          ...result,
          // Fix: Use dms_id instead of dmsId to match the server response
          dmsId: result.dms_id,
          type: matchingImage ? matchingImage.type : 'Unknown'
        };
      });
      
      setMultiComparisonResults(resultsWithType);
      
      // Update KYC data
      updateKycData({
        multiComparisonResults: resultsWithType
      });
      
      console.log('Processed comparison results with types:', resultsWithType);
    } else {
      console.error('Comparison failed:', data.error);
    }
    
  } catch (err) {
    console.error('Error comparing multiple images:', err);
    // Don't set error here to avoid blocking the main comparison flow
  } finally {
    setIsLoading(false);
  }
};

  // Find the comparison result for a specific DMS ID
  const getComparisonResultForDmsId = (dmsId) => {
    return multiComparisonResults.find(result => result.dmsId === dmsId);
  };
  
  // Handle continue to next step
  const handleContinue = () => {
    if (!comparisonResult) {
      setError('Face comparison is required before proceeding');
      return;
    }
    
    // Check if similarity is above threshold
    if (comparisonResult.similarity < 0.3) { // Adjust threshold as needed
      setError('Face similarity is too low to proceed. Please try again with clearer images.');
      return;
    }
    
    // Include all comparison results in the next step
    nextStep({
      comparisonResult: comparisonResult,
      multiComparisonResults: multiComparisonResults,
      livenessImageDmsId: kycData.livenessImageDmsId,
      maskedAadhaarDmsId: kycData.maskedAadhaarDmsId
    });
  };
  
  // Prepare images for grid layout
  const prepareImagesForGrid = () => {
    const images = [];
    
    // Add liveness image as the center (div1)
    if (livenessImage) {
      images.push({
        position: 1,
        url: livenessImage,
        type: 'Live Photo',
        isLiveness: true
      });
    }
    
    // Add Aadhaar face as div2
    if (extractedFace) {
      images.push({
        position: 2,
        url: extractedFace,
        type: 'Aadhaar Face',
        result: comparisonResult,
        isAadhaar: true
      });
    }
    
    // Add additional KYC images to positions 3, 4, 5, etc.
    if (kycImages && kycImages.length > 0) {
      kycImages.forEach((image, index) => {
        // Start from position 3 and go up to 9
        const position = index + 3;
        if (position <= 9) {
          images.push({
            position,
            url: image.url,
            type: image.type,
            dmsId: image.dmsId,
            result: getComparisonResultForDmsId(image.dmsId)
          });
        }
      });
    }
    
    return images;
  };
  
  const gridImages = prepareImagesForGrid();
  
  return (
    <div className="face-comparison">
      <h2>Face Comparison</h2>
      <p className="instructions">
        Comparing your live photo with your identification documents. If faces are not visible, please recapture.
      </p>
      
      {isLoading && (
        <div className="loading-overlay">
          <div className="spinner"></div>
          <p>Processing...</p>
        </div>
      )}
      
      {error && (
        <div className="error-message">
          {error}
          <div className="error-actions">
            <button className="back-btn" onClick={prevStep}>
              Go Back and Recapture
            </button>
          </div>
        </div>
      )}
      
      <div className="comparison-hub-grid">
        {gridImages.map((image) => (
          <div 
            key={`grid-image-${image.position}`} 
            className={`grid-item div${image.position} ${image.isLiveness ? 'liveness-item' : ''}`}
          >
            <div className="grid-image-container">
              <h4>{image.type}</h4>
              <img
                src={image.url}
                alt={image.type}
                className={`grid-image ${image.isLiveness ? 'liveness-image' : 'kyc-image'}`}
              />
              
              {/* Show comparison result if available */}
              {image.result && !image.isLiveness && (
                <div className="comparison-badge">
                  <span className={`similarity ${
                    image.result.similarity >= 0.3 
                      ? 'match' 
                      : 'no-match'
                  }`}>
                    {(image.result.similarity * 100).toFixed(0)}%
                  </span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {/* Comparison Results Table */}
      {(comparisonResult || multiComparisonResults.length > 0) && (
        <div className="comparison-results-table">
          <h3>Comparison Results</h3>
          <table>
            <thead>
              <tr>
                <th>Document</th>
                <th>Similarity</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {comparisonResult && (
                <tr>
                  <td>Aadhaar Face</td>
                  <td>{(comparisonResult.similarity * 100).toFixed(2)}%</td>
                  <td className={comparisonResult.similarity >= 0.3 ? 'match-status' : 'no-match-status'}>
                    {comparisonResult.similarity >= 0.3 ? 'MATCH' : 'NO MATCH'}
                  </td>
                </tr>
              )}
              
              {multiComparisonResults.map((result, index) => (
                <tr key={`result-${index}`}>
                  <td>{result.type || `Document ${index + 1}`}</td>
                  <td>{(result.similarity * 100).toFixed(2)}%</td>
                  <td className={result.similarity >= 0.3 ? 'match-status' : 'no-match-status'}>
                    {result.similarity >= 0.3 ? 'MATCH' : 'NO MATCH'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      <div className="action-buttons">
        {!comparisonResult && (
          <button 
            className="compare-btn" 
            onClick={compareFaces}
            disabled={isLoading || !extractedFace || !livenessImage}
          >
            {isLoading ? 'Comparing...' : 'Compare Faces'}
          </button>
        )}
        
        {comparisonResult && (
          <div className="result-actions">
            <button className="back-btn" onClick={prevStep}>
              Back
            </button>
            <button 
              className="continue-btn" 
              onClick={handleContinue}
              disabled={isLoading || comparisonResult.similarity < 0.3}
            >
              Continue
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default FaceComparison;
