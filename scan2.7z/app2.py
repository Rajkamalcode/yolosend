import os
import numpy as np
from flask import Flask, request, jsonify
from pdf2image import convert_from_path
import cv2
import tempfile
from skimage.feature import local_binary_pattern, graycomatrix, graycoprops
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Configuration
UPLOAD_FOLDER = tempfile.gettempdir()
ALLOWED_EXTENSIONS = {'pdf'}
THRESHOLDS = {
    'lbp_variance': 0.15,      # Lower in photocopies
    'lbp_uniformity': 0.08,    # Higher in photocopies
    'glcm_contrast': 10,       # Lower in photocopies
    'glcm_homogeneity': 0.6,   # Higher in photocopies
    'glcm_energy': 0.2,        # Higher in photocopies
    'glcm_correlation': 0.7,   # Lower in photocopies
}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def calculate_lbp_features(gray):
    # Parameters for LBP
    radius = 3
    n_points = 8 * radius
    
    # Compute LBP
    lbp = local_binary_pattern(gray, n_points, radius, method='uniform')
    
    # Calculate histogram of LBP
    n_bins = n_points + 2
    hist, _ = np.histogram(lbp.ravel(), bins=n_bins, range=(0, n_bins), density=True)
    
    # Calculate features from LBP histogram
    lbp_variance = np.var(hist)
    lbp_uniformity = np.sum(hist ** 2)
    
    return lbp_variance, lbp_uniformity

def calculate_glcm_features(gray):
    # Normalize gray image to reduce computation
    gray = cv2.resize(gray, (256, 256))
    
    # Quantize the image to fewer gray levels to make GLCM computation more efficient
    bins = 16
    gray = (gray / (256 / bins)).astype(np.uint8)
    
    # Calculate GLCM
    distances = [1, 3, 5]
    angles = [0, np.pi/4, np.pi/2, 3*np.pi/4]
    glcm = graycomatrix(gray, distances=distances, angles=angles, 
                        levels=bins, symmetric=True, normed=True)
    
    # Calculate Haralick features
    contrast = graycoprops(glcm, 'contrast').mean()
    homogeneity = graycoprops(glcm, 'homogeneity').mean()
    energy = graycoprops(glcm, 'energy').mean()
    correlation = graycoprops(glcm, 'correlation').mean()
    
    return contrast, homogeneity, energy, correlation

def calculate_metrics(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Calculate LBP features
    lbp_variance, lbp_uniformity = calculate_lbp_features(gray)
    
    # Calculate GLCM features
    glcm_contrast, glcm_homogeneity, glcm_energy, glcm_correlation = calculate_glcm_features(gray)
    
    return {
        'lbp_variance': lbp_variance,
        'lbp_uniformity': lbp_uniformity,
        'glcm_contrast': glcm_contrast,
        'glcm_homogeneity': glcm_homogeneity,
        'glcm_energy': glcm_energy,
        'glcm_correlation': glcm_correlation
    }

def classify_page(metrics):
    score = 0
    
    # LBP features
    if metrics['lbp_variance'] < THRESHOLDS['lbp_variance']:
        score += 1.5  # Lower texture variance in photocopies
    
    if metrics['lbp_uniformity'] > THRESHOLDS['lbp_uniformity']:
        score += 1.5  # Higher uniformity in photocopies
    
    # GLCM features
    if metrics['glcm_contrast'] < THRESHOLDS['glcm_contrast']:
        score += 1.0  # Lower contrast in photocopies
    
    if metrics['glcm_homogeneity'] > THRESHOLDS['glcm_homogeneity']:
        score += 1.0  # Higher homogeneity in photocopies
    
    if metrics['glcm_energy'] > THRESHOLDS['glcm_energy']:
        score += 1.0  # Higher energy in photocopies (more uniform)
    
    if metrics['glcm_correlation'] < THRESHOLDS['glcm_correlation']:
        score += 1.0  # Lower correlation in photocopies
    
    return "photocopy" if score >= 4 else "original"

@app.route('/analyze', methods=['POST'])
def analyze_pdf():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['file']
    if file and allowed_file(file.filename):
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(temp_path)
        
        try:
            images = convert_from_path(temp_path, dpi=300)
            results = []
            
            for idx, image in enumerate(images):
                img = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
                metrics = calculate_metrics(img)
                classification = classify_page(metrics)
                
                results.append({
                    'page': idx + 1,
                    'classification': classification,
                    'metrics': metrics
                })
            
            os.remove(temp_path)
            return jsonify({'results': results})
        
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    return jsonify({'error': 'Invalid file'}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5022, debug=True)
