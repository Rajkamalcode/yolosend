import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import "../styles/adminpage.css";
 
const AdminDashboard = () => {
  const { register, handleSubmit, formState: { errors }, reset } = useForm();
  const [createUserError, setCreateUserError] = useState("");
  const [createUserSuccess, setCreateUserSuccess] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showAdminPassword, setShowAdminPassword] = useState(false);
  const navigate = useNavigate();
 
  useEffect(() => {
    const user = JSON.parse(sessionStorage.getItem("user"));
    if (!user || user.role !== "admin") {
      window.alert("Unauthorized Access")
      navigate("/"); // Redirect to login if not admin
    }
  }, [navigate]);
 
  const onSubmit = async (data) => {
    try {
      const admin = JSON.parse(sessionStorage.getItem("user"));
      const response = await fetch(`${import.meta.env.VITE_API}/createuser`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          admin_username: admin.username,
          admin_password: data.admin_password,
          username: data.username,
          password: data.password,
          role: data.userrole,
        }),
      });
 
      const result = await response.json();
 
      if (result.success) {
        setCreateUserSuccess("User created successfully");
        setCreateUserError("");
        reset();
      } else {
        setCreateUserError(result.message || "Failed to create user");
        setCreateUserSuccess("");
      }
    } catch (error) {
      console.error("User creation failed:", error);
      setCreateUserError("An error occurred. Please try again.");
      setCreateUserSuccess("");
    }
  };
 
  const handleLogout = () => {
    sessionStorage.removeItem("user");
    navigate("/");
  };
 
  return (
    <div className="admin-dashboard">
      <div className="admin-header">
        <h2>Admin Dashboard</h2>
      </div>
      <form onSubmit={handleSubmit(onSubmit)} className="create-user-form">
        <h3>Create New User</h3>
        <div className="form-group">
          <label htmlFor="username">New Username</label>
          <input
            type="text"
            id="username"
            {...register("username", { required: "Username is required" })}
          />
          {errors.username && (
            <span className="error-message">{errors.username.message}</span>
          )}
        </div>
        <div className="form-group">
          <label htmlFor="password">New Password</label>
          <div className="password-input-wrapper">
            <input
              type={showNewPassword ? "text" : "password"}
              id="password"
              {...register("password", { required: "Password is required" })}
            />
            <button
              type="button"
              onClick={() => setShowNewPassword(!showNewPassword)}
              className="toggle-password"
            >
              {showNewPassword ? "Hide" : "Show"}
            </button>
          </div>
          {errors.password && (
            <span className="error-message">{errors.password.message}</span>
          )}
        </div>
        <div className="form-group">
          <label htmlFor="userrole">Role</label>
          <input
            type="text"
            id="userrole"
            {...register("userrole", { required: "Role is required" })}
          />
          {errors.userrole && (
            <span className="error-message">{errors.userrole.message}</span>
          )}
        </div>
        <div className="form-group">
          <label htmlFor="admin_password">Your Admin Password</label>
          <div className="password-input-wrapper">
            <input
              type={showAdminPassword ? "text" : "password"}
              id="admin_password"
              {...register("admin_password", {
                required: "Admin password is required",
              })}
            />
            <button
              type="button"
              onClick={() => setShowAdminPassword(!showAdminPassword)}
              className="toggle-password"
            >
              {showAdminPassword ? "Hide" : "Show"}
            </button>
          </div>
          {errors.admin_password && (
            <span className="error-message">
              {errors.admin_password.message}
            </span>
          )}
        </div>
        <button type="submit" className="submit-button">
          Create User
        </button>
      </form>
      {createUserError && <p className="error-message">{createUserError}</p>}
      {createUserSuccess && <p className="success-message">{createUserSuccess}</p>}
    </div>
  );
};
 
export default AdminDashboard;