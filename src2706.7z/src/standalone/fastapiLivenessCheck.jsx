import React, { useState, useRef, useEffect, useCallback } from 'react';
import '../components/LivenessCheck.css'; // Ensure this path is correct
import config from '../services/config';

const FastapiLivenessCheck = () => {
  const [streaming, setStreaming] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [status, setStatus] = useState('Ready to start');
  const [statusClass, setStatusClass] = useState('pending');
  const [progress, setProgress] = useState(0);
  const [capturedDmsId, setCapturedDmsId] = useState(null);
  const [capturedImageUrl, setCapturedImageUrl] = useState(null);
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [spoofingDetected, setSpoofingDetected] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [livenessComplete, setLivenessComplete] = useState(false);
  const [locationStatus, setLocationStatus] = useState('pending');
  const [originData, setOriginData] = useState(null);
  const [geoPermissionGranted, setGeoPermissionGranted] = useState(false);
  const [mode, setMode] = useState('liveness');
  const [propertyPhotoUrl, setPropertyPhotoUrl] = useState(null);
  const [propertyDmsId, setPropertyDmsId] = useState(null);
  const [propertyPhotoStatus, setPropertyPhotoStatus] = useState('ready');
  const [webSocketReady, setWebSocketReady] = useState(false);
  const [showInstructions, setShowInstructions] = useState(true);
  const [showDebug, setShowDebug] = useState(false);
  const [isMobile, setIsMobile] = useState(null);
  const [isProcessingUpload, setIsProcessingUpload] = useState(false);

  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  const processingIntervalRef = useRef(null);
  const webSocketRef = useRef(null);
  const geoSentRef = useRef(false);
  const instructionVideoRef = useRef(null);

  const serverUrl = config.livenessServerUrl;

  // Detect if user is on mobile device
  useEffect(() => {
    const checkMobile = () => {
      const userAgent = navigator.userAgent || navigator.vendor || window.opera;
      
      // More specific mobile detection
      const isAndroid = /Android/i.test(userAgent);
      const isIOS = /iPhone|iPad|iPod/i.test(userAgent);
      const isWindowsPhone = /Windows Phone/i.test(userAgent);
      const isBlackBerry = /BlackBerry/i.test(userAgent);
      
      // Check for specific mobile browsers
      const isMobileBrowser = /Mobile|mini|Fennec|Android|iP(ad|od|hone)/i.test(userAgent);
      
      // Touch capability (but exclude desktop touch screens)
      const hasTouchScreen = 'ontouchstart' in window && navigator.maxTouchPoints > 0;
      
      // Screen size as secondary check
      const isSmallScreen = window.screen.width <= 768 || window.screen.height <= 768;
      
      // Combine checks - prioritize user agent over touch/screen size
      const isMobileDevice = isAndroid || isIOS || isWindowsPhone || isBlackBerry || 
                                (isMobileBrowser && hasTouchScreen) ||
                                (hasTouchScreen && isSmallScreen && isMobileBrowser);
          
          console.log('Setting isMobile to:', isMobileDevice);
          setIsMobile(isMobileDevice);
      

      console.log('Enhanced device detection:', { 
        userAgent: userAgent.substring(0, 50) + '...', 
        isAndroid, 
        isIOS, 
        isWindowsPhone,
        isBlackBerry,
        isMobileBrowser,
        hasTouchScreen, 
        isSmallScreen,
        final: isMobileDevice 
      });
    };
    
    checkMobile();
    // Don't add resize listener for mobile detection
  }, []);



  const getGeolocation = useCallback(() => {
    if (geoPermissionGranted) {
      console.log("Geolocation permission already granted, skipping request");
      return;
    }
    if (navigator.geolocation) {
      setLocationStatus('requesting');
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const geoData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date().toISOString()
          };
          console.log("Geolocation obtained:", geoData);
          setLocationStatus('captured');
          setGeoPermissionGranted(true);
          setOriginData(prevData => ({ ...prevData, geoLocation: geoData }));
        },
        (error) => {
          console.error("Geolocation error:", error);
          setLocationStatus('error');
          let errorMessage = "Location access error";
          switch(error.code) {
            case error.PERMISSION_DENIED: errorMessage = "Location permission denied. Please enable location access."; break;
            case error.POSITION_UNAVAILABLE: errorMessage = "Location information unavailable."; break;
            case error.TIMEOUT: errorMessage = "Location request timed out."; break;
            default: errorMessage = "Unknown location error occurred.";
          }
          setStatus(errorMessage); setStatusClass('error');
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      console.warn("Geolocation not supported");
      setLocationStatus('error');
      setStatus("Browser doesn't support geolocation."); setStatusClass('error');
    }
  }, [geoPermissionGranted]);

  useEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const origin = queryParams.get('origin');
    const callbackUrl = queryParams.get('callbackUrl');
    const requestId = queryParams.get('requestId');
    const token = queryParams.get('token');
    const captureMode = queryParams.get('mode');
    const vertical = queryParams.get('vertical'); // Extract vertical information

    setMode(captureMode === 'property' ? 'property' : 'liveness');
    
    if (origin && callbackUrl) {
      setOriginData({ origin, callbackUrl, requestId, token, vertical });
      console.log(`Mode: ${mode}, Origin: ${origin}, Callback: ${callbackUrl}, Vertical: ${vertical}`);
    } else {
      setStatus('Missing required parameters (origin, callbackUrl).');
      setStatusClass('error');
      console.warn('Missing required parameters for standalone mode');
    }
  }, [mode]);

  useEffect(() => {
    getGeolocation();
  }, [getGeolocation]);

  const startWebcam = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Browser doesn't support camera access.");
      }
      
      // Use rear camera for property mode on mobile, front camera for liveness
      const facingMode = (mode === 'property' && isMobile) ? 'environment' : 'user';
      
      console.log(`Starting webcam with facing mode: ${facingMode} (mode: ${mode}, mobile: ${isMobile})`);
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 }, 
          height: { ideal: 720 }, 
          facingMode: facingMode 
        },
        audio: false
      });
      
      if (webcamRef.current) {
        webcamRef.current.srcObject = stream;
        return new Promise((resolve) => {
          webcamRef.current.onloadedmetadata = () => {
            setStreaming(true); 
            resolve(true);
          };
        });
      }
      return false;
    } catch (error) {
      console.error('Error accessing webcam:', error);
      
      // If rear camera fails on mobile for property mode, try front camera as fallback
      if (mode === 'property' && isMobile && error.name === 'OverconstrainedError') {
        console.log('Rear camera not available, trying front camera as fallback');
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { 
              width: { ideal: 1280 }, 
              height: { ideal: 720 }, 
              facingMode: 'user' 
            },
            audio: false
          });
          
          if (webcamRef.current) {
            webcamRef.current.srcObject = stream;
            return new Promise((resolve) => {
              webcamRef.current.onloadedmetadata = () => {
                setStreaming(true); 
                resolve(true);
              };
            });
          }
        } catch (fallbackError) {
          console.error('Fallback camera also failed:', fallbackError);
        }
      }
      
      let errorMsg = `Error accessing webcam: ${error.message}`;
      if (error.name === 'NotAllowedError') errorMsg = 'Camera access denied. Please allow camera access to continue.';
      else if (error.name === 'NotFoundError') errorMsg = 'No camera found on this device.';
      else if (error.name === 'NotReadableError') errorMsg = 'Camera is currently in use by another application.';
      else if (error.name === 'OverconstrainedError') errorMsg = 'Camera constraints not supported. Trying alternative camera.';
      
      setStatus(errorMsg); 
      setStatusClass('error');
      return false;
    }
  };


  const stopWebcam = () => {
    if (webcamRef.current && webcamRef.current.srcObject) {
      webcamRef.current.srcObject.getTracks().forEach(track => track.stop());
      webcamRef.current.srcObject = null;
    }
    setStreaming(false);
    if (processingIntervalRef.current) {
      clearInterval(processingIntervalRef.current);
      processingIntervalRef.current = null;
    }
  };

  const captureFrame = () => {
    if (webcamRef.current && webcamRef.current.readyState === webcamRef.current.HAVE_ENOUGH_DATA && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = webcamRef.current.videoWidth;
      canvasRef.current.height = webcamRef.current.videoHeight;
      context.drawImage(webcamRef.current, 0, 0);
      return canvasRef.current.toDataURL('image/jpeg', 0.5);
    }
    return null;
  };
  
  const sendResultToOrigin = useCallback((result) => {
      if (!originData || !originData.origin) {
          console.warn('Cannot send result: missing origin data');
          return;
      }
      
      const resultPayload = { ...result };
      if (originData.requestId) resultPayload.requestId = originData.requestId;
      if (originData.geoLocation) resultPayload.geoLocation = originData.geoLocation;
      if (originData.vertical) resultPayload.vertical = originData.vertical;

      console.log('Sending result to origin:', originData.origin, 'Payload:', resultPayload);

      try {
          if (window.opener) {
              window.opener.postMessage({ type: 'LIVENESS_RESULT', data: resultPayload }, '*');
              console.log('Result sent via postMessage to opener');
          } else if (window.parent && window.parent !== window) {
              window.parent.postMessage({ type: 'LIVENESS_RESULT', data: resultPayload }, '*');
              console.log('Result sent via postMessage to parent');
          }
      } catch (e) { console.warn('Could not send via postMessage:', e); }

      if (originData.callbackUrl && !originData.callbackUrl.startsWith('file://')) {
          fetch(originData.callbackUrl, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(resultPayload)
          })
          .then(response => {
              console.log('Result sent via fetch to callback URL, status:', response.status);
              if (response.ok && resultPayload.success && resultPayload.dms_id && sessionId) {
                  fetch(`${serverUrl}/complete_standalone_session/${sessionId}`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ 
                          liveness_confirmed: true, 
                          dms_id: resultPayload.dms_id,
                          vertical: originData.vertical
                      })
                  });
              }
          })
          .catch(error => console.error('Error sending result to callback URL:', error));
      }

      // Only auto-close window if the verification was successful or user cancelled
      // Don't close on any failures (including retry failures, server errors, max retries)
      if (resultPayload.success || resultPayload.status === 'cancelled') {
          setTimeout(() => {
              try {
                  window.close();
              } catch (e) {
                  console.log('Could not close window automatically');
              }
          }, 2000);
      }
  }, [originData, sessionId, serverUrl]);


  const connectWebSocket = (sessionIdToConnect) => {
    if (webSocketRef.current) {
      webSocketRef.current.close();
    }

    const wsUrl = serverUrl.replace(/^http/, 'ws') + `/ws/liveness/${sessionIdToConnect}`;
    console.log(`Connecting to WebSocket: ${wsUrl}`);
    const ws = new WebSocket(wsUrl);
    webSocketRef.current = ws;

    ws.onopen = () => {
      console.log(`WebSocket connected for session ${sessionIdToConnect}`);
      setWebSocketReady(true);
      
      if (processingIntervalRef.current) clearInterval(processingIntervalRef.current);
      processingIntervalRef.current = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          const imageData = captureFrame();
          if (imageData) {
            ws.send(imageData);
          }
        } else {
          console.log("WebSocket not open, stopping frame sending.");
          clearInterval(processingIntervalRef.current);
        }
      }, 250);
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log("WebSocket message received:", data);

        setStatus(data.message || 'Processing...');
        setProgress(data.progress || 0);
        setCurrentChallenge(data.current_challenge);
        setSpoofingDetected(data.spoofing_detected || false);
        
        // Check if progress reached 100% but no DMS ID yet
        if (data.progress >= 100 && !data.dms_id && !isProcessingUpload) {
          setIsProcessingUpload(true);
          setStatus('Verification complete. Processing and uploading data...');
          setStatusClass('pending');
        }
        
        if (data.status === 'success') setStatusClass('success');
        else if (data.status === 'failed' || data.spoofing_detected) setStatusClass('error');
        else setStatusClass('pending');

        if (data.stop_webcam || data.dms_id) {
          setLivenessComplete(true);
          setIsProcessingUpload(false);
          stopWebcam();
          ws.close();
          setWebSocketReady(false);

          const result = {
            success: !data.spoofing_detected && data.status === 'success',
            status: data.spoofing_detected ? 'failed' : data.status,
            reason: data.spoofing_detected ? (data.message || 'Spoofing detected') : (data.message || 'Liveness check complete'),
            dms_id: data.dms_id,
            session_id: sessionIdToConnect
          };
          
          if (data.dms_id) {
            setCapturedDmsId(data.dms_id);
            setCapturedImageUrl(`${serverUrl}/get_captured_image/${sessionIdToConnect}`);
          }
          sendResultToOrigin(result);
        }
      } catch (error) {
        console.error("Error processing WebSocket message or invalid JSON:", error, event.data);
      }
    };

    ws.onclose = (event) => {
      console.log(`WebSocket disconnected for session ${sessionIdToConnect}`, event.reason, event.code);
      setWebSocketReady(false);
      if (processingIntervalRef.current) clearInterval(processingIntervalRef.current);
      
      if (!livenessComplete && streaming) {
        setStatus('Connection to server lost. Please try again.');
        setStatusClass('error');
        setLivenessComplete(true); 
        stopWebcam(); 
        sendResultToOrigin({
          success: false,
          status: 'error',
          reason: 'WebSocket connection lost'
        });
      }
    };

    ws.onerror = (error) => {
      console.error(`WebSocket error for session ${sessionIdToConnect}:`, error);
      if (streaming && !livenessComplete) {
        setStatus('A communication error occurred. Please try again.');
        setStatusClass('error');
      }
    };
  };

  useEffect(() => {
    if (mode === 'liveness' && webSocketReady && webSocketRef.current && 
        webSocketRef.current.readyState === WebSocket.OPEN) {
      
      // Send geolocation if available
      if (originData?.geoLocation && !geoSentRef.current) {
        console.log("Sending geolocation via WebSocket:", originData.geoLocation);
        webSocketRef.current.send(JSON.stringify({ geo_location: originData.geoLocation }));
        geoSentRef.current = true;
      }
      
      // Send vertical information if available
      if (originData?.vertical && !verticalSentRef.current) {
        console.log("Sending vertical information via WebSocket:", originData.vertical);
        webSocketRef.current.send(JSON.stringify({ vertical: originData.vertical }));
        verticalSentRef.current = true;
      }
    }
  }, [mode, webSocketReady, originData]);

  const verticalSentRef = useRef(false);


  const startLivenessSessionHTTP = async () => {
      try {
          console.log("Starting liveness session (HTTP)...");
          const response = await fetch(`${serverUrl}/start_liveness`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                  vertical: originData?.vertical || 'Unknown'
              })
          });
          const data = await response.json();
          if (data.success) {
              setSessionId(data.session_id);
              return data.session_id;
          } else {
              throw new Error(data.error || 'Failed to start liveness session');
          }
      } catch (error) {
          console.error('Error starting liveness session:', error);
          setStatus(`Error: ${error.message}`); setStatusClass('error');
          return null;
      }
  };


  const startLivenessCheck = async () => {
    setShowInstructions(false);
    setLivenessComplete(false);
    setIsProcessingUpload(false);
    setStatus('Initializing liveness check...'); setStatusClass('pending');
    setProgress(0); setCapturedImageUrl(null); setCapturedDmsId(null);
    setSpoofingDetected(false); setCurrentChallenge(null);
    geoSentRef.current = false;

    if (!streaming) {
      const webcamStarted = await startWebcam();
      if (!webcamStarted) return;
    }

    const newSessionId = await startLivenessSessionHTTP();
    if (newSessionId) {
      connectWebSocket(newSessionId);
    }
  };

  const capturePropertyPhoto = async () => {
      if (!streaming) {
          const webcamStarted = await startWebcam();
          if (!webcamStarted) return;
      }
      const imageData = captureFrame();
      if (!imageData) {
          setStatus('Failed to capture image'); setStatusClass('error'); return;
      }
      if (!originData?.geoLocation) {
          setStatus('Geolocation data is required for property photos.'); setStatusClass('error'); return;
      }

      setPropertyPhotoStatus('uploading'); setStatus('Uploading property photo...'); setStatusClass('pending');
      try {
          const response = await fetch(`${serverUrl}/capture_property_photo`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ 
                  image: imageData, 
                  geo_location: originData.geoLocation,
                  vertical: originData?.vertical || 'Unknown'  // Add vertical information
              })
          });
          const data = await response.json();
          if (data.success) {
              setPropertyPhotoStatus('success'); setStatus('Property photo captured!'); setStatusClass('success');
              setPropertyDmsId(data.dms_id);
              setPropertyPhotoUrl(`${serverUrl}/get_property_photo/${data.dms_id}`);
              stopWebcam();
              sendResultToOrigin({
                  success: true, 
                  status: 'success', 
                  type: 'property_photo',
                  dms_id: data.dms_id, 
                  photo_id: data.photo_id,
                  vertical: originData?.vertical  // Include vertical in the result
              });
          } else { throw new Error(data.error || 'Failed to upload property photo'); }
      } catch (error) {
          console.error('Error capturing property photo:', error);
          setPropertyPhotoStatus('error'); setStatus(`Error: ${error.message}`); setStatusClass('error');
      }
  };

  const stopLivenessCheck = () => {
    console.log("Stopping liveness check");
    setLivenessComplete(true);
    if (webSocketRef.current) {
      webSocketRef.current.close();
      webSocketRef.current = null;
    }
    setWebSocketReady(false);
    stopWebcam();
    
    setStatus('Liveness check cancelled by user.'); setStatusClass('pending');
    setProgress(0); setCapturedImageUrl(null);
    sendResultToOrigin({ success: false, status: 'cancelled', reason: 'User cancelled' });
  };

  const handleRetry = () => {
    const newRetryCount = retryCount + 1;
    setRetryCount(newRetryCount);

    if (newRetryCount >= 3) {
      setStatus('Maximum retry attempts reached. Verification failed.');
      setStatusClass('error');
      setLivenessComplete(true);
      // DON'T send result to origin - just show the failure state
      return;
    }

    // Clean up current session
    if (webSocketRef.current) { 
      webSocketRef.current.close(); 
      webSocketRef.current = null; 
    }
    setWebSocketReady(false);
    stopWebcam();

    // Reset states for retry
    setSpoofingDetected(false); 
    setLivenessComplete(false);
    setSessionId(null); 
    setCapturedImageUrl(null);
    setProgress(0); 
    setCurrentChallenge(null);
    setIsProcessingUpload(false);
    setStatus('Restarting liveness check...'); 
    setStatusClass('pending');
    
    // Start new attempt
    setTimeout(() => startLivenessCheck(), 500);
  };



  const getChallengeText = (challengeCode) => {
    if (challengeCode === 0) return "Blink your eyes";
    return "";
  };

  const proceedFromInstructions = () => {
    setShowInstructions(false);
    if (mode === 'liveness') {
      startLivenessCheck();
    } else {
      startWebcam();
    }
  };
  
  useEffect(() => {
    const checkServer = async () => {
      try {
        const response = await fetch(`${serverUrl}/test`);
        const data = await response.json();
        if (data.status === 'API is working') {
          console.log("Server is available");
          if (originData) {
            setStatus(mode === 'liveness' ? 'Ready for liveness check' : 'Ready for property photo');
          }
        } else { throw new Error('Server not responding correctly'); }
      } catch (error) {
        console.error('Error connecting to server:', error);
        setStatus('Error connecting to server.'); setStatusClass('error');
        // Send error result to origin but don't auto-close the window
        if (originData) {
          sendResultToOrigin({ 
            success: false, 
            status: 'error', 
            reason: 'Cannot connect to server' 
          });
        }
      }
    };
    
    if (originData) {
      checkServer();
    } else {
      setStatus('Waiting for origin parameters...');
    }

    return () => {
      console.log("Component unmounting, cleaning up");
      if (processingIntervalRef.current) clearInterval(processingIntervalRef.current);
      if (webSocketRef.current) { webSocketRef.current.close(); webSocketRef.current = null; }
      stopWebcam();
    };
  }, [originData, mode, geoPermissionGranted]);

  console.log(isMobile ? "Running in mobile mode" : "Running in desktop mode");
  return (
    <div className={`liveness-check standalone-mode ${mode} ${isMobile ? 'mobile' : 'desktop'}`}>
      {/* Instructions Screen */}
        {showInstructions && (
        <div className="instructions-overlay">
          <div className="instructions-content">
            <div className="company-header">
              <h2>🔒 Identity Verification</h2>
              <p className="company-subtitle">Secure Liveness Detection</p>
            </div>
            
            <p className="intro-text">
              {mode === 'liveness' 
                ? 'We need to verify your identity for security purposes. This process will take approximately 30 seconds.'
                : 'We need to capture a property photo with location data for documentation purposes.'}
            </p>

            
          <div className="video-instructions">
          {/* Add a key to force re-render when isMobile changes */}
          <video 
            key={`instruction-video-${isMobile ? 'mobile' : 'desktop'}`}
            ref={instructionVideoRef}
            autoPlay 
            loop 
            muted 
            playsInline
            className="instruction-video"
            onError={(e) => console.error('Video error:', e)}
            onLoadStart={() => console.log(`Video loading: ${isMobile ? 'mobile' : 'desktop'}`)}
          >
            <source 
              src={isMobile ? "/liveness-mobile.webm" : "/liveness-desktop.webm"} 
              type="video/webm" 
            />
            <div className="video-fallback">
              <p>Video instructions not available</p>
            </div>
          </video>
        </div>


          <div className="instruction-points">
            {mode === 'liveness' ? (
              <>
                <div className="instruction-item">
                  <span className="icon">📏</span>
                  <span>Keep the camera one arm's length away</span>
                </div>
                <div className="instruction-item">
                  <span className="icon">💡</span>
                  <span>Ensure adequate lighting on your face</span>
                </div>
                <div className="instruction-item">
                  <span className="icon">👤</span>
                  <span>Make sure only your face is visible</span>
                </div>
              </>
            ) : (
              <>
                <div className="instruction-item">
                  <span className="icon">🏠</span>
                  <span>Point camera at the property</span>
                </div>
                <div className="instruction-item">
                  <span className="icon">💡</span>
                  <span>Ensure good lighting for clear photo</span>
                </div>
                <div className="instruction-item">
                  <span className="icon">📍</span>
                  <span>Location will be embedded in the photo</span>
                </div>
              </>
            )}
          </div>


            <div className="location-permission">
              <div className={`location-status ${locationStatus}`}>
                {locationStatus === 'pending' && <span>📍 Requesting location access...</span>}
                {locationStatus === 'requesting' && <span>📍 Obtaining location data...</span>}
                {locationStatus === 'captured' && originData?.geoLocation && (
                  <span>✅ Location verified successfully</span>
                )}
                {locationStatus === 'error' && <span>⚠️ Location access is required for verification</span>}
              </div>
            </div>

            <button 
              className="proceed-btn"
              onClick={proceedFromInstructions}
              disabled={!geoPermissionGranted || !originData}
            >
              {geoPermissionGranted ? 'Begin Verification' : 'Waiting for permissions...'}
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      {!showInstructions && (
        <>
          <div className="header-section">
            <h2>{mode === 'liveness' ? '🔒 Identity Verification' : '📷 Property Documentation'}</h2>
            {mode === 'liveness' && !livenessComplete && (
              <button 
                className="back-to-instructions"
                onClick={() => setShowInstructions(true)}
              >
                ← View Instructions
              </button>
            )}
          </div>
          
          <div className="status-section">
            <div className={`detection-result ${statusClass}`}>
              <span className="status-icon">
                {statusClass === 'success' && '✅'}
                {statusClass === 'error' && '❌'}
                {statusClass === 'pending' && '⏳'}
              </span>
              {status}
            </div>
            {mode === 'liveness' && !livenessComplete && progress > 0 && (
              <div className="progress-container">
                <div className="progress-bar" style={{ width: `${progress}%` }}></div>
                <span className="progress-text">{Math.round(progress)}%</span>
              </div>
            )}
            {isProcessingUpload && (
              <div className="upload-indicator">
                <div className="spinner"></div>
                <span>Finalizing verification...</span>
              </div>
            )}
          </div>
          
          {mode === 'liveness' && spoofingDetected && (
            <div className="spoofing-alert">
              <div className="alert-content">
                <h3>⚠️ Verification Failed</h3>
                <p>Please ensure you are not using a photograph, screen, or mask. Position yourself in good lighting and try again.</p>
                {retryCount < 2 && <p className="retry-info">Attempts remaining: {2 - retryCount}</p>}
                {retryCount >= 2 ? (
                  <div className="max-attempts-reached">
                    <p><strong>Maximum attempts reached. Verification failed.</strong></p>
                    <button className="close-btn secondary-btn" onClick={() => window.close()}>
                      <span className="btn-icon">✖️</span>
                      Close Window
                    </button>
                  </div>
                ) : (
                  <button 
                    className="retry-btn"
                    onClick={handleRetry}
                  >
                    Retry Verification ({retryCount + 1}/3)
                  </button>
                )}
              </div>
            </div>
          )}

          {!spoofingDetected && (
            <>
              <div className="webcam-section">
                <div className="video-container">
                  {(!capturedImageUrl && !propertyPhotoUrl) && (
                    <>
                      <video ref={webcamRef} autoPlay playsInline muted className="webcam-feed"></video>
                      <div className="face-outline"></div>
                    </>
                  )}
                  <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
                  
                  {mode === 'liveness' && currentChallenge !== null && streaming && !capturedImageUrl && (
                    <div className="challenge-overlay">
                      <div className="challenge-instruction">
                        <span className="challenge-icon">👁️</span>
                        <span className="challenge-text">{getChallengeText(currentChallenge)}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Liveness Controls */}
              {mode === 'liveness' && !capturedImageUrl && !livenessComplete && (
                <div className="controls">
                  {!streaming && (
                    <button 
                      className="start-btn primary-btn" 
                      onClick={startLivenessCheck} 
                      disabled={!geoPermissionGranted || !originData}
                    >
                      <span className="btn-icon">🎥</span>
                      Start Camera
                    </button>
                  )}
                  {streaming && (
                    <button 
                      className="stop-btn secondary-btn" 
                      onClick={stopLivenessCheck}
                    >
                      <span className="btn-icon">⏹️</span>
                      Cancel Verification
                    </button>
                  )}
                </div>
              )}
              
              {/* Property Photo Controls */}
              {mode === 'property' && !propertyPhotoUrl && (
                <div className="controls">
                  {!streaming && (
                    <button 
                      className="start-btn primary-btn" 
                      onClick={startWebcam} 
                      disabled={!geoPermissionGranted || !originData}
                    >
                      <span className="btn-icon">📷</span>
                      Start Camera
                    </button>
                  )}
                  {streaming && (
                    <>
                      <button 
                        className="capture-btn primary-btn" 
                        onClick={capturePropertyPhoto} 
                        disabled={propertyPhotoStatus === 'uploading' || !geoPermissionGranted}
                      >
                        <span className="btn-icon">📸</span>
                        {propertyPhotoStatus === 'uploading' ? 'Processing...' : 'Capture Photo'}
                      </button>
                      <button 
                        className="stop-btn secondary-btn" 
                        onClick={stopWebcam}
                      >
                        <span className="btn-icon">⏹️</span>
                        Stop Camera
                      </button>
                    </>
                  )}
                </div>
              )}
              
              {/* Success Displays */}
              {capturedImageUrl && mode === 'liveness' && (
                <div className="capture-success">
                  <div className="success-content">
                    <h3>✅ Verification Successful!</h3>
                    <img className="captured-image" src={capturedImageUrl} alt="Identity verification capture" />
                    <p>Your identity has been successfully verified. Closing window...</p>
                  </div>
                </div>
              )}
              
              {propertyPhotoUrl && mode === 'property' && (
                <div className="capture-success">
                  <div className="success-content">
                    <h3>✅ Photo Captured!</h3>
                    <img className="captured-image" src={propertyPhotoUrl} alt="Property documentation" />
                    <p>Property photo captured successfully. Closing window...</p>
                  </div>
                </div>
              )}
              
              {/* Manual Close Button - only show for errors that don't auto-close */}
              {(statusClass === 'error' && status.includes('Error connecting to server')) && (
                <div className="controls">
                  <button className="close-btn secondary-btn" onClick={() => window.close()}>
                    <span className="btn-icon">✖️</span>
                    Close Window
                  </button>
                </div>
              )}
            </>
          )}
        </>
      )}

      {/* Debug Panel */}
      {process.env.NODE_ENV !== 'production' && (
        <div className="debug-panel">
          <button 
            className="debug-toggle"
            onClick={() => setShowDebug(!showDebug)}
          >
            🐛 Debug {showDebug ? '▼' : '▶'}
          </button>
          {showDebug && (
            <div className="debug-content">
              <h4>Debug Information</h4>
              <div className="debug-grid">
                <div><strong>Mode:</strong> {mode}</div>
                <div><strong>Device:</strong> {isMobile ? 'Mobile' : 'Desktop'}</div>
                <div><strong>Session ID:</strong> {sessionId || 'N/A'}</div>
                <div><strong>Liveness Complete:</strong> {livenessComplete.toString()}</div>
                <div><strong>Streaming:</strong> {streaming.toString()}</div>
                <div><strong>WebSocket Ready:</strong> {webSocketReady.toString()}</div>
                <div><strong>Geo Permission:</strong> {geoPermissionGranted.toString()}</div>
                <div><strong>Location Status:</strong> {locationStatus}</div>
                <div><strong>Show Instructions:</strong> {showInstructions.toString()}</div>
                <div><strong>Retry Count:</strong> {retryCount}</div>
                <div><strong>Progress:</strong> {progress}%</div>
                <div><strong>Current Challenge:</strong> {currentChallenge || 'N/A'}</div>
                <div><strong>Spoofing Detected:</strong> {spoofingDetected.toString()}</div>
                <div><strong>Processing Upload:</strong> {isProcessingUpload.toString()}</div>
              </div>
              {originData?.geoLocation && (
                <div className="geo-info">
                  <strong>Geolocation:</strong> 
                  <br />Lat: {originData.geoLocation.latitude.toFixed(5)}
                  <br />Lng: {originData.geoLocation.longitude.toFixed(5)}
                  <br />Accuracy: {originData.geoLocation.accuracy}m
                </div>
              )}
              {originData && (
                <div className="origin-info">
                  <strong>Origin Data:</strong>
                  <pre>{JSON.stringify(originData, null, 2)}</pre>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FastapiLivenessCheck;