import os
import io
import numpy as np
import cv2
from PIL import Image
from flask import Flask, request, jsonify, render_template, send_from_directory
from insightface.app import FaceAnalysis
import logging
from flask_cors import CORS
from search import FaceSearchSystem  # Import the search system
from bson import ObjectId
import json
# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
# More permissive CORS for debugging
CORS(app, resources={r"/*": {"origins": "*"}})

# Configuration for search system
CONFIG = {
    "MILVUS_HOST": "localhost",
    "MILVUS_PORT": "19530",
    "COLLECTION_NAME": "indian_face_deduplication",
    "USE_GPU": True,
    "DETECTION_THRESHOLD": 0.4,
    "ANGULAR_MARGIN": 0.1,
    "FACE_DETECTION_THRESHOLD": 0.5,
    "MONGO_URI": "mongodb://bridgedevwrite:BridgedevWrite890@10.9.50.43:10050/",
    "MONGO_DB": "chola_face_db",
    "MONGO_COLLECTION": "face_images"
}

# Initialize face model
def init_face_model():
    """Initialize InsightFace model"""
    logger.info("Initializing face model")
    model_dir = os.path.expanduser("~/.insightface/models/buffalo_m")
    
    face_app = FaceAnalysis(name='buffalo_m', model_dir=model_dir)
    # Use GPU if available, otherwise CPU
    ctx_id = 0  # Change to -1 for CPU
    face_app.prepare(ctx_id=ctx_id, det_size=(640, 640), det_thresh=0.5)
    logger.info("Face model initialized")
    return face_app

# Process image bytes and extract face embedding
def process_image(face_app, image_bytes):
    """Process image bytes and extract face embedding"""
    try:
        img = Image.open(io.BytesIO(image_bytes))
        img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        faces = face_app.get(img)
        if not faces:
            raise ValueError("No faces detected")
        return faces[0].normed_embedding
    except Exception as e:
        logger.error(f"Image processing failed: {str(e)}")
        return None

# Calculate similarity between two face embeddings
def calculate_similarity(emb1, emb2, margin=0.1):
    """Calculate similarity between two face embeddings with margin adjustment"""
    # Compute cosine similarity
    cosine_sim = np.dot(emb1, emb2)
    
    # Convert to angular distance
    angle = np.arccos(np.clip(cosine_sim, -1.0, 1.0))
    
    # Apply margin adjustment
    adjusted_angle = angle + margin
    
    # Convert back to similarity score
    final_score = np.cos(adjusted_angle)
    
    return {
        "original_similarity": float(cosine_sim),
        "angular_distance": float(angle),
        "adjusted_similarity": float(final_score)
    }

@app.before_request
def log_request_info():
    logger.info('Headers: %s', request.headers)
    logger.info('Body: %s', request.get_data())
    logger.info('Files: %s', request.files.keys())


# Initialize the face model
face_app = init_face_model()

# Initialize the search system
search_system = None
try:
    search_system = FaceSearchSystem(CONFIG)
    logger.info("Face Search System initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize Face Search System: {str(e)}")

@app.route('/compare', methods=['POST'])
def compare_faces():
    """Compare two face images and return similarity scores"""
    logger.info("Received /compare request")
    
    if 'image1' not in request.files or 'image2' not in request.files:
        logger.warning("Missing required images in request")
        return jsonify({"error": "Two images required"}), 400
    
    try:
        # Get image bytes
        logger.info("Reading image files from request")
        image1_bytes = request.files['image1'].read()
        image2_bytes = request.files['image2'].read()
        logger.info(f"Received image1: {len(image1_bytes)} bytes, image2: {len(image2_bytes)} bytes")
        
        # Process images
        logger.info("Processing image1")
        emb1 = process_image(face_app, image1_bytes)
        logger.info("Processing image2")
        emb2 = process_image(face_app, image2_bytes)
        
        if emb1 is None or emb2 is None:
            logger.warning("Face detection failed")
            return jsonify({"error": "Face detection failed on one or both images"}), 400
        
        # Calculate similarity
        margin = float(request.form.get('margin', 0.1))
        logger.info(f"Calculating similarity with margin {margin}")
        similarity = calculate_similarity(emb1, emb2, margin)
        logger.info(f"Similarity results: {similarity}")
        
        return jsonify({
            "status": "success",
            "similarity": similarity
        })
    
    except Exception as e:
        logger.error(f"Comparison failed: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Add this class to handle ObjectId serialization
class JSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        return super(JSONEncoder, self).default(obj)

@app.route('/search', methods=['POST'])
def search_database():
    """Search for a face in the database"""
    logger.info("Received /search request")
    
    if 'image' not in request.files:
        logger.warning("Missing required image in request")
        return jsonify({"error": "Image required"}), 400
    
    if search_system is None:
        logger.error("Search system not initialized")
        return jsonify({"error": "Search system not available"}), 500
    
    try:
        # Get image bytes
        logger.info("Reading image file from request")
        image_bytes = request.files['image'].read()
        logger.info(f"Received image: {len(image_bytes)} bytes")
        
        # Set threshold from request or use default
        threshold = float(request.form.get('threshold'))
        
        # Perform search
        logger.info(f"Searching database with threshold {threshold}")
        results, metrics = search_system.search(image_bytes, threshold)
        
        # Convert ObjectId to string in results
        for result in results:
            if 'image_id' in result and isinstance(result['image_id'], ObjectId):
                result['image_id'] = str(result['image_id'])
        
        # Format response
        response = {
            "status": "success",
            "results": results,
            "metrics": {
                "total_time": metrics.get('total_time', 0),
                "processing_time": metrics.get('processing_time', 0),
                "search_time": metrics.get('search_time', 0),
                "mongo_time": metrics.get('mongo_time', 0),
                "candidates_found": metrics.get('candidates_found', 0),
                "verified_matches": metrics.get('verified_matches', 0),
                "metadata_retrieved": metrics.get('metadata_retrieved', 0)
            },
            "system_metrics": search_system.get_system_metrics()
        }
        
        logger.info(f"Search completed with {len(results)} results")
        # Use the custom JSON encoder
        return app.response_class(
            response=json.dumps(response, cls=JSONEncoder),
            status=200,
            mimetype='application/json'
        )
    
    except Exception as e:
        logger.error(f"Search failed: {str(e)}")
        return jsonify({"error": str(e)}), 500



@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy"})

# Serve static files
@app.route('/', methods=['GET'])
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)
