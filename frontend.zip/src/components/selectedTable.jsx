import React, { useState, useEffect } from 'react';
import { AgGridReact } from 'ag-grid-react';
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import '../styles/styles.css';
const SelectedCandidatesTable = () => {
    const [rowData, setRowData] = useState([]);
    const [userInfo, setUserInfo] = useState(JSON.parse(sessionStorage.getItem('user')));
    const [showAllDates, setShowAllDates] = useState(false);
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [showDateRange, setShowDateRange] = useState(false);

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const columnDefs = [
        { field: "name", headerName: "Name", filter: true },
        { field: "selected_job_role.job_role", headerName: "Selected For", filter: true },
        { field: "email", headerName: "Email", filter: true },
        { field: "phone", headerName: "Phone", filter: true },
        { field: "selected_job_role.selected_by", headerName: "Selected By", filter: true },
        {
            field: "selected_job_role.selected_date",
            headerName: "Selection Date",
            filter: true,
            valueFormatter: (params) => {
                if (!params.value) return '';
                return new Date(params.value).toLocaleDateString();
            }
        }
    ];

    useEffect(() => {
        setUserInfo(JSON.parse(sessionStorage.getItem('user')));
        const endpoint = userInfo?.role === 'admin' 
            ? '/selected_candidates'
            : `/selected_candidates/${userInfo?.username}`;

        fetch(`${import.meta.env.VITE_API}${endpoint}`)
            .then(res => res.json())
            .then(data => setRowData(data))
            .catch(err => console.error("Error fetching selected candidates:", err));
    }, [userInfo?.role, userInfo?.username]);

    const handleDateRangeFilter = (params) => {
        if (!startDate || !endDate || !showDateRange) return true;
        
        const selectionDate = new Date(params.data.selected_job_role.selected_date);
        const rangeStart = new Date(startDate);
        const rangeEnd = new Date(endDate);
        rangeEnd.setHours(23, 59, 59);
        
        return selectionDate >= rangeStart && selectionDate <= rangeEnd;
    };

    return (
        <>
            <div style={{ marginBottom: '10px', display: 'flex', gap: '10px', alignItems: 'center' }}>
                <button 
                    onClick={() => setShowAllDates(!showAllDates)}
                    className="toggle-button"
                >
                    {showAllDates ? 'Show Last 6 Months' : 'Show All Dates'}
                </button>
                <button 
                    onClick={() => setShowDateRange(!showDateRange)}
                    className="toggle-button"
                >
                    {showDateRange ? 'Hide Date Range' : 'Filter by Date'}
                </button>
                {showDateRange && (
                    <div className="date-range-controls">
                        <input
                            type="date"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            className="date-input"
                        />
                        <span>to</span>
                        <input
                            type="date"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            className="date-input"
                        />
                    </div>
                )}
            </div>
            <div className="ag-theme-alpine" style={{
                height: 'calc(100vh - 270px)',
                width: '100%',
                marginBottom: '20px'
            }}>
                <AgGridReact
                    rowData={rowData}
                    columnDefs={columnDefs}
                    pagination={true}
                    defaultColDef={{
                        sortable: true
                    }}
                    isExternalFilterPresent={() => showDateRange || !showAllDates}
                    doesExternalFilterPass={(node) => {
                        if (showDateRange) {
                            return handleDateRangeFilter(node);
                        }
                        if (!showAllDates) {
                            const selectionDate = new Date(node.data.selected_job_role.selected_date);
                            return selectionDate >= sixMonthsAgo;
                        }
                        return true;
                    }}
                />
            </div>
        </>
    );
};

export default SelectedCandidatesTable;
