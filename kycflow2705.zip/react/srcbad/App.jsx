import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import './App.css';
import AdminPanel from './components/AdminPanel';
import KycFlow from './components/KycFlow';

// This component will handle the KYC route with query parameters
function KycRoute() {
  const location = useLocation();
  // Just pass the current location (with query params) to the KycFlow component
  return <KycFlow />;
}

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/kyc" element={<KycRoute />} />
          <Route path="/" element={<Navigate to="/admin" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
