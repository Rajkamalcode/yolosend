import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api'; // Update with your Flask server URL

export interface ProcessedFile {
  original_text: string;
  translation: string;
  detected_language: {
    code: string;
    name: string;
  };
  notes: string[];
  error?: string;
  warning?: string;
  tables?: Array<{
    page: number;
    table: string;
  }>;
  embedded_html_tables?: string;
}

export interface SessionResponse {
  session_id: string;
  processed_files: Record<string, ProcessedFile>;
  analysis_result: string;
  usable_files_count: number;
  total_files_count: number;
  chat_history?: Array<{
    role: string;
    content: string;
  }>;
}

export interface ChatRequest {
  session_id: string;
  query: string;
  chat_history: Array<{
    role: string;
    content: string;
  }>;
  ollama_url?: string;
  model_name?: string;
}

export interface ChatResponse {
  response: string;
  chat_history: Array<{
    role: string;
    content: string;
  }>;
}

export interface ServerStatus {
  tesseract_ok: boolean;
  poppler_ok: boolean;
  languages_for_ocr: string;
  default_analysis_model: string;
  default_ollama_url: string;
  ollama_reachable: boolean;
  ollama_error?: string;
  ollama_url?: string;
  translation_model?: string;
  identification_model?: string;
  system_info: {
    platform: string;
    python_version: string;
    non_english_word_threshold: number;
  };
}

export interface SessionInfo {
  session_id: string;
  created_at: string;
  file_count: number;
  usable_file_count: number;
  has_analysis: boolean;
  files: string[];
}

const documentService = {
  // Upload and process documents
  processDocuments: async (files: File[], ollamaUrl?: string, modelName?: string): Promise<SessionResponse> => {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });
    
    if (ollamaUrl) formData.append('ollama_url', ollamaUrl);
    if (modelName) formData.append('model_name', modelName);
    
    const response = await axios.post(`${API_BASE_URL}/process`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    
    return response.data;
  },
  
  // Send follow-up questions about documents
  chat: async (chatRequest: ChatRequest): Promise<ChatResponse> => {
    const response = await axios.post(`${API_BASE_URL}/chat`, chatRequest);
    return response.data;
  },
  
  // Get server status
  getStatus: async (): Promise<ServerStatus> => {
    const response = await axios.get(`${API_BASE_URL}/status`);
    return response.data;
  },
  
  // List all sessions
  listSessions: async (): Promise<{ sessions: SessionInfo[] }> => {
    const response = await axios.get(`${API_BASE_URL}/sessions`);
    return response.data;
  },
  
  // Get session details
  getSession: async (sessionId: string): Promise<SessionResponse> => {
    const response = await axios.get(`${API_BASE_URL}/session/${sessionId}`);
    return response.data;
  },
  
  // Delete a session
  deleteSession: async (sessionId: string): Promise<{ success: boolean; message: string }> => {
    const response = await axios.delete(`${API_BASE_URL}/session/${sessionId}`);
    return response.data;
  },
  
  // Download processed file
  getDownloadUrl: (sessionId: string, filename: string): string => {
    return `${API_BASE_URL}/download/${sessionId}/${filename}`;
  }
};

export default documentService;