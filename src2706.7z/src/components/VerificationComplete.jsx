import React, { useState, useEffect } from 'react';
import './VerificationComplete.css';
import config from '../services/config';
const VerificationComplete = ({ kycData }) => {
  const isApproved = kycData.verificationStatus === 'approved';
  const isDuplicate = kycData.verificationStatus === 'duplicate_found';
  
  // State for application form
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: kycData.applicantName || '',
    dob: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState(null);
  const [error, setError] = useState('');
  
  // Server URL
  const serverUrl = config.facededupeapiServerUrl;
  
  // Autofill form data when kycData changes
  useEffect(() => {
    if (kycData.applicantName) {
      setFormData(prevData => ({
        ...prevData,
        name: kycData.applicantName
      }));
    }
  }, [kycData]);
  
  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  // Handle form submission
  const handleSubmitApplication = async (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.dob) {
      setError('Please fill in all required fields');
      return;
    }
    
    if (!kycData.livenessImage) {
      setError('No liveness image available. Cannot proceed.');
      return;
    }
    
    setSubmitting(true);
    setError('');
    
    try {
      // Get the image data - ensure it's in the correct format
      let imageData = kycData.livenessImage;
      
      // If the image is a URL (starts with http or data:image), we need to handle it differently
      if (imageData.startsWith('data:image')) {
        // It's already a data URL, we're good
        console.log("Image is already in data URL format");
      } else if (imageData.startsWith('http')) {
        // It's a URL, we need to fetch it and convert to base64
        try {
          const response = await fetch(imageData);
          const blob = await response.blob();
          
          // Convert blob to base64
          const reader = new FileReader();
          const base64Promise = new Promise(resolve => {
            reader.onloadend = () => resolve(reader.result);
            reader.readAsDataURL(blob);
          });
          
          imageData = await base64Promise;
          console.log("Converted image URL to data URL");
        } catch (imgError) {
          console.error("Error fetching image:", imgError);
          setError('Failed to process image. Please try again.');
          setSubmitting(false);
          return;
        }
      }
      
      // Prepare the data for submission
      const applicationData = {
        name: formData.name,
        dob: formData.dob,
        image: imageData,
        applicant_id: kycData.applicantId,
        application_id: kycData.applicationId,
        phone: kycData.applicantPhone || '',
        address: kycData.applicantAddress || ''
      };
      
      console.log("Submitting application with image length:", imageData.length);
      
      // Submit to the backend
      const response = await fetch(`${serverUrl}/submit_application`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(applicationData)
      });
      
      const result = await response.json();
      
      if (response.ok) {
        setSubmitResult({
          success: true,
          message: result.message,
          ucic_id: result.ucic_id
        });
      } else {
        setSubmitResult({
          success: false,
          message: result.error || 'Failed to submit application'
        });
      }
    } catch (error) {
      console.error('Error submitting application:', error);
      setError('An error occurred while submitting your application');
    } finally {
      setSubmitting(false);
    }
  };
  
  return (
    <div className="verification-complete">
      <div className={`status-container ${isApproved ? 'approved' : 'rejected'}`}>
        <div className="status-icon">
          {isApproved ? '✓' : '✗'}
        </div>
        <h2 className="status-title">
          {isApproved ? 'Verification Successful' : 'Verification Failed'}
        </h2>
        <p className="status-message">
          {isApproved 
            ? 'Your identity has been successfully verified. You can now proceed with your application.' 
            : isDuplicate 
              ? 'We found a duplicate record in our system. This may indicate a potential fraud attempt.' 
              : kycData.verificationStatus === 'requires_scrutiny'
                ? 'Your verification requires additional review. Our team will contact you shortly.'
                : 'Your verification could not be completed. Please try again or contact support.'}
        </p>
      </div>
      
      <div className="verification-summary">
        <h3>Verification Summary</h3>
        
        <div className="summary-item">
          <div className="summary-label">Liveness Check:</div>
          <div className={`summary-value ${kycData.livenessImage ? 'success' : 'failure'}`}>
            {kycData.livenessImage ? 'Passed' : 'Failed'}
          </div>
        </div>
        
        <div className="summary-item">
          <div className="summary-label">Aadhaar Verification:</div>
          <div className={`summary-value ${kycData.extractedFaceImage ? 'success' : 'failure'}`}>
            {kycData.extractedFaceImage ? 'Passed' : 'Failed'}
          </div>
        </div>
        
        <div className="summary-item">
          <div className="summary-label">Face Comparison:</div>
          <div className={`summary-value ${kycData.comparisonResult && kycData.comparisonResult.similarity >= 0.7 ? 'success' : 'failure'}`}>
            {kycData.comparisonResult 
              ? `${(kycData.comparisonResult.similarity * 100).toFixed(2)}% Match` 
              : 'Not Performed'}
          </div>
        </div>
        
        <div className="summary-item">
          <div className="summary-label">Duplicate Check:</div>
          <div className={`summary-value ${isDuplicate ? 'failure' : 'success'}`}>
            {isDuplicate 
              ? 'Duplicate Found' 
              : kycData.dedupeResults 
                ? 'No Duplicates' 
                : 'Not Performed'}
          </div>
        </div>
      </div>
      
      {/* Application Form */}
      {isApproved && showForm && !submitResult && (
        <div className="application-form-container">
          <h3>Complete Your Application</h3>
          {error && <div className="error-message">{error}</div>}
          <form className="application-form" onSubmit={handleSubmitApplication}>
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
                placeholder="Enter your full name"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="dob">Date of Birth</label>
              <input
                type="date"
                id="dob"
                name="dob"
                value={formData.dob}
                onChange={handleInputChange}
                required
              />
            </div>
            
            <div className="form-actions">
              <button 
                type="button" 
                className="cancel-btn" 
                onClick={() => setShowForm(false)}
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="submit-btn" 
                disabled={submitting}
              >
                {submitting ? 'Submitting...' : 'Submit Application'}
              </button>
            </div>
          </form>
        </div>
      )}
      
      {/* Application Submission Result */}
      {submitResult && (
        <div className={`submission-result ${submitResult.success ? 'success' : 'error'}`}>
          <h3>{submitResult.success ? 'Application Submitted Successfully' : 'Submission Failed'}</h3>
          <p>{submitResult.message}</p>
          {submitResult.success && submitResult.ucic_id && (
            <div className="ucic-display">
              <span>Your UCIC ID:</span>
              <strong>{submitResult.ucic_id}</strong>
              <p>Please save this ID for future reference.</p>
            </div>
          )}
        </div>
      )}
      
      <div className="verification-actions">
        <button className="restart-btn" onClick={() => window.location.reload()}>
          Start New Verification
        </button>
        
        {isApproved && !showForm && !submitResult && (
          <button className="continue-app-btn" onClick={() => setShowForm(true)}>
            Continue to Application
          </button>
        )}
        
        {kycData.verificationStatus === 'requires_scrutiny' && (
          <div className="scrutiny-message">
            <p>Your application is under review. Our team will contact you shortly.</p>
          </div>
        )}
        
        {!isApproved && kycData.verificationStatus !== 'requires_scrutiny' && (
          <button className="contact-support-btn">
            Contact Support
          </button>
        )}
      </div>
    </div>
  );
};

export default VerificationComplete;
