import os
import io
import cv2
import numpy as np
from PIL import Image
from insightface.app import FaceAnalysis
from pymilvus import (
    connections,
    FieldSchema, CollectionSchema, DataType,
    Collection, utility
)
from pymongo import MongoClient
import gridfs
import logging
from tqdm import tqdm
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("FaceDeduplication")

class FaceDeduplicationSystem:
    def __init__(self, config):
        self.config = config
        self._verify_environment()
        self._init_milvus_connection()
        self._init_mongo()
        self._init_face_model()
        self._setup_collection()
        
    def _verify_environment(self):
        """Verify required environment setup"""
        logger.info("Verifying environment setup")
        if self.config['USE_GPU']:
            try:
                import torch
                assert torch.cuda.is_available()
                logger.info("CUDA GPU available")
            except Exception as e:
                logger.error("GPU configuration failed, falling back to CPU")
                self.config['USE_GPU'] = False

    def _init_milvus_connection(self):
        """Initialize and verify Milvus connection"""
        logger.info("Initializing Milvus connection")
        try:
            connections.connect(
                alias="default",
                host=self.config['MILVUS_HOST'],
                port=self.config['MILVUS_PORT']
            )
            logger.info(f"Connected to Milvus at {self.config['MILVUS_HOST']}:{self.config['MILVUS_PORT']}")
        except Exception as e:
            logger.error("Milvus connection failed")
            raise

    def _init_mongo(self):
        """Initialize MongoDB connection and GridFS for image retrieval"""
        logger.info("Initializing MongoDB connection")
        try:
            self.mongo_client = MongoClient(self.config['MONGO_URI'])
            self.mongo_db = self.mongo_client[self.config['MONGO_DB']]
            self.mongo_collection = self.mongo_db[self.config['MONGO_COLLECTION']]
            self.fs = gridfs.GridFS(self.mongo_db)
            logger.info(f"Connected to MongoDB at {self.config['MONGO_URI']}, DB: {self.config['MONGO_DB']}")
        except Exception as e:
            logger.error("MongoDB connection failed")
            raise

    def _init_face_model(self):
        """Initialize InsightFace model with proper configuration"""
        logger.info("Initializing face recognition model")
        try:
            self.app = FaceAnalysis(
                name='buffalo_m',
                root=os.path.expanduser('~/.insightface/')
            )
            ctx_id = 0 if self.config['USE_GPU'] else -1
            self.app.prepare(
                ctx_id=ctx_id,
                det_size=(640, 640),
                det_thresh=self.config['DETECTION_THRESHOLD']
            )
            logger.info(f"Model initialized with {'GPU' if ctx_id == 0 else 'CPU'}")
        except Exception as e:
            logger.error("Model initialization failed")
            raise

    def _setup_collection(self):
        """Set up Milvus collection with proper index handling"""
        logger.info("Setting up Milvus collection")
        if utility.has_collection(self.config['COLLECTION_NAME']):
            logger.info("Collection exists, loading...")
            self.collection = Collection(self.config['COLLECTION_NAME'])
            self._verify_index()
        else:
            logger.info("Creating new collection")
            self._create_collection()
        self._load_collection_with_retry()

    def _create_collection(self):
        """Create new collection with optimized schema"""
        fields = [
            FieldSchema(
                name="ucic_id",
                dtype=DataType.VARCHAR,
                is_primary=True,
                max_length=64
            ),
            FieldSchema(
                name="embedding",
                dtype=DataType.FLOAT_VECTOR,
                dim=512
            )
        ]
        schema = CollectionSchema(
            fields,
            description="Face embeddings storage for deduplication",
            enable_dynamic_field=False
        )
        self.collection = Collection(
            name=self.config['COLLECTION_NAME'],
            schema=schema,
            using='default',
            shards_num=2,
            consistency_level="Strong"
        )
        self._create_index()
        logger.info(f"Collection {self.config['COLLECTION_NAME']} created")

    def _verify_index(self):
        """Ensure required index exists"""
        if not any(index.index_name == "face_embeddings_index" for index in self.collection.indexes):
            logger.warning("Index missing, creating new index")
            self._create_index()

    def _create_index(self):
        """Create optimized vector index using GPU_CAGRA and IP metric"""
        index_params = {
            "index_type": "GPU_CAGRA",
            "metric_type": "IP",  # Use Inner Product metric for normalized embeddings (equivalent to cosine similarity)
            "params": {
                "intermediate_graph_degree": 64,
                "graph_degree": 32,
                "cache_dataset_on_device": "true"  # Optional: cache dataset on GPU if possible
            }
        }
        self.collection.create_index(
            field_name="embedding",
            index_params=index_params,
            index_name="face_embeddings_index"
        )
        logger.info(f"Created {index_params['index_type']} index with metric type {index_params['metric_type']}")
        self.collection.flush()

    def _load_collection_with_retry(self, max_retries=3):
        """Load collection with retry logic"""
        for attempt in range(max_retries):
            try:
                self.collection.load()
                logger.info("Collection loaded successfully")
                return
            except Exception as e:
                logger.warning(f"Load attempt {attempt+1} failed: {str(e)}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                logger.error("Failed to load collection after retries")
                raise

    def process_image(self, image_bytes):
        """Process image bytes and extract face embedding"""
        try:
            img = Image.open(io.BytesIO(image_bytes))
            img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
            faces = self.app.get(img)
            if not faces:
                raise ValueError("No faces detected")
            return faces[0].normed_embedding
        except Exception as e:
            logger.error(f"Image processing failed: {str(e)}")
            return None

    def is_duplicate(self, embedding):
        """Check if the embedding is a duplicate based on threshold"""
        search_params = {
            "metric_type": "IP",
            "params": {"nprobe": 16}
        }
        results = self.collection.search(
            data=[embedding],
            anns_field="embedding",
            param=search_params,
            limit=1,
            output_fields=["ucic_id"]
        )
        
        if results and len(results[0]) > 0:
            similarity = results[0][0].score
            if similarity >= self.config['DUPLICATE_THRESHOLD']:
                duplicate_id = results[0][0].entity.get('ucic_id')
                logger.info(f"Duplicate face found with similarity {similarity:.4f} to UCIC ID: {duplicate_id}")
                return True
        return False

    def insert_embeddings_from_mongo(self):
        """
        Retrieve documents from MongoDB, extract images via GridFS,
        compute face embeddings, and insert them into Milvus.
        Skip duplicates based on threshold.
        """
        logger.info("Inserting embeddings from MongoDB into Milvus")
        documents = list(self.mongo_collection.find({}))
        embeddings = []
        ucic_ids = []
        duplicates_count = 0
        
        for doc in tqdm(documents, desc="Processing MongoDB Images"):
            ucic_id = doc.get("ucic_id")
            if not ucic_id:
                logger.warning("Document missing ucic_id; skipping")
                continue
            try:
                image_id = doc.get("image_id")
                if not image_id:
                    logger.warning(f"No image_id for UCFS {ucic_id}; skipping")
                    continue
                image_bytes = self.fs.get(image_id).read()
                emb = self.process_image(image_bytes)
                
                if emb is not None:
                    # Check if this is a duplicate before adding
                    if self.collection.num_entities > 0 and self.is_duplicate(emb):
                        duplicates_count += 1
                        logger.info(f"Skipping duplicate face for UCIC ID: {ucic_id}")
                        continue
                    
                    embeddings.append(emb)
                    ucic_ids.append(ucic_id)
            except Exception as e:
                logger.error(f"Failed to process document UCFS {ucic_id}: {str(e)}")
        
        total_inserted = 0
        batch_size = 10000
        for i in range(0, len(embeddings), batch_size):
            batch_ids = ucic_ids[i:i+batch_size]
            batch_embs = embeddings[i:i+batch_size]
            try:
                self.collection.insert([batch_ids, batch_embs])
                total_inserted += len(batch_ids)
                logger.debug(f"Inserted batch {i//batch_size + 1}")
            except Exception as e:
                logger.error(f"Batch insert failed: {str(e)}")
        
        self.collection.flush()
        logger.info(f"Successfully inserted {total_inserted} embeddings into Milvus")
        logger.info(f"Skipped {duplicates_count} duplicate faces based on threshold {self.config['DUPLICATE_THRESHOLD']}")


if __name__ == "__main__":
    try:
        # Initialize system
        CONFIG = {
            "MILVUS_HOST": "localhost",
            "MILVUS_PORT": "19530",
            "COLLECTION_NAME": "faces_test",
            "USE_GPU": True,
            "DETECTION_THRESHOLD": 0.5,
            "ANGULAR_MARGIN": 0.1,
            "MONGO_URI": "mongodb://bridgedevwrite:BridgedevWrite890@10.9.50.43:10050/",
            "MONGO_DB": "chola_face_db",
            "MONGO_COLLECTION": "face_images",
            "MAX_BATCH_RETRIES": 3,
            "DUPLICATE_THRESHOLD": 0.65,
            "DUPLICATE_RADIUS": 0.4
        }
        dedup_system = FaceDeduplicationSystem(CONFIG)
        
        # Insert embeddings into Milvus from MongoDB metadata and images
        dedup_system.insert_embeddings_from_mongo()
                
    except Exception as e:
        logger.error(f"System failed: {str(e)}")
        if 'dedup_system' in locals():
            dedup_system.collection.release()
        connections.disconnect("default")
    finally:
        logger.info("Process completed")
