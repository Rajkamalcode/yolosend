import os
import sys
import cv2
import numpy as np
import pytesseract
import re
from ultralytics import YOLO
from pytesseract import Output, TesseractError
from flask import Flask, request, send_file, jsonify, Response
from flask_cors import CORS
import uuid
import io
import logging
from datetime import datetime

# Add parent directory to path to import dms module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from facededupe.dms import upload_to_dms, get_image_from_dms, delete_from_dms


# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Create necessary folders
os.makedirs("temp_results", exist_ok=True)

# Load YOLO models
aadhar_model = YOLO("model.pt")  # Aadhaar number detection model
face_model = YOLO("yolov10n-face.pt")  # Face detection model
aadhar_finder_model = YOLO("aadharfinder.pt")  # Aadhaar card detection model

# Helper Functions
def crop_to_content(image):
    """Crop the image to the content area by removing large empty borders."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    if contours:
        x_min = min([cv2.boundingRect(c)[0] for c in contours])
        y_min = min([cv2.boundingRect(c)[1] for c in contours])
        x_max = max([cv2.boundingRect(c)[0] + cv2.boundingRect(c)[2] for c in contours])
        y_max = max([cv2.boundingRect(c)[1] + cv2.boundingRect(c)[3] for c in contours])
        
        return image[y_min:y_max, x_min:x_max]
    
    return image  # Return original if no contours found

# Function to apply CLAHE preprocessing
def apply_clahe(image):
    """Apply CLAHE preprocessing to enhance image contrast."""
    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    cl = clahe.apply(l)
    merged_lab = cv2.merge((cl, a, b))
    enhanced_image = cv2.cvtColor(merged_lab, cv2.COLOR_LAB2BGR)
    return enhanced_image

def detect_text_orientation(image, aadhar_model):
    """Detect text orientation in the image."""
    try:
        # First try using Tesseract's OSD
        osd = pytesseract.image_to_osd(image, output_type=Output.DICT)
        return osd.get("rotate", 0)
    except TesseractError:
        print("Tesseract failed to detect orientation. Trying alternative method...")
        # If Tesseract fails, try all orientations and use the one with highest confidence
        orientations = [0, 90, 180, 270]
        best_orientation = 0
        highest_confidence = 0
        
        for angle in orientations:
            # Rotate image to the test orientation
            if angle == 0:
                rotated = image
            elif angle == 90:
                rotated = cv2.rotate(image, cv2.ROTATE_90_CLOCKWISE)
            elif angle == 180:
                rotated = cv2.rotate(image, cv2.ROTATE_180)
            elif angle == 270:
                rotated = cv2.rotate(image, cv2.ROTATE_90_COUNTERCLOCKWISE)
            
            # Run Aadhar detection on this orientation
            results = aadhar_model.predict(rotated)
            
            # Calculate average confidence for this orientation
            total_conf = 0
            num_detections = 0
            
            for result in results:
                if len(result.boxes) > 0:
                    confidences = result.boxes.conf.cpu().numpy()
                    total_conf += np.sum(confidences)
                    num_detections += len(confidences)
            
            avg_conf = total_conf / max(1, num_detections)  # Avoid division by zero
            
            print(f"Orientation {angle}°: Average confidence = {avg_conf:.4f}, Detections = {num_detections}")
            
            # Update best orientation if this one has higher confidence
            if num_detections > 2 and avg_conf > highest_confidence:
                highest_confidence = avg_conf
                best_orientation = angle
        
        # If we didn't get any good detections with YOLO, try the crop_to_content approach
        if highest_confidence == 0:
            print("YOLO detection failed to determine orientation. Trying content-based approach...")
            
            # Try all orientations with the crop_to_content method
            best_content_area = 0
            best_content_orientation = 0
            
            for angle in orientations:
                # Rotate image to the test orientation
                if angle == 0:
                    rotated = image
                elif angle == 90:
                    rotated = cv2.rotate(image, cv2.ROTATE_90_CLOCKWISE)
                elif angle == 180:
                    rotated = cv2.rotate(image, cv2.ROTATE_180)
                elif angle == 270:
                    rotated = cv2.rotate(image, cv2.ROTATE_90_COUNTERCLOCKWISE)
                
                # Crop to content
                cropped = crop_to_content(rotated)
                
                # Calculate content area
                content_area = cropped.shape[0] * cropped.shape[1]
                print(f"Orientation {angle}°: Content area = {content_area}")
                
                # Update best orientation if this one has smaller content area
                # (assuming proper orientation has more compact content)
                if content_area > best_content_area:
                    best_content_area = content_area
                    best_content_orientation = angle
            
            print(f"Selected orientation based on content: {best_content_orientation}° with area {best_content_area}")
            return best_content_orientation
        
        print(f"Selected orientation based on YOLO: {best_orientation}° with confidence {highest_confidence:.4f}")
        return best_orientation

def rotate_image(image, angle):
    """Rotate the image based on the detected orientation angle."""
    if angle == 0:
        return image, False
    elif angle == 90:
        return cv2.rotate(image, cv2.ROTATE_90_CLOCKWISE), False
    elif angle == 180:
        return cv2.rotate(image, cv2.ROTATE_180), True  # Flipped 180 degrees
    elif angle == 270:
        return cv2.rotate(image, cv2.ROTATE_90_COUNTERCLOCKWISE), False
    else:
        raise ValueError(f"Unsupported rotation angle: {angle}")

def fit_text_to_box(image, text, x1, y1, x2, y2, color=(0, 0, 0)):
    """Fit text within a bounding box by adjusting font size."""
    box_width = x2 - x1
    box_height = y2 - y1
    
    # Start with a reasonable font scale based on box height
    initial_font_scale = box_height / 50
    font_scale = initial_font_scale
    min_font_scale = 0.3  # Minimum readable font size
    
    # Try to fit text by reducing font size if needed
    while font_scale >= min_font_scale:
        thickness = max(1, int(font_scale * 2))
        text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)[0]
        
        # Check if text fits within box width with some margin
        if text_size[0] < box_width * 0.95 and text_size[1] < box_height * 0.8:
            # Text fits, calculate position to center it
            text_x = x1 + (box_width - text_size[0]) // 2
            text_y = y1 + (box_height + text_size[1]) // 2
            
            # Draw the text
            cv2.putText(image, text, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX,
                        font_scale, color, thickness)
            return True
        
        # Reduce font scale and try again
        font_scale *= 0.9
    
    # If we get here, even the minimum font size doesn't fit
    # Use the minimum font size and truncate text if necessary
    thickness = max(1, int(min_font_scale * 2))
    text_size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, min_font_scale, thickness)[0]
    
    # Calculate position to center it
    text_x = x1 + (box_width - text_size[0]) // 2
    text_y = y1 + (box_height + text_size[1]) // 2
    
    # Draw the text with minimum font size
    cv2.putText(image, text, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX,
                min_font_scale, color, thickness)
    return False

def global_ocr_mask(image, is_flipped):
    """Mask patterns matching 'XXXX XXXX XXXX' globally using OCR."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    data = pytesseract.image_to_data(gray, output_type=Output.DICT, config="--psm 11")
    n_boxes = len(data["text"])
    pattern = re.compile(r'\b[A-Za-z0-9]{4} [A-Za-z0-9]{4} [A-Za-z0-9]{4}\b')
    for i in range(n_boxes - 2):
        word1 = data["text"][i].strip()
        word2 = data["text"][i+1].strip()
        word3 = data["text"][i+2].strip()
        if (len(word1) == 4 and len(word2) == 4 and len(word3) == 4 and
            word1.isalnum() and word2.isalnum() and word3.isalnum()):
            combined = f"{word1} {word2} {word3}"
            if re.match(pattern, combined):
                x_min = min(data["left"][i], data["left"][i+1], data["left"][i+2])
                y_min = min(data["top"][i], data["top"][i+1], data["top"][i+2])
                x_max = max(data["left"][i] + data["width"][i],
                            data["left"][i+1] + data["width"][i+1],
                            data["left"][i+2] + data["width"][i+2])
                y_max = max(data["top"][i] + data["height"][i],
                            data["top"][i+1] + data["height"][i+1],
                            data["top"][i+2] + data["height"][i+2])
                
                # Calculate the width of the box
                box_width = x_max - x_min
                box_height = y_max - y_min
                
                # Determine which part to mask based on orientation
                new_x_min = x_min  # Start at left edge
                new_x_max = x_min + int(box_width * 0.61)  # End at 67% from left
                
                
                # Reduce the height by only 10% (5% from top and 5% from bottom) instead of 30%
                height_reduction = int(box_height * 0.50)
                new_y_min = y_min + int(height_reduction / 2)
                new_y_max = y_max - int(height_reduction / 2)
                
                # Add padding to the bounding box (optional)
                padding_x = 10
                padding_y = 20  # Increased vertical padding
                
                new_x_min = max(0, new_x_min - padding_x)
                new_x_max = min(image.shape[1], new_x_max + padding_x)
                new_y_min = max(0, new_y_min - padding_y)
                new_y_max = min(image.shape[0], new_y_max + padding_y)
                
                # Draw white rectangle over the appropriate part of the detected area
                cv2.rectangle(image, (new_x_min, new_y_min), (new_x_max, new_y_max), (255, 255, 255), -1)
                
                # Only mask the appropriate digits
                masked_text = " "
                # Use the fit_text_to_box function to ensure text fits
                fit_text_to_box(image, masked_text, new_x_min, new_y_min, new_x_max, new_y_max, (0, 0, 0))
    return image

def mask_lowest_confidence_face(image):
    """Detect faces and apply Gaussian blur to the one with lowest confidence if multiple faces are found.
    The blur is applied to a region 3 times larger than the detected face."""
    # Run face detection
    face_results = face_model(image)
    
    faces = []
    
    # Collect all detected faces with their confidence scores
    for result in face_results:
        if len(result.boxes) > 0:
            boxes = result.boxes.xyxy.cpu().numpy()
            confidences = result.boxes.conf.cpu().numpy()
            
            for box, conf in zip(boxes, confidences):
                if conf > 0.5:  # Only consider faces with reasonable confidence
                    faces.append((box, conf))
    
    # If multiple faces are detected, blur the one with lowest confidence
    if len(faces) > 1:
        # Sort faces by confidence (ascending)
        faces.sort(key=lambda x: x[1])
        
        # Get the face with lowest confidence
        lowest_conf_face = faces[0]
        x1, y1, x2, y2 = map(int, lowest_conf_face[0])
        
        # Calculate face dimensions
        face_width = x2 - x1
        face_height = y2 - y1
        
        # Calculate center of the face
        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2
        
        # Calculate expanded region (3 times larger in all dimensions)
        expanded_width = face_width * 3
        expanded_height = face_height * 4
        
        # Calculate new coordinates for the expanded region
        ex1 = max(0, center_x - expanded_width // 2)
        ey1 = max(0, center_y - expanded_height // 2)
        ex2 = min(image.shape[1], center_x + expanded_width // 2)
        ey2 = min(image.shape[0], center_y + expanded_height // 2)
        
        # Check if the expanded region is valid
        if ex2 > ex1 and ey2 > ey1:
            # Extract the expanded region
            expanded_region = image[ey1:ey2, ex1:ex2].copy()
            
            # Apply Gaussian blur to the expanded region
            try:
                # Use a moderate kernel size that's guaranteed to work
                blurred_region = cv2.GaussianBlur(expanded_region, (31, 31), 0)
                
                # Replace the original expanded region with the blurred one
                image[ey1:ey2, ex1:ex2] = blurred_region
                print(f"Applied Gaussian blur to expanded face region with confidence: {lowest_conf_face[1]:.4f}")
                print(f"Original face size: {face_width}x{face_height}, Expanded region: {expanded_width}x{expanded_height}")
            except Exception as e:
                print(f"Error applying Gaussian blur to expanded region: {str(e)}")
                # Fallback to a simpler blur method
                try:
                    blurred_region = cv2.blur(expanded_region, (30, 30))
                    image[ey1:ey2, ex1:ex2] = blurred_region
                    print("Applied simple blur as fallback")
                except Exception as e2:
                    print(f"Error applying simple blur: {str(e2)}")
                    # Last resort: just mask with a white rectangle
                    cv2.rectangle(image, (ex1, ey1), (ex2, ey2), (255, 255, 255), -1)
                    print("Applied white rectangle as last resort")
    
    return image

def detect_and_crop_aadhar_card(image):
    """Detect Aadhaar card in the image and crop it if found.
    If multiple bounding boxes are detected, combine them into one."""
    # Run Aadhaar card detection
    results = aadhar_finder_model.predict(image)
    
    # Initialize variables
    all_boxes = []
    
    # Process detection results and collect all boxes
    for result in results:
        if len(result.boxes) > 0:
            boxes = result.boxes.xyxy.cpu().numpy()
            all_boxes.extend(boxes)
    
    # If any Aadhaar cards are detected, combine the bounding boxes
    if len(all_boxes) > 0:
        # Find the minimum and maximum coordinates to create a bounding box that encompasses all detections
        x1_min = min([box[0] for box in all_boxes])
        y1_min = min([box[1] for box in all_boxes])
        x2_max = max([box[2] for box in all_boxes])
        y2_max = max([box[3] for box in all_boxes])
        
        # Convert to integers and ensure they're within image boundaries
        x1 = max(0, int(x1_min))
        y1 = max(0, int(y1_min))
        x2 = min(image.shape[1], int(x2_max))
        y2 = min(image.shape[0], int(y2_max))
        
        # Crop the image to the combined bounding box
        cropped_card = image[y1:y2, x1:x2]
        logger.info(f"Aadhaar card(s) detected and cropped. Combined {len(all_boxes)} bounding boxes.")
        
        return cropped_card, True
    
    logger.info("No Aadhaar card detected, processing original image")
    return image, False

@app.route('/process_aadhar', methods=['POST'])
def process_aadhar():
    """Process Aadhaar card image, mask sensitive information, and store in DMS"""
    # Check if image file is provided
    if 'image' not in request.files:
        return jsonify({'error': 'No image file provided'}), 400
    
    file = request.files['image']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    # Get applicant_id and session_id from request if available
    applicant_id = request.form.get('applicant_id', '')
    session_id = request.form.get('session_id', str(uuid.uuid4()))

    try:
        # Read the uploaded image
        img_array = np.frombuffer(file.read(), np.uint8)
        image = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        if image is None:
            return jsonify({'error': 'Invalid image file'}), 400
        
        # Step 1: Try to detect and crop Aadhaar card
        cropped_image, is_aadhar_detected = detect_and_crop_aadhar_card(image)
        
        if not is_aadhar_detected:
            return jsonify({'error': 'Aadhaar card not detected clearly. Please upload a clearer image.'}), 400
        
        # Use either the cropped image or the original image for further processing
        image_to_process = cropped_image  # This will be the original image if no card was detected
        
        # Step 2: Correct text orientation
        correct_angle = detect_text_orientation(image_to_process, aadhar_model)
        rotated_image, is_flipped = rotate_image(image_to_process, correct_angle)
        
        logger.info(f"Image orientation: {correct_angle}° - {'Flipped' if is_flipped else 'Normal'} orientation")

        # Make a copy for masking
        masked_image = rotated_image.copy()
        
        # Step 3: Mask the face with lowest confidence if multiple faces are detected
        masked_image = mask_lowest_confidence_face(masked_image)

        # Step 4: YOLO-based Aadhaar Number Detection and Masking
        yolo_masked = False
        results = aadhar_model.predict(masked_image)
        
        for result in results:
            boxes = result.boxes.xyxy.cpu().numpy()
            class_ids = result.boxes.cls.cpu().numpy()
            for box, class_id in zip(boxes, class_ids):
                x1, y1, x2, y2 = map(int, box)
                label = aadhar_model.names[int(class_id)]
                if label == "AADHAR_NUMBER":
                    roi = masked_image[y1:y2, x1:x2]
                    gray_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
                    extracted_text = pytesseract.image_to_string(gray_roi, config="--psm 7").strip()
                    matches = re.findall(r'\b[A-Za-z0-9]{4} [A-Za-z0-9]{4} [A-Za-z0-9]{4}\b', extracted_text)
                    if matches:
                        yolo_masked = True
                        for match in matches:
                            # Calculate the width of the detected area
                            box_width = x2 - x1
                            box_height = y2 - y1
                            
                            new_x1 = x1  # Start at left edge
                            new_x2 = x1 + int(box_width * 0.62)  # End at 67% from left
                            
                            # Reduce the height by only 10% (5% from top and 5% from bottom) instead of 30%
                            height_reduction = int(box_height * 0.10)
                            new_y1 = y1 + int(height_reduction / 2)
                            new_y2 = y2 - int(height_reduction / 2)
                            
                            # Add some padding to the bounding box for better visibility
                            padding_x = int((new_x2 - new_x1) * 0.05)  # 5% padding on each side
                            padding_y = int((y2 - y1) * 0.05)   # 5% padding on top and bottom (increased)
                            
                            # Ensure padding doesn't go out of bounds
                            x1_pad = max(0, new_x1 - padding_x)
                            y1_pad = max(0, new_y1 - padding_y)
                            x2_pad = min(masked_image.shape[1], new_x2 + padding_x)
                            y2_pad = min(masked_image.shape[0], new_y2 + padding_y)
                            
                            # Draw the white rectangle over the appropriate part of the Aadhaar number area
                            cv2.rectangle(masked_image, (x1_pad, y1_pad), (x2_pad, y2_pad), (255, 255, 255), -1)
                            
                            # Only mask the appropriate digits
                            masked_text = " "
                            # Use the fit_text_to_box function to ensure text fits
                            fit_text_to_box(masked_image, masked_text, x1_pad, y1_pad, x2_pad, y2_pad, (0, 0, 0))

        # Step 5: Apply global OCR masking
        # Create a copy before global OCR masking to check if any changes were made
        before_global_ocr = masked_image.copy()
        masked_image = global_ocr_mask(masked_image, is_flipped)
        
        # Check if global OCR made any changes by comparing images
        # Convert to grayscale for simpler comparison
        before_gray = cv2.cvtColor(before_global_ocr, cv2.COLOR_BGR2GRAY)
        after_gray = cv2.cvtColor(masked_image, cv2.COLOR_BGR2GRAY)
        diff = cv2.absdiff(before_gray, after_gray)
        non_zero_pixels = cv2.countNonZero(diff)
        
        global_ocr_masked = non_zero_pixels > 100  # If more than 100 pixels changed, consider it masked
        
        if global_ocr_masked:
            logger.info("Masked with Global OCR")
        else:
            logger.info("Normal mask")
            
        # Check if either YOLO or global OCR successfully masked an Aadhaar number
        if not (yolo_masked or global_ocr_masked):
            return jsonify({'error': 'Aadhaar number not detected clearly. Please upload a clearer image.'}), 400

        # Save the masked image to a temporary file
        temp_filename = os.path.join("temp_results", f"masked_{uuid.uuid4().hex}.jpg")
        cv2.imwrite(temp_filename, masked_image)
        
        # Encode the masked image to JPEG format
        _, img_encoded = cv2.imencode('.jpg', masked_image)
        image_bytes = img_encoded.tobytes()
        
        # Prepare metadata for DMS
        metadata = {
            "session_id": session_id,
            "type": "masked_aadhaar",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        if applicant_id:
            metadata["applicant_id"] = applicant_id
        
        # Upload to DMS
        dms_id = upload_to_dms(image_bytes, metadata)
        
        if dms_id:
            logger.info(f"Masked Aadhaar image uploaded to DMS with ID: {dms_id}")
            
            # Return success response with DMS ID
            return jsonify({
                'success': True,
                'message': 'Aadhaar card processed successfully',
                'dms_id': dms_id
            })
        else:
            logger.error("Failed to upload masked Aadhaar image to DMS")
            
            # Fallback to sending the file directly if DMS upload fails
            return send_file(
                temp_filename, 
                mimetype='image/jpeg', 
                as_attachment=True, 
                download_name='masked_aadhaar.jpg'
            )

    except Exception as e:
        logger.error(f"Error processing Aadhaar card: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/process_aadhar/get_masked_aadhaar/<dms_id>', methods=['GET'])
def get_masked_aadhaar(dms_id):
    """Retrieve a masked Aadhaar image from DMS by its ID"""
    try:
        # Get image from DMS
        image_bytes = get_image_from_dms(dms_id)
        
        if not image_bytes:
            return jsonify({'error': 'Failed to retrieve image from DMS'}), 404
        
        # Return the image
        return Response(
            image_bytes,
            mimetype='image/jpeg'
        )
    except Exception as e:
        logger.error(f"Error retrieving masked Aadhaar image: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy"})

# Run the Flask app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5004, debug=True)
