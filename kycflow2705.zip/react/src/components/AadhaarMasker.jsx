import React, { useState, useRef, useEffect } from 'react';
import './AadhaarMasker.css';

const AadhaarMasker = ({ kycData, updateKycData, nextStep }) => {
  const [originalImage, setOriginalImage] = useState(null);
  const [maskedImage, setMaskedImage] = useState(null);
  const [maskedAadhaarDmsId, setMaskedAadhaarDmsId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  
  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  
  // Server URL
  const serverUrl = 'http://10.9.52.21:5004/process_aadhar';
  const dmsServerUrl = 'http://10.9.52.21:5001/get_dms_image';
  
  // Start webcam
  const startWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user' // Use front camera
        },
        audio: false
      });
      
      if (webcamRef.current) {
        webcamRef.current.srcObject = stream;
        return new Promise((resolve) => {
          webcamRef.current.onloadedmetadata = () => {
            setStreaming(true);
            resolve(true);
          };
        });
      }
      return false;
    } catch (error) {
      console.error('Error accessing webcam:', error);
      setError('Error accessing webcam. Please check permissions.');
      return false;
    }
  };
  
  // Stop webcam
  const stopWebcam = () => {
    if (webcamRef.current && webcamRef.current.srcObject) {
      webcamRef.current.srcObject.getTracks().forEach(track => track.stop());
      webcamRef.current.srcObject = null;
      setStreaming(false);
    }
  };
  
  // Capture frame from webcam
  const captureFrame = () => {
    if (webcamRef.current && webcamRef.current.readyState === webcamRef.current.HAVE_ENOUGH_DATA && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = webcamRef.current.videoWidth;
      canvasRef.current.height = webcamRef.current.videoHeight;
      context.drawImage(webcamRef.current, 0, 0);
      return canvasRef.current.toDataURL('image/jpeg', 0.8);
    }
    return null;
  };
  
  // Capture Aadhaar image
  const captureAadhaarImage = () => {
    const imageData = captureFrame();
    if (imageData) {
      setCapturedImage(imageData);
      setOriginalImage(imageData);
      // Stop webcam after capturing
      stopWebcam();
    } else {
      setError('Failed to capture image. Please try again.');
    }
  };
  const processImage = async () => {
  if (!originalImage) {
    setError('Please capture an image first');
    return;
  }
  
  setIsLoading(true);
  setError('');
  
  try {
    // Convert base64 to blob
    const response = await fetch(originalImage);
    const blob = await response.blob();
    
    const formData = new FormData();
    formData.append('image', blob, 'aadhaar.jpg');
    
    // Add applicant ID if available
    if (kycData.applicantId) {
      formData.append('applicant_id', kycData.applicantId);
    }
    
    const result = await fetch(serverUrl, {
      method: 'POST',
      body: formData
    });
    
    if (!result.ok) {
      // Try to parse error message from JSON response
      const errorData = await result.json().catch(() => null);
      throw new Error(errorData?.error || `Server error: ${result.status} ${result.statusText}`);
    }
    
    // Check if the response is JSON (contains DMS ID) or an image
    const contentType = result.headers.get('Content-Type');
    
    if (contentType && contentType.includes('application/json')) {
      // It's JSON with DMS ID
      const jsonData = await result.json();
      
      if (jsonData.success && jsonData.dms_id) {
        // Get the DMS ID
        const dmsId = jsonData.dms_id;
        console.log("Received DMS ID from server:", dmsId);
        
        // Get the image URL using the DMS ID
        const imageUrl = `${serverUrl}/get_masked_aadhaar/${dmsId}`;
        setMaskedImage(imageUrl);
        
        // Update KYC data with DMS ID
        updateKycData({
          aadhaarImage: originalImage,
          maskedAadhaarImage: imageUrl,
          maskedAadhaarDmsId: dmsId
        });
      } else {
        throw new Error(jsonData.error || 'Failed to process image');
      }
    } else {
      // It's an image blob
      const imageBlob = await result.blob();
      
      // Convert blob to base64 string for storage and transmission
      const reader = new FileReader();
      reader.readAsDataURL(imageBlob);
      reader.onloadend = () => {
        const base64data = reader.result;
        setMaskedImage(base64data);
        
        // Check for DMS ID in headers
        const dmsId = result.headers.get('X-DMS-ID');
        
        // Update KYC data
        updateKycData({
          aadhaarImage: originalImage,
          maskedAadhaarImage: base64data,
          maskedAadhaarDmsId: dmsId
        });
        
        console.log("Masked Aadhaar image processed, DMS ID:", dmsId);
      };
    }
    
  } catch (err) {
    setError(err.message || 'Failed to process image');
    console.error('Error processing Aadhaar image:', err);
    
    // Reset for recapture if there was an error
    setMaskedImage(null);
  } finally {
    setIsLoading(false);
  }
};

  
  // Handle recapture
  const handleRecapture = () => {
    setOriginalImage(null);
    setCapturedImage(null);
    setMaskedImage(null);
    setMaskedAadhaarDmsId(null);
    setError('');
    startWebcam();
  };
  
  // Handle continue to next step
// Modify handleContinue to include DMS ID
const handleContinue = () => {
  if (!maskedImage) {
    setError('Please process an Aadhaar image first');
    return;
  }
  
  // Use the DMS ID from state if available
  const dmsId = kycData.maskedAadhaarDmsId;
  
  console.log("Continuing with masked Aadhaar DMS ID:", dmsId);
  
  nextStep({
    maskedAadhaarImage: maskedImage,
    maskedAadhaarDmsId: dmsId
  });
};

  
  // Ensure DMS ID is properly stored in kycData when it changes
  useEffect(() => {
    if (maskedAadhaarDmsId) {
      console.log('Aadhaar DMS ID updated in state:', maskedAadhaarDmsId);
      
      // Update KYC data with the DMS ID
      updateKycData({
        maskedAadhaarDmsId: maskedAadhaarDmsId
      });
    }
  }, [maskedAadhaarDmsId, updateKycData]);
  
  // Start webcam on component mount
  useEffect(() => {
    startWebcam();
    
    // Clean up on component unmount
    return () => {
      stopWebcam();
    };
  }, []);
  
  return (
    <div className="aadhaar-masker">
      <h2>Aadhaar Card Capture</h2>
      <p className="instructions">
        Position your Aadhaar card in front of the camera and capture a clear image and make sure Aadhar face is visible clearly.
      </p>
      
      {/* Debug information */}
      <div className="debug-info" style={{ margin: '10px', padding: '10px', border: '1px solid #ccc', backgroundColor: '#f8f8f8', fontSize: '12px' }}>
        <h4>Debug Information</h4>
        <p>Masked Aadhaar DMS ID: {maskedAadhaarDmsId || 'Not captured'}</p>
        <p>Original Image: {originalImage ? 'Captured' : 'Not captured'}</p>
        <p>Masked Image: {maskedImage ? 'Processed' : 'Not processed'}</p>
      </div>
      
      {!capturedImage && (
        <div className="webcam-container">
          <video ref={webcamRef} autoPlay playsInline className="webcam-video"></video>
          <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
          
          <div className="capture-controls">
            <button
              className="capture-btn"
              onClick={captureAadhaarImage}
              disabled={!streaming}
            >
              Capture Aadhaar Image
            </button>
          </div>
        </div>
      )}
      
      {isLoading && (
        <div className="loading">
          <div className="spinner"></div>
          <p>Processing image...</p>
        </div>
      )}
      
      {error && (
        <div className="error-message">
          {error}
          {capturedImage && (
            <button className="recapture-btn" onClick={handleRecapture}>
              Recapture Image
            </button>
          )}
        </div>
      )}
      
      <div className="image-preview">
        <div className="preview-container">
          <h3>Original Image</h3>
          {originalImage && <img src={originalImage} alt="Original Aadhaar" className="preview-image" />}
          {originalImage && !maskedImage && !isLoading && (
            <button
              className="process-btn"
              onClick={processImage}
              disabled={isLoading}
            >
              Process Aadhaar Card
            </button>
          )}
          {originalImage && (
            <button
              className="recapture-btn"
              onClick={handleRecapture}
              disabled={isLoading}
            >
              Recapture Image
            </button>
          )}
        </div>
        <div className="preview-container">
          <h3>Masked Image</h3>
          {maskedImage && (
            <>
              <img src={maskedImage} alt="Masked Aadhaar" className="preview-image" />
              {maskedAadhaarDmsId && (
                <div className="dms-info">
                  <small>DMS ID: {maskedAadhaarDmsId}</small>
                </div>
              )}
            </>
          )}
        </div>
      </div>
      
      <div className="navigation-buttons">
        {maskedImage && (
          <button
            className="continue-btn"
            onClick={handleContinue}
          >
            Continue
          </button>
        )}
      </div>
    </div>
  );
};

export default AadhaarMasker;
