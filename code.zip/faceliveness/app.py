from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import cv2
import numpy as np
import base64
from ultralytics import YOLO
import logging
import dlib
import time
import os
from scipy.spatial import distance as dist
from imutils import face_utils
from datetime import datetime
import threading
import uuid

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
#
app = Flask(__name__)
# Configure CORS more explicitly
CORS(app, resources={r"/*": {"origins": "*", "allow_headers": ["Content-Type"], "methods": ["POST", "GET", "OPTIONS"]}})

# Create directories for saving images
os.makedirs("successful_kyc", exist_ok=True)
os.makedirs("failed_kyc", exist_ok=True)
os.makedirs("temp_images", exist_ok=True)

# Constants for liveness detection
EYE_AR_THRESH = 0.25
EYE_AR_CONSEC_FRAMES = 3
MOUTH_AR_THRESH = 0.5
REFLECTION_THRESHOLD = 200
REQUIRED_FRAMES = 5

# Load modelsF
try:
    hand_detector = YOLO('yolov10n_hand_detect.pt')
    has_hand_detector = True
    logger.info("Hand detector loaded successfully")
except Exception as e:
    has_hand_detector = False
    logger.warning(f"Hand detector not loaded: {e}")

try:
    screen_detector = YOLO("screen detect1.pt")
    has_screen_detector = True
    logger.info("Screen detector loaded successfully")
except Exception as e:
    has_screen_detector = False
    logger.warning(f"Screen detector not loaded: {e}")

# Initialize dlib's face detector and facial landmark predictor
logger.info("Loading the predictor and detector...")
detector = dlib.get_frontal_face_detector()
try:
    predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
    has_face_predictor = True
    logger.info("Face predictor loaded successfully")
except Exception as e:
    has_face_predictor = False
    logger.warning(f"Face predictor not loaded: {e}")

# Get facial landmark indexes for eyes and mouth
(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]
(mStart, mEnd) = face_utils.FACIAL_LANDMARKS_IDXS["mouth"]

# Define challenges
challenges = [
    {"name": "BLINK", "instruction": "Please blink your eyes", "duration": 5},
    {"name": "OPEN_MOUTH", "instruction": "Please open your mouth", "duration": 5}
]

# Session storage
sessions = {}

# Helper functions
def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

def mouth_aspect_ratio(mouth):
    A = dist.euclidean(mouth[3], mouth[9])
    B = dist.euclidean(mouth[2], mouth[10])
    C = dist.euclidean(mouth[4], mouth[8])
    D = dist.euclidean(mouth[0], mouth[6])
    mar = (A + B + C) / (3.0 * D)
    return mar

def detect_screen(frame):
    """Detect if a screen is present in the frame"""
    if not has_screen_detector:
        return False
    
    results = screen_detector(frame, verbose=False)[0]
    for box in results.boxes:
        if box.conf > 0.8:
            return True
    return False

def detect_reflections(frame, face_region):
    """Detect unnatural reflections that might indicate a screen"""
    if face_region.size == 0:
        return False
    
    # Convert to HSV for better highlight detection
    hsv = cv2.cvtColor(face_region, cv2.COLOR_BGR2HSV)
    
    # Extract the V channel (brightness)
    _, _, v = cv2.split(hsv)
    print(v)
    # Look for bright spots (potential reflections)
    _, bright_spots = cv2.threshold(v, REFLECTION_THRESHOLD, 255, cv2.THRESH_BINARY)
    
    # Count bright pixels
    bright_pixel_count = cv2.countNonZero(bright_spots)
    bright_pixel_ratio = bright_pixel_count / (face_region.shape[0] * face_region.shape[1])
    
    # If more than 10% of face has bright reflections, it might be a spoof
    return bright_pixel_ratio > 0.20

def save_capture(frame, session_id, success=True):
    """Save the captured frame to the appropriate folder"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = "successful_kyc" if success else "failed_kyc"
    filename = f"{folder}/{timestamp}_{session_id}.jpg"
    temp_filename = f"temp_images/{session_id}.jpg"
    
    # Save to permanent storage
    cv2.imwrite(filename, frame)
    
    # Save to temporary location for frontend access
    cv2.imwrite(temp_filename, frame)
    
    logger.info(f"Image saved to {filename} and {temp_filename}")
    return temp_filename

def process_liveness_frame(frame, session_data):
    """Process a single frame for liveness detection"""
    # Track frame processing time
    current_time = time.time()
    if 'last_frame_time' in session_data:
        frame_interval = current_time - session_data['last_frame_time']
        # Log if frames are coming in too slowly
        if frame_interval > 0.2:  # More than 200ms between frames
            logger.warning(f"Slow frame rate detected: {1/frame_interval:.2f} FPS")
    session_data['last_frame_time'] = current_time
    
    # Convert frame to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Store clean frame for potential capture
    session_data['clean_frame'] = frame.copy()
    
    # Check for screen spoofing
    if not session_data['spoofing_detected'] and time.time() - session_data['last_spoof_check'] > 2:
        session_data['last_spoof_check'] = time.time()
        if has_screen_detector and detect_screen(frame):
            session_data['spoofing_detected'] = True
            session_data['message'] = "SPOOFING DETECTED: Screen Present. Please do not use a phone or screen."
            session_data['status'] = "failed"
            session_data['stop_webcam'] = True
            return
    
    # Detect faces
    faces = detector(gray)
    
    if len(faces) != 1:
        # Only update the message if we're not in a spoofed state
        if not session_data['spoofing_detected']:
            session_data['message'] = "Please position your face in the center of the frame"
        return
    
    face = faces[0]
    
    # Extract face region for reflection analysis
    x, y, w, h = face.left(), face.top(), face.width(), face.height()
    face_region = frame[y:y+h, x:x+w]
    
    # Check for unnatural reflections
    if not session_data['spoofing_detected'] and time.time() - session_data['last_reflection_check'] > 3:
        session_data['last_reflection_check'] = time.time()
        if detect_reflections(frame, face_region):
            session_data['spoofing_detected'] = True
            session_data['message'] = "SPOOFING DETECTED: Unnatural Reflections. Please do not use a phone or screen."
            session_data['status'] = "failed"
            session_data['stop_webcam'] = True
            return
    
    # If spoofing detected, stop processing
    if session_data['spoofing_detected']:
        return
    
    # Get facial landmarks
    shape = predictor(gray, face)
    shape_np = face_utils.shape_to_np(shape)
    
    # Extract eye and mouth regions
    leftEye = shape_np[lStart:lEnd]
    rightEye = shape_np[rStart:rEnd]
    mouth = shape_np[mStart:mEnd]
    
    # Calculate metrics
    leftEAR = eye_aspect_ratio(leftEye)
    rightEAR = eye_aspect_ratio(rightEye)
    ear = (leftEAR + rightEAR) / 2.0
    mar = mouth_aspect_ratio(mouth)
    
    # Process current challenge
    if session_data['current_challenge'] < len(challenges):
        challenge = challenges[session_data['current_challenge']]
        
        # Initialize challenge timer if not started
        if session_data['challenge_start_time'] is None:
            # Add a 2-second delay before starting the first challenge
            if session_data['current_challenge'] == 0 and not session_data.get('initial_delay_shown', False):
                if not session_data.get('initial_delay_start', None):
                    session_data['initial_delay_start'] = time.time()
                    session_data['message'] = "Preparing liveness check..."
                
                # Wait 2 seconds before starting the first challenge
                if time.time() - session_data['initial_delay_start'] < 2.0:
                    return
                
                session_data['initial_delay_shown'] = True
            
            session_data['challenge_start_time'] = time.time()
            session_data['challenge_completed'] = False
            logger.info(f"Starting challenge: {challenge['name']}")
        
        # Calculate remaining time
        elapsed_time = time.time() - session_data['challenge_start_time']
        remaining_time = max(0, challenge["duration"] - elapsed_time)
        
        # Update message with current challenge - match headnod.py format
        session_data['message'] = f"{challenge['instruction']} - Time: {remaining_time:.1f}s"
        
        # Check if challenge is completed - exactly match headnod.py logic
        if challenge["name"] == "BLINK":
            # Log the current eye aspect ratio for debugging
            logger.debug(f"EAR: {ear}, threshold: {EYE_AR_THRESH}, count: {session_data['blink_frame_count']}")
            
            if ear < EYE_AR_THRESH:
                session_data['blink_frame_count'] += 1
            else:
                session_data['blink_frame_count'] = 0
            
            if session_data['blink_frame_count'] >= EYE_AR_CONSEC_FRAMES:
                session_data['challenge_completed'] = True
                logger.info(f"Blink detected! Count: {session_data['blink_frame_count']}")
        
        elif challenge["name"] == "OPEN_MOUTH":
            # Log the current mouth aspect ratio for debugging
            logger.debug(f"MAR: {mar}, threshold: {MOUTH_AR_THRESH}, count: {session_data['open_mouth_frame_count']}")
            
            if mar > MOUTH_AR_THRESH:
                session_data['open_mouth_frame_count'] += 1
            else:
                session_data['open_mouth_frame_count'] = 0
            
            if session_data['open_mouth_frame_count'] >= REQUIRED_FRAMES:
                session_data['challenge_completed'] = True
                logger.info(f"Mouth opening detected! Count: {session_data['open_mouth_frame_count']}")
        
        # Move to next challenge if completed or time expired
        if session_data['challenge_completed'] or remaining_time <= 0:
            if session_data['challenge_completed']:
                logger.info(f"Challenge '{challenge['name']}' completed successfully!")
                # Match headnod.py message
                session_data['message'] = "CHALLENGE COMPLETED!"
                
                # Add a short delay before moving to the next challenge (like in headnod.py)
                if not session_data.get('challenge_completion_time', None):
                    session_data['challenge_completion_time'] = time.time()
                    return
                
                # Wait 0.5 seconds (like the 500ms delay in headnod.py)
                if time.time() - session_data['challenge_completion_time'] < 0.5:
                    return
                
                # Move to next challenge
                session_data['current_challenge'] += 1
                # Clear the completion time for the next challenge
                session_data.pop('challenge_completion_time', None)
            else:
                logger.info(f"Challenge '{challenge['name']}' failed.")
                # Match headnod.py message
                session_data['message'] = "CHALLENGE FAILED!"
                
                # Add a short delay before resetting (like in headnod.py)
                if not session_data.get('challenge_failure_time', None):
                    session_data['challenge_failure_time'] = time.time()
                    return
                
                # Wait 0.5 seconds (like the 500ms delay in headnod.py)
                if time.time() - session_data['challenge_failure_time'] < 0.5:
                    return
                
                # Reset liveness check
                session_data['current_challenge'] = 0
                session_data['blink_frame_count'] = 0
                session_data['open_mouth_frame_count'] = 0
                # Clear the failure time
                session_data.pop('challenge_failure_time', None)
            
            # Reset for next challenge
            session_data['challenge_start_time'] = None
            session_data['challenge_completed'] = False
    else:
        # All challenges completed
        session_data['liveness_confirmed'] = True
        session_data['status'] = "success"
        # Match headnod.py message
        session_data['message'] = "LIVENESS CONFIRMED! Please stay still for photo capture."
        
        # If we haven't started the capture countdown yet
        if session_data['capture_start_time'] is None:
            session_data['capture_start_time'] = time.time()
        
        # Check if it's time to capture
        elapsed_time = time.time() - session_data['capture_start_time']
        remaining_capture_time = max(0, 3 - elapsed_time)  # 5 second delay
        
        # Update message with countdown
        session_data['message'] = f"LIVENESS CONFIRMED! Capturing image in {remaining_capture_time:.1f}s"
        
        if elapsed_time >= 3 and not session_data['image_captured']:  # 3 second delay
            # Capture the image
            temp_filename = save_capture(
                session_data['clean_frame'], 
                session_data['session_id'],
                not session_data['spoofing_detected']
            )
            session_data['image_captured'] = True
            session_data['image_path'] = temp_filename
            session_data['message'] = "Image captured successfully! Redirecting to verification..."


@app.route('/detect', methods=['POST', 'OPTIONS'])
def detect():
    # Handle preflight OPTIONS request
    if request.method == 'OPTIONS':
        logger.debug("Received OPTIONS request")
        return '', 200
    
    logger.debug("Received POST request")
    try:
        # Get the image data from the request
        request_data = request.get_json()
        if not request_data:
            logger.error("No JSON data in request")
            return jsonify({'error': 'No JSON data provided'}), 400
            
        image_data = request_data.get('image')
        if not image_data:
            logger.error("No image data in request JSON")
            return jsonify({'error': 'No image data provided'}), 400
        
        logger.debug("Image data received, processing...")
        
        # Decode the base64 image
        try:
            encoded_data = image_data.split(',')[1]
            nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if img is None:
                logger.error("Failed to decode image")
                return jsonify({'error': 'Failed to decode image'}), 400
                
            logger.debug(f"Image decoded successfully, shape: {img.shape}")
        except Exception as e:
            logger.error(f"Error decoding image: {str(e)}")
            return jsonify({'error': f'Error decoding image: {str(e)}'}), 400
        
        # Run YOLO detection
        logger.debug("Running YOLO detection...")
        results = hand_detector(img)
        logger.debug("YOLO detection completed")
        
        # Process results
        detected_signs = []
        for result in results:
            boxes = result.boxes
            logger.debug(f"Found {len(boxes)} detections")
            
            for box in boxes:
                # Get class and confidence
                cls_id = int(box.cls.item())
                conf = float(box.conf.item())
                
                if conf > 0.5:  # Confidence threshold
                    # Use the model's class names directly
                    hand_sign = result.names[cls_id]
                    detected_signs.append({
                        'sign': hand_sign,
                        'confidence': conf
                    })
                    logger.debug(f"Detected sign: {hand_sign} with confidence: {conf}")
        
        # Return the detected hand signs
        response_data = {
            'success': True,
            'detected_signs': detected_signs
        }
        logger.debug(f"Returning response: {response_data}")
        return jsonify(response_data)
    
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500
@app.route('/start_liveness', methods=['POST'])
def start_liveness():
    """Initialize a new liveness detection session"""
    session_id = str(uuid.uuid4())
    
    # Create a new session
    sessions[session_id] = {
        'session_id': session_id,
        'start_time': time.time(),
        'current_challenge': 0,
        'challenge_start_time': None,
        'challenge_completed': False,
        'blink_frame_count': 0,
        'open_mouth_frame_count': 0,
        'liveness_confirmed': False,
        'spoofing_detected': False,
        'last_spoof_check': 0,
        'last_reflection_check': 0,
        'status': 'pending',
        'message': 'Starting liveness detection...',
        'clean_frame': None,
        'capture_start_time': None,
        'image_captured': False,
        'image_path': None,
        'stop_webcam': False,
        'initial_delay_start': None,
        'initial_delay_shown': False,
        'challenge_completion_time': None,
        'challenge_failure_time': None,
        'last_frame_time': time.time(),
    }
    
    logger.info(f"Created new liveness session: {session_id}")
    # Add this to process_liveness_frame function

    return jsonify({
        'success': True,
        'session_id': session_id,
        'message': 'Liveness detection session started'
    })

@app.route('/process_liveness_frame', methods=['POST'])
def process_liveness():
    """Process a frame for liveness detection"""
    try:
        # Get request data
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        session_id = request_data.get('session_id')
        image_data = request_data.get('image')
        
        if not session_id or not image_data:
            return jsonify({'error': 'Missing session_id or image data'}), 400
        
        # Check if session exists
        if session_id not in sessions:
            return jsonify({'error': 'Invalid session ID'}), 404
        
        session_data = sessions[session_id]
        
        # Decode the base64 image
        try:
            encoded_data = image_data.split(',')[1]
            nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if img is None:
                return jsonify({'error': 'Failed to decode image'}), 400
        except Exception as e:
            logger.error(f"Error decoding image: {str(e)}")
            return jsonify({'error': f'Error decoding image: {str(e)}'}), 400
        
        # Process the frame for liveness detection
        process_liveness_frame(img, session_data)
        
        # Prepare response
        response = {
            'success': True,
            'session_id': session_id,
            'status': session_data['status'] if 'status' in session_data else 'pending',
            'message': session_data['message'],
            'current_challenge': session_data['current_challenge'],
            'total_challenges': len(challenges),
            'liveness_confirmed': session_data['liveness_confirmed'],
            'spoofing_detected': session_data['spoofing_detected'],
            'stop_webcam': session_data.get('stop_webcam', False)

        }
        
        # If image has been captured, include the path
        if session_data['image_captured'] and session_data['image_path']:
            response['image_path'] = session_data['image_path']
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Error processing liveness frame: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/get_captured_image/<session_id>', methods=['GET'])
def get_captured_image(session_id):
    """Return the captured image for a session"""
    if session_id not in sessions:
        return jsonify({'error': 'Invalid session ID'}), 404
    
    session_data = sessions[session_id]
    
    if not session_data['image_captured'] or not session_data['image_path']:
        return jsonify({'error': 'No image captured for this session'}), 404
    
    try:
        return send_file(session_data['image_path'], mimetype='image/jpeg')
    except Exception as e:
        logger.error(f"Error sending image: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/search', methods=['POST'])
def search():
    """Process the captured image for search/verification"""
    try:
        # Get request data
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        session_id = request_data.get('session_id')
        
        if not session_id:
            return jsonify({'error': 'Missing session_id'}), 400
        
        # Check if session exists
        if session_id not in sessions:
            return jsonify({'error': 'Invalid session ID'}), 404
        
        session_data = sessions[session_id]
        
        # Check if image was captured
        if not session_data['image_captured'] or not session_data['image_path']:
            return jsonify({'error': 'No image captured for this session'}), 400
        
        # Here you would implement your search/verification logic
        # For now, we'll just return a success message
        
        # Mock search result
        search_result = {
            'success': True,
            'message': 'Verification completed successfully',
            'match_found': True,
            'match_confidence': 0.95,
            'user_details': {
                'name': 'John Doe',
                'id': '12345',
                'status': 'Verified'
            }
        }
        
        return jsonify(search_result)
    
    except Exception as e:
        logger.error(f"Error in search: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/test', methods=['GET'])
def test():
    return jsonify({'status': 'API is working'})

if __name__ == '__main__':
    logger.info("Starting Flask server...")
    app.run(host='0.0.0.0', port=5003, debug=True)
