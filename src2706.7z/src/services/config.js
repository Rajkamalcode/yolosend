// Configuration service to centralize all environment variables
const config = {
  // API URLs
  facededupeapiServerUrl: import.meta.env.VITE_API_SERVER_URL,
  livenessServerUrl: import.meta.env.VITE_LIVENESS_SERVER_URL || 'http://localhost:5103',
  aadhaarServerUrl: import.meta.env.VITE_AADHAAR_SERVER_URL || 'http://localhost:5004',
  adminPassword: import.meta.env.VITE_ADMIN_PASSWORD || 'admin123', // Add this line
  // Other configuration values can be added here
  isDevelopment: import.meta.env.DEV,
  isProduction: import.meta.env.PROD,
  
  // Helper method to get base URL for a specific service
  getServiceUrl(service) {
    switch(service) {
      case 'api':
        return this.facededupeapiServerUrl;
      case 'liveness':
        return this.livenessServerUrl;
      case 'aadhaar':
        return this.aadhaarServerUrl;
      default:
        return this.facededupeapiServerUrl;
    }
  }
};

export default config;
