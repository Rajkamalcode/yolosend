import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import LivenessCheck from './LivenessCheck';
import FaceDedupe from './FaceDedupe';
import AadhaarMasker from './AadhaarMasker';
import FaceComparison from './FaceComparison';
import GroupLoanDashboard from './GroupLoanDashboard';
import './KycFlow.css';

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

// PrintOptimizedView - Only visible when printing
const PrintOptimizedView = ({ kycData }) => {
  // Determine verification status
  const isApproved = kycData.verificationStatus === 'approved';
  const isDuplicate = kycData.verificationStatus === 'duplicate_found';
  const requiresScrutiny = kycData.verificationStatus === 'requires_scrutiny';
  
  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return new Date().toLocaleDateString();
    try {
      return new Date(dateString).toLocaleDateString();
    } catch (e) {
      return new Date().toLocaleDateString();
    }
  };
  
  return (
    <div className="print-only-view">
      <div className="print-header">
        <h2>KYC Verification Report</h2>
        <div className="print-applicant-info">
          <p><strong>Name:</strong> {kycData.applicantName}</p>
          <p><strong>Application ID:</strong> {kycData.applicationId}</p>
          <p><strong>Date:</strong> {formatDate()}</p>
        </div>
      </div>
      
      <div className="print-status">
        <h3>Verification Status: 
          <span className={
            isApproved ? 'status-approved' : 
            isDuplicate ? 'status-duplicate' : 
            requiresScrutiny ? 'status-scrutiny' : 'status-rejected'
          }>
            {isApproved ? 'APPROVED' : 
             isDuplicate ? 'DUPLICATE FOUND' : 
             requiresScrutiny ? 'UNDER REVIEW' : 'REJECTED'}
          </span>
        </h3>
      </div>
      
      <div className="print-summary-grid">
        {/* Compact summary for printing */}
      </div>
      
      <div className="print-footer">
        <p>This is an automatically generated report. Please contact support for any queries.</p>
        <p>Reference ID: {kycData.applicantId}</p>
      </div>
    </div>
  );
};

const KycSummary = ({ kycData, prevStep, applicationId, applicantId }) => {
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({
      name: kycData.applicantName || '',
      dob: ''
    });
    const [submitting, setSubmitting] = useState(false);
    const [submitResult, setSubmitResult] = useState(null);
    const [error, setError] = useState('');
    const [printTriggered, setPrintTriggered] = useState(false);
    
    // Image states
    const [livenessImageUrl, setLivenessImageUrl] = useState(null);
    const [maskedAadhaarUrl, setMaskedAadhaarUrl] = useState(null);
    
    
    // Server URLs
    const serverUrl = 'http://10.9.52.21:5001';
    const livenessServerUrl = 'http://10.9.52.21:5003';
    const aadhaarServerUrl = 'http://10.9.52.21:5004';
    
    // Autofill form data when kycData changes
    useEffect(() => {
        if (kycData.applicantName) {
            setFormData(prevData => ({
                ...prevData,
                name: kycData.applicantName
            }));
        }
    }, [kycData]);

    useEffect(() => {
      if (kycData.kycImageDmsIds && kycData.kycImageDmsIds.length > 0 && !kycData.multiComparisonResults) {
        console.log("Processing kycImageDmsIds to create multiComparisonResults:", kycData.kycImageDmsIds);
        
        // Create multiComparisonResults from kycImageDmsIds if it doesn't exist
        const multiResults = kycData.kycImageDmsIds.map(item => ({
          dmsId: item.dmsId,
          type: item.type || 'KYC Document',
          similarity: item.similarity || (kycData.comparisonResult ? kycData.comparisonResult.similarity : 0.5)
        }));
        
        // Update the state with these results
        updateKycData({
          multiComparisonResults: multiResults
        });
      }
    }, [kycData.kycImageDmsIds, kycData.multiComparisonResults]);
    
    // Set image URLs directly without checking first
    useEffect(() => {
        console.log("Setting up image URLs with data:", {
            livenessImageDmsId: kycData.livenessImageDmsId,
            livenessImage: kycData.livenessImage,
            maskedAadhaarDmsId: kycData.maskedAadhaarDmsId,
            maskedAadhaarImage: kycData.maskedAadhaarImage
        });
        
        // For liveness image
        if (kycData.livenessImageDmsId) {
            const url = `${aadhaarServerUrl}/process_aadhar/get_masked_aadhaar/${kycData.livenessImageDmsId}`;
            console.log("Setting liveness image URL from DMS ID:", url);
            setLivenessImageUrl(url);
        } else if (kycData.livenessImage) {
            console.log("Setting liveness image URL directly:", kycData.livenessImage);
            setLivenessImageUrl(kycData.livenessImage);
        }
        
        // For masked Aadhaar image
        if (kycData.maskedAadhaarDmsId) {
            const url = `${aadhaarServerUrl}/process_aadhar/get_masked_aadhaar/${kycData.maskedAadhaarDmsId}`;
            console.log("Setting masked Aadhaar URL from DMS ID:", url);
            setMaskedAadhaarUrl(url);
        } else if (kycData.maskedAadhaarImage) {
            console.log("Setting masked Aadhaar URL directly:", kycData.maskedAadhaarImage);
            setMaskedAadhaarUrl(kycData.maskedAadhaarImage);
        }
    }, [
        kycData.livenessImageDmsId, 
        kycData.livenessImage, 
        kycData.maskedAadhaarDmsId, 
        kycData.maskedAadhaarImage,
        livenessServerUrl,
        aadhaarServerUrl
    ]);
    
    // Log when image URLs change
    useEffect(() => {
        console.log("Image URLs updated:", {
            livenessImageUrl,
            maskedAadhaarUrl
        });
    }, [livenessImageUrl, maskedAadhaarUrl]);
    
    // Handle print optimization
    const handlePrint = () => {
      if (printTriggered) return; // Prevent multiple print triggers
      
      setPrintTriggered(true);
      
      // Optimize for printing
      document.body.classList.add('printing');
      
      // Set timeout to allow CSS changes to take effect
      setTimeout(() => {
        window.print();
        
        // Remove print optimization after printing dialog closes
        setTimeout(() => {
          document.body.classList.remove('printing');
          setPrintTriggered(false);
        }, 1000);
      }, 100);
    };
    // Handle form submission
    const handleSubmitApplication = async (e) => {
      e.preventDefault();
      
      if (!formData.name || !formData.dob) {
        setError('Please fill in all required fields');
        return;
      }
      
      if (!kycData.livenessImageDmsId && !kycData.livenessImage) {
        setError('No liveness image available. Cannot proceed.');
        return;
      }
      
      setSubmitting(true);
      setError('');
      
      try {
        // Get the image data - ensure it's in the correct format
        let imageData = kycData.livenessImage;
        
        // If we have a DMS ID, use that instead
        if (kycData.livenessImageDmsId) {
          // Prepare the data for submission with DMS ID
          const applicationData = {
            name: formData.name,
            dob: formData.dob,
            liveness_image_dms_id: kycData.livenessImageDmsId,
            applicant_id: applicantId,
            application_id: applicationId,
            phone: kycData.applicantPhone || '',
            address: kycData.applicantAddress || ''
          };
          
          console.log("Submitting application with DMS ID:", kycData.livenessImageDmsId);
          
          // Submit to the backend
          const response = await fetch(`${serverUrl}/submit_application`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(applicationData)
          });
          
          const result = await response.json();
          
          if (response.ok) {
            setSubmitResult({
              success: true,
              message: result.message,
              ucic_id: result.ucic_id
            });
          } else {
            setSubmitResult({
              success: false,
              message: result.error || 'Failed to submit application'
            });
          }
        } else {
          // If the image is a URL (starts with http or data:image), we need to handle it differently
          if (typeof imageData === 'string') {
            if (imageData.startsWith('data:image')) {
              // It's already a data URL, we're good
              console.log("Image is already in data URL format");
            } else if (imageData.startsWith('http')) {
              // It's a URL, we need to fetch it and convert to base64
              try {
                const response = await fetch(imageData);
                const blob = await response.blob();
                
                // Convert blob to base64
                const reader = new FileReader();
                const base64Promise = new Promise(resolve => {
                  reader.onloadend = () => resolve(reader.result);
                  reader.readAsDataURL(blob);
                });
                
                imageData = await base64Promise;
                console.log("Converted image URL to data URL");
              } catch (imgError) {
                console.error("Error fetching image:", imgError);
                setError('Failed to process image. Please try again.');
                setSubmitting(false);
                return;
              }
            }
          } else {
            setError('Invalid image format. Please try again.');
            setSubmitting(false);
            return;
          }
          
          // Prepare the data for submission with image data
          const applicationData = {
            name: formData.name,
            dob: formData.dob,
            image: imageData,
            applicant_id: applicantId,
            application_id: applicationId,
            phone: kycData.applicantPhone || '',
            address: kycData.applicantAddress || ''
          };
          
          console.log("Submitting application with image length:", imageData.length);
          
          // Submit to the backend
          const response = await fetch(`${serverUrl}/submit_application`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(applicationData)
          });
          
          const result = await response.json();
          
          if (response.ok) {
            setSubmitResult({
              success: true,
              message: result.message,
              ucic_id: result.ucic_id
            });
          } else {
            setSubmitResult({
              success: false,
              message: result.error || 'Failed to submit application'
            });
          }
        }
      } catch (error) {
        console.error('Error submitting application:', error);
        setError('An error occurred while submitting your application');
      } finally {
        setSubmitting(false);
      }
    };
    
    // Determine verification status
    const isApproved = kycData.verificationStatus === 'approved';
    const isDuplicate = kycData.verificationStatus === 'duplicate_found';
    const requiresScrutiny = kycData.verificationStatus === 'requires_scrutiny';
    
return (
  <div className="kyc-summary">
    {/* Minimal header with compact status badge */}
    <div className="kyc-summary-header">
      <div className="header-flex">
        <h2>KYC Summary</h2>
        <span className={`status-badge-compact ${
          isApproved ? 'success' : 
          isDuplicate ? 'duplicate' : 
          requiresScrutiny ? 'scrutiny' : 'rejected'
        }`}>
          {isApproved ? 'Verified' : 
          isDuplicate ? 'Duplicate' : 
          requiresScrutiny ? 'Review' : 'Failed'}
        </span>
      </div>
    </div>
    
    {/* Grid Layout for Summary Sections */}
    <div className="summary-grid">
      {/* Applicant Information - Compact Flex Layout */}
      <div className="summary-grid-item summary-grid-full applicant-info-compact">
        <h3>Applicant Details</h3>
        <div className="info-flex-container">
          <div className="info-flex-item">
            <span className="info-label">Name:</span>
            <span className="info-value">{kycData.applicantName}</span>
          </div>
          <div className="info-flex-item">
            <span className="info-label">Phone:</span>
            <span className="info-value">{kycData.applicantPhone}</span>
          </div>
          <div className="info-flex-item">
            <span className="info-label">App ID:</span>
            <span className="info-value">{kycData.applicationId}</span>
          </div>
          {kycData.applicationType === 'group' && (
            <div className="info-flex-item">
              <span className="info-label">Role:</span>
              <span className="info-value">{kycData.isPrimaryApplicant ? 'Primary' : 'Co-Applicant'}</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Verification Status - Compact Icons in Flex Layout - Full Width */}
      <div className="summary-grid-item summary-grid-full verification-status-flex">
        <h3>Verification Status</h3>
        <div className="verification-icons-flex">
          <div className="verification-icon-item">
            <div className={`status-icon ${kycData.kycSteps?.liveness ? 'success' : 'failure'}`}>
              {kycData.kycSteps?.liveness ? '✓' : '✗'}
            </div>
            <span className="icon-label">Liveness</span>
          </div>
          
          <div className="verification-icon-item">
            <div className={`status-icon ${kycData.kycSteps?.aadhaar ? 'success' : 'failure'}`}>
              {kycData.kycSteps?.aadhaar ? '✓' : '✗'}
            </div>
            <span className="icon-label">Aadhaar</span>
          </div>
          
          <div className="verification-icon-item">
            <div className={`status-icon ${kycData.comparisonResult ? 'success' : 'failure'}`}>
              {kycData.comparisonResult ? '✓' : '✗'}
            </div>
            <span className="icon-label">Face Match</span>
          </div>
          
          <div className="verification-icon-item">
            <div className={`status-icon ${isDuplicate ? 'failure' : requiresScrutiny ? 'warning' : 'success'}`}>
              {isDuplicate ? '✗' : requiresScrutiny ? '!' : '✓'}
            </div>
            <span className="icon-label">Dedupe</span>
          </div>
        </div>
      </div>
      
      {/* Face Comparison Section - Full Width */}
      <div className="summary-grid-item summary-grid-full face-comparison-section">
        <h3>Face Comparison</h3>
        <div className="comparison-container">
          {/* Grid Layout for Face Comparison */}
          <div className="comparison-hub-grid compact-grid">
            {/* Center - Liveness Image (div1) */}
            <div className="grid-item div1 liveness-item">
              <div className="grid-image-container">
                <h4>Live Photo</h4>
                <img 
                  src={livenessImageUrl || 'placeholder-face.jpg'} 
                  alt="Liveness Face" 
                  className="grid-image liveness-image"
                  onError={(e) => {
                    console.error('Failed to load liveness image:', livenessImageUrl);
                    e.target.onerror = null;
                    e.target.src = 'placeholder-face.jpg';
                  }}
                />
              </div>
            </div>
            
            {/* Top Left - Aadhaar Face (div2) */}
            <div className="grid-item div2">
              <div className="grid-image-container">
                <h4>Aadhaar Face</h4>
                <img 
                  src={maskedAadhaarUrl || 'placeholder-image.jpg'} 
                  alt="Masked Aadhaar" 
                  className="grid-image kyc-image" 
                  onError={(e) => {
                    console.error('Failed to load masked Aadhaar image:', maskedAadhaarUrl);
                    e.target.onerror = null;
                    e.target.src = 'placeholder-image.jpg';
                  }}
                />
                {kycData.comparisonResult && (
                  <div className="comparison-badge">
                    <span className={`similarity ${
                      kycData.comparisonResult.similarity >= 0.3 
                        ? 'match' 
                        : 'no-match'
                    }`}>
                      {(kycData.comparisonResult.similarity * 100).toFixed(0)}%
                    </span>
                  </div>
                )}
              </div>
            </div>
            
            {/* Add additional KYC images if available */}
            {(kycData.multiComparisonResults || kycData.kycImageDmsIds) && 
              (kycData.multiComparisonResults || kycData.kycImageDmsIds).map((result, index) => {
                // Only show up to 7 additional images (positions 3-9)
                if (index < 7) {
                  const position = index + 3; // Start from position 3
                  const dmsId = result.dmsId || result.dms_id;
                  const similarity = result.similarity || 0.5; // Default similarity if not available
                  
                  return (
                    <div key={`grid-image-${position}`} className={`grid-item div${position}`}>
                      <div className="grid-image-container">
                        <h4>{result.type || 'KYC Document'}</h4>
                        <img 
                          src={result.url || `${serverUrl}/get_dms_image/${dmsId}`} 
                          alt={result.type || 'KYC Document'} 
                          className="grid-image kyc-image"
                          onError={(e) => {
                            console.error(`Failed to load image for ${result.type}:`, dmsId);
                            e.target.onerror = null;
                            e.target.src = 'placeholder-image.jpg';
                          }}
                        />
                        <div className="comparison-badge">
                          <span className={`similarity ${
                            similarity >= 0.3 
                              ? 'match' 
                              : 'no-match'
                          }`}>
                            {(similarity * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                }
                return null;
              })}

          </div>
          
          {/* Compact Comparison Results */}
          {(kycData.comparisonResult || 
            (kycData.multiComparisonResults && kycData.multiComparisonResults.length > 0) ||
            (kycData.kycImageDmsIds && kycData.kycImageDmsIds.length > 0)) && (
            <div className="comparison-results-compact">
              <h4>Match Results</h4>
              <div className="results-badges">
                {kycData.comparisonResult && (
                  <div className="result-badge">
                    <span className="doc-name">Aadhaar</span>
                    <span className={`match-value ${kycData.comparisonResult.similarity >= 0.3 ? 'match' : 'no-match'}`}>
                      {(kycData.comparisonResult.similarity * 100).toFixed(0)}%
                    </span>
                  </div>
                )}
                
                {kycData.multiComparisonResults && kycData.multiComparisonResults.slice(0, 3).map((result, index) => (
                  <div key={`result-badge-${index}`} className="result-badge">
                    <span className="doc-name">{result.type || `Doc ${index + 1}`}</span>
                    <span className={`match-value ${result.similarity >= 0.3 ? 'match' : 'no-match'}`}>
                      {(result.similarity * 100).toFixed(0)}%
                    </span>
                  </div>
                ))}
                
                {!kycData.multiComparisonResults && kycData.kycImageDmsIds && kycData.kycImageDmsIds.slice(0, 3).map((result, index) => (
                  <div key={`result-badge-dms-${index}`} className="result-badge">
                    <span className="doc-name">{result.type || `Doc ${index + 1}`}</span>
                    <span className={`match-value ${(result.similarity || 0.5) >= 0.3 ? 'match' : 'no-match'}`}>
                      {((result.similarity || 0.5) * 100).toFixed(0)}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>

      
      {/* Two-Column Layout for Remaining Sections */}
      <div className="summary-grid-item">
        <h3>Liveness Check</h3>
        <div className="compact-status">
          <span className={`status-indicator ${kycData.kycSteps?.liveness ? 'success' : 'pending'}`}>
            {kycData.kycSteps?.liveness ? '✓' : '⟳'}
          </span>
          <span className="status-text">
            {kycData.kycSteps?.liveness ? 'Completed' : 'Pending'}
          </span>
        </div>
        {kycData.geoLocation && (
          <div className="geo-location-compact">
            <div className="geo-coordinates">
              <span>Lat: {kycData.geoLocation.latitude}</span>
              <span>Long: {kycData.geoLocation.longitude}</span>
            </div>
          </div>
        )}
      </div>

      {/* Face Deduplication Section */}
      <div className="summary-grid-item">
        <h3>Face Deduplication</h3>
        <div className="compact-status">
          <span className={`status-indicator ${kycData.kycSteps?.dedupe ? 'success' : 'pending'}`}>
            {kycData.kycSteps?.dedupe ? '✓' : '⟳'}
          </span>
          <span className="status-text">
            {kycData.kycSteps?.dedupe ? 'Completed' : 'Pending'}
          </span>
        </div>
        
        {kycData.verificationStatus && (
          <div className="verification-status-compact">
            <span className={`status-badge ${
              kycData.verificationStatus === 'approved' ? 'success' : 
              kycData.verificationStatus === 'requires_scrutiny' ? 'warning' : 'danger'
            }`}>
              {kycData.verificationStatus === 'approved' ? 'Approved' : 
              kycData.verificationStatus === 'requires_scrutiny' ? 'Review' : 
              'Duplicate'}
            </span>
          </div>
        )}
      </div>
      
      {/* Duplicate Matches - Only if matches exist */}
      {kycData.dedupeResults && kycData.dedupeResults.results && kycData.dedupeResults.results.length > 0 && (
        <div className="summary-grid-item">
          <h3>Matching Records Found</h3>
          <div className="matches-list-compact">
            {kycData.dedupeResults.results.slice(0, 2).map((match, index) => (
              <div key={index} className="match-item-compact">
                <div className="match-info-compact">
                  <span className="match-detail-compact">
                    <strong>UCIC:</strong> {match.ucic_id || 'N/A'}
                  </span>
                  <span className="match-detail-compact">
                    <strong>Name:</strong> {match.name || 'N/A'}
                  </span>
                  <span className="match-detail-compact">
                    <strong>Similarity:</strong> {(match.similarity * 100).toFixed(0)}%
                  </span>
                </div>
                {match.image_data ? (
                            <div className="match-image-compact">
                              <img src={match.image_data} alt={`Match ${index + 1}`} />
                            </div>
                          ) : match.dms_id ? (
                            <div className="match-image-compact">
                              <img 
                                src={`${serverUrl}/get_dms_image/${match.dms_id}`} 
                                alt={`Match ${index + 1}`}
                                key={`match-${match.dms_id}`}
                              />
                            </div>
                          ) : (
                            <div className="match-image-compact">No image available</div>
                          )}
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Co-Applicants Section - Compact for Group Loans */}
      {kycData.applicationType === 'group' && kycData.coApplicants && kycData.coApplicants.length > 0 && (
        <div className="summary-grid-item">
          <h3>Co-Applicants Status</h3>
          <div className="co-applicants-grid">
            {kycData.coApplicants.map((coApplicant, index) => (
              <div key={index} className="co-applicant-item-compact">
                <div className="co-applicant-name-compact">{coApplicant.name}</div>
                <div className={`co-applicant-status-compact ${
                  coApplicant.kyc_status === 'completed' ? 'status-completed' : 
                  coApplicant.kyc_status === 'in_progress' ? 'status-in-progress' : 'status-pending'
                }`}>
                  {coApplicant.kyc_status === 'completed' ? '✓' : 
                  coApplicant.kyc_status === 'in_progress' ? '⟳' : '⏱'}
                </div>
              </div>
            ))}
          </div>
          {/* Group Application Progress */}
          <div className="group-progress">
            <h4>Group KYC Progress</h4>
            <div className="progress-bar-container">
              <div className="progress-label">
                <span>KYC Completion:</span>
                <span>
                  {kycData.coApplicants.filter(a => a.kyc_status === 'completed').length} of {kycData.coApplicants.length} completed
                </span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ 
                    width: `${(kycData.coApplicants.filter(a => a.kyc_status === 'completed').length / kycData.coApplicants.length) * 100}%` 
                  }}
                ></div>
              </div>
            </div>
            
            <div className="progress-bar-container">
              <div className="progress-label">
                <span>Verification Status:</span>
                <span>
                  {kycData.coApplicants.filter(a => a.verification_status === 'approved').length} of {kycData.coApplicants.length} approved
                </span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ 
                    width: `${(kycData.coApplicants.filter(a => a.verification_status === 'approved').length / kycData.coApplicants.length) * 100}%` 
                  }}
                ></div>
              </div>
            </div>
          </div>
          
          {/* Group Application Status */}
          {kycData.isPrimaryApplicant && (
            <div className="group-status">
              <h4>Group Application Status</h4>
              <div className={`group-status-badge ${
                kycData.coApplicants.every(a => a.kyc_status === 'completed' && a.verification_status === 'approved') 
                  ? 'status-ready' 
                  : 'status-pending'
              }`}>
                {kycData.coApplicants.every(a => a.kyc_status === 'completed' && a.verification_status === 'approved')
                  ? 'Ready for Submission'
                  : 'Pending Co-Applicant Verification'}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
    
    {/* Application Form - Only show if approved and not yet submitted */}
    {isApproved && !showForm && !submitResult && (
      <div className="summary-actions">
        <button 
          className="continue-app-btn" 
          onClick={() => setShowForm(true)}
        >
          Continue to Application
        </button>
      </div>
    )}
    
    {isApproved && showForm && !submitResult && (
      <div className="application-form-container">
        <h3>Complete Your Application</h3>
        {error && <div className="error-message">{error}</div>}
        <form className="application-form" onSubmit={handleSubmitApplication}>
          <div className="form-group">
            <label htmlFor="name">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              required
              placeholder="Enter your full name"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="dob">Date of Birth</label>
            <input
              type="date"
              id="dob"
              name="dob"
              value={formData.dob}
              onChange={(e) => setFormData({...formData, dob: e.target.value})}
              required
            />
          </div>
          
          <div className="form-actions">
            <button 
              type="button" 
              className="cancel-btn" 
              onClick={() => setShowForm(false)}
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="submit-btn" 
              disabled={submitting}
            >
              {submitting ? 'Submitting...' : 'Submit Application'}
            </button>
          </div>
        </form>
      </div>
    )}
    {/* Application Submission Result */}
    {submitResult && (
      <div className={`submission-result ${submitResult.success ? 'success' : 'error'}`}>
        <h3>{submitResult.success ? 'Application Submitted Successfully' : 'Submission Failed'}</h3>
        <p>{submitResult.message}</p>
        {submitResult.success && submitResult.ucic_id && (
          <div className="ucic-display">
            <span>Your UCIC ID:</span>
            <strong>{submitResult.ucic_id}</strong>
            <p>Please save this ID for future reference.</p>
          </div>
        )}
      </div>
    )}
    
    {/* Review Message for Scrutiny Cases */}
    {requiresScrutiny && (
      <div className="scrutiny-message">
        <h4>Application Under Review</h4>
        <p>Your verification requires additional review by our team due to potential matches found in our system.</p>
        <p>Reference ID: <strong>{applicantId}</strong></p>
      </div>
    )}
    
    {/* Group Loan Message - Only for primary applicant */}
    {kycData.applicationType === 'group' && kycData.isPrimaryApplicant && (
      <div className="group-loan-message">
        <h4>Group Loan Application</h4>
        <p>As the primary applicant, please ensure all co-applicants complete their KYC verification.</p>
        {!kycData.coApplicants.every(a => a.kyc_status === 'completed') && (
          <p className="warning-text">Some co-applicants have not completed their KYC verification yet.</p>
        )}
      </div>
    )}
    
    {/* Print and Navigation Buttons - Hidden in print view */}
    <div className="summary-actions">
      <button 
        className="print-btn" 
        onClick={handlePrint}
      >
        Print Report
      </button>
      
      {!isApproved && !requiresScrutiny && (
        <button className="contact-support-btn">
          Contact Support
        </button>
      )}
      
      {/* Return to Dashboard button for primary applicant in group loan */}
      {kycData.applicationType === 'group' && kycData.isPrimaryApplicant && (
        <button 
          className="dashboard-btn" 
          onClick={() => window.location.reload()}
        >
          Return to Dashboard
        </button>
      )}
    </div>
    
    <div className="navigation-buttons">
      <button className="back-btn" onClick={prevStep}>
        Back
      </button>
      <button className="finish-btn" onClick={() => window.location.href = '/'}>
        Finish
      </button>
    </div>
    
    {/* Hidden print-optimized view that's only visible when printing */}
    <div className="print-only-container" style={{ display: 'none' }}>
      <PrintOptimizedView kycData={kycData} />
    </div>
  </div>
);
};

const KycFlow = () => {
  const query = useQuery();
  const appId = query.get('appId');
  const applicantId = query.get('applicantId');
  const navigate = useNavigate();
  
  const [currentStep, setCurrentStep] = useState(0);
  const [showGroupDashboard, setShowGroupDashboard] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [kycData, setKycData] = useState({
    applicationId: appId,
    applicantId: applicantId,
    applicantName: '',
    applicantPhone: '',
    applicantAddress: '',
    applicationType: '',
    loanType: '',
    coApplicants: [],
    isPrimaryApplicant: false,
    // Add fields for all components
    livenessImage: null,
    livenessImageDmsId: null,
    livenessSessionId: null,
    aadhaarImage: null,
    maskedAadhaarImage: null,
    maskedAadhaarDmsId: null,
    comparisonResult: null,
    dedupeResults: null,
    verificationStatus: 'pending',
    kycImageDmsIds: [] // pending, approved, rejected, requires_scrutiny
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Server URL
  const serverUrl = 'http://10.9.52.21:5001';
  const livenessServerUrl = 'http://10.9.52.21:5003';
  
  // Fetch applicant details on component mount
  useEffect(() => {
    console.log("KycFlow mounted with appId:", appId, "and applicantId:", applicantId);
    if (applicantId) {
      fetchApplicantDetails();
    } else {
      setError('No applicant ID provided');
      setLoading(false);
    }
  }, [applicantId]);
  
  // Fetch applicant details
  const fetchApplicantDetails = async () => {
    try {
      console.log("Fetching applicant details for ID:", applicantId);
      setLoading(true);
      setError('');
      
      const response = await fetch(`${serverUrl}/get_applicant/${applicantId}`);
      console.log("Response status:", response.status);
      
      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log("Applicant data received:", data);
      
      // In fetchApplicantDetails function
      if (data.success) {
        // Check if this is a group application
        const isGroupApplication = data.application_type === 'group';
        const isPrimaryApplicant = data.is_primary_applicant === true;
        
        console.log("Application type:", data.application_type);
        console.log("Is primary applicant:", data.is_primary_applicant);
        const kycImageDmsIds = data.kycImageDmsIds || [];
        console.log("KYC Image DMS IDs from applicant data:", kycImageDmsIds);

        // If KYC is already completed or in progress, fetch the full KYC details
        if (data.kyc_status === 'completed' || data.kyc_status === 'in_progress') {
          await fetchKycDetails(applicantId);
        } else {
          setKycData({
            ...kycData,
            applicationId: appId,
            applicantId: applicantId,
            applicantName: data.name,
            applicantPhone: data.phone,
            applicantAddress: data.address,
            applicationType: data.application_type,
            isPrimaryApplicant: isPrimaryApplicant,
            loanType: data.loan_type,
            coApplicants: data.co_applicants || [],
            kycStatus: data.kyc_status,
            kycSteps: data.kyc_steps,
            verificationStatus: data.verification_status || 'pending',
            kycImageDmsIds: kycImageDmsIds // Use the extracted kycImageDmsIds

          });
        }
        
        // If it's a group application and this is the primary applicant, show the dashboard
        if (isGroupApplication && isPrimaryApplicant && data.co_applicants && data.co_applicants.length > 0) {
          console.log("Showing group dashboard for primary applicant");
          setShowGroupDashboard(true);
        } else {
          setShowGroupDashboard(false);
        }

      } else {
        setError(data.error || 'Failed to fetch applicant details');
      }
    } catch (error) {
      console.error('Error fetching applicant details:', error);
      setError(`Failed to connect to server: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Add a new function to fetch KYC details
const fetchKycDetails = async (applicantId) => {
  try {
    const response = await fetch(`${serverUrl}/get_kyc_details/${applicantId}`);
    
    if (!response.ok) {
      throw new Error(`Server responded with status: ${response.status}`);
    }
    
    const data = await response.json();
    console.log("KYC details received:", data);
    
    if (data.success) {
      // Check if this is a group application and if this is the primary applicant
      const isGroupApplication = data.kyc_details.application_type === 'group';
      const isPrimaryApplicant = data.kyc_details.is_primary_applicant || false;
      
      // Extract DMS IDs from the response
      const livenessImageDmsId = data.kyc_details.livenessImageDmsId || 
                                (data.kyc_details.livenessData && data.kyc_details.livenessData.livenessImageDmsId) ||
                                data.kyc_details.liveness_image_dms_id;
                                
      const maskedAadhaarDmsId = data.kyc_details.maskedAadhaarDmsId || 
                                data.kyc_details.masked_aadhaar_dms_id;
      const kycImageDmsIds = data.kyc_details.kycImageDmsIds || 
                            data.kyc_details.kyc_image_dms_ids || 
                            [];
      console.log("Extracted DMS IDs:", { livenessImageDmsId, maskedAadhaarDmsId });
      console.log("Extracted kycImageDmsIds:", kycImageDmsIds);

      // Log KYC image DMS IDs if they exist
      if (data.kyc_details.kycImageDmsIds) {
        console.log("Found KYC image DMS IDs:", data.kyc_details.kycImageDmsIds);
      } else {
        console.log("No KYC image DMS IDs found in response");
      }
      
      // Map the server response to our KYC data structure
      setKycData({
        ...kycData,
        applicationId: appId,
        applicantId: applicantId,
        applicantName: data.kyc_details.name,
        applicantPhone: data.kyc_details.phone,
        applicantAddress: data.kyc_details.address,
        applicationType: data.kyc_details.application_type,
        loanType: data.kyc_details.loan_type,
        coApplicants: data.kyc_details.co_applicants || [],
        kycStatus: data.kyc_details.kyc_status,
        kycSteps: data.kyc_details.kyc_steps,
        verificationStatus: data.kyc_details.verification_status,
        isPrimaryApplicant: data.kyc_details.is_primary_applicant,
        
        // Image data - directly use the image URLs from response
        livenessImage: data.kyc_details.livenessImage || 
                      (data.kyc_details.livenessData && data.kyc_details.livenessData.livenessImage),

        livenessImageDmsId: livenessImageDmsId,
        livenessSessionId: data.kyc_details.livenessSessionId || 
                          (data.kyc_details.livenessData && data.kyc_details.livenessData.livenessSessionId),

        geoLocation: data.kyc_details.geoLocation || 
                    (data.kyc_details.livenessData && data.kyc_details.livenessData.geoLocation),

        maskedAadhaarImage: data.kyc_details.maskedAadhaarImage,
        maskedAadhaarDmsId: maskedAadhaarDmsId,
        
        // KYC image DMS IDs - Add this line
        kycImageDmsIds: kycImageDmsIds || [],
        
        // Results
        comparisonResult: data.kyc_details.comparisonResult || data.kyc_details.comparison_result,
        multiComparisonResults: data.kyc_details.multiComparisonResults || 
                              data.kyc_details.multi_comparison_results || [],
        dedupeResults: data.kyc_details.dedupeData?.dedupeResults || 
                      (data.kyc_details.dedupe_data && data.kyc_details.dedupe_data.dedupeResults)
      });
      console.log("KYC FLOW", kycData);
      // In the fetchKycDetails function
      // If this is a group application and the primary applicant, show the dashboard
      if (isGroupApplication && isPrimaryApplicant && data.kyc_details.kyc_status !== 'completed') {
        setShowGroupDashboard(true);
      } else {
        // Go to the summary step for completed KYC
        if (data.kyc_details.kyc_status === 'completed') {
          setCurrentStep(4); // Summary step
        }
      }
    } else {
      setError(data.error || 'Failed to fetch KYC details');
    }
  } catch (error) {
    console.error('Error fetching KYC details:', error);
    setError(`Failed to fetch KYC details: ${error.message}`);
  }
};


  // Load KYC details
  const loadKycDetails = async (applicantId) => {
    try {
      const response = await fetch(`${serverUrl}/get_kyc_details/${applicantId}`);
      
      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log("Refreshed KYC details:", data);
      
      if (data.success) {
        // Extract DMS IDs from the response
        const livenessImageDmsId = data.kyc_details.livenessImageDmsId || 
                                  (data.kyc_details.livenessData && data.kyc_details.livenessData.livenessImageDmsId) ||
                                  data.kyc_details.liveness_image_dms_id;
                                  
        const maskedAadhaarDmsId = data.kyc_details.maskedAadhaarDmsId || 
                                  data.kyc_details.masked_aadhaar_dms_id;
        
        console.log("Refreshed DMS IDs:", { livenessImageDmsId, maskedAadhaarDmsId });
        
        // Update only the necessary fields
        setKycData(prevData => ({
          ...prevData,
          kycStatus: data.kyc_details.kyc_status,
          kycSteps: data.kyc_details.kyc_steps,
          verificationStatus: data.kyc_details.verification_status,
          
          // Update DMS IDs if they exist
          livenessImageDmsId: livenessImageDmsId || prevData.livenessImageDmsId,
          maskedAadhaarDmsId: maskedAadhaarDmsId || prevData.maskedAadhaarDmsId,
          
          // Update results if they exist
          comparisonResult: data.kyc_details.comparisonResult || 
                           data.kyc_details.comparison_result || 
                           prevData.comparisonResult,
                           
          dedupeResults: (data.kyc_details.dedupeData && data.kyc_details.dedupeData.dedupeResults) || 
                        (data.kyc_details.dedupe_data && data.kyc_details.dedupe_data.dedupeResults) || 
                        prevData.dedupeResults
        }));
      }
    } catch (error) {
      console.error('Error refreshing KYC details:', error);
    }
  };

  // Update KYC data
  const updateKycData = (newData) => {
    console.log("Updating KYC data with:", newData);
    setKycData({
      ...kycData,
      ...newData
    });
  };
  
  const completeMaskingStep = (maskingData) => {
    console.log("Completing Aadhaar masking step with data:", maskingData);
    
    // Update KYC data in the component state
    updateKycData({
      maskedAadhaarImage: maskingData.maskedAadhaarImage,
      maskedAadhaarDmsId: maskingData.maskedAadhaarDmsId
    });
    
    // Send update to server
    updateKycStatus('aadhaar', {
      masked_aadhaar_image: maskingData.maskedAadhaarImage,
      maskedAadhaarDmsId: maskingData.maskedAadhaarDmsId,
      timestamp: new Date().toISOString()
    });
    
    // Move to next step
    nextStep();
  };
  
  const completeLivenessStep = (livenessData) => {
    console.log("Completing liveness step with data:", livenessData);
    
    // Update KYC data in the component state
    updateKycData({
      livenessImage: livenessData.livenessImage,
      livenessImageDmsId: livenessData.dms_id || livenessData.livenessImageDmsId,
      livenessSessionId: livenessData.livenessSessionId,
      geoLocation: livenessData.geoLocation
    });
    
    // Send update to server
    updateKycStatus('liveness', {
      liveness_data: {
        livenessImage: livenessData.livenessImage,
        livenessImageDmsId: livenessData.dms_id || livenessData.livenessImageDmsId,
        livenessSessionId: livenessData.livenessSessionId,
        livenessTimestamp: livenessData.livenessTimestamp,
        geoLocation: livenessData.geoLocation,
        deviceInfo: {
          userAgent: navigator.userAgent,
          platform: navigator.platform,
          language: navigator.language
        }
      }
    });
    
    // Move to next step
    nextStep();
  };
  
const completeComparisonStep = (comparisonData) => {
  console.log("Completing comparison step with data:", comparisonData);
  
  // Update KYC data in the component state
  updateKycData({
    comparisonResult: comparisonData.comparisonResult,
    multiComparisonResults: comparisonData.multiComparisonResults, // Make sure this is included
    livenessImageDmsId: comparisonData.livenessImageDmsId || kycData.livenessImageDmsId,
    maskedAadhaarDmsId: comparisonData.maskedAadhaarDmsId || kycData.maskedAadhaarDmsId
  });
  
  // Send update to server
  updateKycStatus('comparison', {
    comparison_result: comparisonData.comparisonResult,
    multi_comparison_results: comparisonData.multiComparisonResults, // Include this in the server update
    liveness_image_dms_id: comparisonData.livenessImageDmsId || kycData.livenessImageDmsId,
    masked_aadhaar_dms_id: comparisonData.maskedAadhaarDmsId || kycData.maskedAadhaarDmsId
  });
  
  // Move to next step
  nextStep();
};

  
  const completeDedupeStep = (dedupeData) => {
    console.log("Completing dedupe step with data:", dedupeData);
    
    // Update KYC data in the component state
    updateKycData({
      dedupeResults: dedupeData.dedupeResults,
      verificationStatus: dedupeData.verificationStatus,
      requiresScrutiny: dedupeData.requiresScrutiny

    });
    
    // Send update to server
    updateKycStatus('dedupe', {
      dedupe_data: {
        dedupeResults: dedupeData.dedupeResults,
        verificationStatus: dedupeData.verificationStatus,
        requiresScrutiny: dedupeData.requiresScrutiny,
        comparisonResult: kycData.comparisonResult,
        timestamp: new Date().toISOString()
      }
    });
    
    // Move to next step
    nextStep();
  };
  
  // Update KYC status on the server
  const updateKycStatus = async (step, data) => {
    try {
      console.log(`Updating KYC status for step: ${step} with data:`, data);
      
      // Prepare the update data
      const updateData = {
        applicant_id: applicantId,
        kyc_steps: {
          [step]: true
        },
        ...data
      };
      
      // Send the update to the server
      const response = await fetch(`${serverUrl}/update_kyc_status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updateData)
      });
      
      const result = await response.json();
      console.log("KYC status update result:", result);
      
      if (result.success) {
        console.log("KYC status updated successfully");
        
        // If all steps are completed, refresh the KYC details
        if (result.all_steps_completed) {
          console.log("All KYC steps completed, refreshing KYC details");
          await loadKycDetails(applicantId);
        }
      } else {
        console.error("Failed to update KYC status:", result.error);
      }
    } catch (error) {
      console.error("Error updating KYC status:", error);
    }
  };
  
  // Navigation functions
  const nextStep = () => {
    setCurrentStep(currentStep + 1);
  };
  
  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };
  
  // Handle group dashboard continue
  const handleGroupDashboardContinue = () => {
    setShowGroupDashboard(false);
    setCurrentStep(0);
  };
  
  // Render loading state
  if (loading) {
    return (
      <div className="kyc-flow-container">
        <div className="loading-container">
          <div className="spinner"></div>
          <p>Loading KYC data...</p>
        </div>
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className="kyc-flow-container">
        <div className="error-container">
          <h2>Error</h2>
          <p>{error}</p>
          <button onClick={() => window.location.reload()}>Retry</button>
        </div>
      </div>
    );
  }
  
  // Render group dashboard if needed
{showGroupDashboard && (
  <div className="kyc-flow-container">
    <GroupLoanDashboard 
      applicationData={{
        applicationId: kycData.applicationId,
        applicantName: kycData.applicantName,
        applicantPhone: kycData.applicantPhone,
        loanType: kycData.loanType,
        kycStatus: kycData.kycStatus,
        verificationStatus: kycData.verificationStatus
      }}
      coApplicants={kycData.coApplicants || []}
      onContinue={handleGroupDashboardContinue}
    />
  </div>
)}

  
  // Render KYC flow steps
  return (
    <div className={`kyc-flow-container ${isPrinting ? 'printing' : ''}`}>
      <div className="kyc-header">
        <h1>KYC Verification</h1>
        <div className="applicant-info">
          <p><strong>Name:</strong> {kycData.applicantName}</p>
          <p><strong>Application ID:</strong> {kycData.applicationId}</p>
          {kycData.applicationType === 'group' && (
            <p><strong>Role:</strong> {kycData.isPrimaryApplicant ? 'Primary Applicant' : 'Co-Applicant'}</p>
          )}
        </div>
      </div>
      
      {/* Progress bar - Fixed to match CSS */}
      <div className="kyc-progress">
        <div className={`progress-step ${currentStep >= 0 ? 'active' : ''} ${currentStep > 0 ? 'completed' : ''}`}>
          <div className="step-number">1</div>
          <div className="step-name">Liveness</div>
        </div>
        <div className={`progress-step ${currentStep >= 1 ? 'active' : ''} ${currentStep > 1 ? 'completed' : ''}`}>
          <div className="step-number">2</div>
          <div className="step-name">Aadhaar</div>
        </div>
        <div className={`progress-step ${currentStep >= 2 ? 'active' : ''} ${currentStep > 2 ? 'completed' : ''}`}>
          <div className="step-number">3</div>
          <div className="step-name">Face Match</div>
        </div>
        <div className={`progress-step ${currentStep >= 3 ? 'active' : ''} ${currentStep > 3 ? 'completed' : ''}`}>
          <div className="step-number">4</div>
          <div className="step-name">Dedupe</div>
        </div>
        <div className={`progress-step ${currentStep >= 4 ? 'active' : ''}`}>
          <div className="step-number">5</div>
          <div className="step-name">Summary</div>
        </div>
      </div>
      
      {/* Step content */}
      <div className="step-content">
        {currentStep === 0 && (
          <LivenessCheck 
            kycData={kycData} 
            updateKycData={updateKycData} 
            nextStep={completeLivenessStep} 
          />
        )}
        
        {currentStep === 1 && (
          <AadhaarMasker 
            kycData={kycData} 
            updateKycData={updateKycData} 
            nextStep={completeMaskingStep} 
          />
        )}

        {currentStep === 2 && (
          
          <FaceComparison 
            kycData={kycData} 
            updateKycData={updateKycData} 
            nextStep={completeComparisonStep} 
            prevStep={prevStep} 
          />
        )}
        
        {currentStep === 3 && (
          <FaceDedupe 
            kycData={kycData} 
            updateKycData={updateKycData} 
            nextStep={completeDedupeStep} 
            prevStep={prevStep} 
          />
        )}
        
        {currentStep === 4 && (
          <KycSummary 
            kycData={kycData} 
            prevStep={prevStep} 
            applicationId={appId}
            applicantId={applicantId}
          />
        )}
      </div>
    </div>
  );
};

export default KycFlow;
