import React, { useState, useRef, useEffect, useCallback } from 'react';
import './LivenessCheck.css';
import config from '../services/config';
const LivenessCheck = ({ kycData, updateKycData, nextStep }) => {
  const [streaming, setStreaming] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [status, setStatus] = useState('Ready to start liveness check');
  const [statusClass, setStatusClass] = useState('pending');
  const [progress, setProgress] = useState(0);
  const [capturedDmsId, setCapturedDmsId] = useState(null);
  const [capturedImageUrl, setCapturedImageUrl] = useState(null);
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [spoofingDetected, setSpoofingDetected] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [livenessComplete, setLivenessComplete] = useState(false);
  const [locationStatus, setLocationStatus] = useState('pending');
  const [geoPermissionGranted, setGeoPermissionGranted] = useState(false);
  const [webSocketReady, setWebSocketReady] = useState(false);
  const [showInstructions, setShowInstructions] = useState(true);
  const [showDebug, setShowDebug] = useState(false);
  const [isMobile, setIsMobile] = useState(null);
  const [isProcessingUpload, setIsProcessingUpload] = useState(false);

  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  const processingIntervalRef = useRef(null);
  const webSocketRef = useRef(null);
  const geoSentRef = useRef(false);
  const instructionVideoRef = useRef(null);

  // Use FastAPI server URL - update this to match your FastAPI server
  const serverUrl = config.livenessServerUrl;

  // Detect if user is on mobile device
  useEffect(() => {
    const checkMobile = () => {
      const userAgent = navigator.userAgent || navigator.vendor || window.opera;
      
      const isAndroid = /Android/i.test(userAgent);
      const isIOS = /iPhone|iPad|iPod/i.test(userAgent);
      const isWindowsPhone = /Windows Phone/i.test(userAgent);
      const isBlackBerry = /BlackBerry/i.test(userAgent);
      
      const isMobileBrowser = /Mobile|mini|Fennec|Android|iP(ad|od|hone)/i.test(userAgent);
      const hasTouchScreen = 'ontouchstart' in window && navigator.maxTouchPoints > 0;
      const isSmallScreen = window.screen.width <= 768 || window.screen.height <= 768;
      
      const isMobileDevice = isAndroid || isIOS || isWindowsPhone || isBlackBerry || 
                            (isMobileBrowser && hasTouchScreen) ||
                            (hasTouchScreen && isSmallScreen && isMobileBrowser);
      
      setIsMobile(isMobileDevice);
      console.log('Device detection:', { 
        userAgent: userAgent.substring(0, 50) + '...', 
        isAndroid, 
        isIOS, 
        final: isMobileDevice 
      });
    };
    
    checkMobile();
  }, []);

  // Get geolocation data
  const getGeolocation = useCallback(() => {
    if (geoPermissionGranted) {
      console.log("Geolocation permission already granted, skipping request");
      return;
    }
    
    if (navigator.geolocation) {
      setLocationStatus('requesting');
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const geoData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date().toISOString()
          };
          console.log("Geolocation obtained:", geoData);
          setLocationStatus('captured');
          setGeoPermissionGranted(true);
          
          // Update KYC data with geolocation
          updateKycData({
            geoLocation: geoData
          });
        },
        (error) => {
          console.error("Geolocation error:", error);
          setLocationStatus('error');
          let errorMessage = "Location access error";
          switch(error.code) {
            case error.PERMISSION_DENIED: 
              errorMessage = "Location permission denied. Please enable location access."; 
              break;
            case error.POSITION_UNAVAILABLE: 
              errorMessage = "Location information unavailable."; 
              break;
            case error.TIMEOUT: 
              errorMessage = "Location request timed out."; 
              break;
            default: 
              errorMessage = "Unknown location error occurred.";
          }
          setStatus(errorMessage); 
          setStatusClass('error');
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      console.warn("Geolocation not supported");
      setLocationStatus('error');
      setStatus("Browser doesn't support geolocation."); 
      setStatusClass('error');
    }
  }, [geoPermissionGranted, updateKycData]);

  // Get geolocation on component mount
  useEffect(() => {
    getGeolocation();
  }, [getGeolocation]);

  // Start webcam
  const startWebcam = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Browser doesn't support camera access.");
      }
      
      // Always use front camera for liveness detection
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 }, 
          height: { ideal: 720 }, 
          facingMode: 'user' 
        },
        audio: false
      });
      
      if (webcamRef.current) {
        webcamRef.current.srcObject = stream;
        return new Promise((resolve) => {
          webcamRef.current.onloadedmetadata = () => {
            setStreaming(true); 
            resolve(true);
          };
        });
      }
      return false;
    } catch (error) {
      console.error('Error accessing webcam:', error);
      
      let errorMsg = `Error accessing webcam: ${error.message}`;
      if (error.name === 'NotAllowedError') errorMsg = 'Camera access denied. Please allow camera access to continue.';
      else if (error.name === 'NotFoundError') errorMsg = 'No camera found on this device.';
      else if (error.name === 'NotReadableError') errorMsg = 'Camera is currently in use by another application.';
      
      setStatus(errorMsg); 
      setStatusClass('error');
      return false;
    }
  };

  // Stop webcam
  const stopWebcam = () => {
    if (webcamRef.current && webcamRef.current.srcObject) {
      webcamRef.current.srcObject.getTracks().forEach(track => track.stop());
      webcamRef.current.srcObject = null;
    }
    setStreaming(false);
    if (processingIntervalRef.current) {
      clearInterval(processingIntervalRef.current);
      processingIntervalRef.current = null;
    }
  };

  // Capture frame from webcam
  const captureFrame = () => {
    if (webcamRef.current && webcamRef.current.readyState === webcamRef.current.HAVE_ENOUGH_DATA && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = webcamRef.current.videoWidth;
      canvasRef.current.height = webcamRef.current.videoHeight;
      context.drawImage(webcamRef.current, 0, 0);
      return canvasRef.current.toDataURL('image/jpeg', 0.5);
    }
    return null;
  };

  // Connect to WebSocket
  const connectWebSocket = (sessionIdToConnect) => {
    if (webSocketRef.current) {
      webSocketRef.current.close();
    }

    const wsUrl = serverUrl.replace(/^http/, 'ws') + `/ws/liveness/${sessionIdToConnect}`;
    console.log(`Connecting to WebSocket: ${wsUrl}`);
    const ws = new WebSocket(wsUrl);
    webSocketRef.current = ws;

    ws.onopen = () => {
      console.log(`WebSocket connected for session ${sessionIdToConnect}`);
      setWebSocketReady(true);
      
      if (processingIntervalRef.current) clearInterval(processingIntervalRef.current);
      processingIntervalRef.current = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          const imageData = captureFrame();
          if (imageData) {
            ws.send(imageData);
          }
        } else {
          console.log("WebSocket not open, stopping frame sending.");
          clearInterval(processingIntervalRef.current);
        }
      }, 250);
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log("WebSocket message received:", data);

        setStatus(data.message || 'Processing...');
        setProgress(data.progress || 0);
        setCurrentChallenge(data.current_challenge);
        setSpoofingDetected(data.spoofing_detected || false);
        
        if (data.progress >= 100 && !data.dms_id && !isProcessingUpload) {
          setIsProcessingUpload(true);
          setStatus('Verification complete. Processing and uploading data...');
          setStatusClass('pending');
        }
        
        if (data.status === 'success') setStatusClass('success');
        else if (data.status === 'failed' || data.spoofing_detected) setStatusClass('error');
        else setStatusClass('pending');

        if (data.stop_webcam || data.dms_id) {
          setLivenessComplete(true);
          setIsProcessingUpload(false);
          stopWebcam();
          ws.close();
          setWebSocketReady(false);

          if (data.dms_id) {
            setCapturedDmsId(data.dms_id);
            setCapturedImageUrl(`${serverUrl}/get_captured_image/${sessionIdToConnect}`);
          }
        }
      } catch (error) {
        console.error("Error processing WebSocket message:", error, event.data);
      }
    };

    ws.onclose = (event) => {
      console.log(`WebSocket disconnected for session ${sessionIdToConnect}`, event.reason, event.code);
      setWebSocketReady(false);
      if (processingIntervalRef.current) clearInterval(processingIntervalRef.current);
      
      if (!livenessComplete && streaming) {
        setStatus('Connection to server lost. Please try again.');
        setStatusClass('error');
        setLivenessComplete(true); 
        stopWebcam(); 
      }
    };

    ws.onerror = (error) => {
      console.error(`WebSocket error for session ${sessionIdToConnect}:`, error);
      if (streaming && !livenessComplete) {
        setStatus('A communication error occurred. Please try again.');
        setStatusClass('error');
      }
    };
  };

  // Send geolocation via WebSocket when ready
  useEffect(() => {
    if (webSocketReady && webSocketRef.current && 
        webSocketRef.current.readyState === WebSocket.OPEN && 
        kycData?.geoLocation && !geoSentRef.current) {
      console.log("Sending geolocation via WebSocket:", kycData.geoLocation);
      webSocketRef.current.send(JSON.stringify({ geo_location: kycData.geoLocation }));
      geoSentRef.current = true;
    }
  }, [webSocketReady, kycData]);

  // Start liveness session via HTTP
  const startLivenessSessionHTTP = async () => {
    try {
      console.log("Starting liveness session (HTTP)...");
      const response = await fetch(`${serverUrl}/start_liveness`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await response.json();
      if (data.success) {
        setSessionId(data.session_id);
        return data.session_id;
      } else {
        throw new Error(data.error || 'Failed to start liveness session');
      }
    } catch (error) {
      console.error('Error starting liveness session:', error);
      setStatus(`Error: ${error.message}`); 
      setStatusClass('error');
      return null;
    }
  };

  // Start liveness check
  const startLivenessCheck = async () => {
    setShowInstructions(false);
    setLivenessComplete(false);
    setIsProcessingUpload(false);
    setStatus('Initializing liveness check...'); 
    setStatusClass('pending');
    setProgress(0); 
    setCapturedImageUrl(null); 
    setCapturedDmsId(null);
    setSpoofingDetected(false); 
    setCurrentChallenge(null);
    geoSentRef.current = false;

    if (!streaming) {
      const webcamStarted = await startWebcam();
      if (!webcamStarted) return;
    }

    const newSessionId = await startLivenessSessionHTTP();
    if (newSessionId) {
      connectWebSocket(newSessionId);
    }
  };

  // Stop liveness check
  const stopLivenessCheck = () => {
    console.log("Stopping liveness check");
    setLivenessComplete(true);
    if (webSocketRef.current) {
      webSocketRef.current.close();
      webSocketRef.current = null;
    }
    setWebSocketReady(false);
    stopWebcam();
    
    setStatus('Liveness check cancelled by user.'); 
    setStatusClass('pending');
    setProgress(0); 
    setCapturedImageUrl(null);
  };

  // Handle retry
  const handleRetry = () => {
    const newRetryCount = retryCount + 1;
    setRetryCount(newRetryCount);

    if (newRetryCount >= 3) {
      setStatus('Maximum retry attempts reached. Verification failed.');
      setStatusClass('error');
      setLivenessComplete(true);
      return;
    }

    if (webSocketRef.current) { 
      webSocketRef.current.close(); 
      webSocketRef.current = null; 
    }
    setWebSocketReady(false);
    stopWebcam();

    setSpoofingDetected(false); 
    setLivenessComplete(false);
    setSessionId(null); 
    setCapturedImageUrl(null);
    setProgress(0); 
    setCurrentChallenge(null);
    setIsProcessingUpload(false);
    setStatus('Restarting liveness check...'); 
    setStatusClass('pending');
    
    setTimeout(() => startLivenessCheck(), 500);
  };

  // Get challenge text
  const getChallengeText = (challengeCode) => {
    if (challengeCode === 0) return "Blink your eyes";
    return "";
  };

  // Proceed from instructions
  const proceedFromInstructions = () => {
    setShowInstructions(false);
    startLivenessCheck();
  };

  // Handle successful liveness completion
  const handleLivenessSuccess = () => {
    if (capturedDmsId) {
      // Update KYC data with liveness results
      updateKycData({
        livenessCheck: {
          completed: true,
          success: true,
          dmsId: capturedDmsId,
          sessionId: sessionId,
          timestamp: new Date().toISOString(),
          retryCount: retryCount
        }
      });
      
      // Format data in the way KycFlow expects it for the nextStep function
      const livenessData = {
        livenessImage: capturedImageUrl,
        dms_id: capturedDmsId,
        livenessImageDmsId: capturedDmsId,
        livenessSessionId: sessionId,
        livenessTimestamp: new Date().toISOString(),
        geoLocation: kycData?.geoLocation
      };
      
      // Move to next step in KYC flow with the properly formatted data
      nextStep(livenessData);
    }
  };

  // Handle liveness failure
  const handleLivenessFailure = (reason) => {
    updateKycData({
      livenessCheck: {
        completed: true,
        success: false,
        reason: reason,
        sessionId: sessionId,
        timestamp: new Date().toISOString(),
        retryCount: retryCount
      }
    });
  };

  // Check if liveness is complete and successful
  useEffect(() => {
    if (livenessComplete && capturedDmsId && !spoofingDetected) {
      // Auto-proceed after successful capture
      setTimeout(() => {
        handleLivenessSuccess();
      }, 3000);
    } else if (livenessComplete && spoofingDetected && retryCount >= 2) {
      // Handle final failure
      handleLivenessFailure('Maximum retry attempts reached due to spoofing detection');
    }
  }, [livenessComplete, capturedDmsId, spoofingDetected, retryCount]);

  // Check server status on component mount
  useEffect(() => {
    const checkServer = async () => {
      try {
        const response = await fetch(`${serverUrl}/test`);
        const data = await response.json();
        
        if (data.status === 'API is working') {
          console.log("FastAPI server is available");
          setStatus('Ready for liveness verification');
        } else {
          throw new Error('Server not responding correctly');
        }
      } catch (error) {
        console.error('Error connecting to FastAPI server:', error);
        setStatus('Error connecting to verification server. Please try again later.');
        setStatusClass('error');
      }
    };
    
    checkServer();
    
    // Cleanup on component unmount
    return () => {
      console.log("LivenessCheck component unmounting, cleaning up");
      if (processingIntervalRef.current) {
        clearInterval(processingIntervalRef.current);
        processingIntervalRef.current = null;
      }
      if (webSocketRef.current) { 
        webSocketRef.current.close(); 
        webSocketRef.current = null; 
      }
      stopWebcam();
    };
  }, []);

  return (
    <div className={`liveness-check kyc-mode ${isMobile ? 'mobile' : 'desktop'}`}>
      {/* Instructions Screen */}
      {showInstructions && (
        <div className="instructions-overlay">
          <div className="instructions-content">
            <div className="company-header">
              <h2>🔒 Identity Verification</h2>
              <p className="company-subtitle">Liveness Detection Step</p>
            </div>
            
            <p className="intro-text">
              We need to verify your identity for security purposes. This process will take approximately 30 seconds.
            </p>
            
            {isMobile !== null && (
              <div className="video-instructions">
                <video 
                  ref={instructionVideoRef}
                  autoPlay 
                  loop 
                  muted 
                  playsInline
                  className="instruction-video"
                  onError={(e) => console.error('Video error:', e)}
                >
                  <source 
                    src={isMobile ? "/liveness-mobile.webm" : "/liveness-desktop.webm"} 
                    type="video/webm" 
                  />
                  <div className="video-fallback">
                    <p>Video instructions not available</p>
                  </div>
                </video>
              </div>
            )}

            <div className="instruction-points">
              <div className="instruction-item">
                <span className="icon">📏</span>
                <span>Keep the camera one arm's length away</span>
              </div>
              <div className="instruction-item">
                <span className="icon">💡</span>
                <span>Ensure adequate lighting on your face</span>
              </div>
              <div className="instruction-item">
                <span className="icon">👤</span>
                <span>Make sure only your face is visible</span>
              </div>
            </div>

            <div className="location-permission">
              <div className={`location-status ${locationStatus}`}>
                {locationStatus === 'pending' && <span>📍 Requesting location access...</span>}
                {locationStatus === 'requesting' && <span>📍 Obtaining location data...</span>}
                {locationStatus === 'captured' && kycData?.geoLocation && (
                  <span>✅ Location verified successfully</span>
                )}
                {locationStatus === 'error' && <span>⚠️ Location access is required for verification</span>}
              </div>
            </div>

            <button 
              className="proceed-btn"
              onClick={proceedFromInstructions}
              disabled={!geoPermissionGranted}
            >
              {geoPermissionGranted ? 'Begin Verification' : 'Waiting for permissions...'}
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      {!showInstructions && (
        <>
          <div className="header-section">
            <h2>🔒 Identity Verification</h2>
            {!livenessComplete && (
              <button 
                className="back-to-instructions"
                onClick={() => setShowInstructions(true)}
              >
                ← View Instructions
              </button>
            )}
          </div>
          
          <div className="status-section">
            <div className={`detection-result ${statusClass}`}>
              <span className="status-icon">
                {statusClass === 'success' && '✅'}
                {statusClass === 'error' && '❌'}
                {statusClass === 'pending' && '⏳'}
              </span>
              {status}
            </div>
            {!livenessComplete && progress > 0 && (
              <div className="progress-container">
                <div className="progress-bar" style={{ width: `${progress}%` }}></div>
                <span className="progress-text">{Math.round(progress)}%</span>
              </div>
            )}
            {isProcessingUpload && (
              <div className="upload-indicator">
                <div className="spinner"></div>
                <span>Finalizing verification...</span>
              </div>
            )}
          </div>
          
          {spoofingDetected && (
            <div className="spoofing-alert">
              <div className="alert-content">
                <h3>⚠️ Verification Failed</h3>
                <p>Please ensure you are not using a photograph, screen, or mask. Position yourself in good lighting and try again.</p>
                {retryCount < 2 && <p className="retry-info">Attempts remaining: {2 - retryCount}</p>}
                {retryCount >= 2 ? (
                  <div className="max-attempts-reached">
                    <p><strong>Maximum attempts reached. Please contact support.</strong></p>
                    <button 
                      className="secondary-btn" 
                      onClick={() => handleLivenessFailure('Maximum retry attempts reached')}
                    >
                      <span className="btn-icon">⏭️</span>
                      Continue KYC Process
                    </button>
                  </div>
                ) : (
                  <button 
                    className="retry-btn"
                    onClick={handleRetry}
                  >
                    Retry Verification ({retryCount + 1}/3)
                  </button>
                )}
              </div>
            </div>
          )}
          
          {!spoofingDetected && (
            <>
              <div className="webcam-section">
                <div className="video-container">
                  {!capturedImageUrl && (
                    <>
                      <video ref={webcamRef} autoPlay playsInline muted className="webcam-feed"></video>
                      <div className="face-outline"></div>
                    </>
                  )}
                  <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
                  
                  {currentChallenge !== null && streaming && !capturedImageUrl && (
                    <div className="challenge-overlay">
                      <div className="challenge-instruction">
                        <span className="challenge-icon">👁️</span>
                        <span className="challenge-text">{getChallengeText(currentChallenge)}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Controls */}
              {!capturedImageUrl && !livenessComplete && (
                <div className="controls">
                  {!streaming && (
                    <button 
                      className="start-btn primary-btn" 
                      onClick={startLivenessCheck} 
                      disabled={!geoPermissionGranted}
                    >
                      <span className="btn-icon">🎥</span>
                      Start Camera
                    </button>
                  )}
                  {streaming && (
                    <button 
                      className="stop-btn secondary-btn" 
                      onClick={stopLivenessCheck}
                    >
                      <span className="btn-icon">⏹️</span>
                      Cancel Verification
                    </button>
                  )}
                </div>
              )}
              
              {/* Success Display */}
              {capturedImageUrl && (
                <div className="capture-success">
                  <div className="success-content">
                    <h3>✅ Verification Successful!</h3>
                    <img className="captured-image" src={capturedImageUrl} alt="Identity verification capture" />
                    <p>Your identity has been successfully verified. Proceeding to next step...</p>
                    
                    <div className="kyc-controls">
                      <button 
                        className="primary-btn" 
                        onClick={handleLivenessSuccess}
                      >
                        <span className="btn-icon">⏭️</span>
                        Continue KYC Process
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </>
      )}

      {/* Debug Panel - Only in development */}
      {process.env.NODE_ENV !== 'production' && (
        <div className="debug-panel">
          <button 
            className="debug-toggle"
            onClick={() => setShowDebug(!showDebug)}
          >
            🐛 Debug {showDebug ? '▼' : '▶'}
          </button>
          {showDebug && (
            <div className="debug-content">
              <h4>Debug Information</h4>
              <div className="debug-grid">
                <div><strong>Device:</strong> {isMobile ? 'Mobile' : 'Desktop'}</div>
                <div><strong>Session ID:</strong> {sessionId || 'N/A'}</div>
                <div><strong>Liveness Complete:</strong> {livenessComplete.toString()}</div>
                <div><strong>Streaming:</strong> {streaming.toString()}</div>
                <div><strong>WebSocket Ready:</strong> {webSocketReady.toString()}</div>
                <div><strong>Geo Permission:</strong> {geoPermissionGranted.toString()}</div>
                <div><strong>Location Status:</strong> {locationStatus}</div>
                <div><strong>Show Instructions:</strong> {showInstructions.toString()}</div>
                <div><strong>Retry Count:</strong> {retryCount}</div>
                <div><strong>Progress:</strong> {progress}%</div>
                <div><strong>Current Challenge:</strong> {currentChallenge || 'N/A'}</div>
                <div><strong>Spoofing Detected:</strong> {spoofingDetected.toString()}</div>
                <div><strong>Processing Upload:</strong> {isProcessingUpload.toString()}</div>
              </div>
              {kycData?.geoLocation && (
                <div className="geo-info">
                  <strong>Geolocation:</strong> 
                  <br />Lat: {kycData.geoLocation.latitude.toFixed(5)}
                  <br />Lng: {kycData.geoLocation.longitude.toFixed(5)}
                  <br />Accuracy: {kycData.geoLocation.accuracy}m
                </div>
              )}
              {kycData && (
                <div className="origin-info">
                  <strong>KYC Data:</strong>
                  <pre>{JSON.stringify(kycData, null, 2)}</pre>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default LivenessCheck;
