import pandas as pd
import math

def load_location_data(csv_file='IN.csv'):
    """Load CSV data for offline reverse geocoding"""
    try:
        # Use on_bad_lines='skip' for newer pandas versions
        try:
            return pd.read_csv(csv_file, on_bad_lines='skip')
        except TypeError:
            # For older pandas versions
            return pd.read_csv(csv_file, error_bad_lines=False)
    except Exception as e:
        print(f"Error loading CSV: {e}")
        return None

def calculate_distance(lat1, lon1, lat2, lon2):
    """Calculate distance between two coordinates using Haversine formula"""
    try:
        lat1, lon1, lat2, lon2 = map(math.radians, [float(lat1), float(lon1), float(lat2), float(lon2)])
        
        # Haversine formula
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        r = 6371  # Radius of earth in kilometers
        return c * r
    except (ValueError, TypeError):
        return float('inf')

def reverse_geocode(lat, lon):
    """Reverse geocoding (offline) using CSV data"""
    df = load_location_data()
    if df is None:
        return "CSV data not available"
    
    # Find the closest coordinates in the CSV
    min_distance = float('inf')
    closest_location = None
    
    for _, row in df.iterrows():
        try:
            csv_lat = float(row['latitude'])
            csv_lon = float(row['longitude'])
            distance = calculate_distance(lat, lon, csv_lat, csv_lon)
            
            if distance < min_distance:
                min_distance = distance
                closest_location = row
        except (ValueError, TypeError, KeyError):
            continue
    
    if closest_location is not None:
        try:
            # Format: Place_name, city name, postal code
            location_info = f"{closest_location['place_name']}, {closest_location['city_name']}, {closest_location['postal_code']}"
            return location_info
        except KeyError:
            return f"Location found but missing some details: {str(closest_location)}"
    else:
        return "No matching location found"
