import cv2
import numpy as np
import dlib
from scipy.spatial import distance as dist
import time
import os
import random
import torch
from ultralytics import YOLO  

# Check for GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load models
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor(r"shape_predictor_68_face_landmarks.dat")
phone_detector = YOLO(r"screen detect1.pt")

# Load YOLO model for hand gesture detection
hand_detector = YOLO(r"yolov10n_hand_detect.pt")


# Set capture path
save_path = r"saves"
os.makedirs(save_path, exist_ok=True)


# EAR Calculation
def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5]) 
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

# Improved Mouth Aspect Ratio calculation
def mouth_aspect_ratio(mouth):
    # Horizontal distance
    A = dist.euclidean(mouth[3], mouth[9])  # 51, 59
    # Vertical distances at multiple points for better accuracy
    B = dist.euclidean(mouth[2], mouth[10])  # 50, 58
    C = dist.euclidean(mouth[4], mouth[8])   # 52, 56
    D = dist.euclidean(mouth[0], mouth[6])   # 48, 54
    
    # Average vertical opening
    vertical_opening = (B + C) / 2.0
    
    # Ratio of vertical to horizontal
    mar = vertical_opening / A
    return mar

# New smile detection function
def detect_smile(landmarks):
    # Get mouth corner points
    left_corner = (landmarks.part(48).x, landmarks.part(48).y)
    right_corner = (landmarks.part(54).x, landmarks.part(54).y)
    
    # Get points above the corners to measure lift
    left_top = (landmarks.part(49).x, landmarks.part(49).y)
    right_top = (landmarks.part(53).x, landmarks.part(53).y)
    
    # Calculate vertical displacement of corners relative to center points
    center_y = (landmarks.part(51).y + landmarks.part(57).y) / 2
    left_lift = center_y - left_corner[1]
    right_lift = center_y - right_corner[1]
    
    # Calculate smile score (higher means more likely to be smiling)
    smile_score = (left_lift + right_lift) / 2
    
    return smile_score

    # Check if eyes are closing (transition from open to closed)
    is_closing = prev_ear is not None and prev_ear >= ear_threshold and ear < ear_threshold
    
    # Check if eyes are opening (transition from closed to open)
    is_opening = prev_ear is not None and prev_ear < ear_threshold and ear >= ear_threshold
    
    # If eyes are closing, increment counter
    if is_closing:
       pass
    
    else:
        pass
    

# Head Pose Estimation
def get_head_pose(landmarks, frame):
    # 2D image points
    image_points = np.array([
        (landmarks.part(30).x, landmarks.part(30).y),     # Nose tip
        (landmarks.part(8).x, landmarks.part(8).y),       # Chin
        (landmarks.part(36).x, landmarks.part(36).y),     # Left eye left corner
        (landmarks.part(45).x, landmarks.part(45).y),     # Right eye right corner
        (landmarks.part(48).x, landmarks.part(48).y),     # Left mouth corner
        (landmarks.part(54).x, landmarks.part(54).y)      # Right mouth corner
    ], dtype="double")
    
    # 3D model points
    model_points = np.array([
        (0.0, 0.0, 0.0),             # Nose tip
        (0.0, -330.0, -65.0),        # Chin
        (-225.0, 170.0, -135.0),     # Left eye left corner
        (225.0, 170.0, -135.0),      # Right eye right corner
        (-150.0, -150.0, -125.0),    # Left mouth corner
        (150.0, -150.0, -125.0)      # Right mouth corner
    ])
    
    # Camera internals
    size = frame.shape
    focal_length = size[1]
    center = (size[1]/2, size[0]/2)
    camera_matrix = np.array(
        [[focal_length, 0, center[0]],
        [0, focal_length, center[1]],
        [0, 0, 1]], dtype="double"
    )
    
    dist_coeffs = np.zeros((4,1)) # Assuming no lens distortion
    
    # Solve PnP
    success, rotation_vector, translation_vector = cv2.solvePnP(
        model_points, image_points, camera_matrix, dist_coeffs)
    
    # Convert rotation vector to Euler angles
    rotation_mat, _ = cv2.Rodrigues(rotation_vector)
    pose_mat = cv2.hconcat((rotation_mat, translation_vector))
    _, _, _, _, _, _, euler_angle = cv2.decomposeProjectionMatrix(pose_mat)
    
    return euler_angle

# Texture Analysis for Anti-Spoofing
def texture_analysis(face_region):
    # Convert to grayscale if not already
    if len(face_region.shape) > 2:
        gray_face = cv2.cvtColor(face_region, cv2.COLOR_BGR2GRAY)
    else:
        gray_face = face_region
    
    # Resize for consistent analysis
    gray_face = cv2.resize(gray_face, (128, 128))
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray_face, (5, 5), 0)
    
    # Calculate image gradients using Sobel
    sobelx = cv2.Sobel(blurred, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(blurred, cv2.CV_64F, 0, 1, ksize=3)
    
    # Compute gradient magnitude
    magnitude = np.sqrt(sobelx**2 + sobely**2)
    
    # Compute Local Binary Pattern (simplified version)
    lbp = np.zeros_like(gray_face)
    for i in range(1, gray_face.shape[0]-1):
        for j in range(1, gray_face.shape[1]-1):
            center = gray_face[i, j]
            code = 0
            code |= (gray_face[i-1, j-1] >= center) << 7
            code |= (gray_face[i-1, j] >= center) << 6
            code |= (gray_face[i-1, j+1] >= center) << 5
            code |= (gray_face[i, j+1] >= center) << 4
            code |= (gray_face[i+1, j+1] >= center) << 3
            code |= (gray_face[i+1, j] >= center) << 2
            code |= (gray_face[i+1, j-1] >= center) << 1
            code |= (gray_face[i, j-1] >= center) << 0
            lbp[i, j] = code
    
    # Calculate histogram of LBP
    hist_lbp = cv2.calcHist([lbp], [0], None, [256], [0, 256])
    hist_lbp = cv2.normalize(hist_lbp, hist_lbp).flatten()
    
    # Calculate statistics for texture analysis
    std_dev = np.std(gray_face)
    gradient_mean = np.mean(magnitude)
    lbp_entropy = -np.sum(hist_lbp * np.log2(hist_lbp + 1e-7))
    
    # Heuristic score (higher for real faces)
    texture_score = (std_dev * 0.4) + (gradient_mean * 0.4) + (lbp_entropy * 0.2)
    
    # Return normalized score (0-1)
    return min(max(texture_score / 100.0, 0), 1)

# Light reflection analysis for 3D vs 2D differentiation
def analyze_light_reflections(face_region):
    """
    Analyze light reflections and shadows on the face.
    Real 3D faces have natural light reflections that are difficult to reproduce on 2D displays.
    """
    if face_region.size == 0:
        return 0.0
    
    # Convert to grayscale
    if len(face_region.shape) > 2:
        gray_face = cv2.cvtColor(face_region, cv2.COLOR_BGR2GRAY)
    else:
        gray_face = face_region
    
    # Resize for consistent analysis
    gray_face = cv2.resize(gray_face, (128, 128))
    
    # Apply bilateral filter to preserve edges while reducing noise
    filtered = cv2.bilateralFilter(gray_face, 9, 75, 75)
    
    # Calculate gradient magnitude to find strong edges
    sobelx = cv2.Sobel(filtered, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(filtered, cv2.CV_64F, 0, 1, ksize=3)
    magnitude = np.sqrt(sobelx**2 + sobely**2)
    
    # Analyze brightness variations across the face
    # Split face into regions
    regions = [
        gray_face[0:64, 0:64],    # Top-left
        gray_face[0:64, 64:128],   # Top-right
        gray_face[64:128, 0:64],   # Bottom-left
        gray_face[64:128, 64:128]  # Bottom-right
    ]
    
    # Calculate mean brightness for each region
    region_means = [np.mean(region) for region in regions]
    
    # Calculate standard deviation of region means
    # Higher values indicate more natural lighting variation (3D face)
    # Lower values suggest flat lighting (2D image)
    region_std = np.std(region_means)
    
    # Calculate local contrast variations
    local_contrasts = []
    for y in range(16, 112, 16):
        for x in range(16, 112, 16):
            # Extract 16x16 patch
            patch = gray_face[y-8:y+8, x-8:x+8]
            # Calculate local contrast
            local_contrasts.append(np.std(patch))
    
    # Calculate standard deviation of local contrasts
    # Higher values indicate natural texture variations (3D face)
    local_contrast_std = np.std(local_contrasts)
    
    # Combine metrics
    reflection_score = (region_std / 20.0) + (local_contrast_std / 15.0) + (np.mean(magnitude) / 50.0)
    
    # Normalize to 0-1 range
    return min(1.0, reflection_score)

# Function to evaluate face image quality
def evaluate_face_quality(frame, face, landmarks, euler_angle):
    # Extract metrics for quality assessment
    
    # 1. Face size (larger is better for KYC)
    face_width = face.width()
    face_height = face.height()
    face_size = face_width * face_height
    size_score = min(face_size / 40000.0, 1.0)  # Normalize, max at ~200x200px
    
    # 2. Face centering
    frame_center_x = frame.shape[1] / 2
    frame_center_y = frame.shape[0] / 2
    face_center_x = face.left() + face_width / 2
    face_center_y = face.top() + face_height / 2
    
    # Distance from center (lower is better)
    center_distance = np.sqrt((face_center_x - frame_center_x)**2 + 
                             (face_center_y - frame_center_y)**2)
    center_score = max(0, 1.0 - (center_distance / (frame.shape[1] / 4)))
    
    # 3. Head pose (closer to frontal is better)
    yaw = abs(euler_angle[1, 0])  # Absolute yaw angle
    pitch = abs(euler_angle[0, 0])  # Absolute pitch angle
    
    # Lower angles are better (more frontal)
    pose_score = max(0, 1.0 - (yaw / 15.0) - (pitch / 15.0))
    
    # 4. Eyes open check
    left_eye = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(36, 42)])
    right_eye = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(42, 48)])
    left_ear = eye_aspect_ratio(left_eye)
    right_ear = eye_aspect_ratio(right_eye)
    ear = (left_ear + right_ear) / 2.0
    
    # Higher EAR is better (eyes more open)
    eye_score = min(ear / 0.3, 1.0)
    
    # 5. Mouth closed check (for formal ID)
    mouth = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(48, 68)])
    mar = mouth_aspect_ratio(mouth)
    
    # Lower MAR is better (mouth more closed)
    mouth_score = max(0, 1.0 - (mar / 0.5))
    
    # 6. Brightness and contrast
    face_region = frame[face.top():face.bottom(), face.left():face.right()]
    if face_region.size > 0:
        gray_face = cv2.cvtColor(face_region, cv2.COLOR_BGR2GRAY)
        brightness = np.mean(gray_face)
        contrast = np.std(gray_face)
        
        # Ideal brightness around 120-130 (out of 255)
        brightness_score = 1.0 - abs(brightness - 125) / 125
        
        # Higher contrast is generally better
        contrast_score = min(contrast / 50.0, 1.0)
        
        light_score = (brightness_score * 0.5) + (contrast_score * 0.5)
    else:
        light_score = 0
    
    # Weighted quality score
    quality_score = (
        size_score * 0.2 +
        center_score * 0.2 +
        pose_score * 0.3 +
        eye_score * 0.1 +
        mouth_score * 0.1 +
        light_score * 0.1
    )
    
    quality_metrics = {
        "size": size_score,
        "centering": center_score,
        "pose": pose_score,
        "eyes": eye_score,
        "mouth": mouth_score,
        "lighting": light_score,
        "overall": quality_score
    }
    
    return quality_score, quality_metrics

# Function to calibrate eye threshold
def calibrate_eye_threshold(cap, detector, predictor, frames=30):
    ear_values = []
    print("Calibrating eye threshold, please look at the camera normally...")
    for _ in range(frames):
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector(gray)
        if len(faces) > 0:
            landmarks = predictor(gray, faces[0])
            left_eye = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(36, 42)])
            right_eye = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(42, 48)])
            left_ear = eye_aspect_ratio(left_eye)
            right_ear = eye_aspect_ratio(right_eye)
            ear = (left_ear + right_ear) / 2.0
            ear_values.append(ear)
        
        # Display calibration progress
        cv2.putText(frame, f"Calibrating: {len(ear_values)}/{frames}", (30, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        cv2.imshow("Calibration", frame)
        cv2.waitKey(1)
    
    cv2.destroyWindow("Calibration")
    
    if ear_values:
        # Set threshold to 80% of the average EAR
        threshold = np.mean(ear_values) * 0.8
        print(f"Calibrated EAR threshold: {threshold:.4f}")
        return threshold
    else:
        print("Calibration failed, using default threshold")
        return 0.25  # Default fallback

# Draw movement guide borders
def draw_movement_guides(frame, challenge_name):
    h, w = frame.shape[:2]
    
    if challenge_name == "TURN_LEFT":
        # Draw left border
        cv2.rectangle(frame, (0, 0), (int(w*0.2), h), (0, 255, 0), 3)
        # Draw arrow pointing left
        cv2.arrowedLine(frame, (int(w/2), int(h/2)), (int(w*0.2), int(h/2)), 
                       (0, 255, 0), 2, tipLength=0.03)
        
    elif challenge_name == "TURN_RIGHT":
        # Draw right border
        cv2.rectangle(frame, (int(w*0.8), 0), (w, h), (0, 255, 0), 3)
        # Draw arrow pointing right
        cv2.arrowedLine(frame, (int(w/2), int(h/2)), (int(w*0.8), int(h/2)), 
                       (0, 255, 0), 2, tipLength=0.03)
        
    elif challenge_name == "NOD_UP":
        # Draw top border
        cv2.rectangle(frame, (0, 0), (w, int(h*0.2)), (0, 255, 0), 3)
        # Draw arrow pointing up
        cv2.arrowedLine(frame, (int(w/2), int(h/2)), (int(w/2), int(h*0.2)), 
                       (0, 255, 0), 2, tipLength=0.03)
        
    elif challenge_name == "NOD_DOWN":
        # Draw bottom border
        cv2.rectangle(frame, (0, int(h*0.8)), (w, h), (0, 255, 0), 3)
        # Draw arrow pointing down
        cv2.arrowedLine(frame, (int(w/2), int(h/2)), (int(w/2), int(h*0.8)), 
                       (0, 255, 0), 2, tipLength=0.03)
    
    return frame

# Constants
MAR_THRESHOLD = 0.5
TEXTURE_THRESHOLD = 0.6
HEAD_YAW_THRESHOLD = 20  # degrees
HEAD_PITCH_THRESHOLD = 15  # degrees
QUALITY_THRESHOLD = 0.5  # Minimum quality for captured image

EYE_AR_CONSEC_FRAMES = 2
PREV_EAR = None

# New variables for confidence tracking
smile_confidence = 0

# Face state constants
FACE_NORMAL = 0
FACE_SMILING = 2
current_face_state = FACE_NORMAL

# Challenge-Response Mechanism
challenges = [
    {"name": "SMILE", "instruction": "Please smile", "duration": 10},
    {"name": "TURN_LEFT", "instruction": "Please turn your head left", "duration": 10},
    {"name": "TURN_RIGHT", "instruction": "Please turn your head right", "duration": 10},
    {"name": "NOD_UP", "instruction": "Please nod your head up", "duration": 10},
    {"name": "NOD_DOWN", "instruction": "Please nod your head down", "duration": 10}
]

#selected challenges before using it
selected_challenges= []
# Define remaining_challenges before shuffling
remaining_challenges = challenges.copy()  # Make a copy of challenges
random.shuffle(challenges)
random.shuffle(remaining_challenges)

smile_challenge = next(ch for ch in challenges if ch["name"] == "SMILE")
other_challenges = [ch for ch in challenges if ch["name"] != "SMILE"]
selected_challenges = [smile_challenge] + random.sample(other_challenges, 2)
random.shuffle(selected_challenges)  # Optional: shuffle the order


# Program states
STATE_LIVENESS_CHECK = 0
STATE_FACE_CAPTURE = 1
STATE_COMPLETED = 2

# Initialize variables
current_state = STATE_LIVENESS_CHECK
current_challenge = 0
challenge_start_time = None
challenge_completed = False
smile_detected = False
turn_left_detected = False
turn_right_detected = False
nod_up_detected = False
nod_down_detected = False
capture_start_time = None
best_frame = None
best_quality = 0
capture_countdown = 5 # seconds to capture best frame

# Start webcam
cap = cv2.VideoCapture(0)

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

# Calibrate eye threshold
EAR_THRESHOLD = calibrate_eye_threshold(cap, detector, predictor)

# For tracking facial movements
prev_landmarks = None
movement_scores = []


# For head pose tracking
pitch_history = []
yaw_history = []
max_history_length = 30

while True:
    ret, frame = cap.read()

    # Perform YOLO hand gesture detection
    hand_results = hand_detector.predict(frame, show=True, conf=0.5)
    for result in hand_results:
        for box, cls in zip(result.boxes.xyxy, result.boxes.cls):
            x1, y1, x2, y2 = map(int, box)
            label = result.names[int(cls)]
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, label, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    if not ret:
        break

    # Keep a clean copy of the frame for saving
    original_frame = frame.copy()

    phone_results = phone_detector.predict(source=frame, show=False)
    phone_detected = False
    
    # Check if phone is detected in the results
    for result in phone_results:
        if result.boxes and len(result.boxes) > 0:
            for box in result.boxes:
                # Check if the detected object is a phone (assuming class 0 is phone)
                # Adjust the class index and confidence threshold as needed
                if box.cls[0].item() == 0 and box.conf[0].item() > 0.5:
                    phone_detected = True
                    break
    
    # Display warning if phone is detected
    if phone_detected:
        #cv2.putText(frame, "PHONE DETECTED! Please use your actual face", (30, 350), 
        #           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        # Reset liveness check if in liveness check state
        if current_state == STATE_LIVENESS_CHECK:
            current_challenge = 0
            challenge_start_time = None
            challenge_completed = False
            smile_detected = False
            turn_left_detected = False
            turn_right_detected = False
            nod_up_detected = False
            nod_down_detected = False
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detector(gray)
    
    # Check for multiple faces and display warning
    if len(faces) > 1:
        cv2.putText(frame, f"WARNING: {len(faces)} FACES DETECTED! Only one person allowed.", 
                    (30, 420), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        # Draw red rectangle around all faces
        for face in faces:
            cv2.rectangle(frame, (face.left(), face.top()), (face.right(), face.bottom()), (0, 0, 255), 2)
    
    if len(faces) == 0:
        cv2.putText(frame, "No Face Detected", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    else:
        # Process only the largest face if multiple faces are detected
        if len(faces) > 1:
            # Find the largest face by area
            largest_face = max(faces, key=lambda face: face.width() * face.height())
            face = largest_face
        else:
            face = faces[0]
            
        landmarks = predictor(gray, face)
        
        # Get eye landmarks
        left_eye = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(36, 42)])
        right_eye = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(42, 48)])
        
        # Get mouth landmarks
        mouth = np.array([(landmarks.part(n).x, landmarks.part(n).y) for n in range(48, 68)])
        
        # Calculate EAR and MAR
        left_ear = eye_aspect_ratio(left_eye)
        right_ear = eye_aspect_ratio(right_eye)
        ear = (left_ear + right_ear) / 2.0
        mar = mouth_aspect_ratio(mouth)
        
        # Calculate smile score
        smile_score = detect_smile(landmarks)
        
        # Improved smile detection
        is_smiling = mar > MAR_THRESHOLD and smile_score > 5  # Adjust threshold as needed
        
        # Update confidence scores
        if ear < EAR_THRESHOLD:
            pass
        else:
            pass
            
        if is_smiling:
            smile_confidence = min(smile_confidence + 0.2, 1.0)
        else:
            smile_confidence = max(smile_confidence - 0.1, 0.0)

        
        # Update face state for more robust detection
        if ear < EAR_THRESHOLD:
            pass
        elif is_smiling and current_face_state != FACE_SMILING:
            current_face_state = FACE_SMILING
            if current_state == STATE_LIVENESS_CHECK and current_challenge < len(selected_challenges) and selected_challenges[current_challenge]["name"] == "SMILE":
                smile_detected = True
                challenge_completed = True
        elif ear >= EAR_THRESHOLD and not is_smiling:
            current_face_state = FACE_NORMAL
        
        # Get head pose
        euler_angle = get_head_pose(landmarks, frame)
        yaw = euler_angle[1, 0]  # Yaw angle (left-right head rotation)
        pitch = euler_angle[0, 0]  # Pitch angle (up-down head rotation)
        
        # Store head pose history
        yaw_history.append(yaw)
        pitch_history.append(pitch)
        if len(yaw_history) > max_history_length:
            yaw_history.pop(0)
        if len(pitch_history) > max_history_length:
            pitch_history.pop(0)
        
        # Extract face region for texture analysis
        face_region = frame[face.top():face.bottom(), face.left():face.right()]
        if face_region.size > 0:  # Ensure face region is valid
            texture_score = texture_analysis(face_region)
            light_reflection_score = analyze_light_reflections(face_region)
        else:
            texture_score = 0
            light_reflection_score = 0
        
        # Display metrics
        cv2.putText(frame, f"EAR: {ear:.2f}", (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        cv2.putText(frame, f"MAR: {mar:.2f}", (30, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        cv2.putText(frame, f"Smile Score: {smile_score:.2f}", (30, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        cv2.putText(frame, f"Yaw: {yaw:.1f}", (30, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        cv2.putText(frame, f"Pitch: {pitch:.1f}", (30, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        cv2.putText(frame, f"Texture: {texture_score:.2f}", (30, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        cv2.putText(frame, f"Smile Conf: {smile_confidence:.2f}", (frame.shape[1] - 200, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        
        # Visualize eye state
        if ear < EAR_THRESHOLD:
            cv2.putText(frame, "EYES CLOSED", (face.left(), face.top() - 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        # Visualize smile detection
        if is_smiling:
            cv2.putText(frame, "SMILING", (face.left(), face.top() - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        # STATE MACHINE LOGIC
        if current_state == STATE_LIVENESS_CHECK:
            # Challenge-Response Logic
            if current_challenge < len(selected_challenges):
                challenge = selected_challenges[current_challenge]
                
                # Draw movement guides based on current challenge
                if challenge["name"] in ["TURN_LEFT", "TURN_RIGHT", "NOD_UP", "NOD_DOWN"]:
                    frame = draw_movement_guides(frame, challenge["name"])
                
                # Initialize challenge timer if not started
                if challenge_start_time is None:
                    challenge_start_time = time.time()
                    challenge_completed = False
                
                # Calculate remaining time
                elapsed_time = time.time() - challenge_start_time
                remaining_time = max(0, challenge["duration"] - elapsed_time)
                
                # Display current challenge
                cv2.putText(frame, challenge["instruction"], (30, 210), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                cv2.putText(frame, f"Time: {remaining_time:.1f}s", (30, 240), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                
                # Check if challenge is completed using the improved detection methods

                REQUIRED_FRAMES = 10  # Adjust based on how long the action should be held

                if challenge["name"] == "SMILE":
                    if smile_confidence > 0.7:
                       smile_frame_count += 1  # Track number of frames where smile is detected
                    else:
                        smile_frame_count = 0  # Reset if condition is not continuously met
    
                    if smile_frame_count >= REQUIRED_FRAMES:  # Ensure challenge is held for some time
                        smile_detected = True
                        challenge_completed = True

                elif challenge["name"] == "TURN_LEFT":
                    if yaw < -HEAD_YAW_THRESHOLD:
                       turn_left_frame_count += 1
                    else:
                       turn_left_frame_count = 0
    
                    if turn_left_frame_count >= REQUIRED_FRAMES:
                       turn_left_detected = True
                       challenge_completed = True

                elif challenge["name"] == "TURN_RIGHT":
                    if yaw < -HEAD_YAW_THRESHOLD:
                       turn_right_frame_count += 1
                    else:
                       turn_right_frame_count = 0

                    if turn_right_frame_count >= REQUIRED_FRAMES:
                       turn_right_detected = True
                       challenge_completed = True

                elif challenge["name"] == "NOD_UP":
                    if yaw < -HEAD_YAW_THRESHOLD:
                       nod_up_frame_count += 1
                    else:
                       nod_up_frame_count = 0

                    if nod_up_frame_count >= REQUIRED_FRAMES:
                       nod_up_detected = True
                       challenge_completed = True

                elif challenge["name"] == "NOD_DOWN":
                    if yaw < -HEAD_YAW_THRESHOLD:
                       nod_down_frame_count += 1
                    else:
                       nod_down_frame_count = 0

                    if nod_down_frame_count >= REQUIRED_FRAMES:
                       nod_down_detected = True
                       challenge_completed = True
                
                # Move to next challenge if completed or time expired
                if challenge_completed or remaining_time <= 0:
                    current_challenge += 1
                    challenge_start_time = None
                    
                    if challenge_completed:
                        print(f"Challenge '{challenge['name']}' completed successfully!")
                    else:
                        print(f"Challenge '{challenge['name']}' timed out.")
            else:
                # All challenges completed or timed out
                # Calculate final liveness score
                challenge_score = 0
                max_challenge_score = len(selected_challenges) * 0.4  # 40% weight for challenges
                
                for challenge in selected_challenges:
                    if (challenge["name"] == "SMILE" and smile_detected) or \
                       (challenge["name"] == "TURN_LEFT" and turn_left_detected) or \
                       (challenge["name"] == "TURN_RIGHT" and turn_right_detected) or \
                       (challenge["name"] == "NOD_UP" and nod_up_detected) or \
                       (challenge["name"] == "NOD_DOWN" and nod_down_detected):
                        challenge_score += 0.4
                
                # Texture analysis and light reflection each contribute 30% to final score
                final_score = challenge_score + (texture_score * 0.3) + (light_reflection_score * 0.3)
                
                # Display final score
                cv2.putText(frame, f"Liveness Score: {final_score:.2f}", (30, 270), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                
                # Transition to face capture if liveness confirmed
                if final_score >= 0.7 and not phone_detected and len(faces) == 1:  # Threshold for liveness confirmation
                    cv2.putText(frame, "LIVENESS CONFIRMED", (30, 300), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                    
                    # Transition to face capture state after a short delay
                    if challenge_start_time is None:
                        challenge_start_time = time.time()
                    elif time.time() - challenge_start_time > 5:  # 5 seconds delay
                        current_state = STATE_FACE_CAPTURE
                        capture_start_time = time.time()
                        best_frame = None
                        best_quality = 0
                        print("Liveness confirmed. Transitioning to face capture mode.")
                elif len(faces) > 1:
                    cv2.putText(frame, "ONLY ONE PERSON ALLOWED", (30, 300), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                else:
                    cv2.putText(frame, "LIVENESS CHECK FAILED", (30, 300), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    
                    # Reset challenges after a delay
                    if challenge_start_time is None:
                        challenge_start_time = time.time()
                    elif time.time() - challenge_start_time > 5:  # 5 seconds delay before reset
                        # Reset all variables for a new attempt
                        # Shuffle challenges for unpredictability
                        random.shuffle(challenges)
                        random.shuffle(remaining_challenges)
                        selected_challenges.extend(remaining_challenges[:3])
                        random.shuffle(selected_challenges)  # Randomize final order
                        
                        current_challenge = 0
                        challenge_start_time = None
                        challenge_completed = False
                        smile_detected = False
                        turn_left_detected = False
                        turn_right_detected = False
                        nod_up_detected = False
                        nod_down_detected = False
                        smile_confidence = 0
                        print("Resetting liveness detection for a new attempt.")
        
        elif current_state == STATE_FACE_CAPTURE:
            if phone_detected:
                cv2.putText(frame, "PHONE DETECTED! Returning to liveness check", (30, 350), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                current_state = STATE_LIVENESS_CHECK
                current_challenge = 0
                challenge_start_time = None
                continue
            
            if len(faces) > 1:
                cv2.putText(frame, "MULTIPLE FACES DETECTED! Returning to liveness check", (30, 380), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                current_state = STATE_LIVENESS_CHECK
                current_challenge = 0
                challenge_start_time = None
                continue
                
            # Calculate quality of current frame
            quality_score, quality_metrics = evaluate_face_quality(frame, face, landmarks, euler_angle)
            
            # Display guidance for optimal face capture
            cv2.putText(frame, "Please look straight at the camera", (30, 270), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            # Draw face quality guidance
            cv2.putText(frame, f"Face Quality: {quality_score:.2f}", (30, 300), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            
            # Visual guidance for better positioning
            if quality_metrics["pose"] < 0.7:
                cv2.putText(frame, "Center your face", (30, 330), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            if quality_metrics["size"] < 0.7:
                cv2.putText(frame, "Move closer to camera", (30, 360), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            if quality_metrics["eyes"] < 0.7:
                cv2.putText(frame, "Open your eyes", (30, 390), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            # Calculate remaining capture time
            elapsed_capture_time = time.time() - capture_start_time
            remaining_capture_time = max(0, capture_countdown - elapsed_capture_time)
            
            # Display countdown
            cv2.putText(frame, f"Capturing best image in: {remaining_capture_time:.1f}s", (30, 420), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            # Update best frame if current frame is better
            if quality_score > best_quality and quality_score > QUALITY_THRESHOLD:
                best_quality = quality_score
                best_frame = original_frame.copy()
                print(f"New best frame found with quality: {best_quality:.2f}")
            
            # Transition to completed state when time is up
            if best_frame is not None:
                print(f"Best frame exists with shape: {best_frame.shape}")
                img_name = os.path.join(save_path, f"kyc_image_{int(time.time())}.jpg")  # Unique filename
                success = cv2.imwrite(img_name, best_frame)
    
                if success:
                    print(f"✅ Image saved successfully at {img_name}")
                    current_state = STATE_COMPLETED
                else:
                    print("❌ Failed to save the image.")
            else:
                print("❌ Error: No valid frame to save.")


        elif current_state == STATE_COMPLETED:
            # Display completion message
            cv2.putText(frame, "CAPTURE COMPLETED", (30, 270), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(frame, f"Best Quality: {best_quality:.2f}", (30, 300), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(frame, "Saving image...", (30, 330), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            
            print(f"Best frame captured and saved to {img_name}")
            
            # Exit after a short delay
            time.sleep(2)
            cap.release()
            cv2.destroyAllWindows()
            exit()
        
        # Draw facial landmarks for visualization
        #for n in range(0, 68):
        #   x = landmarks.part(n).x
        #  y = landmarks.part(n).y
        # cv2.circle(frame, (x, y), 2, (0, 255, 0), -1)
        
        # Draw eye contours with color based on state (red for closed, green for open)
        #for eye in [left_eye, right_eye]:
        #   hull = cv2.convexHull(eye)
        #  if ear < EAR_THRESHOLD:
        #     cv2.drawContours(frame, [hull], -1, (0, 0, 255), 1)  # Red for closed
        # else:
        #   cv2.drawContours(frame, [hull], -1, (0, 255, 0), 1)  # Green for open
        
        # Draw mouth contour with color based on smile
        #mouth_hull = cv2.convexHull(mouth)
        #if is_smiling:
        #   cv2.drawContours(frame, [mouth_hull], -1, (0, 255, 0), 1)  # Green for smile
        # else:
        #   cv2.drawContours(frame, [mouth_hull], -1, (255, 0, 0), 1)  # Blue for neutral
        
        # Track facial movement for additional liveness check
        if prev_landmarks is not None:
            # Calculate movement between frames for key points
            movement = np.mean([dist.euclidean(
                (landmarks.part(i).x, landmarks.part(i).y),
                (prev_landmarks.part(i).x, prev_landmarks.part(i).y))
                for i in [30, 8, 36, 45, 48, 54]])  # Key facial points
            
            movement_scores.append(movement)
            
            # Keep only the last 30 frames of movement data
            if len(movement_scores) > 30:
                movement_scores.pop(0)
            
            # Display movement score
            if len(movement_scores) > 10:  # Need some history to calculate
                movement_std = np.std(movement_scores)
                cv2.putText(frame, f"Movement: {movement_std:.2f}", (frame.shape[1] - 200, 120), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        
        # Update previous landmarks
        prev_landmarks = landmarks

    # Display the output
    cv2.imshow("Liveness Detection", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()


