import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import LivenessCheck from './LivenessCheck';
import FaceDedupe from './FaceDedupe';
import AadhaarMasker from './AadhaarMasker';
import FaceComparison from './FaceComparison';
import GroupLoanDashboard from './GroupLoanDashboard';
import './KycFlow.css';

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

const KycFlow = () => {
  const query = useQuery();
  const appId = query.get('appId');
  const applicantId = query.get('applicantId');
  
  const [currentStep, setCurrentStep] = useState(0);
  const [showGroupDashboard, setShowGroupDashboard] = useState(false);
  const [kycData, setKycData] = useState({
    applicationId: appId,
    applicantId: applicantId,
    applicantName: '',
    applicantPhone: '',
    applicantAddress: '',
    applicationType: '',
    loanType: '',
    coApplicants: [],
    isPrimaryApplicant: false,
    // Add fields for all components
    livenessImage: null,
    livenessImageDmsId: null,
    livenessSessionId: null,
    aadhaarImage: null,
    maskedAadhaarImage: null,
    maskedAadhaarDmsId: null,
    comparisonResult: null,
    dedupeResults: null,
    verificationStatus: 'pending' // pending, approved, rejected, requires_scrutiny
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Server URL
  const serverUrl = 'http://10.9.52.21:5001';
  
  // Fetch applicant details on component mount
  useEffect(() => {
    console.log("KycFlow mounted with appId:", appId, "and applicantId:", applicantId);
    if (applicantId) {
      fetchApplicantDetails();
    } else {
      setError('No applicant ID provided');
      setLoading(false);
    }
  }, [applicantId]);
  
  // Fetch applicant details
    const fetchApplicantDetails = async () => {
      try {
        console.log("Fetching applicant details for ID:", applicantId);
        setLoading(true);
        setError('');
        
        const response = await fetch(`${serverUrl}/get_applicant/${applicantId}`);
        console.log("Response status:", response.status);
        
        if (!response.ok) {
          throw new Error(`Server responded with status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log("Applicant data received:", data);
        
        // In fetchApplicantDetails function
        if (data.success) {
          // Check if this is a group application
          const isGroupApplication = data.application_type === 'group';
          const isPrimaryApplicant = data.is_primary_applicant === true;
          
          console.log("Application type:", data.application_type);
          console.log("Is primary applicant:", data.is_primary_applicant);
          
          // If KYC is already completed or in progress, fetch the full KYC details
          if (data.kyc_status === 'completed' || data.kyc_status === 'in_progress') {
            await fetchKycDetails(applicantId);
          } else {
            setKycData({
              ...kycData,
              applicationId: appId,
              applicantId: applicantId,
              applicantName: data.name,
              applicantPhone: data.phone,
              applicantAddress: data.address,
              applicationType: data.application_type,
              isPrimaryApplicant: isPrimaryApplicant,
              loanType: data.loan_type,
              coApplicants: data.co_applicants || [],
              kycStatus: data.kyc_status,
              kycSteps: data.kyc_steps,
              verificationStatus: data.verification_status || 'pending'
            });
          }
          
          // If it's a group application and this is the primary applicant, show the dashboard
          if (isGroupApplication && isPrimaryApplicant && data.co_applicants && data.co_applicants.length > 0) {
            console.log("Showing group dashboard for primary applicant");
            setShowGroupDashboard(true);
          } else {
            setShowGroupDashboard(false);
          }

        } else {
          setError(data.error || 'Failed to fetch applicant details');
        }
      } catch (error) {
        console.error('Error fetching applicant details:', error);
        setError(`Failed to connect to server: ${error.message}`);
      } finally {
        setLoading(false);
      }
    };


  // Add a new function to fetch KYC details
    const fetchKycDetails = async (applicantId) => {
      try {
        const response = await fetch(`${serverUrl}/get_kyc_details/${applicantId}`);
        
        if (!response.ok) {
          throw new Error(`Server responded with status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log("KYC details received:", data);
        
        if (data.success) {
          // Check if this is a group application and if this is the primary applicant
          const isGroupApplication = data.kyc_details.application_type === 'group';
          const isPrimaryApplicant = data.kyc_details.is_primary_applicant || false;
          
          // Map the server response to our KYC data structure
          setKycData({
            ...kycData,
            applicationId: appId,
            applicantId: applicantId,
            applicantName: data.kyc_details.name,
            applicantPhone: data.kyc_details.phone,
            applicantAddress: data.kyc_details.address,
            applicationType: data.kyc_details.application_type,
            loanType: data.kyc_details.loan_type,
            coApplicants: data.kyc_details.co_applicants || [],
            kycStatus: data.kyc_details.kyc_status,
            kycSteps: data.kyc_details.kyc_steps,
            verificationStatus: data.kyc_details.verification_status,
            isPrimaryApplicant: isPrimaryApplicant,
            
            // Image data - use DMS IDs when available
            livenessImage: data.kyc_details.livenessImage,
            livenessImageDmsId: data.kyc_details.livenessData?.liveness_dms_id,
            livenessSessionId: data.kyc_details.livenessData?.livenessSessionId,
            geoLocation: data.kyc_details.livenessData?.geoLocation,
            
            maskedAadhaarImage: data.kyc_details.maskedAadhaarImage,
            maskedAadhaarDmsId: data.kyc_details.masked_aadhaar_dms_id,
            
            // Results
            comparisonResult: data.kyc_details.comparisonResult,
            dedupeResults: data.kyc_details.dedupeData?.dedupeResults
          });
          
          // If this is a group application and the primary applicant, show the dashboard
          if (isGroupApplication && isPrimaryApplicant && data.kyc_details.kyc_status !== 'completed') {
            setShowGroupDashboard(true);
          } else {
            // Go to the summary step for completed KYC
            if (data.kyc_details.kyc_status === 'completed') {
              setCurrentStep(4); // Summary step
            }
          }
        } else {
          setError(data.error || 'Failed to fetch KYC details');
        }
      } catch (error) {
        console.error('Error fetching KYC details:', error);
        setError(`Failed to fetch KYC details: ${error.message}`);
      }
    };


  // Update KYC data
  const updateKycData = (newData) => {
    console.log("Updating KYC data with:", newData);
    setKycData({
      ...kycData,
      ...newData
    });
  };
  
  const completeMaskingStep = (maskingData) => {
    console.log("Completing Aadhaar masking step with data:", maskingData);
    
    // Update KYC data in the component state
    updateKycData({
      maskedAadhaarImage: maskingData.maskedAadhaarImage,
      maskedAadhaarDmsId: maskingData.maskedAadhaarDmsId
    });
    
    // Send update to server
    updateKycStatus('aadhaar', {
      masked_aadhaar_image: maskingData.maskedAadhaarImage,
      masked_aadhaar_dms_id: maskingData.maskedAadhaarDmsId,
      timestamp: new Date().toISOString()
    });
    
    nextStep();
  };
  
  // Update KYC status on the server
  const updateKycStatus = async (stepName, stepData) => {
    try {
      console.log(`Updating KYC status for step: ${stepName}`, stepData);
      // Prepare the data to be sent
      const updateData = {
        applicant_id: applicantId,
        kyc_steps: {
          [stepName]: true
        }
      };
      
      // Add step-specific data with proper field names for backend
      if (stepName === 'aadhaar') {
        // Move these properties to the top level of updateData
        updateData.masked_aadhaar_image = stepData.masked_aadhaar_image;
        updateData.masked_aadhaar_dms_id = stepData.masked_aadhaar_dms_id;
      } else if (stepName === 'liveness') {
        updateData.liveness_data = {
          livenessImage: stepData.livenessImage,
          liveness_dms_id: stepData.liveness_dms_id,
          livenessSessionId: stepData.livenessSessionId,
          livenessTimestamp: stepData.livenessTimestamp,
          geoLocation: stepData.geoLocation,
          deviceInfo: stepData.deviceInfo
        };
      } else if (stepName === 'comparison') {
        updateData.comparison_result = stepData.comparison_result;
      } else if (stepName === 'dedupe') {
        updateData.dedupe_data = {
          dedupeResults: stepData.dedupeResults,
          verificationStatus: stepData.verificationStatus,
          requiresScrutiny: stepData.requiresScrutiny,
          comparisonResult: kycData.comparisonResult,
          timestamp: stepData.timestamp
        };
      }
      
      console.log("Sending data to server:", updateData);
      
      const response = await fetch(`${serverUrl}/update_kyc_status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updateData)
      });
      
      const data = await response.json();
      console.log("Update KYC status response:", data);
      
      if (!data.success) {
        console.error('Failed to update KYC status:', data.error);
      }
    } catch (error) {
      console.error('Error updating KYC status:', error);
    }
  };
  
  // Next step
  const nextStep = () => {
    console.log("Moving to next step from", currentStep);
    setCurrentStep(currentStep + 1);
  };
  
  // Previous step
  const prevStep = () => {
    console.log("Moving to previous step from", currentStep);
    setCurrentStep(currentStep - 1);
  };
  
  // Complete liveness step
  const completeLivenessStep = (livenessData) => {
    console.log("Completing liveness step with data:", livenessData);
    
    // Make sure we have the geolocation data
    const geoLocation = kycData.geoLocation || livenessData.geoLocation;
    
    // Update KYC status with DMS ID if available
    updateKycStatus('liveness', {
      livenessImage: livenessData.livenessImage,
      liveness_dms_id: livenessData.liveness_dms_id,
      livenessSessionId: livenessData.livenessSessionId,
      livenessTimestamp: livenessData.livenessTimestamp || new Date().toISOString(),
      geoLocation: geoLocation,
      deviceInfo: {
        userAgent: navigator.userAgent,
        platform: navigator.platform,
        language: navigator.language
      }
    });
    
    // Update local state with image and DMS ID
    updateKycData({
      livenessImage: livenessData.livenessImage,
      livenessImageDmsId: livenessData.liveness_dms_id,
      geoLocation: geoLocation
    });
    
    nextStep();
  };

  // Complete dedupe step
  const completeDedupeStep = (dedupeData) => {
    console.log("Completing dedupe step with data:", dedupeData);
    
    // Determine verification status based on similarity scores
    let verificationStatus = dedupeData.verificationStatus;
    let requiresScrutiny = false;
    
    if (dedupeData.dedupeResults && dedupeData.dedupeResults.results) {
      const results = dedupeData.dedupeResults.results;
      for (const result of results) {
        if (result.similarity >= 0.4 && result.similarity < 0.5) {
          requiresScrutiny = true;
          verificationStatus = 'requires_scrutiny';
          break;
        }
      }
    }
    
    updateKycStatus('dedupe', {
      dedupeResults: dedupeData.dedupeResults,
      verificationStatus: verificationStatus,
      requiresScrutiny: requiresScrutiny,
      comparisonResult: kycData.comparisonResult,
      timestamp: new Date().toISOString()
    });
    nextStep();
  };
  
  // Handle continue from group dashboard
  const handleContinueFromDashboard = () => {
    setShowGroupDashboard(false);
  };
  
  // Render loading state
  if (loading) {
    return (
      <div className="kyc-flow loading">
        <div className="spinner"></div>
        <p>Loading applicant details...</p>
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className="kyc-flow error">
        <h2>Error</h2>
        <p className="error-message">{error}</p>
        <button onClick={fetchApplicantDetails}>Retry</button>
      </div>
    );
  }
  
  // Render group loan dashboard for primary applicant
  if (showGroupDashboard) {
    return (
      <GroupLoanDashboard 
        applicationData={kycData}
        coApplicants={kycData.coApplicants}
        onContinue={handleContinueFromDashboard}
      />
    );
  }
  
  // Complete comparison step
  const completeComparisonStep = (comparisonData) => {
    console.log("Completing comparison step with data:", comparisonData);
    
    updateKycData({
      comparisonResult: comparisonData
    });
    
    updateKycStatus('comparison', {
      comparison_result: comparisonData
    });
    
    nextStep();
  };
  
  // Render the current step
  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <LivenessCheck 
            onComplete={completeLivenessStep} 
            existingImage={kycData.livenessImage}
            existingDmsId={kycData.livenessImageDmsId}
            existingSessionId={kycData.livenessSessionId}
            applicantData={kycData}
          />
        );
      case 1:
        return (
          <AadhaarMasker 
            onComplete={completeMaskingStep} 
            existingMaskedImage={kycData.maskedAadhaarImage}
            existingMaskedDmsId={kycData.maskedAadhaarDmsId}
            applicantId={kycData.applicantId}
          />
        );
      case 2:
        return (
          <FaceComparison 
            onComplete={completeComparisonStep}
            livenessImage={kycData.livenessImage}
            livenessImageDmsId={kycData.livenessImageDmsId}
            maskedAadhaarImage={kycData.maskedAadhaarImage}
            maskedAadhaarDmsId={kycData.maskedAadhaarDmsId}
            existingResult={kycData.comparisonResult}
          />
        );
      case 3:
        return (
          <FaceDedupe 
            onComplete={completeDedupeStep}
            livenessImage={kycData.livenessImage}
            livenessImageDmsId={kycData.livenessImageDmsId}
            existingResults={kycData.dedupeResults}
            applicantData={kycData}
          />
        );
      case 4:
        return (
          <KycSummary 
            kycData={kycData}
            onPrevStep={prevStep}
          />
        );
      default:
        return <div>Unknown step</div>;
    }
  };
  
  // Render progress bar
  const renderProgressBar = () => {
    const steps = [
      { name: 'Liveness Check', completed: currentStep > 0 || kycData.kycSteps?.liveness },
      { name: 'Aadhaar Masking', completed: currentStep > 1 || kycData.kycSteps?.aadhaar },
      { name: 'Face Comparison', completed: currentStep > 2 || kycData.kycSteps?.comparison },
      { name: 'Face Dedupe', completed: currentStep > 3 || kycData.kycSteps?.dedupe },
      { name: 'Summary', completed: currentStep > 4 }
    ];
    
    return (
      <div className="progress-bar">
        {steps.map((step, index) => (
          <div 
            key={index} 
            className={`progress-step ${currentStep === index ? 'active' : ''} ${step.completed ? 'completed' : ''}`}
          >
            <div className="step-indicator">{index + 1}</div>
            <div className="step-name">{step.name}</div>
          </div>
        ))}
      </div>
    );
  };
  
  return (
    <div className="kyc-flow">
      <div className="kyc-header">
        <h1>KYC Verification</h1>
        <div className="applicant-info">
          <p><strong>Name:</strong> {kycData.applicantName}</p>
          <p><strong>Application ID:</strong> {kycData.applicationId}</p>
          <p><strong>Applicant ID:</strong> {kycData.applicantId}</p>
        </div>
      </div>
      
      {renderProgressBar()}
      
      <div className="kyc-step-container">
        {renderStep()}
      </div>
    </div>
  );
};

// KYC Summary Component
const KycSummary = ({ kycData, onPrevStep }) => {
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');
  const [ucicId, setUcicId] = useState('');
  const [showPrintView, setShowPrintView] = useState(false);
  
  // Server URL
  const serverUrl = 'http://10.9.52.21:5001';
  
  const handleSubmit = async () => {
    try {
      setSubmitting(true);
      setError('');
      
      // Prepare data for submission
      const submissionData = {
        name: kycData.applicantName,
        dob: kycData.dob || '1990-01-01', // Default if not available
        image: kycData.livenessImage,
        dms_id: kycData.livenessImageDmsId,
        applicant_id: kycData.applicantId,
        application_id: kycData.applicationId,
        phone: kycData.applicantPhone,
        address: kycData.applicantAddress
      };
      
      console.log("Submitting application with data:", submissionData);
      
      // Submit to server
      const response = await fetch(`${serverUrl}/submit_application`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(submissionData)
      });
      
      const data = await response.json();
      console.log("Submit application response:", data);
      
      if (data.status === 'success' || data.status === 'partial_success') {
        setSubmitted(true);
        setUcicId(data.ucic_id);
      } else {
        setError(data.error || 'Failed to submit application');
      }
    } catch (error) {
      console.error('Error submitting application:', error);
      setError(`Failed to submit application: ${error.message}`);
    } finally {
      setSubmitting(false);
    }
  };
  
  const togglePrintView = () => {
    setShowPrintView(!showPrintView);
  };
  
  // If print view is active, show the print-optimized view
  if (showPrintView) {
    return (
      <PrintOptimizedView 
        kycData={kycData} 
        ucicId={ucicId}
        onBack={togglePrintView}
      />
    );
  }
  
  return (
    <div className="kyc-summary">
      <h2>KYC Verification Summary</h2>
      
      <div className="summary-section">
        <h3>Applicant Information</h3>
        <div className="summary-row">
          <div className="summary-label">Name:</div>
          <div className="summary-value">{kycData.applicantName}</div>
        </div>
        <div className="summary-row">
          <div className="summary-label">Phone:</div>
          <div className="summary-value">{kycData.applicantPhone}</div>
        </div>
        <div className="summary-row">
          <div className="summary-label">Address:</div>
          <div className="summary-value">{kycData.applicantAddress}</div>
        </div>
        <div className="summary-row">
          <div className="summary-label">Application Type:</div>
          <div className="summary-value">{kycData.applicationType}</div>
        </div>
        <div className="summary-row">
          <div className="summary-label">Loan Type:</div>
          <div className="summary-value">{kycData.loanType}</div>
        </div>
      </div>
      
      <div className="summary-section">
        <h3>Liveness Check</h3>
        <div className="summary-images">
          {kycData.livenessImageDmsId ? (
            <img 
              src={`${serverUrl}/get_dms_image/${kycData.livenessImageDmsId}`} 
              alt="Liveness" 
              className="summary-image"
            />
          ) : kycData.livenessImage ? (
            <img 
              src={kycData.livenessImage} 
              alt="Liveness" 
              className="summary-image"
            />
          ) : (
            <div className="no-image">No liveness image available</div>
          )}
          <div className="image-caption">Liveness Image</div>
        </div>
        {kycData.geoLocation && (
          <div className="geo-location-info">
            <h4>Capture Location</h4>
            <p>Latitude: {kycData.geoLocation.latitude}</p>
            <p>Longitude: {kycData.geoLocation.longitude}</p>
            {kycData.geoLocation.address && (
              <p>Address: {kycData.geoLocation.address}</p>
            )}
          </div>
        )}
      </div>
      
      <div className="summary-section">
        <h3>Masked Aadhaar</h3>
        <div className="summary-images">
          {kycData.maskedAadhaarDmsId ? (
            <img 
              src={`${serverUrl}/get_dms_image/${kycData.maskedAadhaarDmsId}`} 
              alt="Masked Aadhaar" 
              className="summary-image"
            />
          ) : kycData.maskedAadhaarImage ? (
            <img 
              src={kycData.maskedAadhaarImage} 
              alt="Masked Aadhaar" 
              className="summary-image"
            />
          ) : (
            <div className="no-image">No masked Aadhaar image available</div>
          )}
          <div className="image-caption">Masked Aadhaar</div>
        </div>
      </div>
      
      <div className="summary-section">
        <h3>Face Comparison</h3>
        {kycData.comparisonResult ? (
          <div className="comparison-result">
            <div className={`similarity-score ${kycData.comparisonResult.match ? 'match' : 'no-match'}`}>
              <span className="score-value">{(kycData.comparisonResult.similarity * 100).toFixed(2)}%</span>
              <span className="score-label">{kycData.comparisonResult.match ? 'MATCH' : 'NO MATCH'}</span>
            </div>
            <div className="comparison-details">
              <p>Threshold: {(kycData.comparisonResult.threshold * 100).toFixed(2)}%</p>
              <p>Status: {kycData.comparisonResult.match ? 'Verified' : 'Not Verified'}</p>
            </div>
          </div>
        ) : (
          <div className="no-result">No comparison result available</div>
        )}
      </div>
      
      <div className="summary-section">
        <h3>Face Dedupe</h3>
        {kycData.dedupeResults ? (
          <div className="dedupe-results">
            <div className="dedupe-status">
              <h4>Verification Status</h4>
              <div className={`status-indicator ${kycData.verificationStatus}`}>
                {kycData.verificationStatus === 'approved' && 'APPROVED'}
                {kycData.verificationStatus === 'rejected' && 'REJECTED'}
                {kycData.verificationStatus === 'requires_scrutiny' && 'REQUIRES SCRUTINY'}
                {kycData.verificationStatus === 'pending' && 'PENDING'}
                {kycData.verificationStatus === 'duplicate_found' && 'DUPLICATE FOUND'}
              </div>
            </div>
            
            {kycData.dedupeResults.results && kycData.dedupeResults.results.length > 0 ? (
              <div className="dedupe-matches">
                <h4>Potential Matches</h4>
                <div className="matches-list">
                  {kycData.dedupeResults.results.map((result, index) => (
                    <div key={index} className="match-item">
                      <div className="match-details">
                        <p><strong>UCIC:</strong> {result.ucic_id}</p>
                        <p><strong>Name:</strong> {result.name || 'Unknown'}</p>
                        <p><strong>Similarity:</strong> {(result.similarity * 100).toFixed(2)}%</p>
                      </div>
                      {result.image_data && (
                        <img src={result.image_data} alt="Match" className="match-image" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="no-matches">No potential matches found</div>
            )}
          </div>
        ) : (
          <div className="no-result">No dedupe results available</div>
        )}
      </div>
      
      <div className="summary-actions">
        {!submitted ? (
          <>
            <button 
              className="back-button" 
              onClick={onPrevStep}
              disabled={submitting}
            >
              Back
            </button>
            <button 
              className="submit-button" 
              onClick={handleSubmit}
              disabled={submitting}
            >
              {submitting ? 'Submitting...' : 'Submit Application'}
            </button>
          </>
        ) : (
          <>
            <div className="submission-success">
              <h3>Application Submitted Successfully!</h3>
              <p>UCIC ID: <strong>{ucicId}</strong></p>
              <button className="print-button" onClick={togglePrintView}>
                Print Summary
              </button>
            </div>
          </>
        )}
        
        {error && (
          <div className="submission-error">
            <p>{error}</p>
          </div>
        )}
      </div>
    </div>
  );
};

// Print-optimized view component
const PrintOptimizedView = ({ kycData, ucicId, onBack }) => {
  const serverUrl = 'http://10.9.52.21:5001';
  
  // Automatically trigger print when component mounts
  useEffect(() => {
    const timer = setTimeout(() => {
      window.print();
    }, 500);
    
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <div className="print-view">
      <div className="print-header">
        <h1>KYC Verification Certificate</h1>
        <div className="certificate-details">
          <p><strong>UCIC ID:</strong> {ucicId}</p>
          <p><strong>Date:</strong> {new Date().toLocaleDateString()}</p>
          <p><strong>Time:</strong> {new Date().toLocaleTimeString()}</p>
        </div>
      </div>
      
      <div className="print-section">
        <h2>Applicant Information</h2>
        <table className="print-table">
          <tbody>
            <tr>
              <td><strong>Name:</strong></td>
              <td>{kycData.applicantName}</td>
            </tr>
            <tr>
              <td><strong>Phone:</strong></td>
              <td>{kycData.applicantPhone}</td>
            </tr>
            <tr>
              <td><strong>Address:</strong></td>
              <td>{kycData.applicantAddress}</td>
            </tr>
            <tr>
              <td><strong>Application ID:</strong></td>
              <td>{kycData.applicationId}</td>
            </tr>
            <tr>
              <td><strong>Applicant ID:</strong></td>
              <td>{kycData.applicantId}</td>
            </tr>
            <tr>
              <td><strong>Application Type:</strong></td>
              <td>{kycData.applicationType}</td>
            </tr>
            <tr>
              <td><strong>Loan Type:</strong></td>
              <td>{kycData.loanType}</td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div className="print-section">
        <h2>Verification Results</h2>
        <table className="print-table">
          <tbody>
            <tr>
              <td><strong>Liveness Check:</strong></td>
              <td>Passed</td>
            </tr>
            <tr>
              <td><strong>Aadhaar Verification:</strong></td>
              <td>Completed</td>
            </tr>
            <tr>
              <td><strong>Face Comparison:</strong></td>
              <td>
                {kycData.comparisonResult ? 
                  `${(kycData.comparisonResult.similarity * 100).toFixed(2)}% - ${kycData.comparisonResult.match ? 'MATCH' : 'NO MATCH'}` : 
                  'Not Available'}
              </td>
            </tr>
            <tr>
              <td><strong>Dedupe Status:</strong></td>
              <td>
                {kycData.verificationStatus === 'approved' && 'APPROVED'}
                {kycData.verificationStatus === 'rejected' && 'REJECTED'}
                {kycData.verificationStatus === 'requires_scrutiny' && 'REQUIRES SCRUTINY'}
                {kycData.verificationStatus === 'pending' && 'PENDING'}
                {kycData.verificationStatus === 'duplicate_found' && 'DUPLICATE FOUND'}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <div className="print-section print-images">
        <h2>Verification Images</h2>
        <div className="print-image-container">
          <div className="print-image-item">
            <h3>Liveness Image</h3>
            {kycData.livenessImageDmsId ? (
              <img 
                src={`${serverUrl}/get_dms_image/${kycData.livenessImageDmsId}`} 
                alt="Liveness" 
                className="print-image"
              />
            ) : kycData.livenessImage ? (
              <img 
                src={kycData.livenessImage} 
                alt="Liveness" 
                className="print-image"
              />
            ) : (
              <div className="no-image">No liveness image available</div>
            )}
          </div>
          
          <div className="print-image-item">
            <h3>Masked Aadhaar</h3>
            {kycData.maskedAadhaarDmsId ? (
              <img 
                src={`${serverUrl}/get_dms_image/${kycData.maskedAadhaarDmsId}`} 
                alt="Masked Aadhaar" 
                className="print-image"
              />
            ) : kycData.maskedAadhaarImage ? (
              <img 
                src={kycData.maskedAadhaarImage} 
                alt="Masked Aadhaar" 
                className="print-image"
              />
            ) : (
              <div className="no-image">No masked Aadhaar image available</div>
            )}
          </div>
        </div>
      </div>
      
      {kycData.dedupeResults && kycData.dedupeResults.results && kycData.dedupeResults.results.length > 0 && (
        <div className="print-section">
          <h2>Dedupe Results</h2>
          <table className="print-table">
            <thead>
              <tr>
                <th>UCIC ID</th>
                <th>Name</th>
                <th>Similarity</th>
              </tr>
            </thead>
            <tbody>
              {kycData.dedupeResults.results.map((result, index) => (
                <tr key={index}>
                  <td>{result.ucic_id}</td>
                  <td>{result.name || 'Unknown'}</td>
                  <td>{(result.similarity * 100).toFixed(2)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      <div className="print-footer">
        <p>This is a system-generated certificate. No signature required.</p>
        <p>© {new Date().getFullYear()} Chola Finance</p>
      </div>
      
      <div className="screen-only">
        <button className="back-button" onClick={onBack}>
          Back to Summary
        </button>
        <button className="print-button" onClick={() => window.print()}>
          Print Again
        </button>
      </div>
    </div>
  );
};

export default KycFlow;

