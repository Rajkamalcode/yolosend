import os
import gdown
import zipfile
import cv2
import numpy as np
from insightface.app import FaceAnalysis
import onnxruntime as ort
# Define the model directory for buffalo_m (the folder InsightFace expects)
print("AVAILABLE", ort.get_available_providers())
model_dir = os.path.expanduser("~/.insightface/models/buffalo_m")

# Check if the model folder exists; if not, download and extract it
if not os.path.exists(model_dir):
    print("Downloading buffalo_m model from alternate link...")
    # Alternate Google Drive link; extract file id and create a direct download link.
    file_id = "1net68yNxF33NNV6WP7k56FS6V53tq-64"
    url = f"https://drive.google.com/uc?id={file_id}"
    output = "buffalo_m.zip"
    gdown.download(url, output, quiet=False)
    print("Extracting model...")
    with zipfile.ZipFile(output, 'r') as zip_ref:
        zip_ref.extractall(os.path.expanduser("~/.insightface/models/"))
    os.remove(output)
    print("Download and extraction complete.")
else:
    print("buffalo_m model already exists.")

# Initialize the FaceAnalysis app with the buffalo_m model pack.
# Set ctx_id=0 to use the first GPU (if available).
app = FaceAnalysis(name='buffalo_m', providers=['CUDAExecutionProvider'])
app.prepare(ctx_id=0)  # this instructs InsightFace to use GPU if available

# Load your two face images.
# Ensure that 'aravind.jpg' and 'kamal.jpg' are available in your working directory.
img1 = cv2.imread('test1.jpg')
img2 = cv2.imread('test2.jpg')

# Detect and align faces in each image.
faces1 = app.get(img1)
faces2 = app.get(img2)

if len(faces1) == 0 or len(faces2) == 0:
    print("Face not detected in one of the images.")
else:
    # Assume the primary face in each image is the one to compare.
    emb1 = faces1[0].normed_embedding
    emb2 = faces2[0].normed_embedding

    # Compute the cosine similarity (embeddings are L2-normalized).
    cosine_sim = np.dot(emb1, emb2)
    # Convert cosine similarity to an angular distance in radians.
    angle_rad = np.arccos(np.clip(cosine_sim, -1.0, 1.0))
    # Define an additional angular margin (in radians).
    margin = 0.1  # For example, 0.1 radians (~5.7°)
    # Adjust the angle by adding the margin.
    adjusted_angle = angle_rad + margin
    # Convert the adjusted angle back to a cosine similarity score.
    modified_cosine_sim = np.cos(adjusted_angle)
    
    print("Original Cosine similarity:", cosine_sim)
    print("Angular distance (radians):", angle_rad)
    print("Modified Cosine similarity (with margin):", modified_cosine_sim)
