import React from 'react';
import './StepNavigation.css';

const StepNavigation = ({ currentStep, totalSteps }) => {
  return (
    <div className="step-navigation">
      {Array.from({ length: totalSteps }, (_, i) => i + 1).map(step => (
        <div 
          key={step} 
          className={`step ${step === currentStep ? 'active' : ''} ${step < currentStep ? 'completed' : ''}`}
        >
          <div className="step-number">{step}</div>
          <div className="step-label">
            {step === 1 && 'Aadhaar Upload'}
            {step === 2 && 'Liveness Check'}
            {step === 3 && 'Face Comparison'}
            {step === 4 && 'Duplicate Check'}
            {step === 5 && 'Verification Complete'}
          </div>
        </div>
      ))}
    </div>
  );
};

export default StepNavigation;
