import certifi
print(certifi.where())