import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import '../styles/deletedroles.css';
import Navbar from './topBar';

const fetchDeletedRoles = async (setRoles) => {
    try {
        const res = await fetch(`${import.meta.env.VITE_API}/deleted_roles`);
        const data = await res.json();
        console.log("Fetched data:", data); // Add this line
        setRoles(data);
    } catch (error) {
        console.error("Error fetching deleted roles:", error);
    }
};


const fetchConfigFiles = async (setConfigFiles) => {
    try {
        const res = await fetch(`${import.meta.env.VITE_API}/config_files`);
        const data = await res.json();
        setConfigFiles(data.config_files);
    } catch (error) {
        console.error("Error fetching config files:", error);
    }
};

const DeletedRoles = () => {
    const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm();
    const [roles, setRoles] = useState([]);
    const [selectedUser, setSelectedUser] = useState("");
    const [selectedRole, setSelectedRole] = useState(null);
    const [configFiles, setConfigFiles] = useState([]);

    const userSession = JSON.parse(sessionStorage.getItem("user"));
    const username = userSession?.username;
    const isAdmin = userSession?.role === "admin";

    const filteredRoles = isAdmin 
        ? (selectedUser ? roles.filter(role => role.username === selectedUser) : roles)
        : roles.filter(role => role.username === username);

    const uniqueUsernames = [...new Set(roles.map(role => role.username))];
    const revertJobRole = async (serialNumber, setRoles) => {
        if (window.confirm(`Are you sure you want to revert this job role?`)) {
            try {
                const userSession = JSON.parse(sessionStorage.getItem("user"));
                const username = userSession?.username;
                
                const res = await fetch(`${import.meta.env.VITE_API}/revert_job_role/${serialNumber}`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ username })
                });
    
                const data = await res.json();
                if (res.ok) {
                    console.log(data.message);
                    fetchDeletedRoles(setRoles);
                } else {
                    console.error(data.error);
                }
            } catch (error) {
                console.error("Error reverting job role:", error);
            }
        }
    };
    useEffect(() => {
        fetchDeletedRoles(setRoles);
        fetchConfigFiles(setConfigFiles);
        console.log("Roles:", roles); // Add this line
    }, []);
    
    useEffect(() => {
        if (selectedRole) {
            setValue("job_role", selectedRole.job_role);
            setValue("primary_skills", selectedRole.primary_skills.join(", "));
            setValue("secondary_skills", selectedRole.secondary_skills.join(", "));
            setValue("location", selectedRole.location);
            setValue("config_file", selectedRole.config_file);
        }
    }, [selectedRole, setValue]);

    const onSubmit = async (data) => {
        const userSession = JSON.parse(sessionStorage.getItem("user"));
        const username = userSession?.username;
        const editedOn = new Date().toISOString(); // Add this line
    
        try {
            const res = await fetch(`${import.meta.env.VITE_API}/edit_and_revert_job_role/${selectedRole.serial_number}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    username,
                    job_role: data.job_role,
                    editedBy: username,
                    editedOn: editedOn,  // Now this is defined
                    primary_skills: data.primary_skills.split(",").map(skill => skill.trim()),
                    secondary_skills: data.secondary_skills.split(",").map(skill => skill.trim()),
                    location: data.location,
                    config_file: data.config_file,
                }),
            });
    

            if (res.ok) {
                console.log("Job role edited and reverted successfully");
                setSelectedRole(null);
                reset();
                fetchDeletedRoles(setRoles);
            } else {
                console.error("Error editing and reverting job role");
            }
        } catch (error) {
            console.error("Error submitting edited job role:", error);
        }
    };

    return (
        <div className="search-page">
            <Navbar />
            <div className="main-content">
            <div className={`job-role-section ${selectedRole ? 'lock-scroll' : ''}`}>
                    <h2>Deleted Job Roles</h2>
                    {isAdmin && (
                        <div className="admin-filter">
                        <label htmlFor="user-filter">Filter by Created By:</label>
                        <select
                            id="user-filter"
                            value={selectedUser}
                            onChange={(e) => setSelectedUser(e.target.value === "" ? "" : e.target.value)}
                        >
                            <option value="">All Users</option>
                            {uniqueUsernames.map((user, index) => (
                                <option key={index} value={user}>{user}</option>
                            ))}
                        </select>
                    </div>
                    )}
                    <ul>
                        {filteredRoles.map((r, index) => (
                            <li key={index}>
                                <div>
                                <button className={`role-button ${r.serial_number === selectedRole?.serial_number ? 'selected-role' : ''}`}>
                                        <strong>Serial Number:</strong> {r.serial_number} <br />
                                        <strong>Role:</strong> {r.job_role} <br />
                                        <strong>Primary Skills:</strong> {r.primary_skills ? r.primary_skills.join(', ') : 'Not Available'} <br />
                                        <strong>Secondary Skills:</strong> {r.secondary_skills ? r.secondary_skills.join(', ') : 'Not Available'} <br />
                                        <strong>Location:</strong> {r.location || 'Not Available'} <br />
                                        <strong>Config File:</strong> {r.config_file || 'Not Available'} <br />
                                        <strong>Created By:</strong> {r.username || 'Not Available'} <br />
                                        <strong>Created On:</strong> {new Date(r.createdOn).toLocaleDateString()} <br />
                                        <strong>Deleted By:</strong> {r.deleted_by || 'Not Available'} <br />
                                        <strong>Deletion Date:</strong> {new Date(r.deletion_date).toLocaleString()} <br />
                                    </button>

                                    <button
                                        className="revert"
                                        onClick={() => revertJobRole(r.serial_number, setRoles)}
                                    >
                                        Revert
                                    </button>
                                    <button
                                        className={`edit ${selectedRole ? 'cancel-edit' : ''}`}
                                        onClick={() => {
                                            if (selectedRole) {
                                                if (window.confirm("Are you sure you want to cancel? All changes will be lost.")) {
                                                    setSelectedRole(null);
                                                    reset();
                                                }
                                            } else {
                                                setSelectedRole(r);
                                            }
                                        }}
                                    >
                                        {selectedRole ? 'Cancel' : 'Edit'}
                                    </button>

                                </div>
                            </li>
                        ))}
                    </ul>
                </div>

                {selectedRole && (
                    <div className="resume-section">
                        <form onSubmit={handleSubmit(onSubmit)} className="search-form">
                            <h3>Edit Job Role</h3>
                            <div className="form-group">
                                <label htmlFor="job_role">
                                    Job Role <span style={{ color: "red" }}>*</span>
                                </label>
                                <input
                                    {...register("job_role", { required: true })}
                                    type="text"
                                    id="job_role"
                                    placeholder="Enter job role"
                                    required
                                />
                                {errors.job_role && <span className="error-text">Job role is required</span>}
                            </div>

                            <div className="form-group">
                                <label htmlFor="primary_skills">
                                    Primary Skills (comma-separated) <span style={{ color: "red" }}>*</span>
                                </label>
                                <input
                                    {...register("primary_skills", { required: true })}
                                    type="text"
                                    id="primary_skills"
                                    placeholder="Enter primary skills"
                                    required
                                />
                                {errors.primary_skills && <span className="error-text">Primary skills are required</span>}
                            </div>

                            <div className="form-group">
                                <label htmlFor="secondary_skills">Secondary Skills (comma-separated)</label>
                                <input
                                    {...register("secondary_skills")}
                                    type="text"
                                    id="secondary_skills"
                                    placeholder="Enter secondary skills"
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="location">
                                    Applicants Location <span style={{ color: "red" }}>*</span>
                                </label>
                                <input
                                    {...register("location", { required: true })}
                                    type="text"
                                    id="location"
                                    placeholder="Enter location"
                                    required
                                />
                                {errors.location && <span className="error-text">Location is required</span>}
                            </div>

                            <div className="form-group">
                                <label htmlFor="config_file">Configuration File</label>
                                <select
                                    {...register("config_file", { required: true })}
                                    id="config_file"
                                    className={errors.config_file ? "error-input" : ""}
                                >
                                    <option value="">Select Config File</option>
                                    {configFiles
                                        .filter(file => !file.includes("deleted_configurations"))
                                        .map((file, index) => (
                                            <option key={index} value={file}>{file}</option>
                                    ))}
                                </select>
                                {errors.config_file && <span className="error-text">Configuration file is required</span>}
                            </div>
                            <div className="button-container">
                                <button 
                                    type="submit" 
                                    className="submit-button" 
                                    onClick={async (e) => {
                                        e.preventDefault();
                                        if (window.confirm("Are you sure you want to save these changes?")) {
                                            try {
                                                await handleSubmit(onSubmit)(e);
                                                alert("Changes saved successfully!");
                                                setSelectedRole(null);
                                            } catch (error) {
                                                alert("Error saving changes. Please try again.");
                                            }
                                        }
                                    }}
                                >
                                    Save Changes
                                </button>
                                <button 
                                    type="button" 
                                    className="cancel-button" 
                                    onClick={() => {
                                        if (window.confirm("Are you sure you want to cancel? All changes will be lost.")) {
                                            setSelectedRole(null);
                                        }
                                    }}
                                >
                                    Cancel
                                </button>
                            </div>

                        
                        </form>
                    </div>
                )}
            </div>
        </div>
    );
};

export default DeletedRoles;
