import React, { useState, useEffect } from 'react';
import '../styles/log.css';
import Navbar from './topBar';
import SelectedCandidatesTable from './selectedTable';

const LogViewer = () => {
    const [logContent, setLogContent] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [activeButton, setActiveButton] = useState(null);
    const [selectedMonth, setSelectedMonth] = useState('');
    const [availableMonths, setAvailableMonths] = useState([]);
    const [groupedLogs, setGroupedLogs] = useState({});

    const monthNames = {
        '01': 'January', '02': 'February', '03': 'March', '04': 'April',
        '05': 'May', '06': 'June', '07': 'July', '08': 'August',
        '09': 'September', '10': 'October', '11': 'November', '12': 'December'
    };

    const processLogs = (logs) => {
        const groups = {};
        const monthYearSet = new Set();
        const separator = "======================================================";
        const lines = logs.split('\n');
        let currentMonthYear = null;

        // Get current date and date 6 months ago
        const currentDate = new Date();
        const sixMonthsAgo = new Date();
        sixMonthsAgo.setMonth(currentDate.getMonth() - 6);

        lines.forEach(line => {
            if (line.trim()) {
                const match = line.match(/^Processing started at (\w+) (\d{4})/);
                if (match) {
                    const [, monthName, year] = match;
                    // Convert log date to Date object for comparison
                    const logDate = new Date(`${monthName} 1, ${year}`);

                    // Only process if log is within last 6 months
                    if (logDate >= sixMonthsAgo && logDate <= currentDate) {
                        const monthYear = `${monthName} ${year}`;
                        monthYearSet.add(monthYear);
                        currentMonthYear = monthYear;
                        if (!groups[monthYear]) {
                            groups[monthYear] = [];
                        }
                    }
                }

                if (currentMonthYear && groups[currentMonthYear]) {
                    groups[currentMonthYear].push(line);
                    if (line.includes('Processing completed at')) {
                        groups[currentMonthYear].push(separator);
                        groups[currentMonthYear].push('');
                    }
                }
            } else if (currentMonthYear && groups[currentMonthYear]) {
                groups[currentMonthYear].push('');
            }
        });

        const sortedMonthYears = Array.from(monthYearSet).sort((a, b) => {
            const [monthA, yearA] = a.split(' ');
            const [monthB, yearB] = b.split(' ');
            if (yearA !== yearB) return yearB - yearA;
            const monthIndexA = Object.values(monthNames).indexOf(monthA);
            const monthIndexB = Object.values(monthNames).indexOf(monthB);
            return monthIndexB - monthIndexA;
        });

        setAvailableMonths(sortedMonthYears);
        setGroupedLogs(groups);

        if (sortedMonthYears.length > 0 && !selectedMonth) {
            setSelectedMonth(sortedMonthYears[0]);
        }
    };

    const fetchLogs = async (type) => {
        setActiveButton(type);
        setLoading(true);
        setError('');

        const endpoint = type === 'recent' ? '/recent_results' : '/logs';

        try {
            const res = await fetch(`${import.meta.env.VITE_API}${endpoint}`);
            const data = await res.json();

            if (res.ok) {
                setLogContent(data.text);
                if (type === 'logs') {
                    processLogs(data.text);
                }
            } else {
                setError(data.error || 'Error fetching logs');
            }
        } catch (error) {
            setError('Failed to fetch logs');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const renderLogLine = (line) => {
        if (line.includes('Processing started at')) {
            return <span style={{ color: 'yellow' }}>{line}</span>;
        } else if (line.includes('Processing completed at')) {
            return <span style={{ color: 'green' }}>{line}</span>;
        }
        return line;
    };

    const renderContent = () => {
        if (activeButton === 'recent') {
            return (
                <pre>
                    {logContent.split('\n').map((line, index) => (
                        <div key={index}>
                            {renderLogLine(line)}
                        </div>
                    ))}
                </pre>
            );
        }

        if (activeButton === 'logs') {
            if (!selectedMonth) {
                return <p>Please select a month</p>;
            }

            const monthLogs = groupedLogs[selectedMonth];
            if (!monthLogs || monthLogs.length === 0) {
                return <p>No logs present for {selectedMonth}</p>;
            }

            return (
                <pre>
                    {monthLogs.map((line, index) => (
                        <div key={index}>
                            {renderLogLine(line)}
                        </div>
                    ))}
                </pre>
            );
        }

        if (activeButton === 'selected') {
            return <SelectedCandidatesTable />;
        }

        return null;
    };

    return (
        <div>
            <Navbar />
            <div className="log-viewer-container">
                <h3>View Logs</h3>
                <div className="log-buttons">
                    <button
                        onClick={() => fetchLogs('logs')}
                        style={{ backgroundColor: activeButton === 'logs' ? '#007BFF' : '' }}
                    >
                        Logs History
                    </button>
                    <button
                        onClick={() => fetchLogs('recent')}
                        style={{ backgroundColor: activeButton === 'recent' ? '#007BFF' : '' }}
                    >
                        Recent Results
                    </button>
                    <button
                        onClick={() => setActiveButton('selected')}
                        style={{ backgroundColor: activeButton === 'selected' ? '#007BFF' : '' }}
                    >
                        Shortlisted Candidates
                    </button>
                </div>

                {activeButton === 'logs' && (
                    <select
                        value={selectedMonth}
                        onChange={(e) => setSelectedMonth(e.target.value)}
                        className="month-dropdown"
                    >
                        <option value="">Select Month</option>
                        {availableMonths.map(monthYear => (
                            <option key={monthYear} value={monthYear}>
                                {monthYear}
                            </option>
                        ))}
                    </select>
                )}

                {loading && <p>Loading...</p>}
                {error && <p className="error">{error}</p>}
                <div className="log-content">
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};

export default LogViewer;
 