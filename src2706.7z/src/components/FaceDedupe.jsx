import React, { useState, useEffect, useRef } from 'react';
import './FaceDedupe.css';
import config from '../services/config';
const FaceDedupe = ({ kycData, updateKycData, nextStep, prevStep }) => {
  const [searchResults, setSearchResults] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [systemMetrics, setSystemMetrics] = useState(null);
  const [searchMetrics, setSearchMetrics] = useState(null);
  const [livenessImageUrl, setLivenessImageUrl] = useState(null);
  
  // Use ref to track if search has been performed to prevent duplicate API calls
  const searchPerformedRef = useRef(false);
  
  // Server URLs
  const faceServerUrl = config.facededupeapiServerUrl;
  
  // Get liveness image URL from DMS ID
  const getLivenessImageUrl = () => {
    if (kycData.livenessImageDmsId) {
      return `${faceServerUrl}/get_dms_image/${kycData.livenessImageDmsId}`;
    }
    return null;
  };
  
  // Load liveness image on component mount
  useEffect(() => {
    const imageUrl = getLivenessImageUrl();
    if (imageUrl) {
      setLivenessImageUrl(imageUrl);
    }
  }, [kycData.livenessSessionId, kycData.livenessImageDmsId]);
  
  // Search for duplicates on component mount - but only once
  useEffect(() => {
    if (kycData.livenessImageDmsId && !searchPerformedRef.current) {
      searchForDuplicates();
      searchPerformedRef.current = true;
    }
  }, [kycData.livenessImageDmsId]);
  
  // Search for duplicates
  const searchForDuplicates = async () => {
    if (!kycData.livenessImageDmsId) {
      setError('No liveness image available for search');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Instead of fetching the image and sending it as FormData,
      // we'll just send the DMS ID as JSON
      const searchPayload = {
        dms_id: kycData.livenessImageDmsId,
        threshold: 0.5  // You can adjust this value as needed
      };
      
      // If we have a session ID from liveness check, include it
      if (kycData.livenessSessionId) {
        searchPayload.session_id = kycData.livenessSessionId;
      }
      
      console.log("Sending search request to:", `${faceServerUrl}/search`);
      console.log("Search payload:", searchPayload);
      
      const result = await fetch(`${faceServerUrl}/search`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'  // Set the content type to JSON
        },
        body: JSON.stringify(searchPayload)  // Send the data as JSON
      });
      
      if (!result.ok) {
        const errorData = await result.json().catch(() => null);
        throw new Error(errorData?.error || `Server error: ${result.status} ${result.statusText}`);
      }
      
      const searchData = await result.json();
      console.log("Search response:", searchData);
      
      // Extract the results and metrics
      setSearchResults({
        message: searchData.message,
        matches: searchData.results || []
      });
      
      setSearchMetrics(searchData.metrics || {});
      setSystemMetrics(searchData.system_metrics || {});
      
      // Determine verification status based on search results
      let verificationStatus = 'approved';
      let requiresScrutiny = false;
      
      if (searchData.results && searchData.results.length > 0) {
        // Check if any result has similarity above threshold for scrutiny
        for (const result of searchData.results) {
          if (result.similarity >= 0.5) {
            verificationStatus = 'duplicate_found';
            break;
          } else if (result.similarity >= 0.4) {
            verificationStatus = 'requires_scrutiny';
            requiresScrutiny = true;
          }
        }
      }
      
      // Update KYC data
      updateKycData({
        dedupeResults: searchData,
        verificationStatus: verificationStatus,
        requiresScrutiny: requiresScrutiny
      });
      
    } catch (err) {
      setError(err.message || 'Failed to search for duplicates');
      console.error('Error searching for duplicates:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle continue to next step
// Handle continue to next step
const handleContinue = () => {
  if (!searchResults) {
    setError('Face deduplication check is required before proceeding');
    return;
  }
  
  // Determine verification status based on search results
  let verificationStatus = 'approved';
  let requiresScrutiny = false;
  
  if (searchResults.matches && searchResults.matches.length > 0) {
    // Check if any result has similarity above threshold for scrutiny
    for (const result of searchResults.matches) {
      if (result.similarity >= 0.5) {
        verificationStatus = 'duplicate_found';
        break;
      } else if (result.similarity >= 0.4) {
        verificationStatus = 'requires_scrutiny';
        requiresScrutiny = true;
      }
    }
  }
  
  // Call the nextStep function with the dedupe results
  nextStep({
    dedupeResults: {
      results: searchResults.matches,
      message: searchResults.message,
      metrics: searchMetrics,
      system_metrics: systemMetrics
    },
    verificationStatus: verificationStatus,
    requiresScrutiny: requiresScrutiny,
    timestamp: new Date().toISOString()
  });
};

  
  // Format metric value for display
  const formatMetricValue = (value, key) => {
    if (typeof value === 'number') {
      // Check if it's a count metric (these should be integers without units)
      if (['candidates_found', 'verified_matches', 'metadata_retrieved', 'total_searches', 'successful_retrievals'].includes(key)) {
        return value.toString();
      }
      
      // If it's a time value (in seconds), format with ms
      if (value < 10) {
        return `${(value * 1000).toFixed(2)} ms`;
      }
      
      // Otherwise just format with 2 decimal places
      return value.toFixed(2);
    }
    return value;
  };
  
  // Format date of birth
  const formatDate = (dateString) => {
    if (!dateString) return 'Not available';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString();
    } catch (e) {
      return dateString || 'Not available';
    }
  };
  
  return (
    <div className="face-dedupe">
      <h2>Face Deduplication Check</h2>
      <p className="instructions">
        Checking if your face already exists in our database to prevent fraud.
      </p>
      
      {/* Debug information */}
      <div className="debug-info" style={{ margin: '10px', padding: '10px', border: '1px solid #ccc', backgroundColor: '#f8f8f8', fontSize: '12px' }}>
        <h4>Debug Information</h4>
        <p>Liveness DMS ID: {kycData.livenessImageDmsId || 'Not available'}</p>
        <p>Liveness Session ID: {kycData.livenessSessionId || 'Not available'}</p>
        <p>Search Performed: {searchPerformedRef.current ? 'Yes' : 'No'}</p>
      </div>
      
      {isLoading && (
        <div className="loading">
          <div className="spinner"></div>
          <p>Searching database...</p>
        </div>
      )}
      
      {error && <div className="error-message">{error}</div>}
      
      <div className="search-image">
        <h3>Search Image</h3>
        {livenessImageUrl && (
          <img 
            src={livenessImageUrl} 
            alt="Search Face" 
            className="face-image"
            key={`liveness-${kycData.livenessImageDmsId || kycData.livenessSessionId}`}
          />
        )}
      </div>

      {searchResults && (
        <div className="search-results">
          <h3>Search Results</h3>
          
          <div className="result-status">
            {searchResults.matches && searchResults.matches.length > 0 ? (
              <div className="duplicate-found">
                <span className="warning-icon">⚠️</span>
                <span>Duplicate Found! {searchResults.message}</span>
              </div>
            ) : (
              <div className="no-duplicate">
                <span className="success-icon">✓</span>
                <span>No duplicates found. Verification successful.</span>
              </div>
            )}
          </div>
          
          {searchResults.matches && searchResults.matches.length > 0 && (
            <div className="matches-container">
              <h4>Matching Records:</h4>
              {searchResults.matches.map((match, index) => (
                <div key={index} className="match-item">
                  <div className="match-image">
                    {match.image_data ? (
                      <img 
                        src={match.image_data} 
                        alt={`Match ${index + 1}`} 
                        className="match-face-image"
                      />
                    ) : match.dms_id ? (
                      <img 
                        src={`${faceServerUrl}/get_dms_image/${match.dms_id}`} 
                        alt={`Match ${index + 1}`} 
                        className="match-face-image"
                        key={`match-${match.dms_id}`}
                      />
                    ) : (
                      <div className="no-image">No image available</div>
                    )}
                  </div>

                  <div className="match-details">
                    <div className="match-detail">
                      <span className="detail-label">UCIC ID:</span>
                      <span className="detail-value">{match.ucic_id || 'Not available'}</span>
                    </div>
                    <div className="match-detail">
                      <span className="detail-label">Name:</span>
                      <span className="detail-value">{match.name || 'Not available'}</span>
                    </div>
                    <div className="match-detail">
                      <span className="detail-label">Date of Birth:</span>
                      <span className="detail-value">{formatDate(match.dob)}</span>
                    </div>
                    <div className="match-detail">
                      <span className="detail-label">Similarity:</span>
                      <span className="detail-value">{(match.similarity * 100).toFixed(2)}%</span>
                    </div>
                    <div className="match-detail">
                      <span className="detail-label">Match Type:</span>
                      <span className="detail-value">{match.match_type || "standard"}</span>
                    </div>
                    {match.metadata && (
                      <div className="match-metadata">
                        {Object.entries(match.metadata).map(([key, value]) => (
                          <div key={key} className="metadata-item">
                            <span className="metadata-label">{key}:</span>
                            <span className="metadata-value">{value}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
            
      {searchMetrics && (
        <div className="search-metrics">
          <h3>Search Performance</h3>
          <div className="metrics-container">
            {Object.entries(searchMetrics).map(([key, value]) => (
              <div key={key} className="metric-item">
                <span className="metric-label">{key.replace(/_/g, ' ')}:</span>
                <span className="metric-value">
                  {formatMetricValue(value, key)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {systemMetrics && (
        <div className="system-metrics">
          <h3>System Metrics</h3>
          <div className="metrics-container">
            {Object.entries(systemMetrics).map(([key, value]) => (
              <div key={key} className="metric-item">
                <span className="metric-label">{key.replace(/_/g, ' ')}:</span>
                <span className="metric-value">
                  {formatMetricValue(value, key)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      <div className="controls">
        <button 
          className="search-btn" 
          onClick={searchForDuplicates}
          disabled={!kycData.livenessImageDmsId || isLoading}
        >
          Search Again
        </button>
      </div>
      
      <div className="navigation-buttons">
        <button className="back-btn" onClick={prevStep}>
          Back
        </button>
        <button 
          className="continue-btn" 
          onClick={handleContinue}
          disabled={!searchResults}
        >
          Continue
        </button>
      </div>
    </div>
  );
};

export default FaceDedupe;
