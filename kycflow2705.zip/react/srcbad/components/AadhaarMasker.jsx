import React, { useState, useRef, useEffect } from 'react';
import './AadhaarMasker.css';

const AadhaarMasker = ({ kycData, updateKycData, nextStep }) => {
  const [originalImage, setOriginalImage] = useState(null);
  const [maskedImage, setMaskedImage] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  
  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  
  // Server URL
  const serverUrl = 'http://10.9.52.21:5000/process_aadhar';
  
  // Start webcam
  const startWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user' // Use front camera
        },
        audio: false
      });
      
      if (webcamRef.current) {
        webcamRef.current.srcObject = stream;
        return new Promise((resolve) => {
          webcamRef.current.onloadedmetadata = () => {
            setStreaming(true);
            resolve(true);
          };
        });
      }
      return false;
    } catch (error) {
      console.error('Error accessing webcam:', error);
      setError('Error accessing webcam. Please check permissions.');
      return false;
    }
  };
  
  // Stop webcam
  const stopWebcam = () => {
    if (webcamRef.current && webcamRef.current.srcObject) {
      webcamRef.current.srcObject.getTracks().forEach(track => track.stop());
      webcamRef.current.srcObject = null;
      setStreaming(false);
    }
  };
  
  // Capture frame from webcam
  const captureFrame = () => {
    if (webcamRef.current && webcamRef.current.readyState === webcamRef.current.HAVE_ENOUGH_DATA && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = webcamRef.current.videoWidth;
      canvasRef.current.height = webcamRef.current.videoHeight;
      context.drawImage(webcamRef.current, 0, 0);
      return canvasRef.current.toDataURL('image/jpeg', 0.8);
    }
    return null;
  };
  
  // Capture Aadhaar image
  const captureAadhaarImage = () => {
    const imageData = captureFrame();
    if (imageData) {
      setCapturedImage(imageData);
      setOriginalImage(imageData);
      // Stop webcam after capturing
      stopWebcam();
    } else {
      setError('Failed to capture image. Please try again.');
    }
  };
  
  // Process Aadhaar image
  const processImage = async () => {
    if (!originalImage) {
      setError('Please capture an image first');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Convert base64 to blob
      const response = await fetch(originalImage);
      const blob = await response.blob();
      
      const formData = new FormData();
      formData.append('image', blob, 'aadhaar.jpg');
      
      // Add applicant ID to formData if available
      if (kycData && kycData.applicantId) {
        formData.append('applicant_id', kycData.applicantId);
      }
      
      const result = await fetch(serverUrl, {
        method: 'POST',
        body: formData
      });
      
      if (!result.ok) {
        // Try to parse error message from JSON response
        const errorData = await result.json().catch(() => null);
        throw new Error(errorData?.error || `Server error: ${result.status} ${result.statusText}`);
      }
      
      // Check if the response is JSON or a binary image
      const contentType = result.headers.get('content-type');
      
      if (contentType && contentType.includes('application/json')) {
        // Handle JSON response (which might include DMS ID)
        const jsonData = await result.json();
        
        if (jsonData.success) {
          // If the response includes a base64 image
          if (jsonData.image_data) {
            setMaskedImage(jsonData.image_data);
            
            // Update KYC data with base64 image and DMS ID if available
            updateKycData({
              aadhaarImage: originalImage,
              maskedAadhaarImage: jsonData.image_data,
              maskedAadhaarDmsId: jsonData.dms_id || null
            });
          } 
          // If the response includes a DMS ID but no image
          else if (jsonData.dms_id) {
            // Fetch the image from DMS
            const dmsImageUrl = `http://10.9.52.21:5001/get_dms_image/${jsonData.dms_id}`;
            setMaskedImage(dmsImageUrl);
            
            // Update KYC data with DMS ID
            updateKycData({
              aadhaarImage: originalImage,
              maskedAadhaarImage: dmsImageUrl,
              maskedAadhaarDmsId: jsonData.dms_id
            });
          }
        } else {
          throw new Error(jsonData.error || 'Failed to process image');
        }
      } else {
        // Handle binary image response
        const imageBlob = await result.blob();
        
        // Convert blob to base64 string for storage and transmission
        const reader = new FileReader();
        reader.readAsDataURL(imageBlob);
        reader.onloadend = () => {
          const base64data = reader.result;
          setMaskedImage(base64data);
          
          // Update KYC data with base64 string
          updateKycData({
            aadhaarImage: originalImage,
            maskedAadhaarImage: base64data
          });
        };
      }
    } catch (err) {
      setError(err.message || 'Failed to process image');
      console.error('Error processing Aadhaar image:', err);
      
      // Reset for recapture if there was an error
      setMaskedImage(null);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Handle recapture
  const handleRecapture = () => {
    setOriginalImage(null);
    setCapturedImage(null);
    setMaskedImage(null);
    setError('');
    startWebcam();
  };
  
  // Handle continue to next step
  const handleContinue = () => {
    if (!maskedImage) {
      setError('Please process an Aadhaar image first');
      return;
    }
    
    // Prepare data for the next step
    const maskingData = {
      maskedAadhaarImage: maskedImage,
      maskedAadhaarDmsId: kycData.maskedAadhaarDmsId
    };
    
    nextStep(maskingData);
  };
  
  // Start webcam on component mount
  useEffect(() => {
    // Check if we already have masked Aadhaar data
    if (kycData && (kycData.maskedAadhaarImage || kycData.maskedAadhaarDmsId)) {
      console.log("Existing masked Aadhaar data found");
      
      // If we have a DMS ID, use that to display the image
      if (kycData.maskedAadhaarDmsId) {
        setMaskedImage(`http://10.9.52.21:5001/get_dms_image/${kycData.maskedAadhaarDmsId}`);
      } else {
        setMaskedImage(kycData.maskedAadhaarImage);
      }
    } else {
      // Start webcam if no existing data
      startWebcam();
    }
    
    // Clean up on component unmount
    return () => {
      stopWebcam();
    };
  }, [kycData]);
  
  return (
    <div className="aadhaar-masker">
      <h2>Aadhaar Card Capture</h2>
      <p className="instructions">
        Position your Aadhaar card in front of the camera and capture a clear image and make sure Aadhar face is visible clearly.
      </p>
      
      {!capturedImage && !maskedImage && (
        <div className="webcam-container">
          <video ref={webcamRef} autoPlay playsInline className="webcam-video"></video>
          <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
          
          <div className="capture-controls">
            <button
              className="capture-btn"
              onClick={captureAadhaarImage}
              disabled={!streaming}
            >
              Capture Aadhaar Image
            </button>
          </div>
        </div>
      )}
      
      {isLoading && (
        <div className="loading">
          <div className="spinner"></div>
          <p>Processing image...</p>
        </div>
      )}
      
      {error && (
        <div className="error-message">
          {error}
          {capturedImage && (
            <button className="recapture-btn" onClick={handleRecapture}>
              Recapture Image
            </button>
          )}
        </div>
      )}
      
      <div className="image-preview">
        <div className="preview-container">
          <h3>Original Image</h3>
          {originalImage && <img src={originalImage} alt="Original Aadhaar" className="preview-image" />}
          {originalImage && !maskedImage && !isLoading && (
            <button
              className="process-btn"
              onClick={processImage}
              disabled={isLoading}
            >
              Process Aadhaar Card
            </button>
          )}
          {originalImage && (
            <button
              className="recapture-btn"
              onClick={handleRecapture}
              disabled={isLoading}
            >
              Recapture Image
            </button>
          )}
        </div>
        <div className="preview-container">
          <h3>Masked Image</h3>
          {maskedImage && (
            <>
              <img src={maskedImage} alt="Masked Aadhaar" className="preview-image" />
            </>
          )}
        </div>
      </div>
      
      <div className="navigation-buttons">
        {maskedImage && (
          <button
            className="continue-btn"
            onClick={handleContinue}
          >
            Continue
          </button>
        )}
      </div>
    </div>
  );
};

export default AadhaarMasker;
