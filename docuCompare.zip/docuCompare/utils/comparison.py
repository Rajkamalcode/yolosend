import json
import csv
import os
import re
from datetime import datetime
import difflib
import logging
import unicodedata

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Set environment variables for offline mode
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'

# Try to import sentence-transformers with fallback options
model = None
try:
    from sentence_transformers import SentenceTransformer, util
    import torch

    # Try to load the model from a local path
    try:
        model_path = os.environ.get('SENTENCE_TRANSFORMER_MODEL_PATH', 'all-MiniLM-L6-v2')
        if os.path.exists(model_path):
             model = SentenceTransformer(model_path, local_files_only=True)
             logger.info(f"Successfully loaded model from path: {model_path}")
        else:
             model = SentenceTransformer('all-MiniLM-L6-v2', local_files_only=True)
             logger.info(f"Successfully loaded model 'all-MiniLM-L6-v2' using default cache path.")

        test_embedding = model.encode("This is a test sentence")
        logger.info(f"Model test successful. Embedding shape: {test_embedding.shape}")

    except Exception as e:
        logger.error(f"Error loading sentence-transformer model: {e}")
        model = None

except ImportError as e:
    logger.error(f"Could not import sentence-transformers: {e}")
    logger.info("Will use simple text comparison instead of semantic matching")

    class SimpleUtil:
        @staticmethod
        def pytorch_cos_sim(vec1, vec2):
            norm1 = sum(a*a for a in vec1) ** 0.5
            norm2 = sum(b*b for b in vec2) ** 0.5
            if norm1 == 0 or norm2 == 0:
                return 0.0
            return sum(a*b for a, b in zip(vec1, vec2)) / (norm1 * norm2)
    util = SimpleUtil()

try:
    import config
except ImportError:
    class DummyConfig:
        MATCH_THRESHOLD = 0.5
    config = DummyConfig()
    logger.warning("config.py not found. Using default settings.")


# Global variable to store RAPID_SYSTEM data
RAPID_SYSTEM = {}

def set_rapid_system_data(data):
    """ Set RAPID_SYSTEM data for comparison """
    global RAPID_SYSTEM
    RAPID_SYSTEM = data
    logger.info(f"RAPID_SYSTEM data set with {len(RAPID_SYSTEM)} document types")

def ensure_kyc_address_populated(documents_by_type):
    """ Ensure KYC address field is populated with data from sanction letter if needed """
    if "kyc" not in documents_by_type or "sanction_letter" not in documents_by_type:
        return

    kyc_data = documents_by_type["kyc"].get('extracted_data', [])
    sanction_data = documents_by_type["sanction_letter"].get('extracted_data', {})

    property_address = None
    if isinstance(sanction_data, dict):
        for key in ["propertyAddress", "property_address", "propertyaddress", "address"]:
            if key in sanction_data and sanction_data[key]:
                property_address = sanction_data[key]
                break

    if property_address and isinstance(kyc_data, list):
        for kyc_entry in kyc_data:
            if isinstance(kyc_entry, dict) and not kyc_entry.get("address"):
                kyc_entry["address"] = property_address
                logger.info(f"Populated missing KYC address with property address.")

def load_comparison_rules():
    """ Load comparison rules from the CSV file """
    rules = {}
    csv_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'comparsion.csv')
    
    if not os.path.exists(csv_path):
        logger.warning(f"Comparison rules file not found at {csv_path}. Using hardcoded default rules.")
        return {
            "legal_report": {"four_boundaries": {"rule": "Compare with memorandum_of_title", "comparison_type": "boundary match"}, "property_address": {"rule": "Compare with sanction_letter", "comparison_type": "address match"}},
            "memorandum_of_title": {"four_boundaries": {"rule": "Compare with legal_report", "comparison_type": "boundary match"}, "property_address": {"rule": "Compare with sanction_letter", "comparison_type": "address match"}},
            "kyc": {"address": {"rule": "Compare with sanction_letter", "comparison_type": "address match"}},
            "sanction_letter": {"kyc_address": {"rule": "Compare with kyc", "comparison_type": "address match"}, "property_address": {"rule": "Compare with legal_report", "comparison_type": "address match"}}
        }

    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        current_doc_type = None
        for row in reader:
            if len(row) < 3:
                continue

            if row[0] and row[1]:
                doc_name = row[1]
                if "Memorandum of title" in doc_name:
                    current_doc_type = "memorandum_of_title"
                else:
                    current_doc_type = doc_name.lower().replace(' ', '_')
                
                if current_doc_type not in rules:
                    rules[current_doc_type] = {}

            if not current_doc_type or not row[2]:
                continue
            
            field_name = row[2].lower().replace(' ', '_').replace('�', '').replace('?', '').strip()
            comparison_rule = row[3] if len(row) > 3 else ""
            comparison_type = row[4] if len(row) > 4 else ""

            rules[current_doc_type][field_name] = {
                'rule': comparison_rule, 'comparison_type': comparison_type
            }

    if "kyc" not in rules: rules["kyc"] = {}
    if "address" not in rules["kyc"]:
        rules["kyc"]["address"] = {"rule": "Compare with sanction_letter", "comparison_type": "address match"}
    if "sanction_letter" not in rules: rules["sanction_letter"] = {}
    if "kyc_address" not in rules["sanction_letter"]:
        rules["sanction_letter"]["kyc_address"] = {"rule": "Compare with kyc", "comparison_type": "address match"}

    return rules

def compare_documents(case_id, documents_by_type):
    """ Compare documents for a case based on predefined rules """
    ensure_kyc_address_populated(documents_by_type)
    rules = load_comparison_rules()
    results = {}

    for doc_type, rules_for_type in rules.items():
        if doc_type not in documents_by_type:
            continue

        doc = documents_by_type[doc_type]
        extracted_data = doc.get('extracted_data', {})

        if doc_type == "sanction_letter" and isinstance(extracted_data, dict):
            property_address = None
            for key in ["propertyAddress", "property_address", "propertyaddress", "address"]:
                if key in extracted_data and extracted_data[key]:
                    property_address = extracted_data[key]
                    break
            if property_address:
                extracted_data["kyc_address"] = property_address

        if doc_type == "kyc" and isinstance(extracted_data, list):
            if doc_type not in results: results[doc_type] = {}
            for idx, kyc_entry in enumerate(extracted_data):
                entry_prefix = f"entry_{idx+1}_"
                for field_name, rule_data in rules_for_type.items():
                    entry_field_name = f"{entry_prefix}{field_name}"
                    rule = rule_data.get('rule', '')
                    if not isinstance(rule, str): continue
                    
                    if ('name' in field_name.lower() or 'borrower' in field_name.lower()):
                        field_value = kyc_entry.get('name') or kyc_entry.get('borrowers_name')
                    else:
                        field_value = get_nested_field_value(kyc_entry, field_name)

                    results[doc_type][entry_field_name] = {
                        'value': field_value, 'rule': rule, 'rule_data': rule_data,
                        'original_field': field_name, 'entry_index': idx
                    }
                    process_comparison_rule(results, doc_type, entry_field_name, field_value, rule, documents_by_type)
        else:
            results[doc_type] = {}
            for field_name, rule_data in rules_for_type.items():
                rule = rule_data.get('rule', '')
                if not isinstance(rule, str): continue
                
                field_value = get_nested_field_value(extracted_data, field_name)
                results[doc_type][field_name] = {'value': field_value, 'rule': rule, 'rule_data': rule_data}
                process_comparison_rule(results, doc_type, field_name, field_value, rule, documents_by_type)
                
    return results

def process_comparison_rule(results, doc_type, field_name, field_value, rule, documents_by_type):
    """ Process a comparison rule for a field """
    rule_data = results[doc_type][field_name].get('rule_data', {})
    comparison_type = rule_data.get('comparison_type', '')
    original_field = results[doc_type][field_name].get('original_field', field_name)

    if rule.startswith('Compare with '):
        target_doc_type = rule.replace('Compare with ', '').lower().replace(' ', '_')
        target_value, status, message = None, 'compared', ''

        if target_doc_type == 'rapid_system':
            if doc_type in RAPID_SYSTEM and 'fields' in RAPID_SYSTEM[doc_type]:
                target_value = find_matching_field(RAPID_SYSTEM[doc_type]['fields'], original_field)
            else:
                status, message = 'error', f"RAPID_SYSTEM data not found for '{doc_type}'"
        elif target_doc_type in documents_by_type:
            target_data = documents_by_type[target_doc_type].get('extracted_data', {})
            target_value = find_matching_field(target_data, original_field)
        else:
            status, message = 'error', f"Target document '{target_doc_type}' not found"

        if status == 'compared':
            comparison_result = compare_values(field_value, target_value, original_field, comparison_type)
            results[doc_type][field_name].update({
                'status': 'compared', 'target_document': target_doc_type,
                'target_value': target_value, 'result': comparison_result
            })
        else:
            results[doc_type][field_name].update({'status': status, 'message': message})

    elif rule.startswith('Should be '):
        expected_value = rule.replace('Should be ', '')
        comparison_result = compare_values(field_value, expected_value, original_field, comparison_type)
        results[doc_type][field_name].update({'status': 'compared', 'target_value': expected_value, 'result': comparison_result})

    elif rule.startswith('Availability of '):
        is_available = bool(field_value)
        results[doc_type][field_name].update({
            'status': 'compared', 'target_value': 'Available',
            'result': {'overall_match': is_available, 'best_confidence': 1.0 if is_available else 0.0}
        })

    elif rule.startswith('The date should be '):
        date_rule = rule.replace('The date should be ', '')
        field_date = parse_date(field_value)
        if field_date:
            target_doc_type_str = 'after' if 'after' in date_rule else 'greater than'
            target_doc_type = date_rule.split(target_doc_type_str)[-1].strip().lower().replace(' ', '_')
            
            if target_doc_type in documents_by_type:
                target_data = documents_by_type[target_doc_type].get('extracted_data', {})
                target_date_value = find_date_field(target_data)
                target_date = parse_date(target_date_value)
                if target_date:
                    is_after = field_date > target_date
                    results[doc_type][field_name].update({
                        'status': 'compared', 'target_value': target_date_value,
                        'result': {'overall_match': is_after, 'best_confidence': 1.0 if is_after else 0.0}
                    })
                else:
                    results[doc_type][field_name].update({'status': 'error', 'message': f"Could not parse date from '{target_doc_type}'"})
            else:
                results[doc_type][field_name].update({'status': 'error', 'message': f"Target document '{target_doc_type}' not found"})
        else:
            results[doc_type][field_name].update({'status': 'error', 'message': "Could not parse date from field value"})

    else:
        results[doc_type][field_name].update({'status': 'info', 'message': "No specific comparison performed"})

def get_nested_field_value(data, field_name):
    if not data or not isinstance(field_name, str): return None
    if '.' in field_name:
        parts = field_name.split('.')
        current = data
        for part in parts:
            if isinstance(current, dict) and part in current: current = current[part]
            else: return None
        return current
    if field_name in data: return data[field_name]
    for key in data:
        if isinstance(key, str) and key.lower() == field_name.lower(): return data[key]
    normalized_field = field_name.lower().replace('_', '').replace(' ', '')
    for key in data:
        if isinstance(key, str) and key.lower().replace('_', '').replace(' ', '') == normalized_field: return data[key]
    return None

def find_matching_field(data, field_name):
    if isinstance(data, list):
        if data and isinstance(data[0], dict): return find_matching_field(data[0], field_name)
        return None
    if not data or not isinstance(field_name, str): return None

    direct_match = get_nested_field_value(data, field_name)
    if direct_match is not None: return direct_match

    variations = {
        'name': ['name', 'fullName', 'borrowerName', 'customerName', 'borrowers_name', 'account_holder_name', 'property_owner_name'],
        'address': ['address', 'propertyAddress', 'residentialAddress', 'kyc_address', 'property_address'],
        'boundary': ['northBoundary', 'southBoundary', 'eastBoundary', 'westBoundary', 'four_boundaries']
    }
    
    for field_type, names in variations.items():
        if any(term in field_name.lower() for term in [field_type] + names):
            for var_name in names:
                value = get_nested_field_value(data, var_name)
                if value is not None: return value
    return None

def find_date_field(data):
    if isinstance(data, list):
        if data and isinstance(data[0], dict): return find_date_field(data[0])
        return None
    if not isinstance(data, dict): return None
    
    date_keywords = ['date', 'created', 'updated', 'issued', 'dob']
    for key, value in data.items():
        if isinstance(key, str) and any(keyword in key.lower() for keyword in date_keywords):
            if isinstance(value, str) and parse_date(value): return value
    return None

def parse_date(date_str):
    if not date_str or not isinstance(date_str, str): return None
    formats = [
        '%d/%m/%Y', '%d-%m-%Y', '%Y-%m-%d', '%Y/%m/%d', '%d %b %Y', '%d %B %Y',
        '%b %d, %Y', '%B %d, %Y', '%d.%m.%Y', '%Y.%m.%d'
    ]
    for fmt in formats:
        try: return datetime.strptime(date_str.strip(), fmt)
        except ValueError: continue
    return None

### --- START: SPECIALIZED COMPARISON FUNCTIONS --- ###

def normalize_text(text):
    """ Normalize text for comparison by standardizing, cleaning, and removing noise. """
    if text is None: return ""
    text = str(text).lower()
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
    
    replacements = {
        r'\bs\.no\b': 'survey number', r'\bsf\s*no\b': 'survey number', r'\bno\b': 'number',
        r'\bsro\b': 'sub registrar office', r'\bdt\b': 'district', r'\bvil\b': 'village',
        r'\btal\b': 'taluk', r'\bdist\b': 'district', r'\bold\b': 'old', r'\bnew\b': 'new'
    }
    for pattern, replacement in replacements.items():
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)

    text = re.sub(r'[^a-z0-9\s,]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip().strip(',')
    return text

# NEW: Comprehensive list of all Indian States and Union Territories
INDIAN_STATES_AND_UTS = {
    'andhra pradesh', 'arunachal pradesh', 'assam', 'bihar', 'chhattisgarh', 'goa', 'gujarat',
    'haryana', 'himachal pradesh', 'jharkhand', 'karnataka', 'kerala', 'madhya pradesh',
    'maharashtra', 'manipur', 'meghalaya', 'mizoram', 'nagaland', 'odisha', 'punjab',
    'rajasthan', 'sikkim', 'tamil nadu', 'telangana', 'tripura', 'uttar pradesh',
    'uttarakhand', 'west bengal', 'andaman and nicobar islands', 'chandigarh',
    'dadra and nagar haveli and daman and diu', 'delhi', 'jammu and kashmir', 'ladakh',
    'lakshadweep', 'puducherry'
}

def parse_address_components(address):
    """ Parse an address string into structured components using generic patterns. """
    if not address or not isinstance(address, str): return {}
    address = normalize_text(address)
    
    components = {'survey_no': None, 'village': None, 'district': None, 'taluk': None, 'state': None, 'pincode': None, 'street_area': None}
    
    pincode_match = re.search(r'\b(\d{6})\b', address)
    if pincode_match:
        components['pincode'] = pincode_match.group(1)
        address = address.replace(pincode_match.group(0), '')

    survey_patterns = [r'\b(survey\s*number)\s*:?\s*([\d\/\w,\s]+)', r'\b(\d+\/\d+[a-z]?)\b']
    all_survey_numbers = []
    for pattern in survey_patterns:
        matches = re.findall(pattern, address, re.IGNORECASE)
        for match in matches:
            num_part = match[1] if isinstance(match, tuple) else match
            cleaned_num = re.sub(r'[^0-9/]', '', num_part)
            if cleaned_num: all_survey_numbers.append(cleaned_num)
            address = address.replace(match[0] if isinstance(match, tuple) else match, '')
    if all_survey_numbers:
        components['survey_no'] = ' '.join(sorted(list(set(all_survey_numbers))))

    address_parts = [part.strip() for part in address.split(',')]
    remaining_parts = []
    for part in address_parts:
        # UPDATED: Use the comprehensive state list
        found_state = False
        for state in INDIAN_STATES_AND_UTS:
            if state in part:
                components['state'] = state
                part = part.replace(state, '').strip()
                found_state = True
                break
        if part:
            remaining_parts.append(part)

    final_remaining = []
    keyword_patterns = {'village': r'village|vil', 'district': r'district|dist|dt', 'taluk': r'taluk|tal'}
    for part in remaining_parts:
        found_keyword = False
        for comp_name, pattern in keyword_patterns.items():
            if re.search(rf'\b({pattern})\b', part):
                value = re.sub(rf'\b({pattern})\b', '', part).strip()
                components[comp_name] = value
                found_keyword = True
                break
        if not found_keyword:
            final_remaining.append(part)

    components['street_area'] = ' '.join(p for p in final_remaining if p)
    
    return components

def compare_address_components(addr1, addr2):
    """ Compare two addresses with a strict state-mismatch rule. """
    if not addr1 or not addr2:
        return {'overall_match': False, 'best_confidence': 0.0, 'method': 'missing_address'}
    
    components1 = parse_address_components(addr1)
    components2 = parse_address_components(addr2)
    
    # NEW: Immediate failure if states are identified and do not match
    state1 = components1.get('state')
    state2 = components2.get('state')
    if state1 and state2 and state1 != state2:
        logger.warning(f"Immediate address mismatch due to different states: '{state1}' vs '{state2}'")
        return {
            'overall_match': False,
            'best_confidence': 0.0,
            'method': 'state_mismatch',
            'component_results': {
                'state': {'match': False, 'confidence': 0.0, 'value1': state1, 'value2': state2}
            }
        }

    # Proceed with weighted comparison if states match or are not found
    total_weight, weighted_confidence, component_results = 0, 0, {}
    weights = {'survey_no': 0.7, 'village': 0.25, 'district': 0.15, 'taluk': 0.05, 'street_area': 0.1, 'pincode': 0.05}
    
    for component, weight in weights.items():
        value1, value2 = components1.get(component), components2.get(component)
        if not value1 or not value2: continue
            
        similarity = difflib.SequenceMatcher(None, str(value1), str(value2)).ratio()
        component_results[component] = {'match': similarity >= 0.85, 'confidence': similarity, 'value1': value1, 'value2': value2}
        total_weight += weight
        weighted_confidence += similarity * weight
    
    if total_weight == 0:
        return compare_values(addr1, addr2, "address", "default_fallback")
        
    final_confidence = weighted_confidence / total_weight
    overall_match = final_confidence >= 0.5

    return {
        'overall_match': overall_match, 'best_confidence': final_confidence,
        'component_results': component_results, 'method': 'address_component_analysis'
    }

def split_boundary_description(description):
    """ Splits a full boundary description string into its directional components. """
    if not isinstance(description, str) or not description: return {}
    desc_lower = description.lower()
    components, directions = {}, ['north', 'south', 'east', 'west']
    positions = {d: desc_lower.find(d) for d in directions if desc_lower.find(d) != -1}
    if not positions: return {'full': description}
    sorted_directions = sorted(positions.keys(), key=lambda d: positions[d])
    for i, direction in enumerate(sorted_directions):
        start_index = positions[direction]
        end_index = positions.get(sorted_directions[i+1]) if i + 1 < len(sorted_directions) else None
        components[direction] = description[start_index:end_index].strip(' ,;')
    return components

def extract_boundary_content(value, direction):
    """ Extracts the meaningful content from a single boundary description string. """
    if not isinstance(value, str): return ""
    pattern = re.compile(rf'^\s*{direction}\s*(by|on|side|of|:)?\s*', re.IGNORECASE)
    return re.sub(pattern, '', value).strip()

def compare_boundary_content(content1, content2):
    """ Compare boundary content with strict word-based matching. """
    if not content1 or not content2:
        return {'overall_match': False, 'best_confidence': 0.0, 'method': 'missing_content'}

    norm1 = re.sub(r'[^\w\s]', '', str(content1).lower()).strip()
    norm2 = re.sub(r'[^\w\s]', '', str(content2).lower()).strip()
    if norm1 == norm2: return {'overall_match': True, 'best_confidence': 1.0, 'method': 'exact_match'}

    words1, words2 = set(norm1.split()), set(norm2.split())
    stop_words = {'the', 'and', 'of', 'by', 'on', 'in', 'property', 'land', 'house', 'site', 'road', 'north', 'south', 'east', 'west'}
    words1 -= stop_words; words2 -= stop_words
    if not words1 and not words2: return {'overall_match': True, 'best_confidence': 1.0, 'method': 'stop_words_only'}
    
    intersection, union = words1 & words2, words1 | words2
    jaccard = len(intersection) / len(union) if union else 0.0
    return {'overall_match': jaccard > 0.5, 'best_confidence': jaccard, 'method': 'word_jaccard'}

def compare_boundary_descriptions(desc1, desc2):
    """ Compare boundary descriptions by splitting into directions and comparing content. """
    if desc1 is None or desc2 is None:
        return {'overall_match': False, 'best_confidence': 0.0, 'method': 'missing_description'}

    components1, components2 = split_boundary_description(desc1), split_boundary_description(desc2)
    directional_components = {'north', 'south', 'east', 'west'}
    all_components = (set(components1.keys()) | set(components2.keys())) & directional_components
    if not all_components: return compare_boundary_content(desc1, desc2)

    total_confidence, matched_count, component_results = 0, 0, {}
    for comp in all_components:
        content1 = extract_boundary_content(components1.get(comp, ""), comp)
        content2 = extract_boundary_content(components2.get(comp, ""), comp)
        comp_result = compare_boundary_content(content1, content2)
        component_results[comp] = comp_result
        if comp_result['overall_match']: matched_count += 1
        total_confidence += comp_result['best_confidence']
        
    avg_confidence = total_confidence / len(all_components) if all_components else 0
    all_match = (matched_count == len(all_components)) and all_components
    return {
        'overall_match': all_match, 'best_confidence': avg_confidence,
        'components_match': component_results, 'method': 'boundary_component_analysis'
    }

def try_parse_number(s):
    if isinstance(s, (int, float)): return float(s)
    if not isinstance(s, str): return None
    try:
        s_clean = re.sub(r'[^\d.]', '', s)
        return float(s_clean) if s_clean else None
    except (ValueError, TypeError):
        return None

def compare_values(value1, value2, field_name="", comparison_type=""):
    """
    Compare two values using a router to select the best matching strategy.
    """
    if comparison_type == "boundary match" or 'boundary' in field_name.lower():
        is_full_desc1 = isinstance(value1, str) and any(d in value1.lower() for d in ['north', 'south', 'east', 'west'])
        is_full_desc2 = isinstance(value2, str) and any(d in value2.lower() for d in ['north', 'south', 'east', 'west'])
        if is_full_desc1 or is_full_desc2:
            return compare_boundary_descriptions(value1, value2)
        else:
            return compare_boundary_content(value1, value2)

    if comparison_type == "address match" or 'address' in field_name.lower():
        return compare_address_components(value1, value2)

    if value1 is None or value2 is None:
        return {'overall_match': False, 'best_confidence': 0.0, 'method': 'missing_value'}

    num1, num2 = try_parse_number(value1), try_parse_number(value2)
    if num1 is not None and num2 is not None:
        is_match = abs(num1 - num2) < 0.01
        return {'overall_match': is_match, 'best_confidence': 1.0 if is_match else 0.0, 'method': 'numeric'}

    str_value1, str_value2 = str(value1).strip().lower(), str(value2).strip().lower()
    if str_value1 == str_value2:
        return {'overall_match': True, 'best_confidence': 1.0, 'method': 'exact'}
    
    match_threshold = getattr(config, 'MATCH_THRESHOLD', 0.5)
    similarity = difflib.SequenceMatcher(None, str_value1, str_value2).ratio()
    
    if model:
        try:
            embeddings = model.encode([str(value1), str(value2)])
            cos_sim = util.pytorch_cos_sim(embeddings[0], embeddings[1]).item()
            similarity = max(similarity, cos_sim)
        except Exception as e:
            logger.warning(f"Semantic model failed, using string similarity only. Error: {e}")

    return {
        'overall_match': similarity >= match_threshold,
        'best_confidence': similarity,
        'method': 'semantic_or_string_similarity'
    }

### --- END: SPECIALIZED COMPARISON FUNCTIONS --- ###