import React, { useEffect, useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import '../styles/search.css';
import { Link } from "react-router-dom";
import Navbar from './topBar';

const fetchJobRoles = async (setRoles) => {
    try {
        const res = await fetch(`${import.meta.env.VITE_API}/job_roles`);
        const data = await res.json();
        setRoles(data);
    } catch (error) {
        console.error("Error fetching job roles:", error);
    }
};

const fetchConfigFiles = async (setConfigFiles) => {
    try {
        const res = await fetch(`${import.meta.env.VITE_API}/config_files`);
        const data = await res.json();
        setConfigFiles(data.config_files);
    } catch (error) {
        console.error("Error fetching config files:", error);
    }
};

const deleteConfigFile = async (filename, setConfigFiles) => {
    try {
        const res = await fetch(`${import.meta.env.VITE_API}/delete_config/${filename}`, {
            method: "DELETE",
        });

        const data = await res.json();
        if (res.ok) {
            console.log(data.message);
            fetchConfigFiles(setConfigFiles);
        } else {
            console.error(data.error);
        }
    } catch (error) {
        console.error("Error deleting configuration file:", error);
    }
};

const deleteJobRole = async (serialNumber, setRoles) => {
    if (window.confirm(`Are you sure you want to delete this job role?`)) {
        try {
            const userSession = JSON.parse(sessionStorage.getItem("user"));
            const username = userSession?.username;
            
            const res = await fetch(`${import.meta.env.VITE_API}/job_role/${serialNumber}`, {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ username })
            });

            const data = await res.json();
            if (res.ok) {
                alert("Job role deleted successfully!");
                console.log(data.message);
                fetchJobRoles(setRoles);
            } else {
                alert("Error deleting job role. Please try again.");
                console.error(data.error);
            }
        } catch (error) {
            alert("Error deleting job role. Please try again.");
            console.error("Error deleting job role:", error);
        }
    }
};


const Search = () => {
    const { register, handleSubmit, formState: { errors }, reset, setValue } = useForm();
    const [roles, setRoles] = useState([]);
    const [configFiles, setConfigFiles] = useState([]);
    const [file, setFile] = useState(null);
    const [selectedUser, setSelectedUser] = useState("");
    const [selectedRole, setSelectedRole] = useState(null);
    const fileInputRef = useRef(null);

    useEffect(() => {
        fetchJobRoles(setRoles);
        fetchConfigFiles(setConfigFiles);
    }, []);

    useEffect(() => {
        if (selectedRole) {
            setValue("job_role", selectedRole.job_role);
            setValue("job_role", selectedRole.job_role);
            setValue("primary_skills", selectedRole.primary_skills.join(", "));
            setValue("secondary_skills", selectedRole.secondary_skills.join(", "));
            setValue("location", selectedRole.location);
            setValue("config_file", selectedRole.config_file);
        }
    }, [selectedRole, setValue]);

    const handleFileUpload = async () => {
        if (!file) {
            alert("Please select a file first.");
            return;
        }

        const allowedExtensions = ["xlsx", "xls"];
        const fileExtension = file.name.split(".").pop().toLowerCase();

        if (!allowedExtensions.includes(fileExtension)) {
            alert("Only Excel files (.xlsx, .xls) are allowed.");
            setFile(null);
            return;
        }

        const formData = new FormData();
        formData.append("file", file);

        try {
            const res = await fetch(`${import.meta.env.VITE_API}/upload_config`, {
                method: "POST",
                body: formData,
            });

            const responseData = await res.json();
            if (res.ok) {
                console.log("File uploaded successfully:", responseData);
                alert("File uploaded successfully!");
                setFile(null);
                if (fileInputRef.current) {
                    fileInputRef.current.value = '';
                }
                fetchConfigFiles(setConfigFiles);
            } else {
                console.error("Error uploading file:", responseData);
            }
        } catch (error) {
            console.error("Error uploading file:", error);
        }
    };

    const onSubmit = async (data) => {
        const userSession = JSON.parse(sessionStorage.getItem("user"));
        const username = userSession?.username;
        const timestamp = new Date().toISOString();
        const createdBy = username || 'Not Available';
        const createdOn = timestamp;
    
        try {
            if (selectedRole) {
                // Edit existing job role
                const res = await fetch(`${import.meta.env.VITE_API}/edit_and_revert_job_role/${selectedRole.serial_number}`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        username,
                        job_id: data.job_id,
                        job_role: data.job_role,
                        primary_skills: data.primary_skills.split(",").map(skill => skill.trim()),
                        secondary_skills: data.secondary_skills.split(",").map(skill => skill.trim()),
                        location: data.location,
                        config_file: data.config_file,
                        createdOn: selectedRole.createdOn || timestamp,
                        editedBy: username,
                        editedOn: timestamp
                    }),
                });
                console.log("job_id", data.job_id);
                if (res.ok) {
                    setSelectedRole(null);
                    reset();
                    fetchJobRoles(setRoles);
                    alert("Job role updated successfully!");
                }
            } else {
                // Get next serial number for new search
                const serialRes = await fetch(`${import.meta.env.VITE_API}/get_next_serial`);
                const serialData = await serialRes.json();
    
                // Process new job search
                const res = await fetch(`${import.meta.env.VITE_API}/process_job_search`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        username,
                        job_id: data.job_id,
                        job_role: data.job_role,
                        primary_skills: data.primary_skills.split(",").map(skill => skill.trim()),
                        secondary_skills: data.secondary_skills.split(",").map(skill => skill.trim()),
                        location: data.location,
                        config_file: data.config_file,
                        serial_number: serialData.serialNumber,
                        createdOn: timestamp
                    }),
                });
    
                if (res.ok) {
                    reset();
                    fetchJobRoles(setRoles);
                    alert("Job search processed successfully!");
                }
            }
        } catch (error) {
            console.error("Error submitting job role:", error);
            alert("Error processing request. Please try again.");
        }
    };
    
    
    
    const userSession = JSON.parse(sessionStorage.getItem("user"));
    const username = userSession?.username;
    const isAdmin = userSession?.role === "admin";
    const filteredRoles = isAdmin 
    ? (selectedUser 
        ? roles.filter(role => role.username === selectedUser).sort((a, b) => a.serial_number - b.serial_number)
        : roles.sort((a, b) => a.serial_number - b.serial_number))
    : roles.filter(role => role.username === username).sort((a, b) => a.serial_number - b.serial_number);

    const uniqueUsernames = [...new Set(roles.map(role => role.username))];

    return (
        <div className="search-page">
            <Navbar />
            <div className="main-content">
                <div className="resume-section">
                    <form onSubmit={handleSubmit(onSubmit)} className="search-form">
                        <h3>Search Resume</h3>
                        <div className="form-group">
                            <label htmlFor="job_role">
                                Job Role <span style={{ color: "red" }}>*</span>
                            </label>
                            <input
                                {...register("job_role", { required: true })}
                                type="text"
                                id="job_role"
                                placeholder="Enter job role"
                                required
                            />
                            {errors.job_role && <span className="error-text">Job role is required</span>}
                        </div>

                        <label htmlFor="job_id">
                            Job ID <span style={{ color: "red" }}>*</span>
                        </label>
                        <input
                            {...register("job_id", { required: true })}
                            type="text"
                            id="job_id"
                            placeholder="Enter job ID"
                            required
                        />
                        {errors.job_id && <span className="error-text">Job ID is required</span>}

                        <div className="form-group">
                            <label htmlFor="primary_skills">
                                Primary Skills (comma-separated) <span style={{ color: "red" }}>*</span>
                            </label>
                            <input
                                {...register("primary_skills", { required: true })}
                                type="text"
                                id="primary_skills"
                                placeholder="Enter primary skills"
                                required
                            />
                            {errors.primary_skills && <span className="error-text">Primary skills are required</span>}
                        </div>

                        <div className="form-group">
                            <label htmlFor="secondary_skills">Secondary Skills (comma-separated)</label>
                            <input
                                {...register("secondary_skills")}
                                type="text"
                                id="secondary_skills"
                                placeholder="Enter secondary skills"
                            />
                            {errors.secondary_skills && <span className="error-text">Secondary skills are required</span>}
                        </div>

                        <div className="form-group">
                            <label htmlFor="location">
                                Applicants Location <span style={{ color: "red" }}>*</span>
                            </label>
                            <input
                                {...register("location", { required: true })}
                                type="text"
                                id="location"
                                placeholder="Enter location"
                                required
                            />
                            {errors.location && <span className="error-text">Location is required</span>}
                        </div>
                        
                        <div className="form-group">
                            <label htmlFor="config_file">Configuration File</label>
                            <div className="config-container">
                                <select
                                    {...register("config_file", { required: true })}
                                    id="config_file"
                                    className={errors.config_file ? "error-input" : ""}
                                >
                                    <option value="">Select Config File</option>
                                    {configFiles
                                        .filter(file => !file.includes("deleted_configurations"))
                                        .map((file, index) => (
                                            <option key={index} value={file}>{file}</option>
                                    ))}
                                </select>
                                <button
                                    type="button"
                                    className="delete-config-button"
                                    onClick={() => deleteConfigFile(document.getElementById("config_file").value, setConfigFiles)}
                                >
                                    Delete
                                </button>
                            </div>
                            {errors.config_file && <span className="error-text">Configuration file is required</span>}
                        </div>
        

                       <button 
                            type="submit" 
                            className="submit-button" 
                            style={{ 
                                backgroundColor: selectedRole ? '#FFD700' : '',
                                color: selectedRole ? '#000000' : ''
                             }}
                           >
                            {selectedRole ? "Edit and Save" : "Create Job Role"}
                           </button>
                           
                           
                    </form>
                    <div className="uploadbutton">
                        <h3>Upload Config File</h3>
                        <div className="file-input-row">
                        <input
                                type="file"
                                accept=".xlsx, .xls"
                                onChange={(e) => setFile(e.target.files[0])}
                                ref={fileInputRef}
                            />
                            <button onClick={handleFileUpload} className="upload-button">Upload</button>
                        </div>
                    </div>
                </div>
                <div className={`job-role-section ${selectedRole ? 'lock-scroll' : ''}`}>
                    <Link to="/deleted_roles" className="view-deleted-link">
                        <button className="view-deleted-button">
                            View Deleted Roles
                        </button>
                    </Link>
                    <h2>Indexed Job Roles</h2>
                    {isAdmin && (
                        <div className="admin-filter">
                            <label htmlFor="user-filter">Filter by User:</label>
                            <select
                                id="user-filter"
                                value={selectedUser}
                                onChange={(e) => {
                                    const selectedValue = e.target.value;
                                    setSelectedUser(selectedValue === "" ? "" : selectedValue);
                                }}
                            >
                                <option value="">All Users</option>
                                {uniqueUsernames.map((user, index) => (
                                    <option key={index} value={user}>{user}</option>
                                ))}
                            </select>
                        </div>
                    )}
                    <ul>
                    {/* {filteredRoles.map((r, index) => (
                        <li key={index}>
                            <div>
                                <Link to={`/job_role/${r.serial_number}`}>
                                <button className={`role-button ${r.serial_number === selectedRole?.serial_number ? 'selected-role' : ''}`}>
                                    <strong>Serial Number:</strong> {r.serial_number} <br />
                                    <strong>Role:</strong> {r.job_role} <br />
                                    <strong>Primary Skills:</strong> {r.primary_skills ? r.primary_skills.join(', ') : 'Not Available'} <br />
                                    <strong>Secondary Skills:</strong> {r.secondary_skills ? r.secondary_skills.join(', ') : 'Not Available'} <br />
                                    <strong>Location:</strong> {r.location || 'Not Available'} <br />
                                    <strong>Config File:</strong> {r.config_file || 'Not Available'} <br />
                                    <strong>Created By:</strong> {r.username || r.createdBy || 'Not Available'} <br />
                                    <strong>Created On:</strong> {r.createdOn ? new Date(r.createdOn).toLocaleDateString() : 'Not Available'} <br />
                                    {r.editedBy && (
                                        <>
                                            <strong>Edited By:</strong> {r.editedBy} <br />
                                            <strong>Edited On:</strong> {new Date(r.editedOn).toLocaleDateString()} <br />
                                        </>
                                    )}
                                    {r.revertedBy && (
                                        <>
                                            <strong>Reverted By:</strong> {r.revertedBy} <br />
                                            <strong>Reverted On:</strong> {new Date(r.revertedOn).toLocaleDateString()} <br />
                                        </>
                                    )}
                                </button>

                               </Link>
                               <div className="button-group">
                                    <button
                                        className={`edit ${selectedRole ? 'cancel-edit' : ''}`}
                                        onClick={() => {
                                            if (selectedRole) {
                                                if (window.confirm("Are you sure you want to cancel? All changes will be lost.")) {
                                                    setSelectedRole(null);
                                                    reset();
                                                }
                                            } else {
                                                setSelectedRole(r);
                                            }
                                        }}
                                    >
                                        {selectedRole ? 'Cancel' : 'Edit'}
                                    </button>

                                    <button
                                        className="del"
                                        onClick={() => deleteJobRole(r.serial_number, setRoles)}
                                    >
                                        Delete
                                    </button>
                                </div>

                    
                            </div>
                        </li>
                        
                    ))} */}
                    {filteredRoles
                    .sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn))
                    .map((r, index) => (
                        <li key={index}>
                            <div>
                                <Link to={`/job_role/${r.serial_number}`}>
                                    <button className={`role-button ${r.serial_number === selectedRole?.serial_number ? 'selected-role' : ''}`}>
                                        <strong>Serial Number:</strong> {r.serial_number} <br />
                                        <strong>Job ID:</strong> {r.job_id} <br />
                                        <strong>Role:</strong> {r.job_role} <br />
                                        <strong>Primary Skills:</strong> {r.primary_skills ? r.primary_skills.join(', ') : 'Not Available'} <br />
                                        <strong>Secondary Skills:</strong> {r.secondary_skills ? r.secondary_skills.join(', ') : 'Not Available'} <br />
                                        <strong>Location:</strong> {r.location || 'Not Available'} <br />
                                        <strong>Config File:</strong> {r.config_file || 'Not Available'} <br />
                                        <strong>Created By:</strong> {r.username || r.createdBy || 'Not Available'} <br />
                                        <strong>Created On:</strong> {r.createdOn ? new Date(r.createdOn).toLocaleDateString() : 'Not Available'} <br />
                                        {r.editedBy && (
                                            <>
                                                <strong>Edited By:</strong> {r.editedBy} <br />
                                                <strong>Edited On:</strong> {new Date(r.editedOn).toLocaleDateString()} <br />
                                            </>
                                        )}
                                        {r.revertedBy && (
                                            <>
                                                <strong>Reverted By:</strong> {r.revertedBy} <br />
                                                <strong>Reverted On:</strong> {new Date(r.revertedOn).toLocaleDateString()} <br />
                                            </>
                                        )}
                                    </button>
                                </Link>
                                <div className="button-group">
                                    <button
                                        className={`edit ${selectedRole ? 'cancel-edit' : ''}`}
                                        onClick={() => {
                                            if (selectedRole) {
                                                if (window.confirm("Are you sure you want to cancel? All changes will be lost.")) {
                                                    setSelectedRole(null);
                                                    reset();
                                                }
                                            } else {
                                                setSelectedRole(r);
                                            }
                                        }}
                                    >
                                        {selectedRole ? 'Cancel' : 'Edit'}
                                    </button>
                                    <button
                                        className="del"
                                        onClick={() => deleteJobRole(r.serial_number, setRoles)}
                                    >
                                        Delete
                                    </button>
                                </div>
                            </div>
                        </li>
                    ))}


                    </ul>
                </div>
            </div>
        </div>
    );
};

export default Search;
