import { useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import mermaid from 'mermaid';
import { SessionResponse } from '../services/documentService';

interface Props {
  sessionData: SessionResponse;
}

export default function DocumentAnalysis({ sessionData }: Props) {
  const [mermaidSvgs, setMermaidSvgs] = useState<Record<string, string>>({});

  useEffect(() => {
    // Initialize mermaid
    mermaid.initialize({
      startOnLoad: true,
      theme: 'default',
      securityLevel: 'loose',
    });
    
    // Process any mermaid diagrams in the analysis result
    if (sessionData.analysis_result) {
      processMermaidDiagrams(sessionData.analysis_result);
    }
  }, [sessionData]);

  const processMermaidDiagrams = async (content: string) => {
    // Find all mermaid code blocks
    const mermaidRegex = /```mermaid\n([\s\S]*?)```/g;
    const matches = [...content.matchAll(mermaidRegex)];
    
    const newSvgs: Record<string, string> = {};
    
    for (let i = 0; i < matches.length; i++) {
      const match = matches[i];
      const diagramCode = match[1];
      const diagramId = `mermaid-diagram-${i}`;
      
      try {
        // Render the mermaid diagram to SVG
        const { svg } = await mermaid.render(diagramId, diagramCode);
        newSvgs[diagramId] = svg;
      } catch (error) {
        console.error('Error rendering mermaid diagram:', error);
      }
    }
    
    setMermaidSvgs(newSvgs);
  };

  // Custom renderer for code blocks to handle mermaid diagrams
  const CodeBlock = ({ className, children }: { className?: string; children: any }) => {
    const language = className?.replace('language-', '');
    
    if (language === 'mermaid') {
      const diagramCode = children.toString();
      const diagramId = `mermaid-diagram-${Object.keys(mermaidSvgs).length}`;
      
      // If we have a rendered SVG, display it
      if (mermaidSvgs[diagramId]) {
        return <div dangerouslySetInnerHTML={{ __html: mermaidSvgs[diagramId] }} />;
      }
      
      // Otherwise, show the code block
      return (
        <pre className="mermaid">
          <code>{diagramCode}</code>
        </pre>
      );
    }
    
    // Regular code block
    return (
      <pre className={className}>
        <code>{children}</code>
      </pre>
    );
  };

  if (!sessionData.analysis_result) {
    return (
      <div className="p-4 bg-yellow-100 border border-yellow-400 text-yellow-700 rounded">
        No analysis result available. There might have been an error during processing.
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto p-4 bg-white rounded-lg shadow">
      <h2 className="text-xl font-bold mb-4">Document Analysis</h2>
      
      <div className="prose max-w-none">
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          rehypePlugins={[rehypeRaw]}
          components={{
            code: CodeBlock,
            // Custom table renderer to handle color-coded cells
            table: ({ node, ...props }) => (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-300 border" {...props} />
              </div>
            ),
            th: ({ node, ...props }) => (
              <th className="px-3 py-2 bg-gray-100 text-left text-xs font-medium text-gray-600 uppercase tracking-wider" {...props} />
            ),
            td: ({ node, children, ...props }) => {
              // Check if the content includes "red" marker for mismatches
              const content = String(children);
              const isRedCell = content.includes('**red**');
              
              // Remove the marker from the content
              const cleanContent = content.replace('**red**', '');
              
              return (
                <td 
                  className={`px-3 py-2 whitespace-normal text-sm ${isRedCell ? 'bg-red-100' : ''}`} 
                  {...props}
                >
                  {isRedCell ? cleanContent : children}
                </td>
              );
            }
          }}
        >
          {sessionData.analysis_result}
        </ReactMarkdown>
      </div>
    </div>
  );
}