import React, { useState, useEffect } from 'react';
import './GroupLoanDashboard.css';
import config from '../services/config';
const GroupLoanDashboard = ({ applicationData, coApplicants, onContinue }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  
  // Server URL
  const serverUrl = config.facededupeapiServerUrl;
  
  // Calculate group KYC progress
  const totalApplicants = coApplicants.length + 1; // Including primary applicant
  const completedKyc = coApplicants.filter(a => a.kyc_status === 'completed').length + 
                      (applicationData.kycStatus === 'completed' ? 1 : 0);
  const kycProgress = Math.round((completedKyc / totalApplicants) * 100);
  
  // Calculate verification progress
  const approvedVerifications = coApplicants.filter(a => a.verification_status === 'approved').length + 
                               (applicationData.verificationStatus === 'approved' ? 1 : 0);
  const verificationProgress = Math.round((approvedVerifications / totalApplicants) * 100);
  
  // Check if all KYCs are completed
  const allKycCompleted = completedKyc === totalApplicants;
  
  // Check if all verifications are approved
  const allVerificationsApproved = approvedVerifications === totalApplicants;
  
  // Send reminder to co-applicant
  const sendReminder = async (applicantId) => {
    try {
      setLoading(true);
      setError('');
      
      const response = await fetch(`${serverUrl}/send_kyc_reminder`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          applicant_id: applicantId
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        setSuccessMessage(`Reminder sent to ${data.applicant_name}`);
        
        // Clear success message after 3 seconds
        setTimeout(() => {
          setSuccessMessage('');
        }, 3000);
      } else {
        setError(data.error || 'Failed to send reminder');
      }
    } catch (error) {
      console.error('Error sending reminder:', error);
      setError('Failed to connect to server');
    } finally {
      setLoading(false);
    }
  };
  
// Copy KYC link to clipboard
// Copy KYC link to clipboard
const copyToClipboard = (link) => {
    // Check if link is a string (the actual link) or an object (the applicant data)
    let finalLink;
    
    if (typeof link === 'string') {
      // If it's already a string (the link), use it directly
      finalLink = link;
    } else if (link && link.kyc_link) {
      // If it's an applicant object with kyc_link property, use that
      finalLink = link.kyc_link;
    } else if (link && link.applicant_id) {
      // If it's an applicant object without kyc_link, construct the link
      finalLink = `${window.location.origin}/kyc?appId=${applicationData.applicationId}&applicantId=${link.applicant_id}`;
    } else {
      // Fallback - construct link from current application data
      finalLink = `${window.location.origin}/kyc?appId=${applicationData.applicationId}&applicantId=${link}`;
    }
    
    navigator.clipboard.writeText(finalLink)
      .then(() => {
        setSuccessMessage('Link copied to clipboard!');
        
        // Clear success message after 3 seconds
        setTimeout(() => {
          setSuccessMessage('');
        }, 3000);
      })
      .catch(err => {
        console.error('Failed to copy link:', err);
        setError('Failed to copy link to clipboard');
      });
  };
  

  
  
  return (
    <div className="group-loan-dashboard">
      <div className="dashboard-header">
        <h1>Group Loan KYC Dashboard</h1>
        <div className="application-info">
          <p><strong>Application ID:</strong> {applicationData.applicationId}</p>
          <p><strong>Loan Type:</strong> {applicationData.loanType}</p>
          <p><strong>Primary Applicant:</strong> {applicationData.applicantName}</p>
        </div>
      </div>
      
      {error && <div className="error-message">{error}</div>}
      {successMessage && <div className="success-message">{successMessage}</div>}
      
      <div className="dashboard-content">
        <div className="dashboard-section">
          <h2>Group KYC Progress</h2>
          
          <div className="progress-container">
            <div className="progress-item">
              <div className="progress-label">
                <span>KYC Completion:</span>
                <span>{completedKyc} of {totalApplicants} completed</span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ width: `${kycProgress}%` }}
                ></div>
              </div>
              <div className="progress-percentage">{kycProgress}%</div>
            </div>
            
            <div className="progress-item">
              <div className="progress-label">
                <span>Verification Status:</span>
                <span>{approvedVerifications} of {totalApplicants} approved</span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ width: `${verificationProgress}%` }}
                ></div>
              </div>
              <div className="progress-percentage">{verificationProgress}%</div>
            </div>
          </div>
          
          <div className="group-status">
            <h3>Group Application Status</h3>
            <div className={`status-badge ${allKycCompleted && allVerificationsApproved ? 'status-ready' : 'status-pending'}`}>
              {allKycCompleted && allVerificationsApproved 
                ? 'Ready for Submission' 
                : 'Pending Co-Applicant Verification'}
            </div>
            
            {!allKycCompleted && (
              <p className="status-message">
                All co-applicants must complete their KYC verification before the application can proceed.
              </p>
            )}
            
            {allKycCompleted && !allVerificationsApproved && (
              <p className="status-message">
                Some verifications require review. Please check individual applicant status.
              </p>
            )}
            
            {allKycCompleted && allVerificationsApproved && (
              <p className="status-message success">
                All verifications are complete and approved. You can now proceed with your application.
              </p>
            )}
          </div>
        </div>
        
        <div className="dashboard-section">
          <h2>Applicants</h2>
          
          <div className="applicant-card primary">
            <div className="applicant-header">
              <h3>{applicationData.applicantName}</h3>
              <span className="applicant-badge primary">Primary Applicant</span>
            </div>
            
            <div className="applicant-details">
              <div className="detail-item">
                <span className="detail-label">Phone:</span>
                <span className="detail-value">{applicationData.applicantPhone}</span>
              </div>
              
              <div className="detail-item">
                <span className="detail-label">KYC Status:</span>
                <span className={`detail-value status ${applicationData.kycStatus === 'completed' ? 'completed' : 'pending'}`}>
                  {applicationData.kycStatus === 'completed' ? 'Completed' : 'Pending'}
                </span>
              </div>
              
              {applicationData.verificationStatus && (
                <div className="detail-item">
                  <span className="detail-label">Verification:</span>
                  <span className={`detail-value status ${
                    applicationData.verificationStatus === 'approved' ? 'approved' : 
                    applicationData.verificationStatus === 'requires_scrutiny' ? 'scrutiny' : 
                    applicationData.verificationStatus === 'duplicate_found' ? 'duplicate' : 'pending'
                  }`}>
                    {applicationData.verificationStatus === 'approved' ? 'Approved' : 
                     applicationData.verificationStatus === 'requires_scrutiny' ? 'Under Review' : 
                     applicationData.verificationStatus === 'duplicate_found' ? 'Duplicate Found' : 'Pending'}
                  </span>
                </div>
              )}
            </div>
            
            <div className="applicant-actions">
              <button 
                className="action-btn primary"
                onClick={onContinue}
                disabled={loading}
              >
                {applicationData.kycStatus === 'completed' ? 'View KYC Details' : 'Complete KYC'}
              </button>
            </div>
          </div>
          
          <h3 className="co-applicants-title">Co-Applicants</h3>
          
          {coApplicants.length === 0 ? (
            <p className="no-co-applicants">No co-applicants found for this application.</p>
          ) : (
            <div className="co-applicants-list">
              {coApplicants.map((applicant, index) => (
                <div key={index} className="applicant-card">
                  <div className="applicant-header">
                    <h3>{applicant.name}</h3>
                    <span className="applicant-badge">Co-Applicant {index + 1}</span>
                  </div>
                  
                  <div className="applicant-details">
                    <div className="detail-item">
                      <span className="detail-label">Phone:</span>
                      <span className="detail-value">{applicant.phone}</span>
                    </div>
                    
                    <div className="detail-item">
                      <span className="detail-label">KYC Status:</span>
                      <span className={`detail-value status ${
                        applicant.kyc_status === 'completed' ? 'completed' : 
                        applicant.kyc_status === 'in_progress' ? 'in-progress' : 'pending'
                      }`}>
                        {applicant.kyc_status === 'completed' ? 'Completed' : 
                         applicant.kyc_status === 'in_progress' ? 'In Progress' : 'Not Started'}
                      </span>
                    </div>
                    
                    {applicant.verification_status && (
                      <div className="detail-item">
                        <span className="detail-label">Verification:</span>
                        <span className={`detail-value status ${
                          applicant.verification_status === 'approved' ? 'approved' : 
                          applicant.verification_status === 'requires_scrutiny' ? 'scrutiny' : 
                          applicant.verification_status === 'duplicate_found' ? 'duplicate' : 'pending'
                        }`}>
                          {applicant.verification_status === 'approved' ? 'Approved' : 
                           applicant.verification_status === 'requires_scrutiny' ? 'Under Review' : 
                           applicant.verification_status === 'duplicate_found' ? 'Duplicate Found' : 'Pending'}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <div className="applicant-actions">
                    <button 
                      className="action-btn copy"
                      onClick={() => copyToClipboard(applicant.kyc_link)}
                      disabled={loading}
                    >
                      Copy KYC Link
                    </button>
                    
                    <button 
                      className="action-btn remind"
                      onClick={() => sendReminder(applicant.applicant_id)}
                      disabled={loading || applicant.kyc_status === 'completed'}
                    >
                      Send Reminder
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <div className="dashboard-footer">
        <button 
          className="continue-btn"
          onClick={onContinue}
          disabled={loading}
        >
          {applicationData.kycStatus === 'completed' ? 'View My KYC Details' : 'Complete My KYC'}
        </button>
        
        {allKycCompleted && allVerificationsApproved && (
          <button className="submit-application-btn">
            Submit Group Application
          </button>
        )}
      </div>
    </div>
  );
};

export default GroupLoanDashboard;
