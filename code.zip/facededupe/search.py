import os
import io
import cv2
import time
import numpy as np
from PIL import Image
from insightface.app import FaceAnalysis
from pymilvus import connections, Collection
from pymongo import MongoClient
import gridfs
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("FaceSearchSystem")

class FaceSearchSystem:
    def __init__(self, config):
        self.config = config
        self.metrics = {
            'total_searches': 0,
            'average_search_time': 0,
            'successful_retrievals': 0
        }
        self._init_connections()
        self._init_face_model()
        self._prepare_collection()

    def _init_connections(self):
        """Initialize database connections"""
        # Milvus connection
        try:
            connections.connect(
                alias="default",
                host=self.config['MILVUS_HOST'],
                port=self.config['MILVUS_PORT']
            )
            logger.info(f"Connected to Milvus at {self.config['MILVUS_HOST']}:{self.config['MILVUS_PORT']}")
        except Exception as e:
            logger.error("Milvus connection failed")
            raise

        # MongoDB connection
        try:
            self.mongo_client = MongoClient(self.config['MONGO_URI'])
            self.mongo_db = self.mongo_client[self.config['MONGO_DB']]
            self.mongo_collection = self.mongo_db[self.config['MONGO_COLLECTION']]
            self.fs = gridfs.GridFS(self.mongo_db)
            logger.info(f"Connected to MongoDB at {self.config['MONGO_URI']}")
        except Exception as e:
            logger.error("MongoDB connection failed")
            raise

    def _init_face_model(self):
        """Initialize face recognition model"""
        logger.info("Initializing face recognition model")
        try:
            self.app = FaceAnalysis(
                name='buffalo_m',  
                root=os.path.expanduser('~/.insightface/')
            )
            ctx_id = 0 if self.config['USE_GPU'] else -1
            self.app.prepare(
                ctx_id=ctx_id,
                det_size=(640, 640),
                det_thresh=self.config['DETECTION_THRESHOLD']
            )
            logger.info(f"Model initialized with {'GPU' if ctx_id == 0 else 'CPU'}")
        except Exception as e:
            logger.error("Model initialization failed")
            raise

    def _prepare_collection(self):
        """Prepare Milvus collection for searching"""
        logger.info("Loading Milvus collection")
        try:
            self.collection = Collection(self.config['COLLECTION_NAME'])
            self.collection.load()
            logger.info("Collection loaded successfully")
        except Exception as e:
            logger.error(f"Collection load failed: {str(e)}")
            raise

    def _process_image(self, image_bytes):
        """Process image bytes and extract face embedding with timing"""
        start_time = time.time()
        try:
            img = Image.open(io.BytesIO(image_bytes))
            img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
            faces = self.app.get(img)
            if not faces:
                logger.warning("No faces detected in query image")
                return None
            # Check detection confidence if applicable
            detection_threshold = self.config.get('FACE_DETECTION_THRESHOLD', 0.9)
            if hasattr(faces[0], 'det_score') and faces[0].det_score < detection_threshold:
                logger.warning(f"Face detected, but detection score ({faces[0].det_score:.4f}) is below threshold ({detection_threshold})")
                return None
            processing_time = time.time() - start_time
            logger.debug(f"Image processed in {processing_time:.4f}s")
            return faces[0].normed_embedding  # Already normalized
        except Exception as e:
            logger.error(f"Image processing failed: {str(e)}")
            return None

    def search(self, image_bytes, threshold=0.6):
        """
        Perform complete search pipeline using GPU_CAGRA search parameters
        and convert the L2 distance to a cosine-like similarity score.
        """
        search_metrics = {
            'total_time': 0,
            'processing_time': 0,
            'search_time': 0,
            'mongo_time': 0,
            'candidates_found': 0,
            'verified_matches': 0,
            'metadata_retrieved': 0,
            'min_similarity': float('inf'),
            'max_similarity': -float('inf')
        }
        
        start_total = time.time()
        
        # Step 1: Process input image
        processing_start = time.time()
        query_emb = self._process_image(image_bytes)
        search_metrics['processing_time'] = time.time() - processing_start
        
        if query_emb is None:
            search_metrics['total_time'] = time.time() - start_total
            return [], search_metrics

        # Step 2: Perform vector search with GPU_CAGRA parameters using L2 metric
        search_start = time.time()
        try:
            results = self.collection.search(
                data=[query_emb],
                anns_field="embedding",
                param={
                    "metric_type": "IP",  # Using IP for GPU_CAGRA; embeddings are normalized.
                    "params": {
                        "itopk_size": 128,
                        "search_width": 4,
                        "min_iterations": 0,
                        "max_iterations": 0,
                        "team_size": 0
                    }
                },
                limit=100,
                output_fields=["ucic_id"],
                consistency_level="Strong"
            )
            search_metrics['search_time'] = time.time() - search_start
            search_metrics['candidates_found'] = len(results[0])
        except Exception as e:
            logger.error(f"Vector search failed: {str(e)}")
            search_metrics['total_time'] = time.time() - start_total
            return [], search_metrics

        verified_matches = []
        best_candidate = None
        best_score = -float('inf')
        similarity_scores = []
        
        for hit in results[0]:
            try:
                cos_sim = hit.score
                # Update min/max similarity for debugging
                angle = np.arccos(np.clip(cos_sim, -1.0, 1.0))
                # adjusted_angle = angle + self.config['ANGULAR_MARGIN']
                adjusted_angle = angle 
                final_score = np.cos(adjusted_angle)
                # Update min/max for debugging purposes.
                search_metrics['min_similarity'] = min(search_metrics['min_similarity'], cos_sim)
                search_metrics['max_similarity'] = max(search_metrics['max_similarity'], cos_sim)

                if cos_sim > best_score:
                    best_score = cos_sim
                    best_candidate = {
                        "ucic_id": hit.entity.get("ucic_id"),
                        "confidence": float(cos_sim),
                        "similarity": float(cos_sim)
                    }
                
                if cos_sim >= threshold:
                    candidate = {
                        "ucic_id": hit.entity.get("ucic_id"),
                        "confidence": float(cos_sim),
                        "similarity": float(cos_sim),
                        "extraction_method": "threshold"
                    }
                    verified_matches.append(candidate)
                    similarity_scores.append(cos_sim)
            except Exception as e:
                logger.warning(f"Score processing failed: {str(e)}")

        # If no candidate meets the threshold, evaluate the best candidate based on new thresholds
        if not verified_matches and best_candidate is not None:
            if best_candidate["similarity"] < 0.3:
                # No match - similarity too low
                search_metrics['total_time'] = time.time() - start_total
                return [], search_metrics
            else:
                # Potential match (0.3 <= similarity < threshold)
                best_candidate["extraction_method"] = "top1"
                best_candidate["match_type"] = "potential" if best_candidate["similarity"] < 0.5 else "confident"
                verified_matches.append(best_candidate)
        
        search_metrics['verified_matches'] = len(verified_matches)
        
        if not verified_matches:
            logger.info(f"No verified matches. Similarity range: {search_metrics['min_similarity']:.4f} to {search_metrics['max_similarity']:.4f}")
            logger.info(f"Top 5 candidate scores: {sorted(similarity_scores, reverse=True)[:5]}")

        # Step 4: Retrieve metadata from MongoDB
        mongo_start = time.time()
        final_results = []
        for match in verified_matches:
            try:
                doc = self.mongo_collection.find_one(
                    {"ucic_id": match["ucic_id"]},
                    projection=["name", "dob", "image_id","dms_id"]
                )
                if doc:
                    result_dict = {
                        "ucic_id": match["ucic_id"],
                        "name": doc.get("name"),
                        "date_of_birth": doc.get("dob"),
                        "confidence": match["confidence"],
                        "similarity": match["similarity"],
                        "image_id": doc.get("image_id"),
                        "extraction_method": match.get("extraction_method", "unknown"),
                        "match_type": match.get("match_type", "confident"),
                        "dms_id":doc.get("dms_id")
                    }
                    final_results.append(result_dict)
                    search_metrics['metadata_retrieved'] += 1
            except Exception as e:
                logger.error(f"MongoDB lookup failed for {match['ucic_id']}: {str(e)}")
        
        search_metrics['mongo_time'] = time.time() - mongo_start
        search_metrics['total_time'] = time.time() - start_total
        
        # Update system-wide metrics
        self.metrics['total_searches'] += 1
        self.metrics['successful_retrievals'] += len(final_results)
        self.metrics['average_search_time'] = (
            self.metrics['average_search_time'] * (self.metrics['total_searches'] - 1) +
            search_metrics['total_time']
        ) / self.metrics['total_searches']

        # Optionally, fetch and save the retrieved image via GridFS
        if final_results:
            try:
                image_file = self.fs.get(final_results[0]["image_id"])
                image_bytes_result = image_file.read()
                with open("result.jpg", "wb") as f:
                    f.write(image_bytes_result)
                logger.info("Result image saved as result.jpg")
            except Exception as e:
                logger.error("Failed to fetch or save result image: " + str(e))
        
        return final_results, search_metrics


    def search_from_file(self, file_path, threshold=0.6):
        """Convenience method to search from an image file path"""
        try:
            with open(file_path, "rb") as f:
                image_bytes = f.read()
            return self.search(image_bytes, threshold)
        except Exception as e:
            logger.error(f"File read failed: {str(e)}")
            return [], {}

    def get_system_metrics(self):
        """Return accumulated system performance metrics"""
        return self.metrics.copy()

# Configuration -------------------------------------------------
CONFIG = {
    "MILVUS_HOST": "localhost",
    "MILVUS_PORT": "19530",
    "COLLECTION_NAME": "faces_test",
    "USE_GPU": True,
    "DETECTION_THRESHOLD": 0.4,
    "ANGULAR_MARGIN": 0.1,
    "FACE_DETECTION_THRESHOLD": 0.5,  # Filter low-confidence face detections
    "MONGO_URI": "mongodb://bridgedevwrite:BridgedevWrite890@10.9.50.43:10050/",
    "MONGO_DB": "chola_face_db",
    "MONGO_COLLECTION": "face_images"
}

if __name__ == "__main__":
    try:
        # Initialize search system
        search_system = FaceSearchSystem(CONFIG)
        
        # Example search using a test image file
        test_image = "faces/New folder/CHOLA.jpg"
        if os.path.exists(test_image):
            results, metrics = search_system.search_from_file(test_image, threshold=0.5)
            
            print("\n=== Search Results ===")
            for result in results:
                print(f"ID: {result['ucic_id']}")
                print(f"Name: {result['name']}")
                print(f"Similarity: {result['similarity']:.4f}")
                print(f"Extraction Method: {result['extraction_method']}")
                print("-" * 40)
            
            print("\n=== Performance Metrics ===")
            print(f"Total search time: {metrics['total_time']:.4f}s")
            print(f"Processing time: {metrics['processing_time']:.4f}s")
            print(f"Vector search time: {metrics['search_time']:.4f}s")
            print(f"MongoDB retrieval time: {metrics['mongo_time']:.4f}s")
            print(f"Candidates found: {metrics['candidates_found']}")
            print(f"Verified matches: {metrics['verified_matches']}")
            print(f"Metadata retrieved: {metrics['metadata_retrieved']}")
            
            system_metrics = search_system.get_system_metrics()
            print("\n=== System Metrics ===")
            print(f"Total searches: {system_metrics['total_searches']}")
            print(f"Average search time: {system_metrics['average_search_time']:.4f}s")
            print(f"Successful retrievals: {system_metrics['successful_retrievals']}")
        else:
            logger.error("Test image not found")
            
    except Exception as e:
        logger.error(f"Search system failed: {str(e)}")
    finally:
        connections.disconnect("default")
        logger.info("System shutdown complete")
