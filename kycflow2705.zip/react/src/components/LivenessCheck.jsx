import React, { useState, useRef, useEffect } from 'react';
import './LivenessCheck.css';

const LivenessCheck = ({ kycData, updateKycData, nextStep }) => {
  const [streaming, setStreaming] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [status, setStatus] = useState('Ready to start liveness check');
  const [statusClass, setStatusClass] = useState('pending');
  const [progress, setProgress] = useState(0);
  const [capturedDmsId, setCapturedDmsId] = useState(null);
  const [capturedImageUrl, setCapturedImageUrl] = useState(null);
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [spoofingDetected, setSpoofingDetected] = useState(false);
  const [retryCount, setRetryCount] = useState(0); // Track retry attempts
  const [livenessComplete, setLivenessComplete] = useState(false); // New state to track completion
  const [locationStatus, setLocationStatus] = useState('pending'); 
  
  // Use refs to persist values across renders
  const sessionIdRef = useRef(null);
  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  const processingIntervalRef = useRef(null);
  
  // Server URL - make sure this matches your Flask server address
  const serverUrl = 'http://10.9.52.21:5003';
  
  // Start webcam
  const startWebcam = async () => {
    try {
      // Check if mediaDevices is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error(
          "Your browser doesn't support camera access. Please try using Chrome, Firefox, or Edge."
        );
      }
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        },
        audio: false
      });
      
      if (webcamRef.current) {
        webcamRef.current.srcObject = stream;
        return new Promise((resolve) => {
          webcamRef.current.onloadedmetadata = () => {
            setStreaming(true);
            resolve(true);
          };
        });
      }
      return false;
    } catch (error) {
      console.error('Error accessing webcam:', error);
      
      // Provide more specific error messages
      if (error.name === 'NotAllowedError') {
        setStatus('Camera access denied. Please allow camera access and try again.');
      } else if (error.name === 'NotFoundError') {
        setStatus('No camera found. Please connect a camera and try again.');
      } else if (error.name === 'NotReadableError') {
        setStatus('Camera is already in use by another application.');
      } else {
        setStatus(`Error accessing webcam: ${error.message}`);
      }
      
      setStatusClass('error');
      return false;
    }
  };
  
  // Stop webcam
  const stopWebcam = () => {
    if (webcamRef.current && webcamRef.current.srcObject) {
      // Stop processing frames when webcam is stopped
      if (processingIntervalRef.current) {
        clearInterval(processingIntervalRef.current);
        processingIntervalRef.current = null;
      }
      
      webcamRef.current.srcObject.getTracks().forEach(track => track.stop());
      webcamRef.current.srcObject = null;
      setStreaming(false);
    }
  };
  
  // Capture frame from webcam
  const captureFrame = () => {
    if (webcamRef.current && webcamRef.current.readyState === webcamRef.current.HAVE_ENOUGH_DATA && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = webcamRef.current.videoWidth;
      canvasRef.current.height = webcamRef.current.videoHeight;
      context.drawImage(webcamRef.current, 0, 0);
      return canvasRef.current.toDataURL('image/jpeg', 0.8);
    }
    return null;
  };
  
  // Start liveness detection session
  const startLivenessSession = async () => {
    try {
      console.log("Starting liveness session...");
      const response = await fetch(`${serverUrl}/start_liveness`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
      });
      
      const data = await response.json();
      console.log("Liveness session response:", data);
      
      if (data.success) {
        // Store session ID in both state and ref
        setSessionId(data.session_id);
        sessionIdRef.current = data.session_id;
        return data.session_id;
      } else {
        throw new Error(data.error || 'Failed to start liveness session');
      }
    } catch (error) {
      console.error('Error starting liveness session:', error);
      setStatus(`Error: ${error.message}`);
      setStatusClass('error');
      return null;
    }
  };
  
  // Process frame with callback
  const processFrameWithCallback = async (completionCallback) => {
    // Use the ref for session ID to ensure it persists
    const currentSessionId = sessionIdRef.current;
    
    if (!currentSessionId) {
      console.log("No session ID in ref, skipping frame processing");
      return;
    }
    
    const imageData = captureFrame();
    if (!imageData) {
      console.log("No image data captured, skipping frame processing");
      return;
    }
    
    try {
      console.log(`Processing frame for session ${currentSessionId}...`);
      
      // Include location data in the request if available
      const requestData = {
        session_id: currentSessionId,
        image: imageData
      };
      
      // Add location data if available
      if (kycData.geoLocation) {
        requestData.geo_location = kycData.geoLocation;
      }
      
      const response = await fetch(`${serverUrl}/process_liveness_frame`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });
      
      const data = await response.json();
      console.log("Frame processing response:", data);
      
      if (data.success) {
        // Update progress bar - calculate based on challenge progress
        if (data.total_challenges > 0) {
          // If liveness is confirmed, set progress to 100%
          if (data.liveness_confirmed) {
            setProgress(100);
          } else {
            // Otherwise calculate based on current challenge
            setProgress((data.current_challenge / data.total_challenges) * 100);
          }
        }
        
        // Update status message
        setStatus(data.message);
        
        // Update current challenge
        setCurrentChallenge(data.current_challenge);
        
        // Update status class
        if (data.status === 'success') {
          setStatusClass('success');
        } else if (data.status === 'failed') {
          setStatusClass('error');
        } else {
          setStatusClass('pending');
        }
        
        // Check if spoofing was detected
        if (data.spoofing_detected) {
          setSpoofingDetected(true);
          setStatusClass('error');
          setLivenessComplete(true);
          
          // Notify callback that processing is complete
          completionCallback(true);
          
          // Stop the webcam
          stopWebcam();
          
          return; // Stop further processing
        }
        
        // Check if we need to stop the webcam
        if (data.stop_webcam) {
          setLivenessComplete(true);
          
          // Notify callback that processing is complete
          completionCallback(true);
          
          // Stop the webcam
          stopWebcam();
          
          return; // Stop further processing
        }
        
        // If image captured, display it and prepare for next step
        if (data.dms_id) {
          console.log("Image captured, DMS ID:", data.dms_id);
          
          // Mark liveness check as complete
          setLivenessComplete(true);
          
          // Notify callback that processing is complete
          completionCallback(true);
          
          // Store the DMS ID
          setCapturedDmsId(data.dms_id);
          
          // Display captured image - use the session ID to get the image
          const capturedImageUrl = `${serverUrl}/get_captured_image/${currentSessionId}`;
          setCapturedImageUrl(capturedImageUrl);
          
          // Update KYC data with the DMS ID
          updateKycData({
            livenessImageDmsId: data.dms_id,
            livenessSessionId: currentSessionId,
            livenessTimestamp: new Date().toISOString()
          });
          
          // Stop the webcam to free up resources
          stopWebcam();
        }
        
      } else {
        throw new Error(data.error || 'Failed to process frame');
      }
    } catch (error) {
      console.error('Error processing frame:', error);
      setStatus(`Error: ${error.message}`);
      setStatusClass('error');
    }
  };
  
  // Start liveness check
  const startLivenessCheck = async () => {
    // First, explicitly set livenessComplete to false
    setLivenessComplete(false);
    
    // Reset UI and state
    setStatus('Starting liveness check...');
    setStatusClass('pending');
    setProgress(0);
    setCapturedImageUrl(null);
    setCapturedDmsId(null);
    setSpoofingDetected(false);
    setCurrentChallenge(0);
    
    // Request location permission first
    getGeolocation();
    
    // Start webcam if not already streaming
    if (!streaming) {
      const webcamStarted = await startWebcam();
      if (!webcamStarted) return;
    }
    
    // Start liveness session
    const newSessionId = await startLivenessSession();
    if (!newSessionId) return;
    
    console.log(`Starting frame processing with interval for session ${newSessionId}`);
    
    // Clear any existing interval
    if (processingIntervalRef.current) {
      clearInterval(processingIntervalRef.current);
      processingIntervalRef.current = null;
    }
    
    // Create a local variable to track completion state within this function execution
    let isComplete = false;
    
    // Start processing frames with a local variable instead of relying on state
    processingIntervalRef.current = setInterval(() => {
      if (!isComplete) {
        // Call a modified version of processFrame that updates our local variable
        processFrameWithCallback((complete) => {
          isComplete = complete;
          if (complete) {
            console.log("Liveness check completed, clearing interval");
            clearInterval(processingIntervalRef.current);
            processingIntervalRef.current = null;
          }
        });
      } else {
        console.log("Liveness check already complete, clearing interval");
        clearInterval(processingIntervalRef.current);
        processingIntervalRef.current = null;
      }
    }, 100);
  };
  
  // Stop liveness check
  const stopLivenessCheck = () => {
    console.log("Stopping liveness check");
    // Mark as complete to prevent further processing
    setLivenessComplete(true);
    
    // Stop processing
    if (processingIntervalRef.current) {
      clearInterval(processingIntervalRef.current);
      processingIntervalRef.current = null;
    }
    
    // Reset session
    setSessionId(null);
    sessionIdRef.current = null;
    
    // Stop webcam
    stopWebcam();
    
    // Update UI
    setStatus('Liveness check stopped');
    setStatusClass('pending');
    setProgress(0);
    setCapturedImageUrl(null);
  };
  
  // Handle retry
  const handleRetry = () => {
    // Increment retry count
    const newRetryCount = retryCount + 1;
    setRetryCount(newRetryCount);
    
    // If we've reached max retries, reload the page (go back to step 1)
    if (newRetryCount >= 3) {
      window.location.reload();
    } else {
      // First, stop everything
      if (processingIntervalRef.current) {
        clearInterval(processingIntervalRef.current);
        processingIntervalRef.current = null;
      }
      stopWebcam();
      
      // Reset all states
      setSpoofingDetected(false);
      setLivenessComplete(false);
      setSessionId(null);
      sessionIdRef.current = null;
      setCapturedImageUrl(null);
      setProgress(0);
      setCurrentChallenge(null);
      setStatus('Restarting liveness check...');
      setStatusClass('pending');
      
      // Use setTimeout to ensure state updates have been applied
      setTimeout(() => {
        // Start fresh
        startLivenessCheck();
      }, 500);
    }
  };
  
  // Handle continue to next step
// Handle continue to next step
const handleContinue = () => {
  console.log("Continuing to next step with DMS ID:", capturedDmsId);
  
  if (!capturedDmsId) {
    setStatus('No image captured. Please complete the liveness check first.');
    setStatusClass('error');
    return;
  }
  
  // Make sure the liveness DMS ID is stored in kycData for subsequent steps
  nextStep({
    livenessImageDmsId: capturedDmsId,
    livenessSessionId: sessionId,
    livenessTimestamp: new Date().toISOString(),
    geoLocation: kycData.geoLocation
  });
};


  // Get challenge name based on index
  const getChallengeName = (index) => {
    const challenges = ["Blink your eyes", "Open your mouth"];
    return index !== null && index < challenges.length ? challenges[index] : "";
  };
  
  // Get geolocation data
  const getGeolocation = () => {
    setLocationStatus('pending');
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const geoData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            timestamp: new Date().toISOString()
          };
          
          // Update KYC data with geolocation
          updateKycData({
            geoLocation: geoData
          });
          
          setLocationStatus('captured');
          console.log("Geolocation captured:", geoData);
        },
        (error) => {
          console.error("Geolocation error:", error);
          setLocationStatus('error');
          
          // Show appropriate error message based on the error code
          switch(error.code) {
            case error.PERMISSION_DENIED:
              setStatus("Location access denied. Please enable location services to continue.");
              break;
            case error.POSITION_UNAVAILABLE:
              setStatus("Location information is unavailable. Please try again.");
              break;
                          case error.TIMEOUT:
              setStatus("Location request timed out. Please try again.");
              break;
            default:
              setStatus("An unknown error occurred while getting location.");
              break;
          }
          setStatusClass('error');
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    } else {
      console.log("Geolocation is not supported by this browser");
      setLocationStatus('error');
      setStatus("Your browser doesn't support geolocation. Please use a modern browser.");
      setStatusClass('error');
    }
  };
  
  // Capture geolocation when liveness check is complete
  useEffect(() => {
    if (capturedImageUrl) {
      getGeolocation();
    }
  }, [capturedImageUrl]);
  
  // Ensure DMS ID is properly stored in kycData when it changes
  useEffect(() => {
    if (capturedDmsId) {
      console.log('Liveness DMS ID updated in state:', capturedDmsId);
      
      // Update KYC data with the DMS ID
      updateKycData({
        livenessImageDmsId: capturedDmsId
      });
    }
  }, [capturedDmsId, updateKycData]);
  
  // Check if server is available on component mount
  useEffect(() => {
    const checkServer = async () => {
      try {
        console.log(`Checking server at ${serverUrl}/test`);
        const response = await fetch(`${serverUrl}/test`);
        const data = await response.json();
        
        if (data.status === 'API is working') {
          setStatus('Ready to start liveness check');
          setStatusClass('pending');
          console.log("Server is available");
        } else {
          throw new Error('Server not responding correctly');
        }
      } catch (error) {
        console.error('Error connecting to server:', error);
        setStatus('Error connecting to server. Please check if the server is running.');
        setStatusClass('error');
      }
    };
    
    checkServer();
    
    // Clean up on component unmount
    return () => {
      console.log("Component unmounting, cleaning up");
      if (processingIntervalRef.current) {
        clearInterval(processingIntervalRef.current);
        processingIntervalRef.current = null;
      }
      stopWebcam();
    };
  }, []);
  
  return (
    <div className="liveness-check">
      <h2>Liveness Detection</h2>
      <p className="instructions">
        Please look at the camera and follow the instructions to complete the liveness check.
        Make sure your face is clearly visible and well-lit.
      </p>
      
      {/* Status section moved above webcam */}
      <div className="status-section">
        <h3>Status:</h3>
        <div className={`detection-result ${statusClass}`}>{status}</div>
        
        <div className="progress-container">
          <div className="progress-bar" style={{ width: `${progress}%` }}></div>
        </div>
      </div>
      
      {/* Debug information */}
      <div className="debug-info" style={{ margin: '10px', padding: '10px', border: '1px solid #ccc', backgroundColor: '#f8f8f8', fontSize: '12px' }}>
        <h4>Debug Information</h4>
        <p>Session ID: {sessionId || 'Not started'}</p>
        <p>Captured DMS ID: {capturedDmsId || 'Not captured'}</p>
        <p>Liveness Complete: {livenessComplete ? 'Yes' : 'No'}</p>
      </div>
      
      {spoofingDetected && (
        <div className="spoofing-alert">
          <h3>⚠️ Spoofing Detected ⚠️</h3>
          <p>We detected potential spoofing. Please ensure you're not using a screen or photo.</p>
          <p>Attempts remaining: {3 - retryCount - 1}</p>
          <button 
            className="restart-btn" 
            onClick={handleRetry}
          >
            {retryCount < 2 ? `Retry Verification (${retryCount + 1}/3)` : "KYC FAILED RETRY!"}
          </button>
        </div>
      )}
      
      {!spoofingDetected && (
        <>
          <div className="webcam-section">
            <div className="video-container">
              {!capturedImageUrl && (
                <video ref={webcamRef} autoPlay playsInline></video>
              )}
              <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
              
              {currentChallenge !== null && streaming && !capturedImageUrl && (
                <div className="challenge-overlay">
                  <div className="challenge-name">{getChallengeName(currentChallenge)}</div>
                </div>
              )}
            </div>
          </div>

          {!capturedImageUrl && !streaming && (
            <div className="location-permission">
              <h3>Location Permission Required</h3>
              <p>This verification requires your location. Please allow location access when prompted.</p>
              <div className={`location-status ${locationStatus}`}>
                {locationStatus === 'pending' && <span>Waiting for location permission...</span>}
                {locationStatus === 'captured' && <span>✓ Location captured successfully</span>}
                {locationStatus === 'error' && <span>⚠ Location access denied or unavailable</span>}
              </div>
            </div>
          )}
                    
          {!capturedImageUrl && (
            <div className="controls">
              <button 
                className="start-btn" 
                onClick={startLivenessCheck}
                disabled={streaming || livenessComplete || (locationStatus === 'error')}
              >
                {locationStatus === 'error' ? 'Enable Location to Continue' : 'Start Liveness Check'}
              </button>
              <button 
                className="stop-btn" 
                onClick={stopLivenessCheck}
                disabled={!streaming || livenessComplete}
              >
                Stop
              </button>
            </div>
          )}
                    
          {capturedImageUrl && (
            <div className="capture-success">
              <img 
                className="captured-image" 
                src={capturedImageUrl} 
                alt="Captured face" 
              />
              <p>Image captured successfully! Proceeding to next step...</p>
              <button 
                className="continue-btn" 
                onClick={handleContinue}
              >
                Continue to Next Step
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default LivenessCheck;

