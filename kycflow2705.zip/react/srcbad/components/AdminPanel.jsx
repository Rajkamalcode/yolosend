import React, { useState, useEffect } from 'react';
import './AdminPanel.css';

const AdminPanel = () => {
  const [applications, setApplications] = useState([]);
  const [newApplication, setNewApplication] = useState({
    type: 'individual', // or 'group'
    loanType: '',
    branchCode: '',
    applicants: [{ name: '', phone: '', address: '', isPrimary: true }]  });
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [selectedApplication, setSelectedApplication] = useState(null);
  const [selectedApplicant, setSelectedApplicant] = useState(null);
  const [applicantKycDetails, setApplicantKycDetails] = useState(null);
  const [adminDecision, setAdminDecision] = useState({
    notes: '',
    status: '' // approved, rejected
  });
  const [isSubmittingDecision, setIsSubmittingDecision] = useState(false);
  
  // Server URL
  const serverUrl = 'http://10.9.52.21:5001';
  
  // Admin password - hardcoded for POC
  const ADMIN_PASSWORD = 'admin123';
  
  // Handle login
  const handleLogin = () => {
    if (password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      setError('');
      fetchApplications();
    } else {
      setError('Invalid password');
    }
  };

// Send KYC reminder to applicant
const sendKycReminder = async (applicantId) => {
  try {
    const response = await fetch(`${serverUrl}/send_kyc_reminder`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        applicant_id: applicantId
      })
    });
    
    const data = await response.json();
    
    if (data.success) {
      setSuccessMessage(`Reminder sent to ${data.applicant_name}`);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    } else {
      setError(data.error || 'Failed to send reminder');
    }
  } catch (error) {
    console.error('Error sending reminder:', error);
    setError('Failed to connect to server');
  }
};

  // Fetch existing applications
  const fetchApplications = async () => {
    try {
      const response = await fetch(`${serverUrl}/applications`);
      const data = await response.json();
      
      if (data.success) {
        setApplications(data.applications);
      } else {
        setError(data.error || 'Failed to fetch applications');
      }
    } catch (error) {
      console.error('Error fetching applications:', error);
      setError('Failed to connect to server');
    }
  };
  
  // Handle input change for application fields
  const handleInputChange = (e) => {
    setNewApplication({
      ...newApplication,
      [e.target.name]: e.target.value
    });
  };
  const handleApplicantChange = (index, field, value) => {
    const updatedApplicants = [...newApplication.applicants];
    
    // If this is the isPrimary field, we need to update all other applicants to false
    if (field === 'isPrimary' && value === true) {
      // Set all applicants' isPrimary to false
      updatedApplicants.forEach((applicant, i) => {
        updatedApplicants[i] = {
          ...updatedApplicants[i],
          isPrimary: false
        };
      });
    }
    
    // Update the current applicant's field
    updatedApplicants[index] = {
      ...updatedApplicants[index],
      [field]: value
    };
    
    setNewApplication({
      ...newApplication,
      applicants: updatedApplicants
    });
  };
  
  // Update the addApplicant function to include isPrimary (default to false for new applicants)
  const addApplicant = () => {
    setNewApplication({
      ...newApplication,
      applicants: [...newApplication.applicants, { name: '', phone: '', address: '', isPrimary: false }]
    });
  };
  
  // Update the createApplication function to send isPrimary to the backend
  const createApplication = async () => {
    try {
      // Validate form
      if (!newApplication.loanType.trim()) {
        setError('Loan type is required');
        return;
      }
      
      for (const applicant of newApplication.applicants) {
        if (!applicant.name.trim() || !applicant.phone.trim() || !applicant.address.trim()) {
          setError('All applicant fields are required');
          return;
        }
      }
      
      // For group applications, ensure one applicant is marked as primary
      if (newApplication.type === 'group') {
        const hasPrimary = newApplication.applicants.some(applicant => applicant.isPrimary);
        if (!hasPrimary) {
          setError('Please designate one applicant as the primary applicant');
          return;
        }
      }
      
      setError('');
      
      // Send the application data as is - no need to modify the structure
      const response = await fetch(`${serverUrl}/create_application`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newApplication)
      });
      
      const data = await response.json();
      
      if (data.success) {
        setSuccessMessage('Application created successfully!');
        setSelectedApplication(data);
        
        // Reset form
        setNewApplication({
          type: 'individual',
          loanType: '',
          branchCode: '',
          applicants: [{ name: '', phone: '', address: '', isPrimary: true }]
        });
        
        // Refresh applications list
        fetchApplications();
      } else {
        setError(data.error || 'Failed to create application');
      }
    } catch (error) {
      console.error('Error creating application:', error);
      setError('Failed to connect to server');
    }
  };
  
  // View application details
  const viewApplicationDetails = async (applicationId) => {
    try {
      const response = await fetch(`${serverUrl}/get_application/${applicationId}`);
      const data = await response.json();
      
      if (data.success) {
        setSelectedApplication(data);
        setSelectedApplicant(null);
        setApplicantKycDetails(null);
      } else {
        setError(data.error || 'Failed to fetch application details');
      }
    } catch (error) {
      console.error('Error fetching application details:', error);
      setError('Failed to connect to server');
    }
  };
  
  // View applicant KYC details
  const viewApplicantKycDetails = async (applicantId) => {
    try {
      const response = await fetch(`${serverUrl}/get_applicant/${applicantId}`);
      const data = await response.json();
      
      if (data.success) {
        setSelectedApplicant(data);
        
        // Fetch KYC details if available
        if (data.kyc_status === 'completed' || data.kyc_status === 'in_progress') {
          fetchApplicantKycDetails(applicantId);
        } else {
          setApplicantKycDetails(null);
        }
      } else {
        setError(data.error || 'Failed to fetch applicant details');
      }
    } catch (error) {
      console.error('Error fetching applicant details:', error);
      setError('Failed to connect to server');
    }
  };
  
  // Fetch applicant KYC details
  const fetchApplicantKycDetails = async (applicantId) => {
    try {
      const response = await fetch(`${serverUrl}/get_kyc_details/${applicantId}`);
      const data = await response.json();
      
      if (data.success) {
        console.log("KYC details received:", data);
        setApplicantKycDetails(data);
        
        // Initialize admin decision based on current verification status
        if (data.kyc_details && data.kyc_details.verification_status === 'requires_scrutiny') {
          setAdminDecision({
            notes: '',
            status: ''
          });
        }
      } else {
        setError(data.error || 'Failed to fetch KYC details');
      }
    } catch (error) {
      console.error('Error fetching KYC details:', error);
      setError('Failed to connect to server');
    }
  };
  
  // Handle admin decision input change
  const handleDecisionChange = (e) => {
    const { name, value } = e.target;
    setAdminDecision({
      ...adminDecision,
      [name]: value
    });
  };
  
  // Submit admin decision
  const submitAdminDecision = async (status) => {
    try {
      if (!selectedApplicant || !applicantKycDetails) {
        setError('No applicant selected');
        return;
      }
      
      setIsSubmittingDecision(true);
      
      const response = await fetch(`${serverUrl}/update_verification_status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          applicant_id: selectedApplicant.applicant_id,
          verification_status: status,
          admin_notes: adminDecision.notes,
          admin_decision_timestamp: new Date().toISOString(),
          admin_user: 'admin' // In a real system, this would be the logged-in admin's username
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        setSuccessMessage(`Verification status updated to ${status}`);
        
        // Refresh applicant KYC details
        fetchApplicantKycDetails(selectedApplicant.applicant_id);
        
        // Reset admin decision
        setAdminDecision({
          notes: '',
          status: ''
        });
      } else {
        setError(data.error || 'Failed to update verification status');
      }
    } catch (error) {
      console.error('Error updating verification status:', error);
      setError('Failed to connect to server');
    } finally {
      setIsSubmittingDecision(false);
    }
  };
  
  // Go back to application details
  const backToApplicationDetails = () => {
    setSelectedApplicant(null);
    setApplicantKycDetails(null);
  };

  const openLocationInMap = (latitude, longitude) => {
      // Google Maps URL format
      const mapUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
      window.open(mapUrl, '_blank');
    };

  // Copy link to clipboard
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
      .then(() => {
        alert('Link copied to clipboard!');
      })
      .catch(err => {
        console.error('Failed to copy link:', err);
      });
  };
  
  // Login form
  if (!isAuthenticated) {
    return (
      <div className="admin-login">
        <h2>Admin Login</h2>
        {error && <div className="error-message">{error}</div>}
        <div className="form-group">
          <label>Password:</label>
          <input 
            type="password" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
          />
        </div>
        <button onClick={handleLogin}>Login</button>
      </div>
    );
  }
  
  // Render applicant KYC details view
  if (selectedApplicant && applicantKycDetails) {
    // Transform the data to match the KycSummary component's expected format
    const kycData = {
      applicationId: selectedApplication?.application_id,
      applicantId: selectedApplicant.applicant_id,
      applicantName: selectedApplicant.name,
      applicantPhone: selectedApplicant.phone,
      applicantAddress: selectedApplicant.address,
      loanType: selectedApplication?.loan_type,
      
      // KYC data from the applicantKycDetails - handle different possible field names
      maskedAadhaarImage: applicantKycDetails.kyc_details?.masked_aadhaar_image || 
                          applicantKycDetails.kyc_details?.maskedAadhaarImage,
      
      livenessImage: applicantKycDetails.kyc_details?.liveness_image || 
                     applicantKycDetails.kyc_details?.livenessImage || 
                     (applicantKycDetails.kyc_details?.livenessData && 
                      applicantKycDetails.kyc_details?.livenessData.livenessImage),
      
      comparisonResult: applicantKycDetails.kyc_details?.comparison_result || 
                        applicantKycDetails.kyc_details?.comparisonResult,
      
      dedupeResults: applicantKycDetails.kyc_details?.dedupe_data?.dedupeResults || 
                     applicantKycDetails.kyc_details?.dedupeData?.dedupeResults,
      
      verificationStatus: applicantKycDetails.kyc_details?.verification_status || 
                          applicantKycDetails.kyc_details?.verificationStatus || 
                          'pending',
      
      geoLocation: applicantKycDetails.kyc_details?.livenessData?.geoLocation || 
                   applicantKycDetails.kyc_details?.geoLocation,
      
      kycSteps: applicantKycDetails.kyc_details?.kyc_steps || 
                applicantKycDetails.kyc_details?.kycSteps || 
                {},
      
      ucic_id: applicantKycDetails.kyc_details?.ucic_id || 
               applicantKycDetails.kyc_details?.ucicId
    };

    console.log("Transformed KYC data for display:", kycData);

    return (
      <div className="admin-panel">
        <h2>Admin Panel - KYC Details</h2>
        
        {error && <div className="error-message">{error}</div>}
        {successMessage && <div className="success-message">{successMessage}</div>}
        
        <button className="back-btn" onClick={backToApplicationDetails}>
          Back to Application
        </button>
        
        <div className="kyc-summary admin-kyc-view">
          <h2>KYC Verification Summary - {selectedApplicant.name}</h2>
          
          {/* Verification Status Banner */}
          <div className={`status-container ${
            kycData.verificationStatus === 'approved' ? 'approved' : 
            kycData.verificationStatus === 'duplicate_found' ? 'duplicate' : 
            kycData.verificationStatus === 'requires_scrutiny' ? 'scrutiny' : 'rejected'
          }`}>
            <h2 className="status-title">
              {kycData.verificationStatus === 'approved' ? 'Verification Successful' : 
              kycData.verificationStatus === 'duplicate_found' ? 'Duplicate Found' : 
              kycData.verificationStatus === 'requires_scrutiny' ? 'Verification Under Review' : 'Verification Failed'}
            </h2>
            <p className="status-message">
              {kycData.verificationStatus === 'approved' 
                ? 'The identity has been successfully verified.' 
                : kycData.verificationStatus === 'duplicate_found' 
                  ? 'A duplicate record was found in the system.'
                  : kycData.verificationStatus === 'requires_scrutiny'
                    ? 'This verification requires additional review by the admin team.'
                    : 'The verification could not be completed.'}
            </p>
          </div>
          
          {/* Applicant Information */}
          <div className="summary-section">
            <h3>Applicant Information</h3>
            <div className="summary-item">
              <span className="summary-label">Name:</span>
              <span className="summary-value">{kycData.applicantName}</span>
            </div>
            <div className="summary-item">
              <span className="summary-label">Phone:</span>
              <span className="summary-value">{kycData.applicantPhone}</span>
            </div>
            <div className="summary-item">
              <span className="summary-label">Address:</span>
              <span className="summary-value">{kycData.applicantAddress}</span>
            </div>
            {kycData.ucic_id && (
              <div className="summary-item">
                <span className="summary-label">UCIC ID:</span>
                <span className="summary-value">{kycData.ucic_id}</span>
              </div>
            )}
          </div>
          
          {/* Aadhaar Masking Section */}
          {kycData.maskedAadhaarImage && (
            <div className="summary-section">
              <h3>Aadhaar Verification</h3>
              <div className="image-container">
                <h4>Masked Aadhaar</h4>
                <img 
                  src={kycData.maskedAadhaarImage} 
                  alt="Masked Aadhaar" 
                  className="aadhaar-image" 
                  onError={(e) => {
                    console.error('Failed to load masked Aadhaar image');
                    e.target.src = 'placeholder-image.jpg'; // Fallback image
                  }}
                />
              </div>
              
              {kycData.comparisonResult && (
                <div className="verification-result">
                  <h4>Verification Result</h4>
                  <div className={`result-badge ${kycData.comparisonResult.similarity >= 0.4 ? 'success' : 'failure'}`}>
                    {kycData.comparisonResult.similarity >= 0.4 ? 'Verified' : 'UIDAI Not Verified'}
                  </div>
                  <div className="similarity-score">
                    Similarity Score: {(kycData.comparisonResult.similarity * 100).toFixed(2)}%
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Face Comparison Section */}
          {kycData.livenessImage && (
            <div className="summary-section">
              <h3>Face Comparison</h3>
              <div className="comparison-container">
                <div className="comparison-images">
                  <div className="image-container">
                    <h4>Aadhaar Face</h4>
                    <div className="image-wrapper">
                      <img 
                        src={kycData.maskedAadhaarImage} 
                        alt="Extracted Face" 
                        className="comparison-image"
                        onError={(e) => {
                          console.error('Failed to load extracted face image');
                          e.target.src = 'placeholder-face.jpg'; // Fallback image
                        }}
                      />
                    </div>
                  </div>
                  
                  {kycData.comparisonResult && (
                    <div className="similarity-score-container">
                      <div className="similarity-score-circle">
                        <div className={`score-value ${kycData.comparisonResult.similarity > 0.3 ? 'high' : 'low'}`}>
                          {(kycData.comparisonResult.similarity * 100).toFixed(0)}%
                        </div>
                        <div className="score-label">Match</div>
                      </div>
                    </div>
                  )}
                  
                  <div className="image-container">
                    <h4>Liveness Face</h4>
                    <div className="image-wrapper">
                      <img 
                        src={kycData.livenessImage} 
                        alt="Liveness Face" 
                        className="comparison-image"
                        onError={(e) => {
                          console.error('Failed to load liveness image');
                          e.target.src = 'placeholder-face.jpg'; // Fallback image
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Liveness Check Section */}
          <div className="summary-section">
            <h3>Liveness Check</h3>
            <div className="summary-status">
              <span className={`status-indicator ${kycData.kycSteps?.liveness ? 'success' : 'pending'}`}>
                {kycData.kycSteps?.liveness ? '✓' : '⟳'}
              </span>
              <span className="status-text">
                {kycData.kycSteps?.liveness ? 'Completed' : 'Pending'}
              </span>
            </div>
            
            {kycData.geoLocation && (
              <div className="geo-location">
                <h4>Captured Location</h4>
                <div className="summary-item">
                  <span className="summary-label">Latitude:</span>
                  <span className="summary-value">{kycData.geoLocation.latitude}</span>
                </div>
                <div className="summary-item">
                  <span className="summary-label">Longitude:</span>
                  <span className="summary-value">{kycData.geoLocation.longitude}</span>
                </div>
                <div className="summary-item">
                  <span className="summary-label">Timestamp:</span>
                  <span className="summary-value">{kycData.geoLocation.timestamp}</span>
                </div>
                <div className="map-link">
                  <button 
                    className="view-map-btn" 
                    onClick={() => openLocationInMap(kycData.geoLocation.latitude, kycData.geoLocation.longitude)}
                  >
                    <i className="map-icon">🗺️</i> View on Map
                  </button>
                </div>
              </div>
            )}
          </div>
          
          {/* Face Deduplication Section */}
          <div className="summary-section">
            <h3>Face Deduplication</h3>
            <div className="summary-status">
              <span className={`status-indicator ${kycData.kycSteps?.dedupe ? 'success' : 'pending'}`}>
                {kycData.kycSteps?.dedupe ? '✓' : '⟳'}
              </span>
              <span className="status-text">
                {kycData.kycSteps?.dedupe ? 'Completed' : 'Pending'}
              </span>
            </div>
            
            {kycData.verificationStatus && (
              <div className="verification-status">
                <h4>Verification Status</h4>
                <div className={`status-badge ${
                  kycData.verificationStatus === 'approved' ? 'success' : 
                  kycData.verificationStatus === 'requires_scrutiny' ? 'warning' : 'danger'
                }`}>
                  {kycData.verificationStatus === 'approved' ? 'Approved' : 
                   kycData.verificationStatus === 'requires_scrutiny' ? 'Requires Review' : 
                   'Duplicate Found'}
                </div>
              </div>
            )}
            
            {kycData.dedupeResults && kycData.dedupeResults.results && kycData.dedupeResults.results.length > 0 && (
              <div className="duplicate-matches">
                <h4>Matching Records Found</h4>
                <div className="matches-list">
                  {kycData.dedupeResults.results.map((match, index) => (
                    <div key={index} className="match-item">
                      <div className="match-info">
                        <div className="match-detail">
                          <div className="detail-label">UCIC ID</div>
                          <div className="detail-value">{match.ucic_id || 'Not available'}</div>
                        </div>
                        <div className="match-detail">
                          <div className="detail-label">Name</div>
                          <div className="detail-value">{match.name || 'Not available'}</div>
                        </div>
                        <div className="match-detail">
                          <div className="detail-label">Similarity</div>
                          <div className={`detail-value ${
                            match.similarity >= 0.5 ? 'high' : 
                            match.similarity >= 0.4 ? 'medium' : 'low'
                          }`}>
                            {(match.similarity * 100).toFixed(2)}%
                          </div>
                        </div>
                      </div>
                    
                      {match.image_data && (
                        <div className="match-image">
                          <img src={match.image_data} alt={`Match ${index + 1}`} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Verification Summary */}
          <div className="summary-section">
            <h3>Verification Summary</h3>
            
            <div className="summary-item">
              <div className="summary-label">Liveness Check:</div>
              <div className={`summary-value ${kycData.livenessImage ? 'success' : 'failure'}`}>
                {kycData.livenessImage ? 'Passed' : 'Failed'}
              </div>
            </div>
            
            <div className="summary-item">
              <div className="summary-label">Aadhaar Verification:</div>
              <div className={`summary-value ${kycData.comparisonResult && kycData.comparisonResult.similarity >= 0.3 ? 'success' : 'failure'}`}>
                {kycData.comparisonResult && kycData.comparisonResult.similarity >= 0.3 ? 'Passed' : 'Failed'}
              </div>
            </div>
            
            <div className="summary-item">
              <div className="summary-label">Face Comparison:</div>
              <div className={`summary-value ${kycData.comparisonResult && kycData.comparisonResult.similarity >= 0.3 ? 'success' : 'failure'}`}>
                {kycData.comparisonResult 
                  ? `${(kycData.comparisonResult.similarity * 100).toFixed(2)}% Match` 
                  : 'Not Performed'}
              </div>
            </div>
            
            <div className="summary-item">
              <div className="summary-label">Duplicate Check:</div>
              <div className={`summary-value ${
                kycData.verificationStatus === 'duplicate_found' ? 'failure' : 
                kycData.verificationStatus === 'requires_scrutiny' ? 'warning' : 'success'
              }`}>
                {kycData.verificationStatus === 'duplicate_found' 
                  ? 'Duplicate Found' 
                  : kycData.verificationStatus === 'requires_scrutiny'
                    ? 'Potential Match Found'
                    : kycData.dedupeResults 
                      ? 'No Duplicates' 
                      : 'Not Performed'}
              </div>
            </div>
          </div>
          
          {/* Admin Decision Section - Only show for cases requiring scrutiny */}
          {kycData.verificationStatus === 'requires_scrutiny' && (
            <div className="admin-decision">
              <h4>Admin Decision</h4>
              <div className="decision-notes">
                <label htmlFor="notes">Decision Notes:</label>
                <textarea 
                  id="notes" 
                  name="notes" 
                  value={adminDecision.notes}
                  onChange={handleDecisionChange}
                  placeholder="Enter your decision notes here..."
                ></textarea>
              </div>
              <div className="decision-buttons">
                <button 
                  className="approve-btn" 
                  onClick={() => submitAdminDecision('approved')}
                  disabled={isSubmittingDecision}
                >
                  {isSubmittingDecision ? 'Submitting...' : 'Approve Verification'}
                </button>
                <button 
                  className="reject-btn" 
                  onClick={() => submitAdminDecision('rejected')}
                  disabled={isSubmittingDecision}
                >
                  {isSubmittingDecision ? 'Submitting...' : 'Reject Verification'}
                </button>
              </div>
            </div>
          )}
          
          {/* Review Message for Scrutiny Cases */}
          {kycData.verificationStatus === 'requires_scrutiny' && (
            <div className="scrutiny-message">
              <h4>Application Under Review</h4>
              <p>This verification requires additional review due to potential matches found in the system.</p>
              <p>This is a standard procedure to ensure the security of our services.</p>
              <p>Reference ID: <strong>{kycData.applicantId}</strong></p>
            </div>
          )}
          
          {/* Print Button */}
          <div className="summary-actions">
            <button 
              className="print-btn" 
              onClick={() => window.print()}
            >
              Print Report
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  // Main admin panel view
  return (
    <div className="admin-panel">
      <h2>Admin Panel - Application Management</h2>
      
      {error && <div className="error-message">{error}</div>}
      {successMessage && <div className="success-message">{successMessage}</div>}
      
      <div className="create-application">
        <h3>Create New Application</h3>
        
        <div className="form-group">
          <label>Application Type:</label>
          <select 
            name="type" 
            value={newApplication.type}
            onChange={handleInputChange}
          >
            <option value="individual">Individual Loan</option>
            <option value="group">Group Loan</option>
          </select>
        </div>
        
        <div className="form-group">
          <label>Loan Type:</label>
          <input 
            type="text" 
            name="loanType" 
            value={newApplication.loanType}
            onChange={handleInputChange}
            placeholder="e.g., Home Loan, Personal Loan"
          />
        </div>
        
        <div className="form-group">
          <label>Branch Code:</label>
          <input 
            type="text" 
            name="branchCode" 
            value={newApplication.branchCode}
            onChange={handleInputChange}
            placeholder="e.g., BR001"
          />
        </div>
        
        <h4>Applicants</h4>
        {newApplication.applicants.map((applicant, index) => (
        <div key={index} className="applicant-form">
          <h5>Applicant {index + 1}</h5>
          
          <div className="form-group">
            <label>Name:</label>
            <input 
              type="text" 
              value={applicant.name}
              onChange={(e) => handleApplicantChange(index, 'name', e.target.value)}
              placeholder="Full Name"
            />
          </div>
          
          <div className="form-group">
            <label>Phone:</label>
            <input 
              type="tel" 
              value={applicant.phone}
              onChange={(e) => handleApplicantChange(index, 'phone', e.target.value)}
              placeholder="Phone Number"
            />
          </div>
          
          <div className="form-group">
            <label>Address:</label>
            <textarea 
              value={applicant.address}
              onChange={(e) => handleApplicantChange(index, 'address', e.target.value)}
              placeholder="Full Address"
            />
          </div>
          
          {/* Only show Primary Applicant checkbox for group applications */}
          {newApplication.type === 'group' && (
            <div className="form-group checkbox-group">
              <label>
                <input 
                  type="checkbox" 
                  checked={applicant.isPrimary}
                  onChange={(e) => handleApplicantChange(index, 'isPrimary', e.target.checked)}
                />
                Primary Applicant
              </label>
              <span className="helper-text">
                {applicant.isPrimary 
                  ? 'This applicant will be the main contact for the loan.' 
                  : 'Check this box to make this applicant the primary contact.'}
              </span>
            </div>
          )}
          
          {newApplication.applicants.length > 1 && (
            <button 
              type="button" 
              className="remove-applicant" 
              onClick={() => removeApplicant(index)}
            >
              Remove Applicant
            </button>
          )}
        </div>
      ))}


        
        {newApplication.type === 'group' && (
          <button 
            type="button" 
            className="add-applicant" 
            onClick={addApplicant}
          >
            Add Co-Applicant
          </button>
        )}
        
        <button 
          type="button" 
          className="create-btn" 
          onClick={createApplication}
        >
          Create Application
        </button>
      </div>
      

      {selectedApplication && !selectedApplicant && (
        <div className="application-details">
          <h3>Application Details</h3>
          <div className="detail-item">
            <span className="detail-label">Application ID:</span>
            <span className="detail-value">{selectedApplication.application_id}</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Type:</span>
            <span className="detail-value">{selectedApplication.type === 'group' ? 'Group Loan' : 'Individual Loan'}</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Loan Type:</span>
            <span className="detail-value">{selectedApplication.loan_type}</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Branch Code:</span>
            <span className="detail-value">{selectedApplication.branch_code || 'N/A'}</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Status:</span>
            <span className="detail-value">{selectedApplication.status}</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Created:</span>
            <span className="detail-value">
              {new Date(selectedApplication.created_at).toLocaleString()}
            </span>
          </div>
          
          {/* Enhanced Group Loan Information */}
          {selectedApplication.type === 'group' && (
            <div className="group-loan-info">
              <h4>Group Loan Information</h4>
              <div className="detail-item">
                <span className="detail-label">Total Applicants:</span>
                <span className="detail-value">{selectedApplication.applicants ? selectedApplication.applicants.length : 0}</span>
              </div>
              <div className="detail-item">
                <span className="detail-label">KYC Completed:</span>
                <span className="detail-value">
                  {selectedApplication.applicants ? 
                    selectedApplication.applicants.filter(a => a.kyc_status === 'completed').length : 0}
                </span>
              </div>
              <div className="detail-item">
                <span className="detail-label">Verification Status:</span>
                <span className="detail-value">
                  {selectedApplication.applicants && selectedApplication.applicants.every(a => 
                    a.verification_status === 'approved' && a.kyc_status === 'completed') 
                    ? 'All Verified' 
                    : 'Pending Verification'}
                </span>
              </div>
            </div>
          )}
          
          <h4>Applicants</h4>
          <div className="applicants-list">
              {selectedApplication.applicants && selectedApplication.applicants.map((applicant, index) => (
                <div key={index} className="applicant-item">
                  <div className="applicant-info">
                    <div className="applicant-name">
                      {applicant.name}
                      {selectedApplication.type === 'group' && index === 0 && (
                        <span className="primary-badge">Primary</span>
                      )}
                    </div>
                    <div className={`applicant-status ${
                        applicant.kyc_status === 'completed' ? 'completed' : 
                        applicant.kyc_status === 'in_progress' ? 'in_progress' : 
                        applicant.verification_status === 'requires_scrutiny' ? 'requires_scrutiny' : 
                        applicant.verification_status === 'duplicate_found' ? 'duplicate_found' : 'not_started'
                      }`}>
                        {applicant.kyc_status === 'completed' ? 'KYC Completed' : 
                        applicant.kyc_status === 'in_progress' ? 'KYC In Progress' : 
                        applicant.verification_status === 'requires_scrutiny' ? 'Requires Review' : 
                        applicant.verification_status === 'duplicate_found' ? 'Duplicate Found' : 'KYC Not Started'}

                      {(applicant.verification_status === 'requires_scrutiny' || 
                          applicant.verification_status === 'duplicate_found') && (
                          <div className="attention-indicator">
                            <span className="attention-icon">⚠</span>
                          </div>
                        )}
                      </div>
                  </div>
                  <div className="applicant-actions">
                    <button 
                      onClick={() => viewApplicantKycDetails(applicant.applicant_id)}
                      disabled={applicant.kyc_status === 'not_started'}
                    >
                      View KYC Details
                    </button>
                    <button onClick={() => copyToClipboard(applicant.kyc_link)}>
                      Copy KYC Link
                    </button>
                    {selectedApplication.type === 'group' && (
                      <button 
                        onClick={() => sendKycReminder(applicant.applicant_id)}
                        disabled={applicant.kyc_status === 'completed'}
                      >
                        Send Reminder
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
            
            {/* Group Loan Progress Bar */}
            {selectedApplication.type === 'group' && selectedApplication.applicants && selectedApplication.applicants.length > 0 && (
              <div className="group-progress-container">
                <h4>Group KYC Progress</h4>
                <div className="progress-bar-container">
                  <div className="progress-label">
                    <span>KYC Completion:</span>
                    <span>
                      {selectedApplication.applicants.filter(a => a.kyc_status === 'completed').length} of {selectedApplication.applicants.length} completed
                    </span>
                  </div>
                  <div className="progress-bar">
                    <div 
                      className="progress-fill" 
                      style={{ 
                        width: `${(selectedApplication.applicants.filter(a => a.kyc_status === 'completed').length / selectedApplication.applicants.length) * 100}%` 
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

      
      <div className="applications-list">
        <h3>Existing Applications</h3>
        <button onClick={fetchApplications} className="refresh-btn">
          Refresh List
        </button>
        
        {applications.length === 0 ? (
          <p>No applications found.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Application ID</th>
                <th>Type</th>
                <th>Loan Type</th>
                <th>Applicants</th>
                <th>Status</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {applications.map(app => (
                <tr key={app.application_id}>
                  <td>{app.application_id}</td>
                  <td>{app.type}</td>
                  <td>{app.loan_type}</td>
                  <td>{app.applicant_count || 0}</td>
                  <td>{app.status}</td>
                  <td>{new Date(app.created_at).toLocaleDateString()}</td>
                  <td>
                    <button onClick={() => viewApplicationDetails(app.application_id)}>
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;

