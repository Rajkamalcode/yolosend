import uuid
import hashlib
import requests
import json
import logging
import numpy as np
import cv2
import base64
import time
import os
from imutils import face_utils
from datetime import datetime
import threading
import uuid
import io
from PIL import Image
import requests
import json
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def upload_to_dms(image_data, metadata=None):
    """
    Upload image to DMS server with SHA-1 hash metadata
    
    Args:
        image_data: Image data as bytes or numpy array
        metadata: Dictionary containing metadata for the image
        
    Returns:
        DMS ID if successful, None otherwise
    """
    try:
        # Convert numpy array to bytes if needed
        if isinstance(image_data, np.ndarray):
            is_success, buffer = cv2.imencode(".jpg", image_data)
            if not is_success:
                logger.error("Failed to encode image")
                return None
            image_bytes = buffer.tobytes()
        else:
            image_bytes = image_data
        
        # Calculate SHA-1 hash of the image
        import hashlib
        sha1_hash = hashlib.sha1(image_bytes).hexdigest()
        
        # Prepare metadata JSON
        if metadata is None:
            metadata = {}
        
        # Create a clean metadata dictionary with only the required fields
        # This ensures we match the exact format expected by the DMS API
        clean_metadata = {
            "imageId": f"FACELIVENESS_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "uniqueId": metadata.get("session_id", str(uuid.uuid4())),
            "appId": "1000",
            "sourceSys": "Face Liveness",
            "branchCode": "Chennai",  # Changed from Default to match template
            "branch": "Chennai",      # Changed from Default to match template
            "vertical": "KYC",
            "module": "Liveness",
            "stage": "1",
            "imageCategory": "Face_Liveness",
            "imageSubCategory": "1",
            "status": "1",
            "fileName": f"liveness_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg",
            "imageSrc": "Liveness",
            "imageSrcId": "1",
            "format": ".jpg",
            "user": "1",
            "size": str(len(image_bytes)),
            "page": "1",
            "createdBy": "1",
            "createdDate": datetime.now().strftime("%d/%m/%Y"),
            "modifiedBy": "1",
            "modifiedDate": datetime.now().strftime("%d/%m/%Y"),
            "checkSum": sha1_hash
        }
        
        # Add key fields
        if "applicant_id" in metadata:
            clean_metadata["keyId"] = ["Applicant ID", "Document Type"]
            clean_metadata["keyValue"] = [metadata["applicant_id"], "Liveness"]
        else:
            clean_metadata["keyId"] = ["Session ID", "Document Type"]
            clean_metadata["keyValue"] = [metadata.get("session_id", str(uuid.uuid4())), "Liveness"]
        
        # Convert metadata to JSON string
        metadata_json = json.dumps(clean_metadata)
        
        # Create a temporary file for the image
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as temp_file:
            temp_file.write(image_bytes)
            temp_file_path = temp_file.name
        
        # Prepare the request exactly as in the template
        payload = {'data': metadata_json}
        
        files = [
            ('image', ('image.jpg', open(temp_file_path, 'rb'), 'image/jpeg'))
        ]
        
        # Add API key for authentication
        headers = {
            'Authorization': 'Bearer eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhcGltYW5hZ2VyIiwiYXV0IjoiQVBQTElDQVRJT04iLCJhdWQiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwibmJmIjoxNjU2NDk5NjE5LCJhenAiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwic2NvcGUiOiJkZWZhdWx0IiwiaXNzIjoiaHR0cHM6XC9cL3VzdGdhcGkuY2hvbGEubXVydWdhcHBhLmNvbTo0NDNcL29hdXRoMlwvdG9rZW4iLCJleHAiOjg4MDU2NDk5NjE5LCJpYXQiOjE2NTY0OTk2MTksImp0aSI6ImZhNTI5NmZhLTk5MDktNDVjZi05YzdkLWY1NjJmNTY3ZjE1MiJ9.S0EuU9NByou1K7MwOWsPOeP7ciN_i-jcGBdkAFe6EsIxWWDmBGngqfE1eb5EasP9JEGl09MlsY8WDNRskafznA--naCMP4TqhcZF9ISKV2fkOO9h4c6zgC7jf7zL-SdYn1vwUWKVY8lWoc2dJgqib6Wjcb_WfuKBhd3D8zTmKrNekWEmTIiO1kr7Pl4g-B0LtWuIl-VKAtYtMTQtcqSENAiDCQpXjo20U0-1xuxrUe-CjJQ1B5shexH_t5QV8w44bSMQfu5Gx66Cr_16LKIGkBVFzfa9A8SH12jqyYXvgiXBBOrn33bOrblMSq6VU3qD0NWAmbIktEc_bjh4vij-OQ'
        }
        
        # Save request details to a file for Postman testing
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = f"dms_request_{timestamp}.txt"
                
        # Send request to DMS server
        response = requests.request(
            "POST",
            "https://ustgapig.chola.murugappa.com/awsdms/1.0.0/dms/v1/image",
            headers=headers,
            data=payload,
            files=files,
            timeout=100
        )
        
        # Clean up the temporary file
        try:
            os.unlink(temp_file_path)
        except Exception as e:
            logger.warning(f"Failed to delete temporary file: {e}")
        
        # Save response to file
        with open(f"dms_response_{timestamp}.txt", 'w') as f:
            f.write("DMS Response Details\n")
            f.write("===================\n\n")
            
            f.write(f"Status Code: {response.status_code}\n\n")
            
            f.write("Response Headers:\n")
            for key, value in response.headers.items():
                f.write(f"{key}: {value}\n")
            f.write("\n")
            
            f.write("Response Body:\n")
            f.write(response.text)
        
        logger.info(f"DMS response saved to dms_response_{timestamp}.txt")
        
    
        # Check if request was successful
        if response.status_code in [200, 201]:  # Add 201 as a success code
            try:
                # For 201 responses, the DMS ID is often directly in the response text
                if response.status_code == 201:
                    dms_id = response.text.strip()
                    logger.info(f"Image uploaded to DMS successfully. DMS ID: {dms_id}, SHA-1: {sha1_hash}")
                    return dms_id
                else:
                    # For 200 responses, parse JSON
                    result = response.json()
                    if 'dms_id' in result:
                        logger.info(f"Image uploaded to DMS successfully. DMS ID: {result['dms_id']}, SHA-1: {sha1_hash}")
                        return result['dms_id']
                    else:
                        logger.error(f"DMS upload response missing dms_id: {result}")
                        return None
            except Exception as e:
                logger.error(f"Error parsing DMS response: {e}")
                # If we can't parse the response but it's a 201, use the response text as DMS ID
                if response.status_code == 201 and response.text:
                    dms_id = response.text.strip()
                    logger.info(f"Using response text as DMS ID: {dms_id}")
                    return dms_id
                return None
        else:
            logger.error(f"DMS upload failed with status code {response.status_code}: {response.text}")
            return None
            
    except Exception as e:
        logger.error(f"Error uploading to DMS: {str(e)}", exc_info=True)
        return None

def get_image_from_dms(dms_id):
    """
    Retrieve image from DMS server
    
    Args:
        dms_id: DMS ID of the image
        
    Returns:
        Image data as bytes if successful, None otherwise
    """
    
    try:
        # Add API key for authentication
        headers = {
            'Authorization': 'Bearer eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhcGltYW5hZ2VyIiwiYXV0IjoiQVBQTElDQVRJT04iLCJhdWQiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwibmJmIjoxNjU2NDk5NjE5LCJhenAiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwic2NvcGUiOiJkZWZhdWx0IiwiaXNzIjoiaHR0cHM6XC9cL3VzdGdhcGkuY2hvbGEubXVydWdhcHBhLmNvbTo0NDNcL29hdXRoMlwvdG9rZW4iLCJleHAiOjg4MDU2NDk5NjE5LCJpYXQiOjE2NTY0OTk2MTksImp0aSI6ImZhNTI5NmZhLTk5MDktNDVjZi05YzdkLWY1NjJmNTY3ZjE1MiJ9.S0EuU9NByou1K7MwOWsPOeP7ciN_i-jcGBdkAFe6EsIxWWDmBGngqfE1eb5EasP9JEGl09MlsY8WDNRskafznA--naCMP4TqhcZF9ISKV2fkOO9h4c6zgC7jf7zL-SdYn1vwUWKVY8lWoc2dJgqib6Wjcb_WfuKBhd3D8zTmKrNekWEmTIiO1kr7Pl4g-B0LtWuIl-VKAtYtMTQtcqSENAiDCQpXjo20U0-1xuxrUe-CjJQ1B5shexH_t5QV8w44bSMQfu5Gx66Cr_16LKIGkBVFzfa9A8SH12jqyYXvgiXBBOrn33bOrblMSq6VU3qD0NWAmbIktEc_bjh4vij-OQ'
        }
        
        # Send request to DMS server
        response = requests.get(
            f"https://ustgapig.chola.murugappa.com/awsdms/1.0.0/dms/v1/image/downloadimage?dmsid={dms_id}",
            headers=headers,
            timeout=100
        )
        
        # Check if request was successful
        if response.status_code == 200:
            return response.content
        else:
            logger.error(f"DMS get failed with status code {response.status_code}: {response.text}")
            return None
            
    except Exception as e:
        logger.error(f"Error getting image from DMS: {str(e)}", exc_info=True)
        return None

def delete_from_dms(dms_id):
    """
    Delete image from DMS server
    
    Args:
        dms_id: DMS ID of the image
        
    Returns:
        True if successful, False otherwise
    """
    try:
        # Add API key for authentication
        headers = {
            'Authorization': f'Bearer eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhcGltYW5hZ2VyIiwiYXV0IjoiQVBQTElDQVRJT04iLCJhdWQiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwibmJmIjoxNjU2NDk5NjE5LCJhenAiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwic2NvcGUiOiJkZWZhdWx0IiwiaXNzIjoiaHR0cHM6XC9cL3VzdGdhcGkuY2hvbGEubXVydWdhcHBhLmNvbTo0NDNcL29hdXRoMlwvdG9rZW4iLCJleHAiOjg4MDU2NDk5NjE5LCJpYXQiOjE2NTY0OTk2MTksImp0aSI6ImZhNTI5NmZhLTk5MDktNDVjZi05YzdkLWY1NjJmNTY3ZjE1MiJ9.S0EuU9NByou1K7MwOWsPOeP7ciN_i-jcGBdkAFe6EsIxWWDmBGngqfE1eb5EasP9JEGl09MlsY8WDNRskafznA--naCMP4TqhcZF9ISKV2fkOO9h4c6zgC7jf7zL-SdYn1vwUWKVY8lWoc2dJgqib6Wjcb_WfuKBhd3D8zTmKrNekWEmTIiO1kr7Pl4g-B0LtWuIl-VKAtYtMTQtcqSENAiDCQpXjo20U0-1xuxrUe-CjJQ1B5shexH_t5QV8w44bSMQfu5Gx66Cr_16LKIGkBVFzfa9A8SH12jqyYXvgiXBBOrn33bOrblMSq6VU3qD0NWAmbIktEc_bjh4vij-OQ'
        }
        
        # Send request to DMS server
        response = requests.delete(
            f"https://ustgapig.chola.murugappa.com/awsdms/1.0.0/dms/v1/image/delete/{dms_id}",
            headers=headers,
            timeout=50
        )
        
        # Check if request was successful
        if response.status_code == 200:
            logger.info(f"Image deleted from DMS successfully. DMS ID: {dms_id}")
            return True
        else:
            logger.error(f"DMS delete failed with status code {response.status_code}: {response.text}")
            return False
            
    except Exception as e:
        logger.error(f"Error deleting from DMS: {str(e)}", exc_info=True)
        return False
