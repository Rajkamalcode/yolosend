from flask import Flask, request, jsonify, send_file, render_template
from flask_cors import CORS
import cv2
import numpy as np
import base64
from ultralytics import YOLO
import logging
import dlib
import time
import os
from scipy.spatial import distance as dist
from imutils import face_utils
from datetime import datetime
import threading
import uuid
import io
from PIL import Image
from insightface.app import FaceAnalysis
import requests
from geocoder import reverse_geocode
import json
# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
# Configure CORS
CORS(app, resources={r"/*": {"origins": "*", "allow_headers": ["Content-Type"], "methods": ["POST", "GET", "OPTIONS"]}})

# Create directories for temporary processing
os.makedirs("temp_images", exist_ok=True)

# Constants for liveness detection
EYE_AR_THRESH = 0.20  # Threshold for eye aspect ratio (blink detection)
EYE_AR_CONSEC_FRAMES = 1  # Number of consecutive frames for blink detection
CAPTURE_DELAY = 5  # 5 seconds delay before capturing
LIVENESS_DURATION = 5  # Run liveness check for 5 seconds
FACE_LOST_THRESHOLD = 10  # Number of consecutive frames to consider face lost
FACE_BOX_SCALE_FACTOR = 1.5  # Increase face bounding box size by 50%
CLOSE_UP_FACE_RATIO = 0.4  # Face occupying more than 40% of frame height suggests close-up
SCREEN_CONFIDENCE_THRESHOLD = 0.4  # Confidence threshold for screen detection
SCREEN_CHECK_INTERVAL = 0.5  # Check for screens every 0.5 seconds
BLINK_CHALLENGE_DURATION = 5  # 5 seconds to complete blink challenge
BLINKS_REQUIRED = 2  # Number of blinks required to pass the challenge

DMS_SERVER_URL: "https://ustgapig.chola.murugappa.com/awsdms/1.0.0/dms/v1"
DMS_API_KEY: "eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhcGltYW5hZ2VyIiwiYXV0IjoiQVBQTElDQVRJT04iLCJhdWQiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwibmJmIjoxNjU2NDk5NjE5LCJhenAiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwic2NvcGUiOiJkZWZhdWx0IiwiaXNzIjoiaHR0cHM6XC9cL3VzdGdhcGkuY2hvbGEubXVydWdhcHBhLmNvbTo0NDNcL29hdXRoMlwvdG9rZW4iLCJleHAiOjg4MDU2NDk5NjE5LCJpYXQiOjE2NTY0OTk2MTksImp0aSI6ImZhNTI5NmZhLTk5MDktNDVjZi05YzdkLWY1NjJmNTY3ZjE1MiJ9.S0EuU9NByou1K7MwOWsPOeP7ciN_i-jcGBdkAFe6EsIxWWDmBGngqfE1eb5EasP9JEGl09MlsY8WDNRskafznA--naCMP4TqhcZF9ISKV2fkOO9h4c6zgC7jf7zL-SdYn1vwUWKVY8lWoc2dJgqib6Wjcb_WfuKBhd3D8zTmKrNekWEmTIiO1kr7Pl4g-B0LtWuIl-VKAtYtMTQtcqSENAiDCQpXjo20U0-1xuxrUe-CjJQ1B5shexH_t5QV8w44bSMQfu5Gx66Cr_16LKIGkBVFzfa9A8SH12jqyYXvgiXBBOrn33bOrblMSq6VU3qD0NWAmbIktEc_bjh4vij-OQ"  # Replace with actual token or token retrieval logic

# Load models
try:
    screen_detector = YOLO("screen detect1.pt")
    has_screen_detector = True
    logger.info("Screen detector loaded successfully")
except Exception as e:
    has_screen_detector = False
    logger.warning(f"Screen detector not loaded: {e}")

# Initialize dlib's face detector and facial landmark predictor
logger.info("Loading the predictor and detector...")
detector = dlib.get_frontal_face_detector()
try:
    predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
    has_face_predictor = True
    logger.info("Face predictor loaded successfully")
except Exception as e:
    has_face_predictor = False
    logger.warning(f"Face predictor not loaded: {e}")

# Initialize InsightFace model for face comparison
def init_face_model():
    """Initialize InsightFace model"""
    logger.info("Initializing face model")
    model_dir = os.path.expanduser("~/.insightface/models/buffalo_m")
    
    face_app = FaceAnalysis(name='buffalo_m', model_dir=model_dir)
    # Use GPU if available, otherwise CPU
    ctx_id = 0  # Change to -1 for CPU
    face_app.prepare(ctx_id=ctx_id, det_size=(640, 640), det_thresh=0.5)
    logger.info("Face model initialized")
    return face_app

# Initialize the face model
face_app = init_face_model()

# Get facial landmark indexes for eyes
(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]

# Define states for liveness detection
STATE_FACE_TRACKING = 0
STATE_BLINK_CHALLENGE = 1
STATE_CAPTURE_COUNTDOWN = 2
STATE_CAPTURED = 3

# Session storage
sessions = {}
uploaded_images = {}

# DMS Functions
def upload_to_dms(image_data, metadata=None):
    """
    Upload image to DMS server with SHA-1 hash metadata
    
    Args:
        image_data: Image data as bytes or numpy array
        metadata: Dictionary containing metadata for the image
        
    Returns:
        DMS ID if successful, None otherwise
    """
    try:
        # Convert numpy array to bytes if needed
        if isinstance(image_data, np.ndarray):
            is_success, buffer = cv2.imencode(".jpg", image_data)
            if not is_success:
                logger.error("Failed to encode image")
                return None
            image_bytes = buffer.tobytes()
        else:
            image_bytes = image_data
        
        # Calculate SHA-1 hash of the image
        import hashlib
        sha1_hash = hashlib.sha1(image_bytes).hexdigest()
        
        # Prepare metadata JSON
        if metadata is None:
            metadata = {}
        
        # Create a clean metadata dictionary with only the required fields
        # This ensures we match the exact format expected by the DMS API
        clean_metadata = {
            "imageId": f"FACELIVENESS_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "uniqueId": metadata.get("session_id", str(uuid.uuid4())),
            "appId": "1000",
            "sourceSys": "Face Liveness",
            "branchCode": "Chennai",  # Changed from Default to match template
            "branch": "Chennai",      # Changed from Default to match template
            "vertical": "KYC",
            "module": "Liveness",
            "stage": "1",
            "imageCategory": "Face_Liveness",
            "imageSubCategory": "1",
            "status": "1",
            "fileName": f"liveness_{datetime.now().strftime('%Y%m%d%H%M%S')}.jpg",
            "imageSrc": "Liveness",
            "imageSrcId": "1",
            "format": ".jpg",
            "user": "1",
            "size": str(len(image_bytes)),
            "page": "1",
            "createdBy": "1",
            "createdDate": datetime.now().strftime("%d/%m/%Y"),
            "modifiedBy": "1",
            "modifiedDate": datetime.now().strftime("%d/%m/%Y"),
            "checkSum": sha1_hash
        }
        
        # Add key fields
        if "applicant_id" in metadata:
            clean_metadata["keyId"] = ["Applicant ID", "Document Type"]
            clean_metadata["keyValue"] = [metadata["applicant_id"], "Liveness"]
        else:
            clean_metadata["keyId"] = ["Session ID", "Document Type"]
            clean_metadata["keyValue"] = [metadata.get("session_id", str(uuid.uuid4())), "Liveness"]
        
        # Convert metadata to JSON string
        metadata_json = json.dumps(clean_metadata)
        
        # Create a temporary file for the image
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.jpg', delete=False) as temp_file:
            temp_file.write(image_bytes)
            temp_file_path = temp_file.name
        
        # Prepare the request exactly as in the template
        payload = {'data': metadata_json}
        
        files = [
            ('image', ('image.jpg', open(temp_file_path, 'rb'), 'image/jpeg'))
        ]
        
        # Add API key for authentication
        headers = {
            'Authorization': 'Bearer eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJhcGltYW5hZ2VyIiwiYXV0IjoiQVBQTElDQVRJT04iLCJhdWQiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwibmJmIjoxNjU2NDk5NjE5LCJhenAiOiJ6dEpRUUp2cXQyeHZTcFJhSkp5UjU0dXFyUTRhIiwic2NvcGUiOiJkZWZhdWx0IiwiaXNzIjoiaHR0cHM6XC9cL3VzdGdhcGkuY2hvbGEubXVydWdhcHBhLmNvbTo0NDNcL29hdXRoMlwvdG9rZW4iLCJleHAiOjg4MDU2NDk5NjE5LCJpYXQiOjE2NTY0OTk2MTksImp0aSI6ImZhNTI5NmZhLTk5MDktNDVjZi05YzdkLWY1NjJmNTY3ZjE1MiJ9.S0EuU9NByou1K7MwOWsPOeP7ciN_i-jcGBdkAFe6EsIxWWDmBGngqfE1eb5EasP9JEGl09MlsY8WDNRskafznA--naCMP4TqhcZF9ISKV2fkOO9h4c6zgC7jf7zL-SdYn1vwUWKVY8lWoc2dJgqib6Wjcb_WfuKBhd3D8zTmKrNekWEmTIiO1kr7Pl4g-B0LtWuIl-VKAtYtMTQtcqSENAiDCQpXjo20U0-1xuxrUe-CjJQ1B5shexH_t5QV8w44bSMQfu5Gx66Cr_16LKIGkBVFzfa9A8SH12jqyYXvgiXBBOrn33bOrblMSq6VU3qD0NWAmbIktEc_bjh4vij-OQ'
        }
        
        # Save request details to a file for Postman testing
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = f"dms_request_{timestamp}.txt"
        
        with open(log_file, 'w') as f:
            f.write("DMS Request Details for Postman Testing\n")
            f.write("======================================\n\n")
            
            # URL
            f.write("URL: https://ustgapig.chola.murugappa.com/awsdms/1.0.0/dms/v1/image\n\n")
            
            # Headers
            f.write("Headers:\n")
            for key, value in headers.items():
                f.write(f"{key}: {value}\n")
            f.write("\n")
            
            # Payload
            f.write("Payload:\n")
            f.write(str(payload))
            f.write("\n\n")
            
            # Files
            f.write("Files:\n")
            f.write(str(files))
            f.write("\n\n")
            
            # Metadata JSON
            f.write("Metadata JSON (for 'data' form field):\n")
            f.write(metadata_json)
            f.write("\n\n")
            
            # Image details
            f.write("Image Details:\n")
            f.write(f"File name: image.jpg\n")
            f.write(f"Content type: image/jpeg\n")
            f.write(f"Size: {len(image_bytes)} bytes ({len(image_bytes)/1024/1024:.2f} MB)\n")
            f.write(f"SHA-1 hash: {sha1_hash}\n\n")
            
            # cURL command for testing
            f.write("cURL Command:\n")
            f.write(r"curl --location 'https://ustgapig.chola.murugappa.com/awsdms/1.0.0/dms/v1/image' \\" + "\n")
            f.write(r"--header 'Authorization: Bearer " + headers["Authorization"] + r"' \\" + "\n")
            f.write(r"--form 'data=\"" + metadata_json.replace('"', '\\"') + r"\"' \\" + "\n")
            f.write(r"--form 'image=@\"/path/to/image.jpg\"'" + "\n")

                    
        logger.info(f"DMS request details saved to {log_file} for Postman testing")
        
        # Send request to DMS server
        response = requests.request(
            "POST",
            "https://ustgapig.chola.murugappa.com/awsdms/1.0.0/dms/v1/image",
            headers=headers,
            data=payload,
            files=files,
            timeout=10
        )
        
        # Clean up the temporary file
        try:
            os.unlink(temp_file_path)
        except Exception as e:
            logger.warning(f"Failed to delete temporary file: {e}")
        
        # Save response to file
        with open(f"dms_response_{timestamp}.txt", 'w') as f:
            f.write("DMS Response Details\n")
            f.write("===================\n\n")
            
            f.write(f"Status Code: {response.status_code}\n\n")
            
            f.write("Response Headers:\n")
            for key, value in response.headers.items():
                f.write(f"{key}: {value}\n")
            f.write("\n")
            
            f.write("Response Body:\n")
            f.write(response.text)
        
        logger.info(f"DMS response saved to dms_response_{timestamp}.txt")
        
    
        # Check if request was successful
        if response.status_code in [200, 201]:  # Add 201 as a success code
            try:
                # For 201 responses, the DMS ID is often directly in the response text
                if response.status_code == 201:
                    dms_id = response.text.strip()
                    logger.info(f"Image uploaded to DMS successfully. DMS ID: {dms_id}, SHA-1: {sha1_hash}")
                    return dms_id
                else:
                    # For 200 responses, parse JSON
                    result = response.json()
                    if 'dms_id' in result:
                        logger.info(f"Image uploaded to DMS successfully. DMS ID: {result['dms_id']}, SHA-1: {sha1_hash}")
                        return result['dms_id']
                    else:
                        logger.error(f"DMS upload response missing dms_id: {result}")
                        return None
            except Exception as e:
                logger.error(f"Error parsing DMS response: {e}")
                # If we can't parse the response but it's a 201, use the response text as DMS ID
                if response.status_code == 201 and response.text:
                    dms_id = response.text.strip()
                    logger.info(f"Using response text as DMS ID: {dms_id}")
                    return dms_id
                return None
        else:
            logger.error(f"DMS upload failed with status code {response.status_code}: {response.text}")
            return None
            
    except Exception as e:
        logger.error(f"Error uploading to DMS: {str(e)}", exc_info=True)
        return None

def get_image_from_dms(dms_id):
    """
    Retrieve image from DMS server
    
    Args:
        dms_id: DMS ID of the image
        
    Returns:
        Image data as bytes if successful, None otherwise
    """
    
    try:
        # Add API key for authentication
        headers = {
            'Authorization': f'Bearer eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0'
        }
        
        # Send request to DMS server
        response = requests.get(
            f"{DMS_SERVER_URL}/get/{dms_id}",
            headers=headers,
            timeout=10
        )
        
        # Check if request was successful
        if response.status_code == 200:
            return response.content
        else:
            logger.error(f"DMS get failed with status code {response.status_code}: {response.text}")
            return None
            
    except Exception as e:
        logger.error(f"Error getting image from DMS: {str(e)}", exc_info=True)
        return None

def delete_from_dms(dms_id):
    """
    Delete image from DMS server
    
    Args:
        dms_id: DMS ID of the image
        
    Returns:
        True if successful, False otherwise
    """
    try:
        # Add API key for authentication
        headers = {
            'Authorization': f'Bearer eyJ4NXQiOiJOMkpqTWpOaU0yRXhZalJrTnpaalptWTFZVEF4Tm1GbE5qZzRPV1UxWVdRMll6YzFObVk1TlEiLCJraWQiOiJNREpsTmpJeE4yRTFPR1psT0dWbU1HUXhPVEZsTXpCbU5tRmpaalEwWTJZd09HWTBOMkkwWXpFNFl6WmpOalJoWW1SbU1tUTBPRGRpTkRoak1HRXdNQV9SUzI1NiIsImFsZyI6IlJTMjU2In0'
        }
        
        # Send request to DMS server
        response = requests.delete(
            f"{DMS_SERVER_URL}/delete/{dms_id}",
            headers=headers,
            timeout=10
        )
        
        # Check if request was successful
        if response.status_code == 200:
            logger.info(f"Image deleted from DMS successfully. DMS ID: {dms_id}")
            return True
        else:
            logger.error(f"DMS delete failed with status code {response.status_code}: {response.text}")
            return False
            
    except Exception as e:
        logger.error(f"Error deleting from DMS: {str(e)}", exc_info=True)
        return False

# Helper functions
def eye_aspect_ratio(eye):
    """Calculate the eye aspect ratio for blink detection"""
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

def detect_screen(frame):
    """Detect screens in the frame using YOLO model"""
    if not has_screen_detector:
        return False, "Screen detector not available"
    
    results = screen_detector(frame, verbose=False)[0]
    for box in results.boxes:
        if box.conf > SCREEN_CONFIDENCE_THRESHOLD:
            return True, "Screen detected by model"
    return False, ""

def reverse_geocode(latitude, longitude, timeout=3):
    """Get location details from coordinates using reverse geocoding with timeout"""
    try:
        url = f"https://nominatim.openstreetmap.org/reverse?format=json&lat={latitude}&lon={longitude}&zoom=18&addressdetails=1"
        headers = {
            "User-Agent": "FaceLivenessApp/1.0"
        }
        response = requests.get(url, headers=headers, timeout=timeout)
        data = response.json()
        
        if "display_name" in data:
            return data["display_name"]
        return "No matching location found"
    except requests.exceptions.Timeout:
        logger.warning(f"Reverse geocoding timed out after {timeout} seconds")
        return "Geocoding timed out"
    except Exception as e:
        logger.error(f"Error in reverse geocoding: {e}")
        return "Error in geocoding"

def save_capture_to_dms(frame, session_id, success=True):
    """Save the captured frame to DMS with location overlay"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Get session data
    session_data = sessions.get(session_id, {})
    geo_location = session_data.get('geo_location')
    
    # Create a copy of the frame for overlay
    overlay_frame = frame.copy()
    
    # Get frame dimensions
    height, width = overlay_frame.shape[:2]
    
    # Prepare text lines for overlay
    text_lines = []
    
    # Add timestamp
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    text_lines.append(f"Time: {current_time}")
    
    if geo_location:
        # Add coordinates with full precision
        lat = geo_location.get('latitude')
        lon = geo_location.get('longitude')
        # Use string formatting to preserve full precision
        text_lines.append(f"Lat: {lat:.10f}, Lon: {lon:.10f}")
        
        # Add reverse geocoded location if available
        try:
            location_info = reverse_geocode(lat, lon)
            if location_info and location_info != "No matching location found":
                # Split location info into multiple lines if it's too long
                location_parts = [location_info[i:i+40] for i in range(0, len(location_info), 40)]
                text_lines.append(f"Location:")
                for part in location_parts:
                    text_lines.append(f"{part}")
            else:
                text_lines.append("Location: Unknown")
        except Exception as e:
            logger.error(f"Error in reverse geocoding: {e}")
            text_lines.append("Location: Error in geocoding")
    else:
        text_lines.append("Location: Not available")
    
    # Calculate text block dimensions
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.7
    font_thickness = 2
    line_height = 30
    padding = 10
    
    text_height = len(text_lines) * line_height + 2 * padding
    text_width = max([cv2.getTextSize(line, font, font_scale, font_thickness)[0][0] for line in text_lines]) + 2 * padding
    
    # Position in bottom left corner
    overlay_x = 20
    overlay_y = height - text_height - 20
    
    # Create semi-transparent black background for text
    overlay = overlay_frame.copy()
    cv2.rectangle(overlay, 
                 (overlay_x - padding, overlay_y - padding), 
                 (overlay_x + text_width, overlay_y + text_height), 
                 (0, 0, 0), 
                 -1)  # Filled rectangle
    
    # Apply transparency
    alpha = 0.6  # 60% opacity
    cv2.addWeighted(overlay, alpha, overlay_frame, 1 - alpha, 0, overlay_frame)
    
    # Add text lines
    for i, line in enumerate(text_lines):
        y_position = overlay_y + i * line_height + padding
        cv2.putText(overlay_frame, line, (overlay_x + padding, y_position), 
                    font, font_scale, (255, 255, 255), font_thickness)
    
    # Prepare metadata for DMS
    metadata = {
        'session_id': session_id,
        'timestamp': current_time,
        'success': 'true' if success else 'false',
        'type': 'liveness_capture'
    }
    
    if geo_location:
        metadata['latitude'] = str(geo_location.get('latitude'))
        metadata['longitude'] = str(geo_location.get('longitude'))
    
    # Upload to DMS
    dms_id = upload_to_dms(overlay_frame, metadata)
    
    if dms_id:
        logger.info(f"Image uploaded to DMS with ID: {dms_id}")
        return dms_id
    else:
        logger.error("Failed to upload image to DMS")
        return None

def calculate_face_movement(current_face, last_face):
    """Calculate face movement between frames"""
    if current_face is None or last_face is None:
        return 0
    
    current_center = ((current_face.left() + current_face.right()) // 2, 
                      (current_face.top() + current_face.bottom()) // 2)
    last_center = ((last_face.left() + last_face.right()) // 2, 
                   (last_face.top() + last_face.bottom()) // 2)
    
    movement = np.sqrt((current_center[0] - last_center[0])**2 + 
                       (current_center[1] - last_center[1])**2)
    
    return movement

def expand_face_box(face, frame_width, frame_height, scale_factor=FACE_BOX_SCALE_FACTOR):
    """Expand the face bounding box by the given scale factor"""
    # Calculate current width and height
    width = face.right() - face.left()
    height = face.bottom() - face.top()
    
    # Calculate new dimensions
    new_width = int(width * scale_factor)
    new_height = int(height * scale_factor)
    
    # Calculate new center
    center_x = (face.left() + face.right()) // 2
    center_y = (face.top() + face.bottom()) // 2
    
    # Calculate new coordinates
    new_left = max(0, center_x - new_width // 2)
    new_top = max(0, center_y - new_height // 2)
    new_right = min(frame_width - 1, center_x + new_width // 2)
    new_bottom = min(frame_height - 1, center_y + new_height // 2)
    
    # Create a new rectangle with expanded dimensions
    expanded_face = dlib.rectangle(new_left, new_top, new_right, new_bottom)
    
    return expanded_face

def detect_close_up_face(face_rect, frame_height):
    """Detect if face is too close to the camera (potential phone screen)"""
    face_height = face_rect.bottom() - face_rect.top()
    height_ratio = face_height / frame_height
    return height_ratio > CLOSE_UP_FACE_RATIO

def process_liveness_frame(frame, session_data):
    """Process a single frame for liveness detection"""
    # Track frame processing time
    current_time = time.time()
    if 'last_frame_time' in session_data:
        frame_interval = current_time - session_data['last_frame_time']
        # Log if frames are coming in too slowly
        if frame_interval > 0.2:  # More than 200ms between frames
            logger.warning(f"Slow frame rate detected: {1/frame_interval:.2f} FPS")
    session_data['last_frame_time'] = current_time
    
    # Store clean frame for potential capture
    clean_frame = frame.copy()
    session_data['clean_frame'] = clean_frame
    
    # Convert to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Check for screen spoofing
    if not session_data['spoofing_detected'] and current_time - session_data.get('last_screen_check_time', 0) > SCREEN_CHECK_INTERVAL:
        session_data['last_screen_check_time'] = current_time
        is_screen, screen_reason = detect_screen(frame)
        if is_screen:
            session_data['spoofing_detected'] = True
            session_data['spoofing_reason'] = screen_reason
            session_data['spoofing_detector'] = "screen_detector"
            session_data['message'] = f"SPOOFING DETECTED: {screen_reason}"
            session_data['status'] = "failed"
            session_data['stop_webcam'] = True
            logger.info(f"Spoofing detected by screen_detector: {screen_reason}")
            session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
            session_data['capture_start_time'] = time.time()
            return
    
    # Detect faces
    faces = detector(gray)
    
    # Update face tracking status
    if len(faces) == 1:
        face_present = True
        session_data['face_lost_frames'] = 0
        session_data['face_tracking_frames'] = session_data.get('face_tracking_frames', 0) + 1
        
        # Expand the face bounding box
        frame_height, frame_width = frame.shape[:2]
        expanded_face = expand_face_box(faces[0], frame_width, frame_height)
        
        # Check for close-up face (potential phone screen)
        if detect_close_up_face(faces[0], frame_height) and not session_data['spoofing_detected']:
            session_data['spoofing_detected'] = True
            session_data['spoofing_reason'] = "Face too close to camera (potential phone screen)"
            session_data['spoofing_detector'] = "close_up_detector"
            session_data['message'] = "SPOOFING DETECTED: Face too close to camera (potential phone screen)"
            session_data['status'] = "failed"
            session_data['stop_webcam'] = True
            logger.info(f"Spoofing detected by close_up_detector: Face too close to camera")
            session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
            session_data['capture_start_time'] = time.time()
            return
        
        if session_data.get('last_face_position') is not None:
            face_movement = calculate_face_movement(expanded_face, session_data['last_face_position'])
            session_data['face_movement'] = face_movement
        
        session_data['last_face_position'] = expanded_face
    else:
        face_present = False
        session_data['face_lost_frames'] = session_data.get('face_lost_frames', 0) + 1
        session_data['face_tracking_frames'] = 0
        
        if session_data.get('face_lost_frames', 0) >= FACE_LOST_THRESHOLD:
            session_data['last_face_position'] = None
            # Reset liveness timer if face is lost for too long during face tracking
            if session_data.get('current_state') == STATE_FACE_TRACKING and session_data.get('liveness_start_time') is not None:
                session_data['liveness_start_time'] = None
                session_data['face_tracking_continuous'] = False
                session_data['message'] = "Face tracking interrupted - face lost for too long. Timer reset."
                logger.info("Face tracking interrupted - face lost for too long. Timer reset.")
    
    # Initialize liveness timer
    if face_present and session_data.get('liveness_start_time') is None and session_data.get('current_state') == STATE_FACE_TRACKING:
        session_data['liveness_start_time'] = time.time()
        session_data['message'] = "Starting liveness check timer..."
        logger.info("Starting liveness check timer...")
    
    # Calculate elapsed time for liveness check
    liveness_elapsed_time = 0
    if session_data.get('liveness_start_time') is not None and session_data.get('current_state') == STATE_FACE_TRACKING:
        liveness_elapsed_time = time.time() - session_data['liveness_start_time']
        session_data['message'] = f"Liveness check: {liveness_elapsed_time:.1f}/{LIVENESS_DURATION}s"
    
    # Process face for visualization and challenges
    if face_present and not session_data['spoofing_detected']:
        face = faces[0]
        
        # Get facial landmarks
        shape = predictor(gray, face)
        shape_np = face_utils.shape_to_np(shape)
        
        # Extract eye landmarks
        leftEye = shape_np[lStart:lEnd]
        rightEye = shape_np[rStart:rEnd]
        
        # Calculate eye aspect ratio
        leftEAR = eye_aspect_ratio(leftEye)
        rightEAR = eye_aspect_ratio(rightEye)
        ear = (leftEAR + rightEAR) / 2.0
        
        # Store EAR for frontend
        session_data['current_ear'] = ear
    
    # State-specific processing
    current_state = session_data.get('current_state', STATE_FACE_TRACKING)
    
    if current_state == STATE_FACE_TRACKING:
        if face_present:
            if liveness_elapsed_time >= LIVENESS_DURATION:
                if not session_data.get('liveness_confirmed', False) and not session_data['spoofing_detected']:
                    logger.info("Face tracking successful for required duration. Starting blink challenge!")
                    session_data['current_state'] = STATE_BLINK_CHALLENGE
                    session_data['blink_challenge_start_time'] = time.time()
                    session_data['blink_counter'] = 0
                    session_data['blink_total'] = 0
                    session_data['message'] = f"BLINK CHALLENGE: Blink {BLINKS_REQUIRED} times"
        else:
            session_data['message'] = "NO FACE DETECTED"
    
    elif current_state == STATE_BLINK_CHALLENGE:
        elapsed_time = time.time() - session_data.get('blink_challenge_start_time', time.time())
        remaining_time = max(0, BLINK_CHALLENGE_DURATION - elapsed_time)
        
        # Display blink challenge instructions
        session_data['message'] = f"BLINK CHALLENGE: Blink {BLINKS_REQUIRED} times. Time remaining: {remaining_time:.1f}s. Blinks detected: {session_data.get('blink_total', 0)}/{BLINKS_REQUIRED}"
        
        if not face_present:
            session_data['message'] = "FACE LOST DURING CHALLENGE!"
            if session_data.get('face_lost_frames', 0) >= FACE_LOST_THRESHOLD:
                session_data['spoofing_detected'] = True
                session_data['spoofing_reason'] = "Face lost during blink challenge"
                session_data['spoofing_detector'] = "face_lost_detector"
                session_data['message'] = "SPOOFING DETECTED: Face lost during blink challenge"
                session_data['status'] = "failed"
                session_data['stop_webcam'] = True
                logger.info(f"Spoofing detected by face_lost_detector: Face lost during blink challenge")
                session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
                session_data['capture_start_time'] = time.time()
        
        if face_present:
            if ear < EYE_AR_THRESH:
                session_data['blink_counter'] = session_data.get('blink_counter', 0) + 1
            else:
                if session_data.get('blink_counter', 0) >= EYE_AR_CONSEC_FRAMES:
                    session_data['blink_total'] = session_data.get('blink_total', 0) + 1
                    session_data['message'] = "BLINK DETECTED!"
                    logger.info(f"Blink detected! Total: {session_data.get('blink_total', 0)}")
                session_data['blink_counter'] = 0
        
        if session_data.get('blink_total', 0) >= BLINKS_REQUIRED:
            session_data['liveness_confirmed'] = True
            session_data['message'] = "LIVENESS CONFIRMED!"
            session_data['status'] = "success"
            session_data['liveness_flag'] = True  # Add liveness flag
            logger.info("Blink challenge completed successfully!")
            session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
            session_data['capture_start_time'] = time.time()
        elif remaining_time <= 0:
            session_data['spoofing_detected'] = True
            session_data['spoofing_reason'] = "Failed blink challenge"
            session_data['spoofing_detector'] = "blink_challenge_timeout"
            session_data['message'] = "SPOOFING DETECTED: Failed blink challenge"
            session_data['status'] = "failed"
            session_data['liveness_flag'] = False  # Add liveness flag
            session_data['stop_webcam'] = True
            logger.info(f"Spoofing detected by blink_challenge_timeout: Failed blink challenge")
            session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
            session_data['capture_start_time'] = time.time()
    
    elif current_state == STATE_CAPTURE_COUNTDOWN:
        elapsed_time = time.time() - session_data.get('capture_start_time', time.time())
        remaining_time = max(0, CAPTURE_DELAY - elapsed_time)
        
        # Display countdown message
        if session_data.get('spoofing_detected', False):
            session_data['message'] = f"KYC FAILED: {session_data.get('spoofing_reason', 'Unknown reason')}. Capturing image in {remaining_time:.1f}s"
        else:
            session_data['message'] = f"LIVENESS CONFIRMED! Capturing image in {remaining_time:.1f}s"
        
        if remaining_time <= 0 and not session_data.get('image_captured', False):
            # Upload to DMS instead of saving locally
            dms_id = save_capture_to_dms(
                session_data['clean_frame'], 
                session_data['session_id'],
                not session_data.get('spoofing_detected', False)
            )
            
            session_data['image_captured'] = True
            session_data['dms_id'] = dms_id  # Store DMS ID instead of local path
            session_data['current_state'] = STATE_CAPTURED
            
            if session_data.get('spoofing_detected', False):
                session_data['message'] = f"KYC FAILED: {session_data.get('spoofing_reason', 'Unknown reason')}. Image captured and uploaded to DMS."
            else:
                session_data['message'] = "LIVENESS CONFIRMED! Image captured and uploaded to DMS successfully."
        
    elif current_state == STATE_CAPTURED:
        if session_data.get('spoofing_detected', False):
            session_data['message'] = f"KYC FAILED: {session_data.get('spoofing_reason', 'Unknown reason')}. Image uploaded to DMS."
        else:
            session_data['message'] = "LIVENESS CONFIRMED! Image uploaded to DMS successfully."
        
        # Only upload to DMS once
        if not session_data.get('dms_upload_attempted', False):
            session_data['dms_upload_attempted'] = True
            
            # Upload to DMS
            dms_id = save_capture_to_dms(
                session_data['clean_frame'], 
                session_data['session_id'],
                not session_data.get('spoofing_detected', False)
            )
            
            if dms_id:
                session_data['dms_id'] = dms_id
                session_data['image_captured'] = True
            
        session_data['stop_webcam'] = True


# Process image bytes and extract face embedding
def process_image(image_bytes):
    """Process image bytes and extract face embedding"""
    try:
        img = Image.open(io.BytesIO(image_bytes))
        img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        faces = face_app.get(img)
        if not faces:
            raise ValueError("No faces detected")
        return faces[0].normed_embedding, img
    except Exception as e:
        logger.error(f"Image processing failed: {str(e)}")
        return None, None

# Calculate similarity between two face embeddings
def calculate_similarity(emb1, emb2, margin=0.1):
    """Calculate similarity between two face embeddings with margin adjustment"""
    # Compute cosine similarity
    cosine_sim = np.dot(emb1, emb2)
    
    # Convert to angular distance
    angle = np.arccos(np.clip(cosine_sim, -1.0, 1.0))
    
    # Apply margin adjustment
    adjusted_angle = angle + margin
    
    # Convert back to similarity score
    final_score = np.cos(adjusted_angle)
    
    return float(cosine_sim)

@app.route('/faceliveness/')
def home():
    return render_template('main.html')

@app.route('/fullface')
def index():
    return render_template('index.html')

@app.route('/faceliveness/liveness_check.html')
def liveness_check():
    return render_template('liveness_check.html')

@app.route('/faceliveness/get_location_details', methods=['POST'])
def get_location_details():
    """Get location details from coordinates using reverse geocoding"""
    try:
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        latitude = request_data.get('latitude')
        longitude = request_data.get('longitude')
        
        if not latitude or not longitude:
            return jsonify({'error': 'Missing latitude or longitude'}), 400
        
        # Perform reverse geocoding using the offline geocoder
        location_info = reverse_geocode(latitude, longitude)
        
        return jsonify({
            'success': True,
            'location': location_info
        })
    except Exception as e:
        logger.error(f"Error getting location details: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/faceliveness/start_liveness', methods=['POST'])
def start_liveness():
    """Initialize a new liveness detection session"""
    session_id = str(uuid.uuid4())
    
    # Create a new session
    sessions[session_id] = {
        'session_id': session_id,
        'start_time': time.time(),
        'current_state': STATE_FACE_TRACKING,
        'liveness_start_time': None,
        'blink_challenge_start_time': None,
        'blink_counter': 0,
        'blink_total': 0,
        'face_tracking_frames': 0,
        'face_lost_frames': 0,
        'last_face_position': None,
        'face_movement': 0,
        'liveness_confirmed': False,
        'face_tracking_continuous': True,
        'spoofing_detected': False,
        'spoofing_reason': None,
        'spoofing_detector': None,
        'last_screen_check_time': time.time(),
        'status': 'pending',
        'message': 'Starting liveness detection...',
        'clean_frame': None,
        'capture_start_time': None,
        'image_captured': False,
        'dms_id': None,  # Changed from image_path to dms_id
        'stop_webcam': False,
        'last_frame_time': time.time(),
        'current_ear': 0.0,
        'geo_location': None,
        'liveness_flag': False  # Initialize liveness flag
    }
    
    logger.info(f"Created new liveness session: {session_id}")
    return jsonify({
        'success': True,
        'session_id': session_id,
        'message': 'Liveness detection session started'
    })

@app.route('/faceliveness/process_liveness_frame', methods=['POST'])
def process_liveness():
    """Process a frame for liveness detection"""
    try:
        # Get request data
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        session_id = request_data.get('session_id')
        image_data = request_data.get('image')
        geo_location = request_data.get('geo_location')  # Get location data if provided
        
        if not session_id or not image_data:
            return jsonify({'error': 'Missing session_id or image data'}), 400
        
        # Check if session exists
        if session_id not in sessions:
            return jsonify({'error': 'Invalid session ID'}), 404
        
        session_data = sessions[session_id]
        
        # Store geo_location in session data if provided
        if geo_location and not session_data.get('geo_location'):
            session_data['geo_location'] = geo_location
            logger.info(f"Geo location data received for session {session_id}")
        
        # Decode the base64 image
        try:
            encoded_data = image_data.split(',')[1]
            nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if img is None:
                return jsonify({'error': 'Failed to decode image'}), 400
        except Exception as e:
            logger.error(f"Error decoding image: {str(e)}")
            return jsonify({'error': f'Error decoding image: {str(e)}'}), 400
        
        # Process the frame for liveness detection
        process_liveness_frame(img, session_data)
        
        # Prepare response
        response = {
            'success': True,
            'session_id': session_id,
            'status': session_data.get('status', 'pending'),
            'message': session_data.get('message', 'Processing...'),
            'current_state': session_data.get('current_state', STATE_FACE_TRACKING),
            'liveness_confirmed': session_data.get('liveness_confirmed', False),
            'spoofing_detected': session_data.get('spoofing_detected', False),
            'stop_webcam': session_data.get('stop_webcam', False),
            'blink_total': session_data.get('blink_total', 0),
            'blinks_required': BLINKS_REQUIRED,
            'current_ear': session_data.get('current_ear', 0.0),
            'ear_threshold': EYE_AR_THRESH,
            'liveness_flag': session_data.get('liveness_flag', False)  # Include liveness flag in response
        }
        
        # If image has been captured, include the DMS ID
        if session_data.get('image_captured', False) and session_data.get('dms_id'):
            response['dms_id'] = session_data['dms_id']
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Error processing liveness frame: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/faceliveness/upload_image', methods=['POST'])
def upload_image():
    """Upload an image for comparison and store in DMS"""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        image_file = request.files['image']
        if image_file.filename == '':
            return jsonify({"error": "No image file selected"}), 400
        
        # Generate a unique ID for this upload
        upload_id = str(uuid.uuid4())
        
        # Read the image file
        image_bytes = image_file.read()
        
        # Process the image to extract face embedding
        embedding, img = process_image(image_bytes)
        
        if embedding is None:
            return jsonify({"error": "No face detected in the uploaded image"}), 400
        
        # Upload to DMS
        metadata = {
            'upload_id': upload_id,
            'upload_time': datetime.now().isoformat(),
            'type': 'reference_image'
        }
        
        dms_id = upload_to_dms(img, metadata)
        
        if not dms_id:
            return jsonify({"error": "Failed to upload image to DMS"}), 500
        
        # Store the embedding and DMS ID
        uploaded_images[upload_id] = {
            'embedding': embedding,
            'dms_id': dms_id,
            'upload_time': datetime.now().isoformat()
        }
        
        return jsonify({
            "success": True,
            "upload_id": upload_id,
            "dms_id": dms_id,
            "message": "Image uploaded to DMS and processed successfully"
        })
        
    except Exception as e:
        logger.error(f"Error uploading image: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/faceliveness/compare_faces', methods=['POST'])
def compare_faces():
    """Compare a liveness-verified face with an uploaded face"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No JSON data provided"}), 400
        
        session_id = data.get('session_id')
        upload_id = data.get('upload_id')
        
        if not session_id or not upload_id:
            return jsonify({"error": "Missing session_id or upload_id"}), 400
        
        # Check if session exists and has a captured image
        if session_id not in sessions:
            return jsonify({"error": "Invalid session ID"}), 404
        
        session_data = sessions[session_id]
        if not session_data.get('image_captured', False) or not session_data.get('dms_id'):
            return jsonify({"error": "No liveness-verified image available for this session"}), 400
        
        # Check if upload exists
        if upload_id not in uploaded_images:
            return jsonify({"error": "Invalid upload ID"}), 404
        
        upload_data = uploaded_images[upload_id]
        
        # Get the liveness image from DMS
        liveness_image_bytes = get_image_from_dms(session_data['dms_id'])
        
        if not liveness_image_bytes:
            return jsonify({"error": "Failed to retrieve liveness image from DMS"}), 500
        
        # Process the liveness image to extract face embedding
        liveness_embedding, _ = process_image(liveness_image_bytes)
        
        if liveness_embedding is None:
            return jsonify({"error": "No face detected in the liveness image"}), 400
        
        # Calculate similarity
        similarity = calculate_similarity(liveness_embedding, upload_data['embedding'])
        
        # Determine match status
        match_threshold = 0.5  # Adjust as needed
        is_match = similarity >= match_threshold
        
        return jsonify({
            "success": True,
            "similarity": similarity,
            "is_match": is_match,
            "threshold": match_threshold,
            "liveness_dms_id": session_data['dms_id'],
            "reference_dms_id": upload_data['dms_id'],
            "liveness_flag": session_data.get('liveness_flag', False)  # Include liveness flag in response
        })
        
    except Exception as e:
        logger.error(f"Error comparing faces: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/faceliveness/list_uploads', methods=['GET'])
def list_uploads():
    """List all uploaded reference images"""
    uploads_list = []
    for upload_id, data in uploaded_images.items():
        uploads_list.append({
            'upload_id': upload_id,
            'dms_id': data.get('dms_id'),
            'upload_time': data['upload_time']
        })
    
    return jsonify({
        'success': True,
        'uploads': uploads_list
    })

@app.route('/faceliveness/list_sessions', methods=['GET'])
def list_sessions():
    """List all liveness sessions"""
    sessions_list = []
    for session_id, data in sessions.items():
        session_info = {
            'session_id': session_id,
            'start_time': datetime.fromtimestamp(data['start_time']).isoformat(),
            'status': data.get('status', 'pending'),
            'liveness_confirmed': data.get('liveness_confirmed', False),
            'spoofing_detected': data.get('spoofing_detected', False),
            'liveness_flag': data.get('liveness_flag', False)  # Include liveness flag
        }
        
        if data.get('image_captured', False) and data.get('dms_id'):
            session_info['dms_id'] = data['dms_id']
        
        sessions_list.append(session_info)
    
    return jsonify({
        'success': True,
        'sessions': sessions_list
    })

@app.route('/faceliveness/search', methods=['POST'])
def search():
    """Process the captured image for search/verification"""
    try:
        # Get request data
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        session_id = request_data.get('session_id')
        
        if not session_id:
            return jsonify({'error': 'Missing session_id'}), 400
        
        # Check if session exists
        if session_id not in sessions:
            return jsonify({'error': 'Invalid session ID'}), 404
        
        session_data = sessions[session_id]
        
        # Check if image was captured
        if not session_data.get('image_captured', False) or not session_data.get('dms_id'):
            return jsonify({'error': 'No image captured for this session'}), 400
        
        # Here you would implement your search/verification logic
        # For now, we'll just return a success message with the DMS ID
        
        # Mock search result
        search_result = {
            'success': True,
            'message': 'Verification completed successfully',
            'match_found': True,
            'match_confidence': 0.95,
            'liveness_flag': session_data.get('liveness_flag', False),  # Include liveness flag
            'dms_id': session_data['dms_id'],
            'user_details': {
                'name': 'John Doe',
                'id': '12345',
                'status': 'Verified'
            }
        }
        
        return jsonify(search_result)
    
    except Exception as e:
        logger.error(f"Error in search: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/faceliveness/detect', methods=['POST', 'OPTIONS'])
def detect():
    # Handle preflight OPTIONS request
    if request.method == 'OPTIONS':
        logger.debug("Received OPTIONS request")
        return '', 200
    
    logger.debug("Received POST request")
    try:
        # Get the image data from the request
        request_data = request.get_json()
        if not request_data:
            logger.error("No JSON data in request")
            return jsonify({'error': 'No JSON data provided'}), 400
            
        image_data = request_data.get('image')
        if not image_data:
            logger.error("No image data in request JSON")
            return jsonify({'error': 'No image data provided'}), 400
        
        logger.debug("Image data received, processing...")
        
        # Decode the base64 image
        try:
            encoded_data = image_data.split(',')[1]
            nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if img is None:
                logger.error("Failed to decode image")
                return jsonify({'error': 'Failed to decode image'}), 400
                
            logger.debug(f"Image decoded successfully, shape: {img.shape}")
        except Exception as e:
            logger.error(f"Error decoding image: {str(e)}")
            return jsonify({'error': f'Error decoding image: {str(e)}'}), 400
        
        # For hand detection, we would need a hand detector model
        # Since we don't have the hand detector model, we'll return a mock response
        detected_signs = [
            {
                'sign': 'thumbs_up',
                'confidence': 0.95
            }
        ]
        
        # Return the detected hand signs
        response_data = {
            'success': True,
            'detected_signs': detected_signs
        }
        logger.debug(f"Returning response: {response_data}")
        return jsonify(response_data)
    
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/faceliveness/capture_property_photo', methods=['POST'])
def capture_property_photo():
    """Capture a property photo with geolocation data and upload to DMS"""
    try:
        # Get request data
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        image_data = request_data.get('image')
        geo_location = request_data.get('geo_location')
        
        if not image_data:
            return jsonify({'error': 'Missing image data'}), 400
        
        if not geo_location:
            return jsonify({'error': 'Missing geolocation data'}), 400
        
        # Generate a unique ID for this property photo
        photo_id = str(uuid.uuid4())
        
        # Decode the base64 image
        try:
            encoded_data = image_data.split(',')[1]
            nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if img is None:
                return jsonify({'error': 'Failed to decode image'}), 400
        except Exception as e:
            logger.error(f"Error decoding image: {str(e)}")
            return jsonify({'error': f'Error decoding image: {str(e)}'}), 400
        
        # Create a copy of the frame for overlay
        overlay_frame = img.copy()
        
        # Get frame dimensions
        height, width = overlay_frame.shape[:2]
        
        # Prepare text lines for overlay
        text_lines = []
        
        # Add timestamp
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        text_lines.append(f"Time: {current_time}")
        
        # Add coordinates with full precision
        lat = geo_location.get('latitude')
        lon = geo_location.get('longitude')
        text_lines.append(f"Lat: {lat:.10f}, Lon: {lon:.10f}")
        
        # Add reverse geocoded location if available
        try:
            location_info = reverse_geocode(lat, lon)
            if location_info and location_info != "No matching location found":
                # Split location info into multiple lines if it's too long
                location_parts = [location_info[i:i+40] for i in range(0, len(location_info), 40)]
                text_lines.append(f"Location:")
                for part in location_parts:
                    text_lines.append(f"{part}")
            else:
                text_lines.append("Location: Unknown")
        except Exception as e:
            logger.error(f"Error in reverse geocoding: {e}")
            text_lines.append("Location: Error in geocoding")
        
        # Calculate text block dimensions
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.7
        font_thickness = 2
        line_height = 30
        padding = 10
        
        text_height = len(text_lines) * line_height + 2 * padding
        text_width = max([cv2.getTextSize(line, font, font_scale, font_thickness)[0][0] for line in text_lines]) + 2 * padding
        
        # Position in bottom left corner
        overlay_x = 20
        overlay_y = height - text_height - 20
        
        # Create semi-transparent black background for text
        overlay = overlay_frame.copy()
        cv2.rectangle(overlay, 
                     (overlay_x - padding, overlay_y - padding), 
                     (overlay_x + text_width, overlay_y + text_height), 
                     (0, 0, 0), 
                     -1)  # Filled rectangle
        
        # Apply transparency
        alpha = 0.6  # 60% opacity
        cv2.addWeighted(overlay, alpha, overlay_frame, 1 - alpha, 0, overlay_frame)
        
        # Add text lines
        for i, line in enumerate(text_lines):
            y_position = overlay_y + i * line_height + padding
            cv2.putText(overlay_frame, line, (overlay_x + padding, y_position), 
                        font, font_scale, (255, 255, 255), font_thickness)
        
        # Prepare metadata for DMS
        metadata = {
            'photo_id': photo_id,
            'timestamp': current_time,
            'latitude': str(lat),
            'longitude': str(lon),
            'type': 'property_photo'
        }
        
        # Upload to DMS
        dms_id = upload_to_dms(overlay_frame, metadata)
        
        if not dms_id:
            return jsonify({"error": "Failed to upload property photo to DMS"}), 500
        
        logger.info(f"Property photo uploaded to DMS with ID: {dms_id}")
        
        return jsonify({
            'success': True,
            'photo_id': photo_id,
            'dms_id': dms_id,
            'message': 'Property photo captured and uploaded to DMS successfully'
        })
        
    except Exception as e:
        logger.error(f"Error capturing property photo: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/faceliveness/list_property_photos', methods=['GET'])
def list_property_photos():
    """List all property photos from DMS"""
    try:
        # This would typically involve querying the DMS API for all property photos
        # Since we don't have direct access to the DMS API's list functionality,
        # we'll return a mock response or implement this when the DMS API is available
        
        # Mock response for now
        return jsonify({
            'success': True,
            'message': 'This endpoint would list all property photos from DMS. Implementation pending DMS API access.'
        })
    except Exception as e:
        logger.error(f"Error listing property photos: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/faceliveness/upload_and_compare', methods=['POST'])
def upload_and_compare():
    """Upload a reference image and compare with a liveness image in one step"""
    try:
        if 'image' not in request.files:
            return jsonify({"error": "No image file provided"}), 400
        
        session_id = request.form.get('session_id')
        if not session_id:
            return jsonify({"error": "Missing session_id"}), 400
        
        # Check if session exists and has a captured image
        if session_id not in sessions:
            return jsonify({"error": "Invalid session ID"}), 404
        
        session_data = sessions[session_id]
        if not session_data.get('image_captured', False) or not session_data.get('dms_id'):
            return jsonify({"error": "No liveness-verified image available for this session"}), 400
        
        # Process the uploaded image
        image_file = request.files['image']
        if image_file.filename == '':
            return jsonify({"error": "No image file selected"}), 400
        
        # Generate a unique ID for this upload
        upload_id = str(uuid.uuid4())
        
        # Read the image file
        image_bytes = image_file.read()
        
        # Process the image to extract face embedding
        reference_embedding, reference_img = process_image(image_bytes)
        
        if reference_embedding is None:
            return jsonify({"error": "No face detected in the uploaded reference image"}), 400
        
        # Upload reference image to DMS
        reference_metadata = {
            'upload_id': upload_id,
            'upload_time': datetime.now().isoformat(),
            'type': 'reference_image',
            'session_id': session_id
        }
        
        reference_dms_id = upload_to_dms(reference_img, reference_metadata)
        
        if not reference_dms_id:
            return jsonify({"error": "Failed to upload reference image to DMS"}), 500
        
        # Get the liveness image from DMS
        liveness_image_bytes = get_image_from_dms(session_data['dms_id'])
        
        if not liveness_image_bytes:
            return jsonify({"error": "Failed to retrieve liveness image from DMS"}), 500
        
        # Process the liveness image to extract face embedding
        liveness_embedding, _ = process_image(liveness_image_bytes)
        
        if liveness_embedding is None:
            return jsonify({"error": "No face detected in the liveness image"}), 400
        
        # Calculate similarity
        similarity = calculate_similarity(liveness_embedding, reference_embedding)
        
        # Determine match status
        match_threshold = 0.5  # Adjust as needed
        is_match = similarity >= match_threshold
        
        # Store the reference image data
        uploaded_images[upload_id] = {
            'embedding': reference_embedding,
            'dms_id': reference_dms_id,
            'upload_time': datetime.now().isoformat()
        }
        
        return jsonify({
            "success": True,
            "upload_id": upload_id,
            "reference_dms_id": reference_dms_id,
            "liveness_dms_id": session_data['dms_id'],
            "similarity": similarity,
            "is_match": is_match,
            "threshold": match_threshold,
            "liveness_flag": session_data.get('liveness_flag', False)
        })
        
    except Exception as e:
        logger.error(f"Error in upload and compare: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/faceliveness/get_session_status/<session_id>', methods=['GET'])
def get_session_status(session_id):
    """Get the status of a liveness session"""
    if session_id not in sessions:
        return jsonify({'error': 'Invalid session ID'}), 404
    
    session_data = sessions[session_id]
    
    response = {
        'success': True,
        'session_id': session_id,
        'status': session_data.get('status', 'pending'),
        'liveness_confirmed': session_data.get('liveness_confirmed', False),
        'spoofing_detected': session_data.get('spoofing_detected', False),
        'liveness_flag': session_data.get('liveness_flag', False),
        'message': session_data.get('message', '')
    }
    
    if session_data.get('image_captured', False) and session_data.get('dms_id'):
        response['dms_id'] = session_data['dms_id']
    
    return jsonify(response)

@app.route('/faceliveness/test', methods=['GET'])
@app.route('/test', methods=['GET'])
def test():
    return jsonify({'status': 'API is working'})

if __name__ == '__main__':
    logger.info("Starting Flask server...")
    app.run(host='0.0.0.0', port=5045, debug=True)
