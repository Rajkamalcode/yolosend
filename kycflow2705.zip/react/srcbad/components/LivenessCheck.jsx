import React, { useState, useRef, useEffect } from 'react';
import './LivenessCheck.css';

const LivenessCheck = ({ kycData, updateKycData, nextStep }) => {
  const [streaming, setStreaming] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [status, setStatus] = useState('Ready to start liveness check');
  const [statusClass, setStatusClass] = useState('pending');
  const [progress, setProgress] = useState(0);
  const [capturedImageUrl, setCapturedImageUrl] = useState(null);
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [spoofingDetected, setSpoofingDetected] = useState(false);
  const [retryCount, setRetryCount] = useState(0); // Track retry attempts
  const [livenessComplete, setLivenessComplete] = useState(false); // New state to track completion
  const [locationStatus, setLocationStatus] = useState('pending'); 
  // Use refs to persist values across renders
  const sessionIdRef = useRef(null);
  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  const processingIntervalRef = useRef(null);
  
  // Server URL - make sure this matches your Flask server address
  const serverUrl = 'http://10.9.52.21:5003';
  
  // Start webcam
  const startWebcam = async () => {
    try {
      // Check if mediaDevices is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error(
          "Your browser doesn't support camera access. Please try using Chrome, Firefox, or Edge."
        );
      }
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        },
        audio: false
      });
      
      if (webcamRef.current) {
        webcamRef.current.srcObject = stream;
        return new Promise((resolve) => {
          webcamRef.current.onloadedmetadata = () => {
            setStreaming(true);
            resolve(true);
          };
        });
      }
      return false;
    } catch (error) {
      console.error('Error accessing webcam:', error);
      
      // Provide more specific error messages
      if (error.name === 'NotAllowedError') {
        setStatus('Camera access denied. Please allow camera access and try again.');
      } else if (error.name === 'NotFoundError') {
        setStatus('No camera found. Please connect a camera and try again.');
      } else if (error.name === 'NotReadableError') {
        setStatus('Camera is already in use by another application.');
      } else {
        setStatus(`Error accessing webcam: ${error.message}`);
      }
      
      setStatusClass('error');
      return false;
    }
  };
  
  // Stop webcam
  const stopWebcam = () => {
    if (webcamRef.current && webcamRef.current.srcObject) {
      // Stop processing frames when webcam is stopped
      if (processingIntervalRef.current) {
        clearInterval(processingIntervalRef.current);
        processingIntervalRef.current = null;
      }
      
      webcamRef.current.srcObject.getTracks().forEach(track => track.stop());
      webcamRef.current.srcObject = null;
      setStreaming(false);
    }
  };
  
  // Capture frame from webcam
  const captureFrame = () => {
    if (webcamRef.current && webcamRef.current.readyState === webcamRef.current.HAVE_ENOUGH_DATA && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      canvasRef.current.width = webcamRef.current.videoWidth;
      canvasRef.current.height = webcamRef.current.videoHeight;
      context.drawImage(webcamRef.current, 0, 0);
      return canvasRef.current.toDataURL('image/jpeg', 0.8);
    }
    return null;
  };
  
  // Start liveness detection session
  const startLivenessSession = async () => {
    try {
      console.log("Starting liveness session...");
      const response = await fetch(`${serverUrl}/start_liveness`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
      });
      
      const data = await response.json();
      console.log("Liveness session response:", data);
      
      if (data.success) {
        // Store session ID in both state and ref
        setSessionId(data.session_id);
        sessionIdRef.current = data.session_id;
        return data.session_id;
      } else {
        throw new Error(data.error || 'Failed to start liveness session');
      }
    } catch (error) {
      console.error('Error starting liveness session:', error);
      setStatus(`Error: ${error.message}`);
      setStatusClass('error');
      return null;
    }
  };

  const processFrameWithCallback = async (completionCallback) => {
    // Use the ref for session ID to ensure it persists
    const currentSessionId = sessionIdRef.current;
    
    if (!currentSessionId) {
      console.log("No session ID in ref, skipping frame processing");
      return;
    }
    
    const imageData = captureFrame();
    if (!imageData) {
      console.log("No image data captured, skipping frame processing");
      return;
    }
    
    try {
      console.log(`Processing frame for session ${currentSessionId}...`);
      
      // Include location data in the request if available
      const requestData = {
        session_id: currentSessionId,
        image: imageData
      };
      
      // Add location data if available
      if (kycData.geoLocation) {
        requestData.geo_location = kycData.geoLocation;
      }
      
      const response = await fetch(`${serverUrl}/process_liveness_frame`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
      });
      
      const data = await response.json();
      console.log("Frame processing response:", data);
      
      if (data.success) {
        // Update progress bar - calculate based on challenge progress
        if (data.total_challenges > 0) {
          // If liveness is confirmed, set progress to 100%
          if (data.liveness_confirmed) {
            setProgress(100);
          } else {
            // Otherwise calculate based on current challenge
            setProgress((data.current_challenge / data.total_challenges) * 100);
          }
        }
        
        // Update status message
        setStatus(data.message);
        
        // Update current challenge
        setCurrentChallenge(data.current_challenge);
        
        // Update status class
        if (data.status === 'success') {
          setStatusClass('success');
        } else if (data.status === 'failed') {
          setStatusClass('error');
        } else {
          setStatusClass('pending');
        }
        
        // Check if spoofing was detected
        if (data.spoofing_detected) {
          setSpoofingDetected(true);
          setStatusClass('error');
          setLivenessComplete(true);
          
          // Notify callback that processing is complete
          completionCallback(true);
          
          // Stop the webcam
          stopWebcam();
          
          return; // Stop further processing
        }
        
        // Check if we need to stop the webcam
        if (data.stop_webcam) {
          setLivenessComplete(true);
          
          // Notify callback that processing is complete
          completionCallback(true);
          
          // Stop the webcam
          stopWebcam();
          
          return; // Stop further processing
        }
        
        // If image has been captured, display it and prepare for next step
        if (data.image_path) {
          console.log("Image captured, path:", data.image_path);
          
          // Mark liveness check as complete
          setLivenessComplete(true);
          
          // Notify callback that processing is complete
          completionCallback(true);
          
          // Display captured image - use the session ID to get the image
          const capturedImageUrl = `${serverUrl}/get_captured_image/${currentSessionId}`;
          setCapturedImageUrl(capturedImageUrl);
          
          // Get DMS ID if available
          const dmsId = data.dms_id || null;
          
          // Update KYC data with the captured image URL and DMS ID
          updateKycData({
            livenessImage: capturedImageUrl,
            livenessImageDmsId: dmsId,
            livenessSessionId: currentSessionId,
            livenessTimestamp: new Date().toISOString()
          });
          
          // Stop the webcam to free up resources
          stopWebcam();
        }
        
      } else {
        throw new Error(data.error || 'Failed to process frame');
      }
    } catch (error) {
      console.error('Error processing frame:', error);
      setStatus(`Error: ${error.message}`);
      setStatusClass('error');
    }
  }
  
  // Process frame for liveness detection
  const processFrame = async () => {
    // Skip processing if liveness check is already complete
    if (livenessComplete) {
      console.log("Liveness check already complete, skipping frame processing");
      
      // Make sure to clear the interval
      if (processingIntervalRef.current) {
        clearInterval(processingIntervalRef.current);
        processingIntervalRef.current = null;
      }
      return;
    }
    
    // Use the ref for session ID to ensure it persists
    const currentSessionId = sessionIdRef.current;
    
    if (!currentSessionId) {
      console.log("No session ID in ref, skipping frame processing");
      return;
    }
    
    const imageData = captureFrame();
    if (!imageData) {
      console.log("No image data captured, skipping frame processing");
      return;
    }
    
    try {
      console.log(`Processing frame for session ${currentSessionId}...`);
      const response = await fetch(`${serverUrl}/process_liveness_frame`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          session_id: currentSessionId,
          image: imageData
        })
      });
      
      const data = await response.json();
      console.log("Frame processing response:", data);
      
      if (data.success) {
        // Update progress bar - calculate based on challenge progress
        if (data.total_challenges > 0) {
          // If liveness is confirmed, set progress to 100%
          if (data.liveness_confirmed) {
            setProgress(100);
          } else {
            // Otherwise calculate based on current challenge
            setProgress((data.current_challenge / data.total_challenges) * 100);
          }
        }
        
        // Update status message
        setStatus(data.message);
        
        // Update current challenge
        setCurrentChallenge(data.current_challenge);
        
        // Update status class
        if (data.status === 'success') {
          setStatusClass('success');
        } else if (data.status === 'failed') {
          setStatusClass('error');
        } else {
          setStatusClass('pending');
        }
        
        // Check if spoofing was detected
        if (data.spoofing_detected) {
          setSpoofingDetected(true);
          setStatusClass('error');
          setLivenessComplete(true); // Mark as complete to stop processing
          
          // Stop processing frames
          if (processingIntervalRef.current) {
            clearInterval(processingIntervalRef.current);
            processingIntervalRef.current = null;
          }
          
          // Stop the webcam
          stopWebcam();
          
          return; // Stop further processing
        }
        
        // Check if we need to stop the webcam
        if (data.stop_webcam) {
          setLivenessComplete(true); // Mark as complete to stop processing
          
          // Stop processing frames
          if (processingIntervalRef.current) {
            clearInterval(processingIntervalRef.current);
            processingIntervalRef.current = null;
          }
          
          // Stop the webcam
          stopWebcam();
          
          return; // Stop further processing
        }
        
        // If image has been captured, display it and prepare for next step
        if (data.image_path) {
          console.log("Image captured, path:", data.image_path);
          
          // Mark liveness check as complete to prevent further processing
          setLivenessComplete(true);
          
          // Display captured image - use the session ID to get the image
          const capturedImageUrl = `${serverUrl}/get_captured_image/${currentSessionId}`;
          setCapturedImageUrl(capturedImageUrl);
          
          // Get DMS ID if available
          const dmsId = data.dms_id || null;
          
          // Update KYC data with the captured image URL and DMS ID
          updateKycData({
            livenessImage: capturedImageUrl,
            livenessImageDmsId: dmsId,
            livenessSessionId: currentSessionId,
            livenessTimestamp: new Date().toISOString()
          });
          
          // Stop processing frames
          if (processingIntervalRef.current) {
            clearInterval(processingIntervalRef.current);
            processingIntervalRef.current = null;
          }
          
          // Stop the webcam to free up resources
          stopWebcam();
        }
        
      } else {
        throw new Error(data.error || 'Failed to process frame');
      }
    } catch (error) {
      console.error('Error processing frame:', error);
      setStatus(`Error: ${error.message}`);
      setStatusClass('error');
    }
  };
  
  // Complete liveness step
  const completeLivenessStep = (livenessData) => {
    console.log("Completing liveness step with data:", livenessData);
    
    // Make sure the liveness image is stored in kycData for subsequent steps
    updateKycData({
      livenessImage: livenessData.livenessImage,
      livenessImageDmsId: livenessData.livenessImageDmsId,
      livenessSessionId: livenessData.livenessSessionId,
      livenessTimestamp: livenessData.livenessTimestamp,
      geoLocation: livenessData.geoLocation || (kycData ? kycData.geoLocation : undefined)    });
    
    // Move to next step
    nextStep();
  };
  
  // Start liveness check
  const startLivenessCheck = async () => {
    // First, explicitly set livenessComplete to false
    setLivenessComplete(false);
    
    // Reset UI and state
    setStatus('Starting liveness check...');
    setStatusClass('pending');
    setProgress(0);
    setCapturedImageUrl(null);
    // Start webcam
    const webcamStarted = await startWebcam();
    if (!webcamStarted) {
      console.error('Failed to start webcam');
      return;
    }
    
    // Start liveness session
    const newSessionId = await startLivenessSession();
    if (!newSessionId) {
      console.error('Failed to start liveness session');
      stopWebcam();
      return;
    }
    
    // Start processing frames
    console.log("Starting frame processing...");
    setStatus('Preparing liveness check...');
    
    // Use an interval to process frames regularly
    processingIntervalRef.current = setInterval(processFrame, 200); // Process 5 frames per second
  };
  
  // Retry liveness check
  const retryLivenessCheck = () => {
    // Increment retry count
    setRetryCount(retryCount + 1);
    
    // Reset state
    setSpoofingDetected(false);
    setLivenessComplete(false);
    setProgress(0);
    setCapturedImageUrl(null);
    
    // Start liveness check again
    startLivenessCheck();
  };
  
  // Get geolocation
// Get geolocation with timeout
const getGeolocation = () => {
  if (navigator.geolocation) {
    setLocationStatus('loading');
    
    // Set a timeout to prevent hanging
    const timeoutId = setTimeout(() => {
      console.error("Geolocation request timed out");
      setLocationStatus('error');
      setStatus("Location request timed out. Continuing without location.");
      setStatusClass('error');
    }, 10000); // 10 seconds timeout
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        // Clear the timeout since we got a response
        clearTimeout(timeoutId);
        
        const { latitude, longitude } = position.coords;
        console.log("Geolocation obtained:", latitude, longitude);
        
        // Update KYC data with geolocation
        updateKycData({
          geoLocation: { latitude, longitude }
        });
        
        setLocationStatus('success');
        
        // Attempt to get address from coordinates
        fetch(`${serverUrl}/get_location_details`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ latitude, longitude })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success && data.location) {
            console.log("Location details:", data.location);
            
            // Update KYC data with address
            updateKycData({
              geoLocation: { 
                latitude, 
                longitude,
                address: data.location
              }
            });
          }
        })
        .catch(error => {
          console.error("Error getting location details:", error);
          // Continue anyway, we have the coordinates
        });
      },
      (error) => {
        // Clear the timeout since we got a response
        clearTimeout(timeoutId);
        
        console.error("Error getting geolocation:", error);
        setLocationStatus('error');
        
        let errorMessage = "Unknown error";
        switch(error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location access denied. Please enable location services.";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information is unavailable.";
            break;
          case error.TIMEOUT:
            errorMessage = "Location request timed out.";
            break;
        }
        
        setStatus(errorMessage);
        setStatusClass('error');
      },
      {
        enableHighAccuracy: false, // Set to false for faster response
        timeout: 8000,            // 8 seconds timeout
        maximumAge: 30000         // Accept cached positions up to 30 seconds old
      }
    );
  } else {
    console.error("Geolocation is not supported by this browser");
    setLocationStatus('error');
    setStatus("Geolocation is not supported by your browser");
    setStatusClass('error');
  }
};

  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      // Stop webcam and clear intervals when component unmounts
      stopWebcam();
      if (processingIntervalRef.current) {
        clearInterval(processingIntervalRef.current);
      }
    };
  }, []);
  
  // Check if we already have liveness data
  useEffect(() => {
    if (kycData && (kycData.livenessImage || kycData.livenessImageDmsId)) {
      console.log("Existing liveness data found:", kycData.livenessImage || kycData.livenessImageDmsId);
      setLivenessComplete(true);
      setStatus('Liveness check already completed');
      setStatusClass('success');
      setProgress(100);
      
      // If we have a DMS ID, use that to display the image
      if (kycData.livenessImageDmsId) {
        setCapturedImageUrl(`http://10.9.52.21:5001/get_dms_image/${kycData.livenessImageDmsId}`);
      } else {
        setCapturedImageUrl(kycData.livenessImage);
      }
    }

    
    // Check if we already have geolocation
  if (kycData && kycData.geoLocation) {
    console.log("Existing geolocation found:", kycData.geoLocation);
    setLocationStatus('success');
  } else {
    // Get geolocation on component mount
    getGeolocation();
  }

  }, [kycData]);
  
  // Render the component
  return (
    <div className="liveness-check">
      <h2>Liveness Check</h2>
      
      <div className="liveness-container">
        <div className="webcam-container">
          {!livenessComplete ? (
            <>
              <video 
                ref={webcamRef} 
                autoPlay 
                playsInline 
                className={streaming ? 'active' : 'hidden'}
              />
              <canvas ref={canvasRef} className="hidden" />
              
              {!streaming && (
                <div className="webcam-placeholder">
                  <div className="camera-icon">
                    <i className="fas fa-camera"></i>
                  </div>
                  <p>Camera will appear here</p>
                </div>
              )}
            </>
          ) : (
            <div className="captured-image-container">
              {capturedImageUrl ? (
                <img 
                  src={capturedImageUrl} 
                  alt="Captured" 
                  className="captured-image" 
                />
              ) : (
                <div className="no-image">
                  <p>No image captured</p>
                </div>
              )}
            </div>
          )}
        </div>
        
        <div className="liveness-controls">
          <div className={`status-message ${statusClass}`}>
            {status}
          </div>
          
          {currentChallenge && (
            <div className="challenge-container">
              <h3>Current Challenge</h3>
              <div className="challenge-description">
                {currentChallenge}
              </div>
            </div>
          )}
          
          <div className="progress-container">
            <div 
              className="progress-bar" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          
          <div className="location-status">
            <p>
              <i className={`fas fa-map-marker-alt ${locationStatus}`}></i>
              {locationStatus === 'loading' && 'Getting location...'}
              {locationStatus === 'success' && 'Location captured'}
              {locationStatus === 'error' && 'Location error'}
            </p>
            
            {kycData && kycData.geoLocation && kycData.geoLocation.address && (
              <p className="location-address">
                {kycData.geoLocation.address}
              </p>
            )}

          </div>
          
          <div className="button-container">
            {!streaming && !livenessComplete && (
              <button 
                className="start-button"
                onClick={startLivenessCheck}
              >
                Start Liveness Check
              </button>
            )}
            
            {spoofingDetected && (
              <button 
                className="retry-button"
                onClick={retryLivenessCheck}
                disabled={retryCount >= 3}
              >
                {retryCount >= 3 ? 'Too many attempts' : 'Retry Liveness Check'}
              </button>
            )}
            
            {livenessComplete && !spoofingDetected && (
              <button 
                className="next-button"
                onClick={() => {
                  // Prepare data for the next step
                  const livenessData = {
                    livenessImage: capturedImageUrl,
                    livenessImageDmsId: kycData.livenessImageDmsId,
                    livenessSessionId: sessionId,
                    livenessTimestamp: new Date().toISOString(),
                    geoLocation: kycData.geoLocation
                  };
                  
                  // Complete liveness step
                  completeLivenessStep(livenessData);
                }}
              >
                Continue to Next Step
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LivenessCheck;
