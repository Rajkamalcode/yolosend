import './globals.css';
import { Inter, JetBrains_Mono } from 'next/font/google';
import Link from 'next/link';

const sans = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const mono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata = {
  title: 'Property Document Comparison',
  description: 'Compare property documents and check similarity',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${sans.variable} ${mono.variable}`}>
      <body className="bg-gray-50 min-h-screen">
        <header className="bg-white shadow">
          <div className="container mx-auto px-4 py-4">
            <nav className="flex justify-between items-center">
              <Link href="/" className="text-xl font-bold">
                Property Document Analyzer
              </Link>
              <div className="space-x-4">
                <Link href="/document-comparison" className="hover:underline">
                  New Comparison
                </Link>
                <Link href="/sessions" className="hover:underline">
                  Sessions
                </Link>
              </div>
            </nav>
          </div>
        </header>
        <main>{children}</main>
      </body>
    </html>
  );
}
