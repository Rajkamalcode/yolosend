import { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import documentService, { ChatRequest } from '../services/documentService';

interface Props {
  sessionId: string;
  initialChatHistory?: Array<{
    role: string;
    content: string;
  }>;
}

export default function DocumentChat({ sessionId, initialChatHistory = [] }: Props) {
  const [chatHistory, setChatHistory] = useState(initialChatHistory);
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!query.trim()) return;
    
    try {
      setIsLoading(true);
      setError(null);
      
      const chatRequest: ChatRequest = {
        session_id: sessionId,
        query: query.trim(),
        chat_history: chatHistory,
      };
      
      const response = await documentService.chat(chatRequest);
      setChatHistory(response.chat_history);
      setQuery('');
    } catch (err: any) {
      setError(err.response?.data?.error || 'An error occurred while processing your question');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 bg-white rounded-lg shadow">
      <h2 className="text-xl font-bold mb-4">Ask Follow-up Questions</h2>
      
      <div className="mb-4 h-96 overflow-y-auto border rounded p-4">
        {chatHistory.length === 0 ? (
          <p className="text-gray-500 italic">No messages yet. Ask a question about the documents.</p>
        ) : (
          <div className="space-y-4">
            {chatHistory.map((message, index) => (
              <div 
                key={index} 
                className={`p-3 rounded-lg ${
                  message.role === 'user' 
                    ? 'bg-blue-100 ml-8' 
                    : 'bg-gray-100 mr-8'
                }`}
              >
                <p className="text-xs font-semibold mb-1">
                  {message.role === 'user' ? 'You' : 'Assistant'}
                </p>
                
                {message.role === 'user' ? (
                  <p>{message.content}</p>
                ) : (
                  <div className="prose max-w-none">
                    <ReactMarkdown
                      remarkPlugins={[remarkGfm]}
                      rehypePlugins={[rehypeRaw]}
                    >
                      {message.content}
                    </ReactMarkdown>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      
      {error && (
        <div className="mb-4 p-2 bg-red-100 border border-red-400 text-red-700 rounded">
          {error}
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask a question about the documents..."
          className="flex-1 p-2 border rounded"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !query.trim()}
          className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded
                    disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Sending...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
