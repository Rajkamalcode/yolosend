import { useState } from 'react';
import documentService from '../services/documentService';

interface Props {
  onProcessingComplete: (sessionData: any) => void;
  setIsLoading: (loading: boolean) => void;
}

export default function DocumentUpload({ onProcessingComplete, setIsLoading }: Props) {
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const fileArray = Array.from(e.target.files);
      setFiles(fileArray);
      setError(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (files.length < 2) {
      setError('Please upload at least two documents for comparison');
      return;
    }
    
    try {
      setIsLoading(true);
      setError(null);
      
      const result = await documentService.processDocuments(files);
      onProcessingComplete(result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'An error occurred while processing the documents');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-4 bg-white rounded-lg shadow">
      <h2 className="text-xl font-bold mb-4">Upload Property Documents</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select PDF or TXT files (minimum 2)
          </label>
          <input
            type="file"
            multiple
            accept=".pdf,.txt"
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-500
                      file:mr-4 file:py-2 file:px-4
                      file:rounded-md file:border-0
                      file:text-sm file:font-semibold
                      file:bg-blue-50 file:text-blue-700
                      hover:file:bg-blue-100"
          />
          <p className="mt-1 text-sm text-gray-500">
            Selected files: {files.length}
          </p>
        </div>
        
        {error && (
          <div className="mb-4 p-2 bg-red-100 border border-red-400 text-red-700 rounded">
            {error}
          </div>
        )}
        
        <button
          type="submit"
          disabled={files.length < 2}
          className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg
                    disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          Process Documents
        </button>
      </form>
    </div>
  );
}