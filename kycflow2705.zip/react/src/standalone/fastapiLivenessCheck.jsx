import React, { useState, useRef, useEffect, useCallback } from 'react';
import '../components/LivenessCheck.css';

const FastapiLivenessCheck = () => { // Renamed component to match file name
  const [streaming, setStreaming] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [status, setStatus] = useState('Ready to start liveness check');
  const [statusClass, setStatusClass] = useState('pending');
  const [progress, setProgress] = useState(0);
  const [capturedDmsId, setCapturedDmsId] = useState(null);
  const [capturedImageUrl, setCapturedImageUrl] = useState(null);
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [spoofingDetected, setSpoofingDetected] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [livenessComplete, setLivenessComplete] = useState(false);
  const [locationStatus, setLocationStatus] = useState('pending');
  const [originData, setOriginData] = useState(null);
  const [geoPermissionGranted, setGeoPermissionGranted] = useState(false);
  const [mode, setMode] = useState('liveness'); // 'liveness' or 'property'
  const [propertyPhotoUrl, setPropertyPhotoUrl] = useState(null);
  const [propertyDmsId, setPropertyDmsId] = useState(null);
  const [propertyPhotoStatus, setPropertyPhotoStatus] = useState('ready');
  const [useWebSocket, setUseWebSocket] = useState(false);
  const [wsConnected, setWsConnected] = useState(false);
  const serverCheckedRef = useRef(false);
  // Use refs to persist values across renders
  const sessionIdRef = useRef(null);
  const webcamRef = useRef(null);
  const canvasRef = useRef(null);
  const processingIntervalRef = useRef(null);
  const webSocketRef = useRef(null);

  // Server URL - make sure this matches your FastAPI server address
  const serverUrl = 'http://127.0.0.1:5103';
  const wsUrl = 'ws://127.0.0.1:5103';

  // Get geolocation data
  const getGeolocation = useCallback(() => {
    // Skip if we already have permission
    if (geoPermissionGranted) {
      console.log("Geolocation permission already granted, skipping request");
      // If WS is already connected and we just got geo, send it
      if (useWebSocket && webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN && originData?.geoLocation) {
         console.log("Sending existing geolocation via WebSocket");
         webSocketRef.current.send(JSON.stringify({ geo_location: originData.geoLocation }));
      }
      return;
    }

    if (navigator.geolocation) {
      setLocationStatus('requesting');
      console.log("Requesting geolocation permission...");

      navigator.geolocation.getCurrentPosition(
        (position) => {
          // Store the full precision values
          const geoData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date().toISOString()
          };

          console.log("Geolocation obtained:", geoData);
          setLocationStatus('captured');
          setGeoPermissionGranted(true);

          // Store the geolocation data
          const updatedOriginData = {
            ...originData, // Keep existing origin, callback, etc.
            geoLocation: geoData
          };
          setOriginData(updatedOriginData);

          // If using WebSocket and connected, send geolocation data immediately
          if (useWebSocket && webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN) {
            console.log("Sending newly obtained geolocation via WebSocket");
            webSocketRef.current.send(JSON.stringify({ geo_location: geoData }));
          }
        },
        (error) => {
          console.error("Geolocation error:", error);
          setLocationStatus('error');

          let errorMessage = "Location access error";
          switch(error.code) {
            case error.PERMISSION_DENIED:
              errorMessage = "Location permission denied. Please enable location access.";
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage = "Location information unavailable.";
              break;
            case error.TIMEOUT:
              errorMessage = "Location request timed out.";
              break;
            default:
              errorMessage = "Unknown location error occurred.";
          }
          setStatus(errorMessage);
          setStatusClass('error');
        },
        {
          enableHighAccuracy: true,  // Request high accuracy
          timeout: 10000,            // 10 second timeout
          maximumAge: 0              // Don't use cached position
        }
      );
    } else {
      console.warn("Geolocation not supported by this browser");
      setLocationStatus('error');
      setStatus("Your browser doesn't support geolocation.");
      setStatusClass('error');
    }
  }, [geoPermissionGranted, useWebSocket, originData]); // Added originData to dependencies

  // Parse URL parameters on component mount
  useEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const origin = queryParams.get('origin');
    const callbackUrl = queryParams.get('callbackUrl');
    const requestId = queryParams.get('requestId');
    const token = queryParams.get('token');
    const captureMode = queryParams.get('mode'); // 'liveness' or 'property'
    const wsParam = queryParams.get('ws'); // 'true' or 'false'

    // Check if WebSocket should be used
    if (wsParam === 'true') {
      setUseWebSocket(true);
    } else {
      setUseWebSocket(false); // Explicitly set to false if not 'true'
    }

    if (captureMode === 'property') {
      setMode('property');
    } else {
      setMode('liveness'); // Default to liveness
    }

    if (origin && callbackUrl) {
      setOriginData({
        origin,
        callbackUrl,
        requestId,
        token
      });
      console.log(`Standalone mode initialized with origin: ${origin}, callback: ${callbackUrl}`);
    } else {
      console.warn('Missing required parameters for standalone mode');
      setStatus('Missing required parameters for standalone mode');
      setStatusClass('error');
    }
  }, []); // Dependencies: [] means run once on mount

  // Request geolocation on component mount or when originData/mode/ws changes
  useEffect(() => {
    // Only request if originData is available and we haven't granted permission yet
    if (originData && !geoPermissionGranted) {
       getGeolocation();
    } else if (originData && geoPermissionGranted && useWebSocket && webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN && originData?.geoLocation && !originData.geoLocationSent) {
       // If geo is already granted and WS is connected, send it now
       console.log("Sending existing geolocation via WebSocket after WS connect");
       webSocketRef.current.send(JSON.stringify({ geo_location: originData.geoLocation }));
       // Mark as sent to avoid resending
       setOriginData(prevData => ({ ...prevData, geoLocationSent: true }));
    }
  }, [originData, geoPermissionGranted, getGeolocation, useWebSocket, wsConnected]); // Added dependencies

  // Initialize WebSocket connection
  const initializeWebSocket = useCallback((sessionId) => {
    if (!useWebSocket || webSocketRef.current) {
      console.log("WebSocket not enabled or already initialized.");
      return;
    }

    console.log(`Attempting to connect WebSocket to ${wsUrl}/ws/liveness/${sessionId}`);
    const ws = new WebSocket(`${wsUrl}/ws/liveness/${sessionId}`);

    ws.onopen = () => {
      console.log('WebSocket connection opened');
      setWsConnected(true);
      setStatus('WebSocket connected. Ready to start.');
      setStatusClass('pending');

      // If geolocation is already captured, send it immediately after connecting
      if (originData?.geoLocation && !originData.geoLocationSent) {
         console.log("Sending captured geolocation via WebSocket on open");
         ws.send(JSON.stringify({ geo_location: originData.geoLocation }));
         // Mark as sent
         setOriginData(prevData => ({ ...prevData, geoLocationSent: true }));
      }
    };

    ws.onmessage = (event) => {
      console.log('WebSocket message received:', event.data);
      try {
        const message = JSON.parse(event.data);
        // Handle different message types from the server
        if (message.type === 'liveness_update') {
           // Update state based on server message
           setStatus(message.message);
           setStatusClass(message.status);
           setProgress(message.progress || 0);
           setCurrentChallenge(message.current_challenge);
           setSpoofingDetected(message.spoofing_detected || false);
           setLivenessComplete(message.liveness_complete || false);

           if (message.stop_webcam) {
              stopWebcam();
           }

           if (message.dms_id) {
              setCapturedDmsId(message.dms_id);
              const capturedImageUrl = `${serverUrl}/get_captured_image/${message.dms_id}`;
              setCapturedImageUrl(capturedImageUrl);
              // Liveness is complete when image is captured
              setLivenessComplete(true);
              // Send final result to origin
              sendResultToOrigin({
                 success: !message.spoofing_detected,
                 status: message.status,
                 dms_id: message.dms_id,
                 session_id: sessionId,
                 type: 'liveness',
                 spoofing_detected: message.spoofing_detected,
                 spoofing_reason: message.spoofing_reason,
                 // Include geolocation if available
                 geoLocation: originData?.geoLocation
              });
           }
        } else if (message.type === 'property_photo_update') {
            // Handle property photo updates if needed via WS
            setStatus(message.message);
            setStatusClass(message.status);
            if (message.dms_id) {
                setPropertyDmsId(message.dms_id);
                const photoUrl = `${serverUrl}/get_property_photo/${message.dms_id}`;
                setPropertyPhotoUrl(photoUrl);
                setPropertyPhotoStatus('success');
                stopWebcam();
                // Send final result to origin
                sendResultToOrigin({
                   success: true,
                   status: 'success',
                   type: 'property_photo',
                   dms_id: message.dms_id,
                   photo_id: message.photo_id, // Assuming photo_id is returned
                   // Include geolocation if available
                   geoLocation: originData?.geoLocation
                });
            } else if (message.status === 'error') {
                 setPropertyPhotoStatus('error');
                 setStatus(`Error: ${message.message}`);
                 setStatusClass('error');
            }
        } else if (message.geo_location_received) {
           console.log("Server confirmed geolocation received.");
           // Mark as sent
           setOriginData(prevData => ({ ...prevData, geoLocationSent: true }));
        }
        // Add other message types as needed
      } catch (e) {
        console.error("Error parsing WebSocket message:", e);
      }
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      setWsConnected(false);
      // Only show fallback message if WS was initially enabled
      if (useWebSocket) {
         setStatus("WebSocket connection error. Falling back to HTTP.");
         setStatusClass('error');
         // Do NOT set useWebSocket(false) here, as it might trigger re-renders
         // and complex state issues. The processFrameWithCallback will check
         // wsConnected state instead.
      }
    };

    ws.onclose = (event) => {
      console.log('WebSocket connection closed:', event.code, event.reason);
      setWsConnected(false);
      // If liveness is not complete and WS was expected, show a message
      if (useWebSocket && !livenessComplete && !spoofingDetected) {
         setStatus("WebSocket connection closed. Falling back to HTTP.");
         setStatusClass('error');
      }
      // The interval will continue running and use HTTP if WS is not connected
    };

    webSocketRef.current = ws;

    // Clean up WebSocket on component unmount
    return () => {
      console.log("Closing WebSocket connection");
      if (webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN) {
        webSocketRef.current.close();
      }
    };
  }, [useWebSocket, originData, livenessComplete, spoofingDetected, serverUrl, wsUrl, getGeolocation]); // Added dependencies
  // Stop webcam
  // Stop webcam
  const stopWebcam = useCallback(() => {
    console.log("Stopping webcam");
    if (webcamRef.current && webcamRef.current.srcObject) {
      webcamRef.current.srcObject.getTracks().forEach(track => track.stop());
      webcamRef.current.srcObject = null;
      setStreaming(false);
    }
    // Always clear interval when stopping webcam
    if (processingIntervalRef.current) {
        clearInterval(processingIntervalRef.current);
        processingIntervalRef.current = null;
    }
     // Close WebSocket if open
    if (webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN) {
        webSocketRef.current.close();
        webSocketRef.current = null;
        setWsConnected(false);
    }
  }, [webcamRef, processingIntervalRef, setStreaming, webSocketRef, setWsConnected]); // Add dependencies


  // Start webcam
  // Start webcam
  const startWebcam = useCallback(async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error(
          "Your browser doesn't support camera access. Please try using Chrome, Firefox, or Edge."
        );
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        },
        audio: false
      });

      if (webcamRef.current) {
        webcamRef.current.srcObject = stream;
        return new Promise((resolve) => {
          webcamRef.current.onloadedmetadata = () => {
            setStreaming(true);
            resolve(true);
          };
        });
      }
      return false;
    } catch (error) {
      console.error('Error accessing webcam:', error);

      if (error.name === 'NotAllowedError') {
        setStatus('Camera access denied. Please allow camera access and try again.');
      } else if (error.name === 'NotFoundError') {
        setStatus('No camera found. Please connect a camera and try again.');
      } else if (error.name === 'NotReadableError') {
        setStatus('Camera is already in use by another application.');
      } else {
        setStatus(`Error accessing webcam: ${error.message}`);
      }

      setStatusClass('error');
      return false;
    }
  }, [webcamRef, canvasRef, setStreaming, setStatus, setStatusClass, stopWebcam]); // Add dependencies



  // Capture frame from webcam
  const captureFrame = () => {
    if (webcamRef.current && webcamRef.current.readyState === webcamRef.current.HAVE_ENOUGH_DATA && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      // Set canvas dimensions to match video feed
      canvasRef.current.width = webcamRef.current.videoWidth;
      canvasRef.current.height = webcamRef.current.videoHeight;
      // Draw the current frame from the video onto the canvas
      context.drawImage(webcamRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height);
      // Get the image data as a base64 encoded JPEG
      return canvasRef.current.toDataURL('image/jpeg', 0.8); // 0.8 quality
    }
    return null;
  };

  // Start liveness detection session (HTTP call)
  const startLivenessSession = async () => {
    try {
      console.log("Starting liveness session...");
      const response = await fetch(`${serverUrl}/start_liveness`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({}) // Send empty body or initial data if needed
      });

      const data = await response.json();
      console.log("Liveness session response:", data);

      if (data.success) {
        setSessionId(data.session_id);
        sessionIdRef.current = data.session_id; // Update ref immediately
        return data.session_id;
      } else {
        throw new Error(data.error || 'Failed to start liveness session');
      }
    } catch (error) {
      console.error('Error starting liveness session:', error);
      setStatus(`Error: ${error.message}`);
      setStatusClass('error');
      return null;
    }
  };

  // Process frame with callback (sends via WS or HTTP)
  const processFrameWithCallback = async () => { // Removed completionCallback as WS handles completion
    const currentSessionId = sessionIdRef.current;

    if (!currentSessionId) {
      console.log("No session ID in ref, skipping frame processing");
      return;
    }

    const imageData = captureFrame();
    if (!imageData) {
      console.log("No image data captured, skipping frame processing");
      return;
    }

    // Prepare request data with geo location if available
    const requestData = {
      session_id: currentSessionId,
      image: imageData
    };

    // Add geo location if available and not sent yet (primarily for HTTP fallback)
    if (originData && originData.geoLocation && !originData.geoLocationSent) {
      requestData.geo_location = originData.geoLocation;
      console.log("Including geolocation data in frame request:", originData.geoLocation);
      // Mark as sent if sending via HTTP
      if (!wsConnected) {
         setOriginData(prevData => ({ ...prevData, geoLocationSent: true }));
      }
    }

    try {
      if (useWebSocket && wsConnected && webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN) {
        // Send frame data via WebSocket
        console.log(`Sending frame via WebSocket for session ${currentSessionId}...`);
        webSocketRef.current.send(JSON.stringify({ frame: imageData })); // Send frame data
        // Geolocation is sent separately on WS open or geo capture
      } else {
        // Fallback to HTTP if WebSocket is not enabled or not connected
        console.log(`Processing frame via HTTP for session ${currentSessionId}...`);
        const response = await fetch(`${serverUrl}/process_liveness_frame`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(requestData)
        });

        const data = await response.json();
        console.log("HTTP frame processing response:", data);

        // Update state based on HTTP response (similar to WS message handling)
        if (data.success) {
           setStatus(data.message);
           setStatusClass(data.status);
           setProgress(data.progress || 0);
           setCurrentChallenge(data.current_challenge);
           setSpoofingDetected(data.spoofing_detected || false);
           setLivenessComplete(data.liveness_complete || false);

           if (data.stop_webcam) {
              stopWebcam();
           }

           if (data.dms_id) {
              setCapturedDmsId(data.dms_id);
              const capturedImageUrl = `${serverUrl}/get_captured_image/${data.dms_id}`;
              setCapturedImageUrl(capturedImageUrl);
              setLivenessComplete(true); // Liveness complete on capture
              // Send final result to origin
              sendResultToOrigin({
                 success: !data.spoofing_detected,
                 status: data.status,
                 dms_id: data.dms_id,
                 session_id: currentSessionId,
                 type: 'liveness',
                 spoofing_detected: data.spoofing_detected,
                 spoofing_reason: data.spoofing_reason,
                 // Include geolocation if available
                 geoLocation: originData?.geoLocation
              });
           }
        } else {
           // Handle HTTP error response
           setStatus(`Error: ${data.error || 'Failed to process frame via HTTP'}`);
           setStatusClass('error');
           // Consider stopping or retrying on persistent errors
        }
      }
    } catch (error) {
      console.error('Error processing frame:', error);
      setStatus(`Error: ${error.message}`);
      setStatusClass('error');
      // Consider stopping or retrying on persistent errors
    }
  };

  // Send result back to origin website
  const sendResultToOrigin = (result) => {
    if (!originData || !originData.origin) {
      console.warn('Cannot send result: missing origin data');
      return;
    }

    console.log('Sending result to origin:', originData.origin);
    console.log('Result data:', result);

    // Add request ID if provided
    if (originData.requestId) {
      result.requestId = originData.requestId;
    }

    // Add geolocation data if available (ensure it's the original captured data)
    if (originData.geoLocation) {
      result.geoLocation = originData.geoLocation;
    }
    // Method 1: Using postMessage if opened in iframe/popup
    try {
      console.log('Attempting to use postMessage to:', originData.origin);

      // Try to send to opener if it exists (popup mode)
      if (window.opener) {
        console.log('Window opener exists, sending via postMessage');
        window.opener.postMessage({
          type: 'LIVENESS_RESULT',
          data: result
        }, '*'); // Use * to avoid origin issues, or specify originData.origin if known and safe
        console.log('Result sent via postMessage to opener');
      }
      // Try to send to parent if it exists (iframe mode)
      else if (window.parent && window.parent !== window) {
        console.log('Window parent exists, sending via postMessage');
        window.parent.postMessage({
          type: 'LIVENESS_RESULT',
          data: result
        }, '*'); // Use * to avoid origin issues, or specify originData.origin if known and safe
        console.log('Result sent via postMessage to parent');
      }
    } catch (e) {
      console.warn('Could not send via postMessage:', e);
    }

    // Method 2: Using callback URL with query parameters (less reliable for complex data/file://)
    // This method is less preferred than postMessage for standalone mode,
    // but kept for potential compatibility or alternative use cases.
    // Note: Sending complex JSON via URL query params is limited.
    // A better approach for callbackUrl might be to send the session_id
    // and let the origin page fetch the result from the server.
    if (originData.callbackUrl && !originData.callbackUrl.startsWith('file://')) {
      try {
        console.log('Attempting to use callback URL (POST fetch):', originData.callbackUrl);

        // Send the result to the callback URL via POST request
        fetch(originData.callbackUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(result)
        })
        .then(response => {
          console.log('Result sent via fetch, response:', response.status);
          // If successful, also complete the session on our backend if needed
          // (This might be redundant if the server already marked it complete via WS)
          // if (response.ok && result.success && result.dms_id && sessionIdRef.current) {
          //   return fetch(`${serverUrl}/complete_standalone_session/${sessionIdRef.current}`, {
          //     method: 'POST',
          //     headers: { 'Content-Type': 'application/json' },
          //     body: JSON.stringify({
          //       liveness_confirmed: result.liveness_confirmed,
          //       dms_id: result.dms_id
          //     })
          //   });
          // }
        })
        .catch(error => {
          console.error('Error sending result to callback URL (fetch):', error);
        });
      } catch (e) {
        console.warn('Could not send via callback URL (fetch):', e);
      }
    } else if (originData.callbackUrl && originData.callbackUrl.startsWith('file://')) {
        console.warn('Callback URL is a file:// URL. Cannot send POST request. Relying on postMessage.');
    }


    // Auto-close window after sending result (if opened as popup)
    // Add a small delay to allow messages/requests to send
    setTimeout(() => {
      if (window.opener) {
        console.log("Closing popup window.");
        window.close();
      }
    }, 2000); // 2 second delay
  };

  // Start liveness check
  // Start liveness check
  const startLivenessCheck = useCallback(async () => {
    setLivenessComplete(false);
    setSpoofingDetected(false); // Reset spoofing state on retry/start

    // Reset UI and state
    setStatus('Starting liveness check...');
    setStatusClass('pending');
    setProgress(0);
    setCapturedImageUrl(null);
    setCapturedDmsId(null);
    setCurrentChallenge(null); // Reset challenge display

    // Start webcam if not already streaming
    if (!streaming) {
      const webcamStarted = await startWebcam();
      if (!webcamStarted) return; // Stop if webcam failed to start
    }

    // Start liveness session (HTTP call is still needed to get session ID)
    const newSessionId = await startLivenessSession();
    if (!newSessionId) {
        stopWebcam(); // Stop webcam if session creation failed
        return; // Stop if session creation failed
    }

    // Initialize WebSocket if enabled *after* getting session ID
    if (useWebSocket) {
      // initializeWebSocket handles connection and sending initial geo
      initializeWebSocket(newSessionId);
      console.log("Attempting to use WebSocket for frame processing");
    } else {
      console.log("Using HTTP for frame processing");
      // If not using WS, ensure geo is sent with the first frame if available
      if (originData?.geoLocation && !originData.geoLocationSent) {
         // Mark as sent now, it will be included in the first frame POST
         setOriginData(prevData => ({ ...prevData, geoLocationSent: true }));
      }
    }

    console.log(`Starting frame processing interval for session ${newSessionId}`);

    // Clear any existing interval
    if (processingIntervalRef.current) {
      clearInterval(processingIntervalRef.current);
      processingIntervalRef.current = null;
    }

    // Start processing frames interval (for both HTTP and WS)
    processingIntervalRef.current = setInterval(() => {
      // Only process if webcam is streaming and liveness is not complete
      if (streaming && !livenessComplete && !spoofingDetected) {
         // processFrameWithCallback handles capturing and sending via WS or HTTP internally
         processFrameWithCallback(); // No completion callback needed here anymore
      } else if (!streaming && processingIntervalRef.current) {
         // If streaming stops unexpectedly, clear interval
         console.log("Streaming stopped, clearing interval");
         clearInterval(processingIntervalRef.current);
         processingIntervalRef.current = null;
      } else if ((livenessComplete || spoofingDetected) && processingIntervalRef.current) {
         // If liveness is complete or spoofing detected, clear interval
         console.log("Liveness complete or spoofing detected, clearing interval");
         clearInterval(processingIntervalRef.current);
         processingIntervalRef.current = null;
      }
    }, 100); // Process frame every 100ms (10 FPS)
  }, [
      streaming, startWebcam, startLivenessSession, useWebSocket, initializeWebSocket,
      originData, processingIntervalRef, livenessComplete, spoofingDetected,
      processFrameWithCallback, stopWebcam, setLivenessComplete, setSpoofingDetected,
      setStatus, setStatusClass, setProgress, setCapturedImageUrl, setCapturedDmsId,
      setCurrentChallenge, setSessionId, sessionIdRef, setWsConnected, setOriginData // Added setOriginData
  ]); // Add dependencies


  // Capture property photo
  const capturePropertyPhoto = async () => {
    if (!streaming) {
      const webcamStarted = await startWebcam();
      if (!webcamStarted) return;
    }

    // Capture a single frame
    const imageData = captureFrame();
    if (!imageData) {
      setStatus('Failed to capture image');
      setStatusClass('error');
      return;
    }

    // Check if we have geolocation data before proceeding
    if (!originData?.geoLocation) {
      setStatus('Geolocation data is required for property photos');
      setStatusClass('error');
      return;
    }

    setPropertyPhotoStatus('uploading');
    setStatus('Uploading property photo...');
    setStatusClass('pending');

    try {
      // Send the image and geolocation to the server via HTTP POST
      console.log("Sending property photo via HTTP POST...");
      const response = await fetch(`${serverUrl}/capture_property_photo`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          image: imageData,
          geo_location: originData.geoLocation,
          requestId: originData.requestId // Include requestId if available
        })
      });

      const data = await response.json();
      console.log("Property photo upload response:", data);

      if (data.success) {
        setPropertyPhotoStatus('success');
        setStatus('Property photo captured successfully!');
        setStatusClass('success');
        setPropertyDmsId(data.dms_id);

        // Display the captured image
        const photoUrl = `${serverUrl}/get_property_photo/${data.dms_id}`;
        setPropertyPhotoUrl(photoUrl);

        // Stop the webcam and interval
        stopWebcam();

        // Send result to origin
        sendResultToOrigin({
          success: true,
          status: 'success',
          type: 'property_photo',
          dms_id: data.dms_id,
          photo_id: data.photo_id, // Assuming photo_id is returned by FastAPI
          // Include geolocation if available
          geoLocation: originData.geoLocation,
          requestId: originData.requestId
        });
      } else {
        throw new Error(data.error || 'Failed to upload property photo');
      }
    } catch (error) {
      console.error('Error capturing property photo:', error);
      setPropertyPhotoStatus('error');
      setStatus(`Error: ${error.message}`);
      setStatusClass('error');
      // Consider stopping webcam or allowing retry
      // stopWebcam(); // Decide if webcam should stop on error
    }
  };


  // Stop liveness check (User initiated cancel)
  const stopLivenessCheck = () => {
    console.log("Stopping liveness check (user cancelled)");
    setLivenessComplete(true); // Mark as complete to stop interval/WS processing
    setSpoofingDetected(false); // Ensure spoofing is false on cancel

    // Clear interval and stop webcam
    stopWebcam(); // This also clears the interval and closes WS

    setSessionId(null);
    sessionIdRef.current = null;

    setStatus('Verification cancelled by user');
    setStatusClass('pending'); // Or 'cancelled' if you have that style
    setProgress(0);
    setCapturedImageUrl(null);
    setPropertyPhotoUrl(null); // Clear property photo preview on cancel
    setPropertyDmsId(null);
    setPropertyPhotoStatus('ready'); // Reset property photo status

    // Send cancellation result to origin
    sendResultToOrigin({
      success: false,
      status: 'cancelled',
      reason: 'User cancelled the verification',
      requestId: originData?.requestId,
      type: mode, // Indicate which mode was cancelled
      // Include geolocation if available
      geoLocation: originData?.geoLocation
    });
  };

  // Handle retry for Liveness (after spoofing or failure)
  const handleRetry = () => {
    // Increment retry count
    const newRetryCount = retryCount + 1;
    setRetryCount(newRetryCount);

    // If we've reached max retries, send failure and close
    if (newRetryCount >= 3) {
      setStatus('Maximum retry attempts reached. Verification failed.');
      setStatusClass('error');
      setLivenessComplete(true); // Ensure UI reflects completion/failure

      sendResultToOrigin({
        success: false,
        status: 'failed',
        reason: 'Maximum retry attempts reached',
        requestId: originData?.requestId,
        type: 'liveness',
        // Include geolocation if available
        geoLocation: originData?.geoLocation
      });

      // Auto-close after a delay if in popup mode
      setTimeout(() => {
        if (window.opener) {
          console.log("Closing popup window after max retries.");
          window.close();
        }
      }, 3000); // 3 second delay

    } else {
      // First, stop everything
      stopWebcam(); // This clears interval and closes WS

      // Reset all relevant states for a fresh start
      setSpoofingDetected(false);
      setLivenessComplete(false);
      setSessionId(null);
      sessionIdRef.current = null;
      setCapturedImageUrl(null);
      setCapturedDmsId(null);
      setProgress(0);
      setCurrentChallenge(null);
      setStatus('Restarting verification...');
      setStatusClass('pending');
      setWsConnected(false); // Reset WS connection state

      // Use setTimeout to ensure state updates have been applied before restarting
      setTimeout(() => {
        console.log(`Attempting retry ${newRetryCount}/3`);
        // Start fresh
        // Re-request geolocation if it wasn't successfully captured initially
        if (!geoPermissionGranted) {
            getGeolocation();
        }
        // Start the process again
        if (mode === 'liveness') {
            startLivenessCheck();
        } else if (mode === 'property') {
            // For property, just restart webcam and allow capture
            startWebcam();
            setPropertyPhotoStatus('ready');
            setStatus('Ready to capture property photo.');
            setStatusClass('pending');
        }
      }, 500); // Small delay before restarting
    }
  };

  // Get challenge name based on index (adjust based on your FastAPI challenges)
  const getChallengeName = (index) => {
    // Assuming your FastAPI sends challenge index 0 for Blink, 1 for Mouth Open, etc.
    const challenges = ["Blink your eyes", "Open your mouth", "Look left", "Look right"]; // Example challenges
    if (index === null || index === undefined) return "";
    return index < challenges.length ? challenges[index] : `Challenge ${index + 1}`;
  };

    // Check if server is available on component mount and auto-start
    useEffect(() => {
    const checkServer = async () => {
        // Skip if we've already checked the server
        if (serverCheckedRef.current) {
        return;
        }
        
        try {
        console.log(`Checking server at ${serverUrl}/test`);
        const response = await fetch(`${serverUrl}/test`);
        const data = await response.json();

        // Mark that we've checked the server
        serverCheckedRef.current = true;

        if (data.status === 'API is working') {
            setStatus('Server is available. Ready to start.');
            setStatusClass('pending');
            console.log("Server is available");

            // Auto-start if originData is available (means it's standalone mode)
            // Wait for geolocation permission before auto-starting
            if (originData && geoPermissionGranted) {
            console.log("Origin data and geo permission available, auto-starting...");
            // Short delay to ensure UI updates and state is ready
            setTimeout(() => {
                if (mode === 'liveness') {
                    startLivenessCheck();
                } else if (mode === 'property') {
                    // For property mode, just start the webcam initially
                    startWebcam();
                    setPropertyPhotoStatus('ready');
                    setStatus('Ready to capture property photo.');
                    setStatusClass('pending');
                }
            }, 1000); // 1 second delay
            } else if (originData && !geoPermissionGranted) {
            // If originData is available but geo not granted, status will update when geo is handled
            setStatus('Waiting for location permission to auto-start...');
            setStatusClass('pending');
            }
        } else {
            throw new Error('Server not responding correctly');
        }
        } catch (error) {
        console.error('Error connecting to server:', error);
        setStatus('Error connecting to server. Please check if the server is running.');
        setStatusClass('error');

        // Notify origin of error if in standalone mode
        if (originData) {
            sendResultToOrigin({
            success: false,
            status: 'error',
            reason: 'Could not connect to verification server',
            requestId: originData.requestId,
            type: mode,
            // Include geolocation if available
            geoLocation: originData?.geoLocation
            });
        }
        
        // Even on error, mark as checked to prevent repeated attempts
        serverCheckedRef.current = true;
        }
    };

    // Check server status only if we haven't checked yet
    if (!serverCheckedRef.current) {
        checkServer();
    }

    // Clean up on component unmount
    return () => {
        console.log("Component unmounting, cleaning up");
        // Stop interval, webcam, and close WebSocket
        stopWebcam(); // This function handles clearing interval and closing WS
    };
    }, [originData, geoPermissionGranted, mode, serverUrl, startLivenessCheck, startWebcam, sendResultToOrigin, stopWebcam]); 

  // Effect to initialize WebSocket when session ID is set and WS is enabled
  useEffect(() => {
      if (sessionId && useWebSocket && !webSocketRef.current      ) {
          console.log("Session ID set and WS enabled, initializing WebSocket...");
          initializeWebSocket(sessionId);
      }
  }, [sessionId, useWebSocket, initializeWebSocket]); // Added dependencies

  return (
    <div className={`liveness-check standalone-mode ${mode}`}>
      <h2>{mode === 'liveness' ? 'Liveness Detection' : 'Property Photo Capture'}</h2>
      <p className="instructions">
        {mode === 'liveness'
          ? 'Please look at the camera and follow the instructions to complete the liveness check. Make sure your face is clearly visible and well-lit.'
          : 'Please position the camera to capture a clear photo of the property. Location data will be embedded in the image.'}
      </p>

      {/* Status section */}
      <div className="status-section">
        <h3>Status:</h3>
        <div className={`detection-result ${statusClass}`}>{status}</div>

        {mode === 'liveness' && (
          <div className="progress-container">
            <div className="progress-bar" style={{ width: `${progress}%` }}></div>
          </div>
        )}
         {/* Display current challenge if in liveness mode and challenge is active */}
        {mode === 'liveness' && streaming && !livenessComplete && currentChallenge !== null && (
             <div className="challenge-display">
                 <strong>Challenge:</strong> {getChallengeName(currentChallenge)}
             </div>
        )}
      </div>

      {spoofingDetected && mode === 'liveness' && (
        <div className="spoofing-alert">
          <h3>⚠️ Spoofing Detected ⚠️</h3>
          <p>We detected potential spoofing. Please ensure you're not using a screen or photo.</p>
          <p>Attempts remaining: {Math.max(0, 3 - retryCount - 1)}</p> {/* Display remaining attempts */}
          <button
            className="restart-btn"
            onClick={handleRetry}
            disabled={retryCount >= 2} // Disable button after 3 attempts (0, 1, 2)
          >
            {retryCount < 2 ? `Retry Verification (${retryCount + 1}/3)` : "Verification Failed"}
          </button>
        </div>
      )}

      {/* Only show webcam/capture area if not spoofing detected */}
      {!spoofingDetected && (
        <>
          <div className="webcam-section">
            <div className="video-container">
              {/* Show video if streaming and no final image captured */}
              {streaming && !capturedImageUrl && !propertyPhotoUrl && (
                <video ref={webcamRef} autoPlay playsInline></video>
              )}
              {/* Canvas is hidden, used for capturing frames */}
              <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>

              {/* Show captured image if available */}
              {capturedImageUrl && mode === 'liveness' && (
                <img
                  className="captured-image"
                  src={capturedImageUrl}
                  alt="Captured face"
                />
              )}
               {/* Show property photo if available */}
              {propertyPhotoUrl && mode === 'property' && (
                <img
                  className="captured-image"
                  src={propertyPhotoUrl}
                  alt="Property photo"
                />
              )}

              {/* Overlay for liveness challenges (optional, can be handled by server messages) */}
              {/* Removed challenge overlay as status message is used */}

            </div>
          </div>

          {/* Show permission/status message before streaming starts */}
          {!streaming && !capturedImageUrl && !propertyPhotoUrl && (
            <div className="permission-status">
              <h3>Camera & Location Permission Required</h3>
              <p>This verification requires your camera and location. Please allow access when prompted.</p>
              <div className={`location-status ${locationStatus}`}>
                {locationStatus === 'pending' && <span>Waiting for location permission...</span>}
                {locationStatus === 'requesting' && <span>⏳ Requesting location access...</span>}
                {locationStatus === 'captured' && (
                  <span>
                    ✓ Location captured successfully
                    {originData && originData.geoLocation && (
                      <div className="location-details">
                        <small>
                          Lat: {originData.geoLocation.latitude.toFixed(6)},
                          Lon: {originData.geoLocation.longitude.toFixed(6)}
                          {originData.geoLocation.accuracy && (
                            <span> (Accuracy: ±{Math.round(originData.geoLocation.accuracy)}m)</span>
                          )}
                        </small>
                      </div>
                    )}
                  </span>
                )}
                {locationStatus === 'error' && <span>⚠ Location access denied or unavailable</span>}
              </div>
              {/* Show Start Camera button if not streaming and geo is granted (for property mode or manual start) */}
              {mode === 'property' && !streaming && geoPermissionGranted && (
                 <button
                   className="start-btn"
                   onClick={startWebcam}
                 >
                   Start Camera
                 </button>
              )}
            </div>
          )}

          {/* Liveness mode controls */}
          {mode === 'liveness' && !capturedImageUrl && !livenessComplete && (
            <div className="controls">
              <button
                className="start-btn"
                onClick={startLivenessCheck}
                disabled={streaming || !geoPermissionGranted} // Disable if streaming or geo not granted
              >
                {streaming ? 'Processing...' : 'Start Liveness Check'}
              </button>
              <button
                className="stop-btn"
                onClick={stopLivenessCheck}
                disabled={!streaming && !sessionId} // Disable if not streaming and no session started
              >
                Cancel
              </button>
            </div>
          )}

          {/* Property photo mode controls */}
          {mode === 'property' && !propertyPhotoUrl && streaming && (
            <div className="controls">
                <button
                  className="capture-btn"
                  onClick={capturePropertyPhoto}
                  disabled={propertyPhotoStatus === 'uploading' || !geoPermissionGranted}
                >
                  {propertyPhotoStatus === 'uploading' ? 'Uploading...' : 'Capture Property Photo'}
                </button>
                 <button
                  className="stop-btn"
                  onClick={stopWebcam}
                  disabled={!streaming}
                >
                  Cancel
                </button>
            </div>
          )}
           {/* Property photo mode controls - if not streaming but geo granted */}
           {mode === 'property' && !propertyPhotoUrl && !streaming && geoPermissionGranted && (
             <div className="controls">
                <button
                  className="start-btn"
                  onClick={startWebcam}
                >
                  Start Camera
                </button>
             </div>
           )}


          {/* Liveness capture success message */}
          {capturedImageUrl && mode === 'liveness' && (
            <div className="capture-success">
              <p>Image captured successfully! Sending results...</p>
              {/* Auto-close handled by sendResultToOrigin */}
            </div>
          )}

          {/* Property photo capture success message */}
          {propertyPhotoUrl && mode === 'property' && (
            <div className="capture-success">
              <p>Property photo captured successfully! Sending results...</p>
               {/* Auto-close handled by sendResultToOrigin */}
            </div>
          )}
        </>
      )}

      {/* Debug information - remove in production */}
      {process.env.NODE_ENV !== 'production' && (
        <div className="debug-info" style={{ margin: '10px', padding: '10px', border: '1px solid #ccc', backgroundColor: '#f8f8f8', fontSize: '12px' }}>
          <h4>Debug Information</h4>
          <p>Mode: {mode}</p>
          <p>Use WebSocket: {useWebSocket ? 'Yes' : 'No'}</p>
          <p>WS Connected: {wsConnected ? 'Yes' : 'No'}</p>
          <p>Session ID: {sessionId || 'Not started'}</p>
          <p>Captured DMS ID: {capturedDmsId || propertyDmsId || 'Not captured'}</p>
          <p>Liveness Complete: {livenessComplete ? 'Yes' : 'No'}</p>
          <p>Spoofing Detected: {spoofingDetected ? 'Yes' : 'No'}</p>
          <p>Geo Permission: {geoPermissionGranted ? 'Granted' : 'Not granted'}</p>
          <p>Location Status: {locationStatus}</p>
          {originData && originData.geoLocation && (
            <p>
              Geo: {originData.geoLocation.latitude?.toFixed(6)},
              {originData.geoLocation.longitude?.toFixed(6)}
              {originData.geoLocation.accuracy && ` (±${Math.round(originData.geoLocation.accuracy)}m)`}
            </p>
          )}
           <p>Geo Sent (WS/HTTP): {originData?.geoLocationSent ? 'Yes' : 'No'}</p>
           <p>Retry Count: {retryCount}</p>
        </div>
      )}
    </div>
  );
};

export default FastapiLivenessCheck;

