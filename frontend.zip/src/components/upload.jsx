import React, { useState, useEffect } from 'react';
import '../styles/upload.css';
import { Link } from 'react-router-dom';
import Navbar from './topBar';
import { useLocation, useNavigate } from 'react-router-dom';

const Upload = () => {
    const navigate = useNavigate();

    const [files, setFiles] = useState([]);
    const [uploadCounter, setUploadCounter] = useState(() => {
        const saved = localStorage.getItem('uploadCounter');
        return saved ? JSON.parse(saved) : { total: 0, uploaded: 0 };
    });
    const [uploadMessage, setUploadMessage] = useState(() => 
        localStorage.getItem('uploadMessage') || ""
    );
    const [processingStatus, setProcessingStatus] = useState("idle");
    const [totalFiles, setTotalFiles] = useState(0);
    const [remainingFiles, setRemainingFiles] = useState(0);
    const [lockedTotalFiles, setLockedTotalFiles] = useState(null);
    const [uploadStatus, setUploadStatus] = useState(() => {
        const saved = localStorage.getItem('uploadStatus');
        return saved ? JSON.parse(saved) : { successful: [], skipped: [] };
    });
    const [isSelectingFolder, setIsSelectingFolder] = useState(false);
    const [isSelectingFiles, setIsSelectingFiles] = useState(false);

    const [showSuccessColor, setShowSuccessColor] = useState(() => {
        const saved = localStorage.getItem('showSuccessColor');
        return saved ? JSON.parse(saved) : false;
    });

    const handleFolderSelection = async () => {
    try {
        setIsSelectingFolder(true);
        setIsSelectingFiles(false);
        setShowSuccessColor(false);
        setUploadMessage("");

        const input = document.createElement('input');
        input.type = 'file';
        input.setAttribute('directory', '');
        input.setAttribute('webkitdirectory', '');
        
        input.onchange = async (e) => {
            const selectedFiles = Array.from(e.target.files);
            const validFiles = [];
            const skippedFiles = [];

            selectedFiles.forEach(file => {
                const ext = file.name.split('.').pop().toLowerCase();
                if (ext === 'pdf' || ext === 'docx') {
                    // Clean the filename by removing the path
                    const cleanFileName = file.name.split('/').pop().split('\\').pop();
                    // Create new File object with clean filename
                    const cleanFile = new File([file], cleanFileName, { type: file.type });
                    validFiles.push(cleanFile);
                } else {
                    skippedFiles.push(file.name);
                }
            });

            if (validFiles.length > 0) {
                setFiles(validFiles);
                setUploadCounter({ total: validFiles.length, uploaded: 0 });
                setUploadStatus({
                    successful: [],
                    skipped: skippedFiles
                });
                let statusMessage = "Selected Files Status:\n";
                statusMessage += `✅ Valid files selected: ${validFiles.length}\n`;
                if (skippedFiles.length > 0) {
                    statusMessage += `⚠️ Skipped files (only PDF/DOCX allowed):\n${skippedFiles.join('\n')}`;
                }
                setUploadMessage(statusMessage);
            }
        };
        input.click();
    } catch (error) {
        console.log('Folder selection:', error);
    }
};


    const handleFileChange = (event) => {
        setIsSelectingFiles(true);
        setIsSelectingFolder(false);
        setShowSuccessColor(false);

        const selectedFiles = Array.from(event.target.files);
        const validFiles = [];
        const skippedFiles = [];

        selectedFiles.forEach(file => {
            const ext = file.name.split('.').pop().toLowerCase();
            if (ext === 'pdf' || ext === 'docx') {
                validFiles.push(file);
            } else {
                skippedFiles.push(file.name);
            }
        });

        setFiles(validFiles);
        setUploadCounter({ total: validFiles.length, uploaded: 0 });
        setUploadStatus({
            successful: [],
            skipped: skippedFiles
        });

        let statusMessage = "Selected Files Status:\n";
        statusMessage += `✅ Valid files selected: ${validFiles.length}\n`;
        if (skippedFiles.length > 0) {
            statusMessage += `⚠️ Skipped files (only PDF/DOCX allowed):\n${skippedFiles.join('\n')}`;
        }
        setUploadMessage(statusMessage);
    };



    const handleBulkUpload = async () => {
        if (files.length === 0) {
            alert("Please select files to upload.");
            return;
        }

        setUploadMessage("Uploading files...");
        const successfulUploads = [];
        const failedUploads = [];

        for (const file of files) {
            const formData = new FormData();
            formData.append('file', file);

            try {
                const res = await fetch(`${import.meta.env.VITE_API}/upload_file`, {
                    method: "POST",
                    body: formData,
                });

                if (res.status === 200) {
                    successfulUploads.push(file.name);
                    setIsSelectingFolder(false);
                    setIsSelectingFiles(false);
                } else {
                    failedUploads.push(file.name);
                }
            } catch (error) {
                failedUploads.push(file.name);
                console.error("Error uploading file:", file.name, error);
            }
        }

        let statusMessage = "Upload Status:\n";
        if (successfulUploads.length > 0) {
            statusMessage += `✅ Successfully uploaded:\n${successfulUploads.join('\n')}\n\n`;
        }
        if (failedUploads.length > 0) {
            statusMessage += `❌ Failed to upload:\n${failedUploads.join('\n')}`;
        }

        if (successfulUploads.length === (files.length - failedUploads.length)) {
            setShowSuccessColor(true);
        }
        
        setUploadMessage(statusMessage);
        setUploadCounter({ total: files.length, uploaded: successfulUploads.length });
        setUploadStatus({
            successful: successfulUploads,
            skipped: failedUploads
        });
        await initializeComponent(); // Refresh counts

    };

    const handleFilesUpload = async () => {
        if (files.length === 0) {
            alert("Please select files to upload.");
            return;
        }

        const formData = new FormData();
        files.forEach(file => {
            formData.append('files', file);
        });

        try {
            const res = await fetch(`${import.meta.env.VITE_API}/bulk_upload`, {
                method: "POST",
                body: formData,
            });

            const data = await res.json();
            
            let statusMessage = "Upload Status:\n";
            if (files.length > 0) {
                statusMessage += `✅ Successfully uploaded:\n${files.map(f => f.name).join('\n')}\n\n`;
            }
            if (uploadStatus.skipped.length > 0) {
                statusMessage += `⚠️ Skipped files (only PDF/DOCX allowed):\n${uploadStatus.skipped.join('\n')}`;
            }

            
            if (files.length === (files.length - uploadStatus.skipped.length)) {
                setShowSuccessColor(true);
            }
            
            setUploadMessage(statusMessage);
            setUploadCounter({ total: files.length, uploaded: files.length });

            setIsSelectingFolder(false);
            setIsSelectingFiles(false);
            await initializeComponent(); // Refresh counts

        } catch (error) {
            console.error("Error uploading files:", error);
            setUploadMessage(`Error during upload. Please try again.\nSkipped files: ${uploadStatus.skipped.join(', ')}`);
        }
    };

    const handleParseResumes = async () => {
        if (processingStatus === "processing") return;

        try {
            const res = await fetch(`${import.meta.env.VITE_API}/parse_resumes`, {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'start' })
            });

            const data = await res.json();
            if (data.success) {
                console.log("Resume parsing started.", data);
                setTotalFiles(data.total);
                setProcessingStatus("processing");
                checkProcessingStatus();
            } else {
                alert(data.message);
            }
        } catch (error) {
            console.error("Resume parsing error:", error);
        }
    };

    const handleStopProcessing = async () => {
        try {
            const res = await fetch(`${import.meta.env.VITE_API}/parse_resumes`, {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'stop' })
            });

            const data = await res.json();
            if (data.success) {
                setProcessingStatus("stopped");
                setLockedTotalFiles(null);
            }
        } catch (error) {
            console.error("Error stopping process:", error);
        }
    };

    const checkProcessingStatus = async () => {
        try {
            const res = await fetch(`${import.meta.env.VITE_API}/parse_resumes`, {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'status' })
            });

            const data = await res.json();
            setProcessingStatus(data.status);
            setRemainingFiles(data.remaining);
            // setTotalFiles(data.total);
            if (data.completed) {
                setProcessingStatus("completed");
                alert("Processing completed successfully!");
                setTotalFiles(null);
                await initializeComponent();
            } else if (data.status === "processing") {
                setTimeout(checkProcessingStatus, 10000);
                console.log("Checking:", data);
            }
        } catch (error) {
            console.error("Error checking status:", error);
        }
    };

    const initializeComponent = async () => {
        const res = await fetch(`${import.meta.env.VITE_API}/get_resume_progress`);
        const data = await res.json();
        setRemainingFiles(data.remaining);
    };

    useEffect(() => {
        let isMounted = true;
        
        const loadInitialData = async () => {
            if (isMounted) {
                await initializeComponent();
            }
        };

        checkProcessingStatus();
        loadInitialData();
        
        return () => { isMounted = false; };
    }, []);

    useEffect(() => {
        localStorage.setItem('uploadCounter', JSON.stringify(uploadCounter));
        localStorage.setItem('uploadStatus', JSON.stringify(uploadStatus));
        localStorage.setItem('uploadMessage', uploadMessage);
        localStorage.setItem('showSuccessColor', JSON.stringify(showSuccessColor));
    }, [uploadCounter, uploadStatus, uploadMessage, showSuccessColor]);
    

   // In the return statement of upload.jsx
    return (
        <div>
            <Navbar />
            <div className="upload-page">
            
                <div className="upload-container">
                    <h3>Bulk Upload Resumes</h3>
                    <div className="upload-controls">
                        <div className="control-row">
                            <button onClick={handleFolderSelection} className="folder-button" disabled={isSelectingFiles}>
                                Select Folder
                            </button>
                            <button onClick={handleBulkUpload} className="upload-button" disabled={isSelectingFiles}>
                                Upload Folder
                            </button>
                        </div>
                        <div className="control-row">
                            <label className={`file-input-label ${isSelectingFolder ? 'disabled' : ''}`}>
                                Choose Files
                                <input
                                    type="file"
                                    multiple
                                    onChange={handleFileChange}
                                    accept=".pdf,.docx"
                                    className="file-input"
                                    disabled={isSelectingFolder}
                                />
                            </label>
                            <button onClick={handleFilesUpload} className="upload-button" disabled={isSelectingFolder}>
                                Upload Files
                            </button>
                        </div>
                    </div>
                </div>

                <div className="parse-container">
                    <h3>Process Uploaded Resumes</h3>
                    <div className="process-controls">
                        <button
                            onClick={handleParseResumes}
                            className="parse-button"
                            disabled={processingStatus === "processing"||remainingFiles===0}
                        >
                            {processingStatus === "processing" ? "Processing..." : "Process"}
                        </button>
                        {processingStatus === "processing" && (
                            <button onClick={handleStopProcessing} className="stop-button">
                                Stop Processing
                            </button>
                        )}
                    </div>
                    <div className="status-message">
                        <span>
                            {totalFiles ? 
                                `${remainingFiles} out of ${totalFiles} resumes remaining` : 
                                `Number of resumes to parse : ${remainingFiles} `
                            }
                        </span>
                        <p>Status: {processingStatus}</p>
                    </div>
                    <button 
                        onClick={() => navigate('/logs', { state: { showOnlyRecent: true } })} 
                        className="view-results-button"
                    >
                        View Results
                    </button>
                </div>

                <div className="status-container">
                    <h3>Upload Status</h3>
                    <div className="upload-status">
                        <div className="status-counts">
                        <p className={showSuccessColor ? 'success' : ''}>
                            Total Files to be uploaded: {uploadCounter.total}
                            {uploadCounter.total === 0 && isSelectingFolder && " - ⚠️ Folder is empty"}
                        </p>
                            <p className={showSuccessColor ? 'success' : ''}>
                                Number of Files Uploaded: {uploadCounter.uploaded}
                            </p>
                            <p>Number of Files Skipped: {uploadStatus.skipped.length}</p>
                        </div>
                        <div className="status-message" style={{ whiteSpace: 'pre-line' }}>
                            {uploadMessage}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

};

export default Upload;