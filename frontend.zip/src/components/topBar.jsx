import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../styles/topbar.css"; // Ensure to create this file for styling
import cholalogo from '../assets/img/Chola.png';
const Navbar = () => {
  const navigate = useNavigate();
 
  const [isDropdownOpen, setIsDropdownOpen] = useState(false); // Track dropdown state
  const [isMobile, setIsMobile] = useState(false); // Track if it's in mobile view
 
  useEffect(() => {
    // Check screen size on initial load and whenever the window is resized
    const checkIfMobile = () => {
      if (window.innerWidth <= 768) {
        setIsMobile(true);
      } else {
        setIsMobile(false);
        setIsDropdownOpen(false); // Reset dropdown when switching to desktop
      }
    };
 
    checkIfMobile();
    window.addEventListener("resize", checkIfMobile);
 
    return () => {
      window.removeEventListener("resize", checkIfMobile);
    };
  }, []);
 
  const handleLogout = () => {
    const confirmLogout = window.confirm("Are you sure you want to log out?");
    if (confirmLogout) {
      sessionStorage.removeItem("user");
      navigate("/");
    }
  };
 
  // Toggle dropdown visibility for mobile
  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };
 
  const user = JSON.parse(sessionStorage.getItem("user"));
  const role = user?.role;
  const username = user?.username;
 
  return (
    <nav className="alumni-navbar">
      <div className="nav-container alumni-navbar-content">
        {/* Left: Logo */}
        <ul className="org-brand">
          <li>
            <a href="#">
              <img className="alumniappnav-logo" src={cholalogo} alt="Logo" />
            </a>
          </li>
        </ul>
 
        <div className="nav-title">
          <h1>Resume Parser</h1>
        </div>
 
        <ul className={`alumni-nav-items ${isMobile && !isDropdownOpen ? 'hidden' : ''}`}>
          <li>
            <Link to="/search">Search</Link>
          </li>
          <li>
            <Link to="/upload">Upload</Link>
          </li>
          <li>
            <Link to="/logs">Logs</Link>
          </li>
          {role === "admin" && (
            <li>
              <Link to="/user_creation">Create User</Link>
            </li>
          )}
          <li>
            <button onClick={handleLogout} className="logout-button">
              Logout
            </button>
          </li>
          {username && (
            <li className="user-profile">
             
              <img
                className="profile-photo"
                src="src\assets\img\profile.png"
                alt="Profile"
              />
 
              <span className="username">{username}</span>
            </li>
          )}
        </ul>
 
        <div className="hamburger-menu" onClick={toggleDropdown}>
          <span>&#9776;</span>
        </div>
 
        {isMobile && isDropdownOpen && (
          <div className="dropdown-content show">
            <Link to="/search" onClick={() => setIsDropdownOpen(false)}>Search</Link>
            <Link to="/upload" onClick={() => setIsDropdownOpen(false)}>Upload</Link>
            <Link to="/logs" onClick={() => setIsDropdownOpen(false)}>Logs</Link>
            {role === "admin" && (
              <Link to="/user_creation" onClick={() => setIsDropdownOpen(false)}>Create User</Link>
            )}
               <button onClick={() => { handleLogout(); setIsDropdownOpen(false); }} className="logout-button">
              Logout
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};
 
export default Navbar;