import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import cholaSketch from '../assets/img/chola_sketch.jpg';
import cholalogo from '../assets/img/Chola.png';
import '../styles/login.css';
import "../styles/topbar.css";
 
const Login = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [loginError, setLoginError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
 
  useEffect(() => {
    const user = JSON.parse(sessionStorage.getItem('user'));
    if (user && user.isAuthenticated) {
      window.location.href = user.role === 'admin' ? '/user_creation' : '/search';
    }
  }, []);
 
  const onSubmit = async (data) => {
    try {
      const response = await fetch(`${import.meta.env.VITE_API}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: data.username,
          password: data.password,
        }),
      });
 
      const result = await response.json();
      console.log('Login response:', result);
 
      if (result.success) {
        sessionStorage.setItem('user', JSON.stringify({
          username: data.username,
          role: result.role,
          isAuthenticated: true
        }));
       
        if (result.role === 'admin') {
          window.location.href = '/user_creation';
        } else {
          window.location.href = '/search';
        }
      } else {
        setLoginError('Invalid username or password');
      }
    } catch (error) {
      console.error('Login failed:', error);
      setLoginError('An error occurred. Please try again.');
    }
  };
 
  return (
    <div className="login-container" style={{
      backgroundImage: `url(${cholaSketch})`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat'
    }}>
      <nav className="alumni-navbar">
        <div className="nav-container alumni-navbar-content">
          <ul className="org-brand">
            <li>
              <a href="#">
                <img
                  className="alumniappnav-logo"
                  src={cholalogo}
                  alt="Logo"
                />
              </a>
            </li>
          </ul>
        </div>
      </nav>
      <form className="login-form" onSubmit={handleSubmit(onSubmit)}>
        <h2>Login</h2>
        <div className="input-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            {...register("username", { required: "Username is required" })}
          />
          {errors.username && <span className="error-message">{errors.username.message}</span>}
        </div>
        <div className="input-group">
          <label htmlFor="password">Password</label>
          <div className="password-input-container">
            <input
              type={showPassword ? "text" : "password"}
              id="password"
              {...register("password", { required: "Password is required" })}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="password-toggle-btn"
            >
              {showPassword ? "Hide" : "Show"}
            </button>
          </div>
          {errors.password && <span className="error-message">{errors.password.message}</span>}
        </div>
        <button type="submit" className="login-button">
          Log In
        </button>
        {loginError && <p className="error-message">{loginError}</p>}
      </form>
    </div>
  );
};
 
export default Login;
 
