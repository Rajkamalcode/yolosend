import cv2
import numpy as np
from skimage.feature import graycomatrix, graycoprops # Optional for texture
from scipy.stats import entropy # Optional for entropy
import fitz  # PyMuPDF
import os
import io
from PIL import Image # To potentially help with image format conversion if needed

# --- Feature Calculation Functions (Unchanged) ---

def calculate_sharpness(image_gray):
    """Calculates sharpness using Laplacian variance."""
    if image_gray is None or image_gray.size == 0:
        return 0.0
    # Use CV_64F for higher precision, prevent overflow/underflow
    laplacian = cv2.Laplacian(image_gray, cv2.CV_64F)
    variance = laplacian.var()
    return variance

def calculate_contrast_stddev(image_gray):
    """Calculates contrast using standard deviation of pixel intensities."""
    if image_gray is None or image_gray.size == 0:
        return 0.0
    return image_gray.std()

# Optional: Entropy function (often less discriminative for this task)
# def calculate_entropy(image_gray):
#     """Calculates image entropy."""
#     if image_gray is None or image_gray.size == 0:
#         return 0.0
#     hist = cv2.calcHist([image_gray], [0], None, [256], [0, 256])
#     hist_prob = hist / (hist.sum() + 1e-6) # Add epsilon to avoid division by zero
#     return entropy(hist_prob.flatten())

# --- Analysis Function (Modified to accept image object) ---

def analyze_page_image(image_cv2, page_num, source_desc, sharpness_threshold, contrast_threshold):
    """
    Analyzes a single page image (as a NumPy array) and guesses its type.
    Returns features dictionary and classification string.
    """
    if image_cv2 is None:
        print(f"Error: Invalid image data for page {page_num} from {source_desc}")
        return None, "Error"

    # Convert to grayscale for analysis
    try:
        if len(image_cv2.shape) == 3 and image_cv2.shape[2] == 3:
             gray = cv2.cvtColor(image_cv2, cv2.COLOR_BGR2GRAY)
        elif len(image_cv2.shape) == 2:
             gray = image_cv2 # Already grayscale
        else:
             print(f"Warning: Unexpected image shape {image_cv2.shape} for page {page_num} from {source_desc}. Trying to convert.")
             # Attempt conversion, might fail for unusual formats
             gray = cv2.cvtColor(image_cv2, cv2.COLOR_BGR2GRAY) # Assume BGR if > 2 channels
    except cv2.error as e:
         print(f"Error converting page {page_num} from {source_desc} to grayscale: {e}")
         return None, "Conversion Error"


    # --- Calculate Features ---
    sharpness = calculate_sharpness(gray)
    contrast_std = calculate_contrast_stddev(gray)
    # image_entropy = calculate_entropy(gray) # Optional

    features = {
        "sharpness": sharpness,
        "contrast": contrast_std,
        # "entropy": image_entropy # Optional
    }

    # --- Decision Logic (Needs Tuning!) ---
    is_likely_photocopy = False
    decision_reason = "N/A"

    # Prioritize sharpness as primary indicator of photocopy degradation
    if sharpness < sharpness_threshold:
        is_likely_photocopy = True
        decision_reason = f"Low sharpness ({sharpness:.2f} < {sharpness_threshold})"
    # Optional: Add contrast check as a secondary factor or alternative
    # elif contrast_std < contrast_threshold and sharpness < (sharpness_threshold * 1.1): # Example: if contrast is low AND sharpness is borderline
    #     is_likely_photocopy = True
    #     decision_reason = f"Low contrast ({contrast_std:.2f} < {contrast_threshold}) and borderline sharpness"
    else: # Default to original if sharp enough
         is_likely_photocopy = False
         decision_reason = f"Sufficient sharpness ({sharpness:.2f} >= {sharpness_threshold})"

    result_type = "Photocopy of Scan" if is_likely_photocopy else "Original Scan"

    # print(f"  Page {page_num} ({source_desc}): Sharp={sharpness:.2f}, Contr={contrast_std:.2f} -> Likely {result_type} ({decision_reason})")

    return features, result_type


# --- PDF Processing Function ---

def extract_pages_as_images(pdf_path, dpi=300):
    """
    Extracts all pages from a PDF file as OpenCV images (NumPy arrays in BGR format).
    """
    images = []
    try:
        doc = fitz.open(pdf_path)
    except Exception as e:
        print(f"Error opening PDF {pdf_path}: {e}")
        return None # Return None to indicate failure

    print(f"Extracting pages from {os.path.basename(pdf_path)}...")
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        # Render page to a pixmap (image)
        # Higher DPI generally gives better quality for analysis, but increases processing time/memory
        pix = page.get_pixmap(dpi=dpi)

        # Convert pixmap to NumPy array for OpenCV
        try:
            # Get image bytes
            img_bytes = pix.samples
            # Create numpy array from bytes
            img_np = np.frombuffer(img_bytes, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)

            # Convert to BGR format which OpenCV prefers
            if pix.n == 1:  # Grayscale
                img_cv2 = cv2.cvtColor(img_np, cv2.COLOR_GRAY2BGR)
            elif pix.n == 3:  # RGB
                img_cv2 = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
            elif pix.n == 4:  # RGBA
                img_cv2 = cv2.cvtColor(img_np, cv2.COLOR_RGBA2BGR)
            else:
                 print(f"Warning: Unsupported number of channels ({pix.n}) for page {page_num+1} in {pdf_path}. Skipping page.")
                 images.append(None) # Add placeholder for skipped page
                 continue

            images.append(img_cv2)

        except Exception as e:
             print(f"Error converting page {page_num+1} from {pdf_path} to OpenCV format: {e}")
             images.append(None) # Add placeholder on error


    doc.close()
    print(f"  Extracted {len(images)} pages.")
    return images

# --- Main Comparison Workflow ---

def compare_pdf_documents(pdf_path1, pdf_path2, sharpness_threshold, contrast_threshold, dpi=300):
    """
    Compares two PDF documents page by page based on image analysis metrics.
    """
    print(f"\n--- Comparing PDF Documents ---")
    print(f"Document 1: {pdf_path1}")
    print(f"Document 2: {pdf_path2}")
    print(f"Sharpness Threshold: {sharpness_threshold}")
    print(f"Contrast Threshold: {contrast_threshold}") # Keep track even if not primary decider
    print(f"Rendering DPI: {dpi}")
    print("-" * 30)

    images1 = extract_pages_as_images(pdf_path1, dpi=dpi)
    images2 = extract_pages_as_images(pdf_path2, dpi=dpi)

    if images1 is None or images2 is None:
        print("Error: Could not process one or both PDF files.")
        return None

    if len(images1) != len(images2):
        print(f"Error: PDF documents have different number of pages ({len(images1)} vs {len(images2)}). Cannot compare page by page.")
        # Optional: Analyze available pages anyway? For now, we stop.
        return None

    if len(images1) == 0:
        print("Error: No pages found or extracted from the PDFs.")
        return None

    results = []
    doc1_photocopy_votes = 0
    doc2_photocopy_votes = 0
    analyzed_pages = 0

    for i in range(len(images1)):
        page_num = i + 1
        img1 = images1[i]
        img2 = images2[i]

        # Basic check if extraction worked for both pages
        if img1 is None or img2 is None:
            print(f"\n--- Page {page_num} ---")
            print("  Skipping comparison due to extraction error on one or both pages.")
            results.append({
                "page": page_num,
                "status": "Skipped (Extraction Error)",
                "doc1_features": None, "doc1_type": "Error",
                "doc2_features": None, "doc2_type": "Error"
            })
            continue

        print(f"\n--- Analyzing Page {page_num} ---")

        features1, type1 = analyze_page_image(img1, page_num, f"Doc1 ({os.path.basename(pdf_path1)})", sharpness_threshold, contrast_threshold)
        features2, type2 = analyze_page_image(img2, page_num, f"Doc2 ({os.path.basename(pdf_path2)})", sharpness_threshold, contrast_threshold)

        # Print summary for the page
        if features1 and features2:
             print(f"  Page {page_num} Summary:")
             print(f"    Doc 1: Sharp={features1['sharpness']:.2f}, Contr={features1['contrast']:.2f} -> Likely {type1}")
             print(f"    Doc 2: Sharp={features2['sharpness']:.2f}, Contr={features2['contrast']:.2f} -> Likely {type2}")
        else:
             print(f"  Page {page_num}: Analysis incomplete due to errors.")


        results.append({
            "page": page_num,
            "status": "Analyzed",
            "doc1_features": features1, "doc1_type": type1,
            "doc2_features": features2, "doc2_type": type2
        })

        if type1 != "Error" and type1 != "Conversion Error":
            analyzed_pages += 0.5 # Count half per doc analyzed successfully
            if type1 == "Photocopy of Scan":
                doc1_photocopy_votes += 1
        if type2 != "Error" and type2 != "Conversion Error":
            analyzed_pages += 0.5
            if type2 == "Photocopy of Scan":
                doc2_photocopy_votes += 1

    # --- Overall Summary ---
    print("\n--- Overall Document Comparison Summary ---")
    if analyzed_pages > 0:
        doc1_photocopy_percent = (doc1_photocopy_votes / (analyzed_pages)) * 100 if analyzed_pages > 0 else 0
        doc2_photocopy_percent = (doc2_photocopy_votes / (analyzed_pages)) * 100 if analyzed_pages > 0 else 0

        print(f"Total Pages Analyzed (potentially partially): {int(analyzed_pages)}") # Use int for display
        print(f"Doc 1 Pages Classified as Photocopy: {doc1_photocopy_votes} ({doc1_photocopy_percent:.1f}%)")
        print(f"Doc 2 Pages Classified as Photocopy: {doc2_photocopy_votes} ({doc2_photocopy_percent:.1f}%)")

        # Make a simple overall guess based on majority vote
        # This assumes one is the original and one is the photocopy
        if doc1_photocopy_votes < doc2_photocopy_votes:
            print("\nOverall Guess: Document 1 is more likely the 'Original Scan', Document 2 the 'Photocopy'.")
        elif doc2_photocopy_votes < doc1_photocopy_votes:
            print("\nOverall Guess: Document 2 is more likely the 'Original Scan', Document 1 the 'Photocopy'.")
        elif doc1_photocopy_votes == doc2_photocopy_votes and doc1_photocopy_votes > 0:
             print("\nOverall Guess: Indeterminate based on page count - both have equal number of pages classified as photocopy.")
             # You could add logic here to compare average sharpness/contrast if counts are equal
             avg_sharp1 = np.mean([r['doc1_features']['sharpness'] for r in results if r['status']=='Analyzed' and r['doc1_features']])
             avg_sharp2 = np.mean([r['doc2_features']['sharpness'] for r in results if r['status']=='Analyzed' and r['doc2_features']])
             print(f"  (Avg Sharpness: Doc1={avg_sharp1:.2f}, Doc2={avg_sharp2:.2f})")
             if avg_sharp1 > avg_sharp2 :
                 print("  (Hint: Doc 1 has higher average sharpness, suggesting it might be the original)")
             elif avg_sharp2 > avg_sharp1:
                 print("  (Hint: Doc 2 has higher average sharpness, suggesting it might be the original)")

        else: # Both have 0 photocopy votes
            print("\nOverall Guess: Both documents appear to be 'Original Scans' based on the thresholds.")
            avg_sharp1 = np.mean([r['doc1_features']['sharpness'] for r in results if r['status']=='Analyzed' and r['doc1_features']])
            avg_sharp2 = np.mean([r['doc2_features']['sharpness'] for r in results if r['status']=='Analyzed' and r['doc2_features']])
            print(f"  (Avg Sharpness: Doc1={avg_sharp1:.2f}, Doc2={avg_sharp2:.2f})")


    else:
        print("No pages were successfully analyzed.")

    print("-" * 30)
    return results


# --- Example Usage ---
if __name__ == "__main__":
    # --- IMPORTANT: Define Paths to Your PDFs ---
    # Replace these with the actual paths to your files
    pdf_original_scan = '2.pdf'
    pdf_photocopied_scan = '1.pdf'

    # --- CRITICAL: Tune These Thresholds! ---
    # These values are guesses. You MUST determine them by analyzing
    # known samples generated by YOUR scanner and YOUR photocopier.
    # - Run the script on known originals and known photocopies.
    # - Observe the 'Sharpness (Laplacian Var)' values.
    # - Choose a threshold that typically separates them.
    # - Higher values mean sharper. Photocopies should have lower values.
    SHARPNESS_THRESHOLD_FOR_PHOTOCOPY = 100.0 # Example: If below this, likely a photocopy

    # Contrast is secondary but can be useful. Lower values might indicate photocopy.
    CONTRAST_THRESHOLD_FOR_PHOTOCOPY = 55.0  # Example: Std Dev of pixel intensity

    # --- Set DPI for rendering PDF pages ---
    # Higher DPI uses more memory/time but provides more detail for analysis.
    # 200, 300, or even 600 are common. Match your scanner DPI if possible.
    RENDERING_DPI = 300

    # --- Check if files exist before running ---
    if not os.path.exists(pdf_original_scan):
        print(f"Error: File not found - {pdf_original_scan}")
    elif not os.path.exists(pdf_photocopied_scan):
         print(f"Error: File not found - {pdf_photocopied_scan}")
    else:
        # --- Run the Comparison ---
        # You might compare the known original against the known photocopy first
        # to help tune the thresholds.
        # print("\n*** Comparing Known Original vs Known Photocopy (for tuning) ***")
        # comparison_results = compare_pdf_documents(
        #     pdf_original_scan,
        #     pdf_photocopied_scan,
        #     sharpness_threshold=SHARPNESS_THRESHOLD_FOR_PHOTOCOPY,
        #     contrast_threshold=CONTRAST_THRESHOLD_FOR_PHOTOCOPY, # Pass even if not primary decider
        #     dpi=RENDERING_DPI
        # )

        print("\n*** Comparing two unknown documents ***")
        unknown_pdf_1 = '1.pdf'
        unknown_pdf_2 = '2.pdf'
        if os.path.exists(unknown_pdf_1) and os.path.exists(unknown_pdf_2):
            unknown_results = compare_pdf_documents(
                unknown_pdf_1,
                unknown_pdf_2,
                sharpness_threshold=SHARPNESS_THRESHOLD_FOR_PHOTOCOPY,
                contrast_threshold=CONTRAST_THRESHOLD_FOR_PHOTOCOPY,
                dpi=RENDERING_DPI
            )
        else:
            print("One or both unknown PDF paths are invalid.")

        print("\nDetailed Results:")
        for page_result in unknown_results:
            print(page_result)