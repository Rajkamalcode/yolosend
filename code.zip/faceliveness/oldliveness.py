from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import cv2
import numpy as np
import base64
from ultralytics import YOLO
import logging
import dlib
import time
import os
from scipy.spatial import distance as dist
from imutils import face_utils
from datetime import datetime
import threading
import uuid
from geocoder import reverse_geocode

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
# Configure CORS more explicitly
CORS(app, resources={r"/*": {"origins": "*", "allow_headers": ["Content-Type"], "methods": ["POST", "GET", "OPTIONS"]}})

# Create directories for saving images
os.makedirs("successful_kyc", exist_ok=True)
os.makedirs("failed_kyc", exist_ok=True)
os.makedirs("temp_images", exist_ok=True)

# Constants for liveness detection
EYE_AR_THRESH = 0.20  # Threshold for eye aspect ratio (blink detection)
EYE_AR_CONSEC_FRAMES = 1  # Number of consecutive frames for blink detection
CAPTURE_DELAY = 5  # 5 seconds delay before capturing
LIVENESS_DURATION = 5  # Run liveness check for 12 seconds
FACE_LOST_THRESHOLD = 10  # Number of consecutive frames to consider face lost
FACE_BOX_SCALE_FACTOR = 1.5  # Increase face bounding box size by 50%
CLOSE_UP_FACE_RATIO = 0.4  # Face occupying more than 40% of frame height suggests close-up
SCREEN_CONFIDENCE_THRESHOLD = 0.4  # Confidence threshold for screen detection
SCREEN_CHECK_INTERVAL = 0.5  # Check for screens every 0.5 seconds
BLINK_CHALLENGE_DURATION = 5  # 5 seconds to complete blink challenge
BLINKS_REQUIRED = 2  # Number of blinks required to pass the challenge

# Load models
try:
    hand_detector = YOLO('yolov10n_hand_detect.pt')
    has_hand_detector = True
    logger.info("Hand detector loaded successfully")
except Exception as e:
    has_hand_detector = False
    logger.warning(f"Hand detector not loaded: {e}")

try:
    screen_detector = YOLO("screen detect1.pt")
    has_screen_detector = True
    logger.info("Screen detector loaded successfully")
except Exception as e:
    has_screen_detector = False
    logger.warning(f"Screen detector not loaded: {e}")

# Initialize dlib's face detector and facial landmark predictor
logger.info("Loading the predictor and detector...")
detector = dlib.get_frontal_face_detector()
try:
    predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
    has_face_predictor = True
    logger.info("Face predictor loaded successfully")
except Exception as e:
    has_face_predictor = False
    logger.warning(f"Face predictor not loaded: {e}")

# Get facial landmark indexes for eyes
(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]

# Define states for liveness detection
STATE_FACE_TRACKING = 0
STATE_BLINK_CHALLENGE = 1
STATE_CAPTURE_COUNTDOWN = 2
STATE_CAPTURED = 3

# Session storage
sessions = {}

# Helper functions
def eye_aspect_ratio(eye):
    """Calculate the eye aspect ratio for blink detection"""
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

def detect_screen(frame):
    """Detect screens in the frame using YOLO model"""
    if not has_screen_detector:
        return False, "Screen detector not available"
    
    results = screen_detector(frame, verbose=False)[0]
    for box in results.boxes:
        if box.conf > SCREEN_CONFIDENCE_THRESHOLD:
            return True, "Screen detected by model"
    return False, ""

# Add a new endpoint to get location details
@app.route('/get_location_details', methods=['POST'])
def get_location_details():
    """Get location details from coordinates using reverse geocoding"""
    try:
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        latitude = request_data.get('latitude')
        longitude = request_data.get('longitude')
        
        if not latitude or not longitude:
            return jsonify({'error': 'Missing latitude or longitude'}), 400
        
        # Perform reverse geocoding
        location_info = reverse_geocode(latitude, longitude)
        
        return jsonify({
            'success': True,
            'location': location_info
        })
    except Exception as e:
        logger.error(f"Error getting location details: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

def save_capture(frame, session_id, success=True):
    """Save the captured frame to the appropriate folder with location overlay"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = "successful_kyc" if success else "failed_kyc"
    filename = f"{folder}/{timestamp}_{session_id}.jpg"
    temp_filename = f"temp_images/{session_id}.jpg"
    
    # Get session data
    session_data = sessions.get(session_id, {})
    geo_location = session_data.get('geo_location')
    
    # Create a copy of the frame for overlay
    overlay_frame = frame.copy()
    
    # Get frame dimensions
    height, width = overlay_frame.shape[:2]
    
    # Prepare text lines for overlay
    text_lines = []
    
    # Add timestamp
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    text_lines.append(f"Time: {current_time}")
    
    if geo_location:
        # Add coordinates with full precision
        lat = geo_location.get('latitude')
        lon = geo_location.get('longitude')
        # Use string formatting to preserve full precision
        text_lines.append(f"Lat: {lat:.10f}, Lon: {lon:.10f}")
        
        # Add reverse geocoded location if available
        try:
            location_info = reverse_geocode(lat, lon)
            if location_info and location_info != "No matching location found":
                # Split location info into multiple lines if it's too long
                location_parts = [location_info[i:i+40] for i in range(0, len(location_info), 40)]
                for part in location_parts:
                    text_lines.append(f"Location: {part}")
            else:
                text_lines.append("Location: Unknown")
        except Exception as e:
            logger.error(f"Error in reverse geocoding: {e}")
            text_lines.append("Location: Error in geocoding")
    else:
        text_lines.append("Location: Not available")
    
    # Calculate text block dimensions
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.7
    font_thickness = 2
    line_height = 30
    padding = 10
    
    text_height = len(text_lines) * line_height + 2 * padding
    text_width = max([cv2.getTextSize(line, font, font_scale, font_thickness)[0][0] for line in text_lines]) + 2 * padding
    
    # Position in bottom left corner
    overlay_x = 20
    overlay_y = height - text_height - 20
    
    # Create semi-transparent black background for text
    overlay = overlay_frame.copy()
    cv2.rectangle(overlay, 
                 (overlay_x - padding, overlay_y - padding), 
                 (overlay_x + text_width, overlay_y + text_height), 
                 (0, 0, 0), 
                 -1)  # Filled rectangle
    
    # Apply transparency
    alpha = 0.6  # 60% opacity
    cv2.addWeighted(overlay, alpha, overlay_frame, 1 - alpha, 0, overlay_frame)
    
    # Add text lines
    for i, line in enumerate(text_lines):
        y_position = overlay_y + i * line_height + padding
        cv2.putText(overlay_frame, line, (overlay_x + padding, y_position), 
                    font, font_scale, (255, 255, 255), font_thickness)
    
    # Save to permanent storage
    cv2.imwrite(filename, overlay_frame)
    
    # Save to temporary location for frontend access
    cv2.imwrite(temp_filename, overlay_frame)
    
    logger.info(f"Image saved to {filename} and {temp_filename}")
    return temp_filename

def calculate_face_movement(current_face, last_face):
    """Calculate face movement between frames"""
    if current_face is None or last_face is None:
        return 0
    
    current_center = ((current_face.left() + current_face.right()) // 2, 
                      (current_face.top() + current_face.bottom()) // 2)
    last_center = ((last_face.left() + last_face.right()) // 2, 
                   (last_face.top() + last_face.bottom()) // 2)
    
    movement = np.sqrt((current_center[0] - last_center[0])**2 + 
                       (current_center[1] - last_center[1])**2)
    
    return movement

def expand_face_box(face, frame_width, frame_height, scale_factor=FACE_BOX_SCALE_FACTOR):
    """Expand the face bounding box by the given scale factor"""
    # Calculate current width and height
    width = face.right() - face.left()
    height = face.bottom() - face.top()
    
    # Calculate new dimensions
    new_width = int(width * scale_factor)
    new_height = int(height * scale_factor)
    
    # Calculate new center
    center_x = (face.left() + face.right()) // 2
    center_y = (face.top() + face.bottom()) // 2
    
    # Calculate new coordinates
    new_left = max(0, center_x - new_width // 2)
    new_top = max(0, center_y - new_height // 2)
    new_right = min(frame_width - 1, center_x + new_width // 2)
    new_bottom = min(frame_height - 1, center_y + new_height // 2)
    
    # Create a new rectangle with expanded dimensions
    expanded_face = dlib.rectangle(new_left, new_top, new_right, new_bottom)
    
    return expanded_face

def detect_close_up_face(face_rect, frame_height):
    """Detect if face is too close to the camera (potential phone screen)"""
    face_height = face_rect.bottom() - face_rect.top()
    height_ratio = face_height / frame_height
    return height_ratio > CLOSE_UP_FACE_RATIO

def process_liveness_frame(frame, session_data):
    """Process a single frame for liveness detection"""
    # Track frame processing time
    current_time = time.time()
    if 'last_frame_time' in session_data:
        frame_interval = current_time - session_data['last_frame_time']
        # Log if frames are coming in too slowly
        if frame_interval > 0.2:  # More than 200ms between frames
            logger.warning(f"Slow frame rate detected: {1/frame_interval:.2f} FPS")
    session_data['last_frame_time'] = current_time
    
    # Store clean frame for potential capture
    clean_frame = frame.copy()
    session_data['clean_frame'] = clean_frame
    
    # Convert to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Check for screen spoofing
    if not session_data['spoofing_detected'] and current_time - session_data.get('last_screen_check_time', 0) > SCREEN_CHECK_INTERVAL:
        session_data['last_screen_check_time'] = current_time
        is_screen, screen_reason = detect_screen(frame)
        if is_screen:
            session_data['spoofing_detected'] = True
            session_data['spoofing_reason'] = screen_reason
            session_data['spoofing_detector'] = "screen_detector"
            session_data['message'] = f"SPOOFING DETECTED: {screen_reason}"
            session_data['status'] = "failed"
            session_data['stop_webcam'] = True
            logger.info(f"Spoofing detected by screen_detector: {screen_reason}")
            session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
            session_data['capture_start_time'] = time.time()
            return
    
    # Detect faces
    faces = detector(gray)
    
    # Update face tracking status
    if len(faces) == 1:
        face_present = True
        session_data['face_lost_frames'] = 0
        session_data['face_tracking_frames'] = session_data.get('face_tracking_frames', 0) + 1
        
        # Expand the face bounding box
        frame_height, frame_width = frame.shape[:2]
        expanded_face = expand_face_box(faces[0], frame_width, frame_height)
        
        # Check for close-up face (potential phone screen)
        if detect_close_up_face(faces[0], frame_height) and not session_data['spoofing_detected']:
            session_data['spoofing_detected'] = True
            session_data['spoofing_reason'] = "Face too close to camera (potential phone screen)"
            session_data['spoofing_detector'] = "close_up_detector"
            session_data['message'] = "SPOOFING DETECTED: Face too close to camera (potential phone screen)"
            session_data['status'] = "failed"
            session_data['stop_webcam'] = True
            logger.info(f"Spoofing detected by close_up_detector: Face too close to camera")
            session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
            session_data['capture_start_time'] = time.time()
            return
        
        if session_data.get('last_face_position') is not None:
            face_movement = calculate_face_movement(expanded_face, session_data['last_face_position'])
            session_data['face_movement'] = face_movement
        
        session_data['last_face_position'] = expanded_face
    else:
        face_present = False
        session_data['face_lost_frames'] = session_data.get('face_lost_frames', 0) + 1
        session_data['face_tracking_frames'] = 0
        
        if session_data.get('face_lost_frames', 0) >= FACE_LOST_THRESHOLD:
            session_data['last_face_position'] = None
            # Reset liveness timer if face is lost for too long during face tracking
            if session_data.get('current_state') == STATE_FACE_TRACKING and session_data.get('liveness_start_time') is not None:
                session_data['liveness_start_time'] = None
                session_data['face_tracking_continuous'] = False
                session_data['message'] = "Face tracking interrupted - face lost for too long. Timer reset."
                logger.info("Face tracking interrupted - face lost for too long. Timer reset.")
    
    # Initialize liveness timer
    if face_present and session_data.get('liveness_start_time') is None and session_data.get('current_state') == STATE_FACE_TRACKING:
        session_data['liveness_start_time'] = time.time()
        session_data['message'] = "Starting liveness check timer..."
        logger.info("Starting liveness check timer...")
    
    # Calculate elapsed time for liveness check
    liveness_elapsed_time = 0
    if session_data.get('liveness_start_time') is not None and session_data.get('current_state') == STATE_FACE_TRACKING:
        liveness_elapsed_time = time.time() - session_data['liveness_start_time']
        session_data['message'] = f"Liveness check: {liveness_elapsed_time:.1f}/{LIVENESS_DURATION}s"
    
    # Process face for visualization and challenges
    if face_present and not session_data['spoofing_detected']:
        face = faces[0]
        
        # Get facial landmarks
        shape = predictor(gray, face)
        shape_np = face_utils.shape_to_np(shape)
        
        # Extract eye landmarks
        leftEye = shape_np[lStart:lEnd]
        rightEye = shape_np[rStart:rEnd]
        
        # Calculate eye aspect ratio
        leftEAR = eye_aspect_ratio(leftEye)
        rightEAR = eye_aspect_ratio(rightEye)
        ear = (leftEAR + rightEAR) / 2.0
        
        # Store EAR for frontend
        session_data['current_ear'] = ear
    
    # State-specific processing
    current_state = session_data.get('current_state', STATE_FACE_TRACKING)
    
    if current_state == STATE_FACE_TRACKING:
        if face_present:
            if liveness_elapsed_time >= LIVENESS_DURATION:
                if not session_data.get('liveness_confirmed', False) and not session_data['spoofing_detected']:
                    logger.info("Face tracking successful for required duration. Starting blink challenge!")
                    session_data['current_state'] = STATE_BLINK_CHALLENGE
                    session_data['blink_challenge_start_time'] = time.time()
                    session_data['blink_counter'] = 0
                    session_data['blink_total'] = 0
                    session_data['message'] = f"BLINK CHALLENGE: Blink {BLINKS_REQUIRED} times"
        else:
            session_data['message'] = "NO FACE DETECTED"
    
    elif current_state == STATE_BLINK_CHALLENGE:
        elapsed_time = time.time() - session_data.get('blink_challenge_start_time', time.time())
        remaining_time = max(0, BLINK_CHALLENGE_DURATION - elapsed_time)
        
        # Display blink challenge instructions
        session_data['message'] = f"BLINK CHALLENGE: Blink {BLINKS_REQUIRED} times. Time remaining: {remaining_time:.1f}s. Blinks detected: {session_data.get('blink_total', 0)}/{BLINKS_REQUIRED}"
        
        if not face_present:
            session_data['message'] = "FACE LOST DURING CHALLENGE!"
            if session_data.get('face_lost_frames', 0) >= FACE_LOST_THRESHOLD:
                session_data['spoofing_detected'] = True
                session_data['spoofing_reason'] = "Face lost during blink challenge"
                session_data['spoofing_detector'] = "face_lost_detector"
                session_data['message'] = "SPOOFING DETECTED: Face lost during blink challenge"
                session_data['status'] = "failed"
                session_data['stop_webcam'] = True
                logger.info(f"Spoofing detected by face_lost_detector: Face lost during blink challenge")
                session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
                session_data['capture_start_time'] = time.time()
        
        if face_present:
            if ear < EYE_AR_THRESH:
                session_data['blink_counter'] = session_data.get('blink_counter', 0) + 1
            else:
                if session_data.get('blink_counter', 0) >= EYE_AR_CONSEC_FRAMES:
                    session_data['blink_total'] = session_data.get('blink_total', 0) + 1
                    session_data['message'] = "BLINK DETECTED!"
                    logger.info(f"Blink detected! Total: {session_data.get('blink_total', 0)}")
                session_data['blink_counter'] = 0
        
        if session_data.get('blink_total', 0) >= BLINKS_REQUIRED:
            session_data['liveness_confirmed'] = True
            session_data['message'] = "LIVENESS CONFIRMED!"
            session_data['status'] = "success"
            logger.info("Blink challenge completed successfully!")
            session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
            session_data['capture_start_time'] = time.time()
        elif remaining_time <= 0:
            session_data['spoofing_detected'] = True
            session_data['spoofing_reason'] = "Failed blink challenge"
            session_data['spoofing_detector'] = "blink_challenge_timeout"
            session_data['message'] = "SPOOFING DETECTED: Failed blink challenge"
            session_data['status'] = "failed"
            session_data['stop_webcam'] = True
            logger.info(f"Spoofing detected by blink_challenge_timeout: Failed blink challenge")
            session_data['current_state'] = STATE_CAPTURE_COUNTDOWN
            session_data['capture_start_time'] = time.time()
    
    elif current_state == STATE_CAPTURE_COUNTDOWN:
        elapsed_time = time.time() - session_data.get('capture_start_time', time.time())
        remaining_time = max(0, CAPTURE_DELAY - elapsed_time)
        
        # Display countdown message
        if session_data.get('spoofing_detected', False):
            session_data['message'] = f"KYC FAILED: {session_data.get('spoofing_reason', 'Unknown reason')}. Capturing image in {remaining_time:.1f}s"
        else:
            session_data['message'] = f"LIVENESS CONFIRMED! Capturing image in {remaining_time:.1f}s"
        
        if remaining_time <= 0 and not session_data.get('image_captured', False):
            temp_filename = save_capture(
                session_data['clean_frame'], 
                session_data['session_id'],
                not session_data.get('spoofing_detected', False)
            )
            session_data['image_captured'] = True
            session_data['image_path'] = temp_filename
            session_data['current_state'] = STATE_CAPTURED
            
            if session_data.get('spoofing_detected', False):
                session_data['message'] = f"KYC FAILED: {session_data.get('spoofing_reason', 'Unknown reason')}. Image captured."
            else:
                session_data['message'] = "LIVENESS CONFIRMED! Image captured successfully."
    
    elif current_state == STATE_CAPTURED:
        if session_data.get('spoofing_detected', False):
            session_data['message'] = f"KYC FAILED: {session_data.get('spoofing_reason', 'Unknown reason')}. Image captured."
        else:
            session_data['message'] = "LIVENESS CONFIRMED! Image captured successfully."
        
        session_data['stop_webcam'] = True

@app.route('/detect', methods=['POST', 'OPTIONS'])
def detect():
    # Handle preflight OPTIONS request
    if request.method == 'OPTIONS':
        logger.debug("Received OPTIONS request")
        return '', 200
    
    logger.debug("Received POST request")
    try:
        # Get the image data from the request
        request_data = request.get_json()
        if not request_data:
            logger.error("No JSON data in request")
            return jsonify({'error': 'No JSON data provided'}), 400
            
        image_data = request_data.get('image')
        if not image_data:
            logger.error("No image data in request JSON")
            return jsonify({'error': 'No image data provided'}), 400
        
        logger.debug("Image data received, processing...")
        
        # Decode the base64 image
        try:
            encoded_data = image_data.split(',')[1]
            nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if img is None:
                logger.error("Failed to decode image")
                return jsonify({'error': 'Failed to decode image'}), 400
                
            logger.debug(f"Image decoded successfully, shape: {img.shape}")
        except Exception as e:
            logger.error(f"Error decoding image: {str(e)}")
            return jsonify({'error': f'Error decoding image: {str(e)}'}), 400
        
        # Run YOLO detection
        logger.debug("Running YOLO detection...")
        results = hand_detector(img)
        logger.debug("YOLO detection completed")
        
        # Process results
        detected_signs = []
        for result in results:
            boxes = result.boxes
            logger.debug(f"Found {len(boxes)} detections")
            
            for box in boxes:
                # Get class and confidence
                cls_id = int(box.cls.item())
                conf = float(box.conf.item())
                
                if conf > 0.5:  # Confidence threshold
                    # Use the model's class names directly
                    hand_sign = result.names[cls_id]
                    detected_signs.append({
                        'sign': hand_sign,
                        'confidence': conf
                    })
                    logger.debug(f"Detected sign: {hand_sign} with confidence: {conf}")
        
        # Return the detected hand signs
        response_data = {
            'success': True,
            'detected_signs': detected_signs
        }
        logger.debug(f"Returning response: {response_data}")
        return jsonify(response_data)
    
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/start_liveness', methods=['POST'])
def start_liveness():
    """Initialize a new liveness detection session"""
    session_id = str(uuid.uuid4())
    
    # Create a new session
    sessions[session_id] = {
        'session_id': session_id,
        'start_time': time.time(),
        'current_state': STATE_FACE_TRACKING,
        'liveness_start_time': None,
        'blink_challenge_start_time': None,
        'blink_counter': 0,
        'blink_total': 0,
        'face_tracking_frames': 0,
        'face_lost_frames': 0,
        'last_face_position': None,
        'face_movement': 0,
        'liveness_confirmed': False,
        'face_tracking_continuous': True,
        'spoofing_detected': False,
        'spoofing_reason': None,
        'spoofing_detector': None,
        'last_screen_check_time': time.time(),
        'status': 'pending',
        'message': 'Starting liveness detection...',
        'clean_frame': None,
        'capture_start_time': None,
        'image_captured': False,
        'image_path': None,
        'stop_webcam': False,
        'last_frame_time': time.time(),
        'current_ear': 0.0
    }
    
    logger.info(f"Created new liveness session: {session_id}")
    return jsonify({
        'success': True,
        'session_id': session_id,
        'message': 'Liveness detection session started'
    })

@app.route('/process_liveness_frame', methods=['POST'])
def process_liveness():
    """Process a frame for liveness detection"""
    try:
        # Get request data
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        session_id = request_data.get('session_id')
        image_data = request_data.get('image')
        geo_location = request_data.get('geo_location')  # Get location data if provided
        
        if not session_id or not image_data:
            return jsonify({'error': 'Missing session_id or image data'}), 400
        
        # Check if session exists
        if session_id not in sessions:
            return jsonify({'error': 'Invalid session ID'}), 404
        
        session_data = sessions[session_id]
        
        # Store geo_location in session data if provided
        if geo_location and not session_data.get('geo_location'):
            session_data['geo_location'] = geo_location
            logger.info(f"Geo location data received for session {session_id}")
        
        # Decode the base64 image
        try:
            encoded_data = image_data.split(',')[1]
            nparr = np.frombuffer(base64.b64decode(encoded_data), np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if img is None:
                return jsonify({'error': 'Failed to decode image'}), 400
        except Exception as e:
            logger.error(f"Error decoding image: {str(e)}")
            return jsonify({'error': f'Error decoding image: {str(e)}'}), 400
        
        # Process the frame for liveness detection
        process_liveness_frame(img, session_data)
        
        # Prepare response
        response = {
            'success': True,
            'session_id': session_id,
            'status': session_data.get('status', 'pending'),
            'message': session_data.get('message', 'Processing...'),
            'current_state': session_data.get('current_state', STATE_FACE_TRACKING),
            'liveness_confirmed': session_data.get('liveness_confirmed', False),
            'spoofing_detected': session_data.get('spoofing_detected', False),
            'stop_webcam': session_data.get('stop_webcam', False),
            'blink_total': session_data.get('blink_total', 0),
            'blinks_required': BLINKS_REQUIRED,
            'current_ear': session_data.get('current_ear', 0.0),
            'ear_threshold': EYE_AR_THRESH
        }
        
        # If image has been captured, include the path
        if session_data.get('image_captured', False) and session_data.get('image_path'):
            response['image_path'] = session_data['image_path']
        
        return jsonify(response)
    
    except Exception as e:
        logger.error(f"Error processing liveness frame: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/get_captured_image/<session_id>', methods=['GET'])
def get_captured_image(session_id):
    """Return the captured image for a session"""
    if session_id not in sessions:
        return jsonify({'error': 'Invalid session ID'}), 404
    
    session_data = sessions[session_id]
    
    if not session_data.get('image_captured', False) or not session_data.get('image_path'):
        return jsonify({'error': 'No image captured for this session'}), 404
    
    try:
        return send_file(session_data['image_path'], mimetype='image/jpeg')
    except Exception as e:
        logger.error(f"Error sending image: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/search', methods=['POST'])
def search():
    """Process the captured image for search/verification"""
    try:
        # Get request data
        request_data = request.get_json()
        if not request_data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        session_id = request_data.get('session_id')
        
        if not session_id:
            return jsonify({'error': 'Missing session_id'}), 400
        
        # Check if session exists
        if session_id not in sessions:
            return jsonify({'error': 'Invalid session ID'}), 404
        
        session_data = sessions[session_id]
        
        # Check if image was captured
        if not session_data.get('image_captured', False) or not session_data.get('image_path'):
            return jsonify({'error': 'No image captured for this session'}), 400
        
        # Here you would implement your search/verification logic
        # For now, we'll just return a success message
        
        # Mock search result
        search_result = {
            'success': True,
            'message': 'Verification completed successfully',
            'match_found': True,
            'match_confidence': 0.95,
            'user_details': {
                'name': 'John Doe',
                'id': '12345',
                'status': 'Verified'
            }
        }
        
        return jsonify(search_result)
    
    except Exception as e:
        logger.error(f"Error in search: {str(e)}", exc_info=True)
        return jsonify({'error': str(e)}), 500

@app.route('/test', methods=['GET'])
def test():
    return jsonify({'status': 'API is working'})

if __name__ == '__main__':
    logger.info("Starting Flask server...")
    app.run(host='0.0.0.0', port=5003, debug=True)

