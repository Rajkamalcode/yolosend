'use client';

import { useState } from 'react';
import DocumentUpload from '../../components/document-upload';
import DocumentAnalysis from '../../components/document-analysis';
import DocumentChat from '../../components/document-chat';
import { SessionResponse } from '../../services/documentService';

export default function DocumentComparisonPage() {
  const [sessionData, setSessionData] = useState<SessionResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleProcessingComplete = (result: SessionResponse) => {
    setSessionData(result);
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8 text-center">Property Document Comparison</h1>
      
      {!sessionData && (
        <DocumentUpload 
          onProcessingComplete={handleProcessingComplete}
          setIsLoading={setIsLoading}
        />
      )}
      
      {isLoading && (
        <div className="w-full max-w-2xl mx-auto p-4 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700 mx-auto mb-4"></div>
          <p className="text-gray-700">Processing documents. This may take several minutes...</p>
        </div>
      )}
      
      {sessionData && (
        <div className="space-y-8">
          <DocumentAnalysis sessionData={sessionData} />
          
          <DocumentChat 
            sessionId={sessionData.session_id}
            initialChatHistory={sessionData.chat_history || []}
          />
          
          <div className="w-full max-w-4xl mx-auto p-4 bg-white rounded-lg shadow">
            <h2 className="text-xl font-bold mb-4">Document Details</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(sessionData.processed_files).map(([filename, fileData]) => (
                <div key={filename} className="border rounded p-4">
                  <h3 className="font-bold text-lg mb-2">{filename}</h3>
                  
                  {fileData.error ? (
                    <p className="text-red-600">{fileData.error}</p>
                  ) : (
                    <>
                      <p>
                        <span className="font-semibold">Language:</span> {fileData.detected_language.name}
                      </p>
                      {fileData.notes && fileData.notes.length > 0 && (
                        <div className="mt-2">
                          <p className="font-semibold">Notes:</p>
                          <ul className="list-disc list-inside">
                            {fileData.notes.map((note, i) => (
                              <li key={i} className="text-sm">{note}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          <div className="text-center">
            <button
              onClick={() => setSessionData(null)}
              className="py-2 px-4 bg-gray-600 hover:bg-gray-700 text-white font-bold rounded"
            >
              Start New Comparison
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
