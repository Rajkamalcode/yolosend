import os
import base64
import json
from PIL import Image, ImageDraw
import io
import tempfile
import config
from .vertex_ai import generate_content_with_image

def detect_signatures(file_path, project_id=config.VERTEX_AI_PROJECT_ID, 
                     location=config.VERTEX_AI_LOCATION, 
                     credentials_path=config.CREDENTIALS_PATH):
    """
    Detect signatures in a document image using Vertex AI.
    
    Args:
        file_path:  (JPEG)
        project_id: Google Cloud project ID
        location: Google Cloud region
        credentials_path: Path to the service account credentials file
        
    Returns:
        Dictionary with signature detection results
    """
    from google import genai
    
    # Set up Vertex AI client
    os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_path
    client = genai.Client(vertexai=True, project=project_id, location=location)
    model = config.VERTEX_AI_MODEL
    
    # Verify file exists and is an image
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_extension = os.path.splitext(file_path)[1].lower()
    if file_extension not in ['.jpg', '.jpeg', '.png']:
        raise ValueError(f"Unsupported file format: {file_extension}. Please provide a JPEG or PNG image.")
    
    # Read and encode the image
    with open(file_path, "rb") as image_file:
        image_bytes = image_file.read()
        image_base64 = base64.b64encode(image_bytes).decode('utf-8')
    
    # Create prompt for signature detection
    prompt = """
    Analyze this document image and identify all signatures present in it. 
    For each signature detected, provide:
    1. The location (approximate coordinates or region description)
    2. Whether it appears to be a customer/borrower signature or an official/authorized signature
    3. Confidence level of detection (high, medium, low)
    
    Return the results in the following JSON format:
    {
        "signatures_detected": [
            {
                "type": "customer" or "authorized" or "unknown",
                "location": "description of location",
                "confidence": "high/medium/low",
                "approximate_coordinates": {
                    "top_left": [x, y],
                    "bottom_right": [x, y]
                }
            }
        ],
        "total_signatures": number,
        "has_customer_signature": boolean,
        "has_authorized_signature": boolean,
        "signature_verification": {
            "status": "complete" or "incomplete",
            "missing_signatures": ["customer", "authorized"] or []
        }
    }
    
    If you cannot determine exact coordinates, provide your best estimate or omit the coordinates field.
    """
    
    # Process the image with Vertex AI
    try:
        response = generate_content_with_image(client, model, prompt, image_base64, "image/jpeg")
        
        # Extract structured data
        if response and 'structured_data' in response:
            result = response['structured_data']
            
            # Add the raw response for debugging
            result['raw_response'] = response.get('raw_response', '')
            
            # Visualize signatures if coordinates are available
            if 'signatures_detected' in result:
                try:
                    visualization_path = visualize_signatures(file_path, result['signatures_detected'])
                    result['visualization_path'] = visualization_path
                except Exception as e:
                    result['visualization_error'] = str(e)
            
            return result
        else:
            return {
                'error': 'Failed to extract structured data from response',
                'raw_response': response.get('raw_response', '')
            }
    
    except Exception as e:
        return {
            'error': f'Error detecting signatures: {str(e)}'
        }

def visualize_signatures(image_path, signatures_detected):
    """
    Create a visualization of detected signatures on the original image.
    
    Args:
        image_path: Path to the original image
        signatures_detected: List of signature detection results with coordinates
        
    Returns:
        Path to the visualization image
    """
    # Open the original image
    image = Image.open(image_path)
    draw = ImageDraw.Draw(image)
    
    # Define colors for different signature types
    colors = {
        'customer': (255, 0, 0),  # Red for customer signatures
        'authorized': (0, 255, 0),  # Green for authorized signatures
        'unknown': (0, 0, 255)     # Blue for unknown signatures
    }
    
    # Draw boxes around detected signatures
    for signature in signatures_detected:
        if 'approximate_coordinates' in signature:
            coords = signature.get('approximate_coordinates', {})
            if 'top_left' in coords and 'bottom_right' in coords:
                top_left = coords['top_left']
                bottom_right = coords['bottom_right']
                
                # Get color based on signature type
                sig_type = signature.get('type', 'unknown')
                color = colors.get(sig_type, colors['unknown'])
                
                # Draw rectangle
                draw.rectangle([tuple(top_left), tuple(bottom_right)], outline=color, width=3)
                
                # Add label
                confidence = signature.get('confidence', 'unknown')
                label = f"{sig_type} ({confidence})"
                draw.text((top_left[0], top_left[1] - 15), label, fill=color)
    
    # Save the visualization to a temporary file
    output_dir = os.path.join(tempfile.gettempdir(), 'signature_detection')
    os.makedirs(output_dir, exist_ok=True)
    
    base_filename = os.path.basename(image_path)
    output_path = os.path.join(output_dir, f"detected_{base_filename}")
    
    image.save(output_path)
    return output_path

def verify_document_signatures(file_path, required_signatures=None):
    """
    Verify if a document has all required signatures.
    
    Args:
        file_path: Path to the document image
        required_signatures: List of required signature types (e.g., ['customer', 'authorized'])
        
    Returns:
        Dictionary with verification results
    """
    if required_signatures is None:
        required_signatures = ['customer', 'authorized']
    
    # Detect signatures in the document
    detection_result = detect_signatures(file_path)
    
    if 'error' in detection_result:
        return {
            'verification_status': 'error',
            'error': detection_result['error']
        }
    
    # Check if all required signatures are present
    signatures_detected = detection_result.get('signatures_detected', [])
    detected_types = [sig.get('type') for sig in signatures_detected]
    
    missing_signatures = [sig_type for sig_type in required_signatures 
                         if sig_type not in detected_types]
    
    verification_status = 'complete' if not missing_signatures else 'incomplete'
    
    return {
        'verification_status': verification_status,
        'missing_signatures': missing_signatures,
        'detection_result': detection_result
    }

def batch_verify_signatures(document_paths, required_signatures=None):
    """
    Verify signatures for multiple documents.
    
    Args:
        document_paths: Dictionary mapping document types to file paths
        required_signatures: Dictionary mapping document types to required signature types
        
    Returns:
        Dictionary with verification results for each document
    """
    if required_signatures is None:
        # Default required signatures by document type
        required_signatures = {
            'sanction_letter': ['customer', 'authorized'],
            'agreement': ['customer'],
            'kyc': ['customer'],
            'legal_report': ['authorized'],
            'memorandum_of_title': ['customer', 'authorized']
        }
    
    results = {}
    
    for doc_type, file_path in document_paths.items():
        # Skip if file doesn't exist
        if not os.path.exists(file_path):
            results[doc_type] = {
                'verification_status': 'error',
                'error': f'File not found: {file_path}'
            }
            continue
        
        # Get required signatures for this document type
        doc_required_signatures = required_signatures.get(doc_type, ['customer', 'authorized'])
        
        # Verify signatures
        verification_result = verify_document_signatures(file_path, doc_required_signatures)
        results[doc_type] = verification_result
    
    # Calculate overall verification status
    all_complete = all(result.get('verification_status') == 'complete' 
                      for result in results.values() 
                      if result.get('verification_status') != 'error')
    
    overall_status = 'complete' if all_complete else 'incomplete'
    
    return {
        'overall_status': overall_status,
        'document_results': results
    }

res = verify_document_signatures(r"D:\documents\docuCompare\utils\1.jpeg")
print(res)