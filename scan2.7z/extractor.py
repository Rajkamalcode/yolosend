import cv2
import numpy as np
import pytesseract
from skimage.metrics import structural_similarity as ssim
from pdf2image import convert_from_path
from Levenshtein import ratio as levenshtein_ratio
from sklearn.metrics.pairwise import cosine_similarity
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe' # Windows Example

def preprocess_image(img):
    """Enhanced document-specific preprocessing"""
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    
    # Adaptive thresholding with noise reduction
    blurred = cv2.bilateralFilter(gray, 9, 75, 75)
    thresh = cv2.adaptiveThreshold(blurred, 255, 
                                  cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                  cv2.THRESH_BINARY, 11, 2)
    
    # Morphological cleanup
    kernel = np.ones((2,2), np.uint8)
    cleaned = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
    
    return cleaned

def document_sift_alignment(base_img, aligned_img):
    """Document-optimized alignment using SIFT features"""
    sift = cv2.SIFT_create()
    kp1, des1 = sift.detectAndCompute(base_img, None)
    kp2, des2 = sift.detectAndCompute(aligned_img, None)

    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)
    
    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(des1, des2, k=2)

    good = []
    for m,n in matches:
        if m.distance < 0.7*n.distance:
            good.append(m)

    if len(good) > 10:
        src_pts = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1,1,2)
        dst_pts = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1,1,2)

        M, _ = cv2.findHomography(dst_pts, src_pts, cv2.RANSAC, 5.0)
        aligned = cv2.warpPerspective(aligned_img, M, 
                                    (base_img.shape[1], base_img.shape[0]))
    else:
        aligned = aligned_img

    return aligned

def calculate_document_similarity(orig_img, scan_img):
    """Optimized document similarity calculation"""
    # Structural similarity
    ssim_score, _ = ssim(orig_img, scan_img, full=True)
    
    # OCR-based text similarity
    config = r'--oem 3 --psm 6'  # Optimized for document text
    orig_text = pytesseract.image_to_string(orig_img, config=config)
    scan_text = pytesseract.image_to_string(scan_img, config=config)
    text_score = levenshtein_ratio(orig_text, scan_text)
    
    # Layout-based similarity using keypoint matching
    sift = cv2.SIFT_create()
    kp1, des1 = sift.detectAndCompute(orig_img, None)
    kp2, des2 = sift.detectAndCompute(scan_img, None)
    
    layout_score = 0
    if des1 is not None and des2 is not None:
        matches = cosine_similarity(des1, des2)
        layout_score = np.mean(np.max(matches, axis=1))
    
    # Weighted combination (adjust these weights based on your document types)
    combined_score = (
        0.25 * ssim_score +
        0.55 * text_score +
        0.20 * layout_score
    )
    
    print(f"SSIM: {ssim_score:.3f} | Text: {text_score:.3f} | Layout: {layout_score:.3f} | Total: {combined_score:.3f}")
    return combined_score

def compare_documents(original_pdf, scanned_pdf, threshold=0.65):
    """Final document comparison with clear separation"""
    original_images = convert_from_path(original_pdf, dpi=300)
    scanned_images = convert_from_path(scanned_pdf, dpi=300)
    
    min_pages = min(len(original_images), len(scanned_images))
    all_match = True
    
    for i in range(min_pages):
        orig_pre = preprocess_image(np.array(original_images[i]))
        scan_pre = preprocess_image(np.array(scanned_images[i]))
        
        aligned_scan = document_sift_alignment(orig_pre, scan_pre)
        similarity = calculate_document_similarity(orig_pre, aligned_scan)
        
        if similarity < threshold:
            print(f"❌ Page {i+1} Mismatch (Score: {similarity:.3f})")
            all_match = False
        else:
            print(f"✅ Page {i+1} Match (Score: {similarity:.3f})")

    # Handle page count mismatch
    page_diff = len(original_images) - len(scanned_images)
    if page_diff != 0:
        print(f"⚠️ Page count mismatch: {abs(page_diff)} pages difference")
        all_match = False

    return all_match

# Example usage
if __name__ == "__main__":
    SIMILARITY_THRESHOLD = 0.65  # Adjust based on your testing
    
    # Test with different documents
    print("Testing DIFFERENT documents:")
    diff_result = compare_documents('Rajkamal_July_scanned.pdf', 'Resume Rajkamal.pdf', SIMILARITY_THRESHOLD)
    
    # Test with same documents
    print("\nTesting SAME documents:")
    same_result = compare_documents('Rajkamal_July_scanned.pdf', 'Rajkamal_July.pdf', SIMILARITY_THRESHOLD)

    print("\nTesting ANOTHER SAME documents:")
    same_result = compare_documents('1.pdf', '2.pdf', SIMILARITY_THRESHOLD)