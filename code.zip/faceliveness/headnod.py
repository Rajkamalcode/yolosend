import cv2
import dlib
import time
import numpy as np
import random
import os
from scipy.spatial import distance as dist
from imutils import face_utils
from ultralytics import YOLO
from datetime import datetime

# Create directories for saving images
os.makedirs("successful_kyc", exist_ok=True)
os.makedirs("failed_kyc", exist_ok=True)

# Constants
EYE_AR_THRESH = 0.18
EYE_AR_CONSEC_FRAMES = 3
MOUTH_AR_THRESH = 0.75
REFLECTION_THRESHOLD = 200
REQUIRED_FRAMES = 5  # Reduced for faster detection
CAPTURE_DELAY = 5  # 5 seconds delay before capturing

# Initialize dlib's face detector and facial landmark predictor
print("[INFO] Loading the predictor and detector...")
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

# Load YOLO models
try:
    screen_detector = YOLO("screen detect.pt")
    has_screen_detector = True
    print("[INFO] Screen detector loaded successfully")
except Exception as e:
    has_screen_detector = False
    print(f"[WARNING] Screen detector not loaded: {e}")

# Start video capture
cap = cv2.VideoCapture(0)

# Helper functions
def eye_aspect_ratio(eye):
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    C = dist.euclidean(eye[0], eye[3])
    ear = (A + B) / (2.0 * C)
    return ear

def mouth_aspect_ratio(mouth):
    A = dist.euclidean(mouth[3], mouth[9])
    B = dist.euclidean(mouth[2], mouth[10])
    C = dist.euclidean(mouth[4], mouth[8])
    D = dist.euclidean(mouth[0], mouth[6])
    mar = (A + B + C) / (3.0 * D)
    return mar

def midpoint(p1, p2):
    return int((p1.x + p2.x)/2), int((p1.y + p2.y)/2)

def get_improved_gaze_ratio(eye_points, facial_landmarks, frame, gray):
    # Extract eye region
    eye_region = np.array([(facial_landmarks.part(point).x, facial_landmarks.part(point).y) for point in eye_points], np.int32)
    
    # Create mask for the eye
    height, width = frame.shape[:2]
    mask = np.zeros((height, width), np.uint8)
    cv2.polylines(mask, [eye_region], True, 255, 2)
    cv2.fillPoly(mask, [eye_region], 255)
    eye = cv2.bitwise_and(gray, gray, mask=mask)
    
    # Find eye boundaries
    min_x = np.min(eye_region[:, 0])
    max_x = np.max(eye_region[:, 0])
    min_y = np.min(eye_region[:, 1])
    max_y = np.max(eye_region[:, 1])
    
    # Extract eye ROI
    gray_eye = eye[min_y:max_y, min_x:max_x]
    if gray_eye.size == 0:
        return 1.0  # Default value if eye region is invalid
    
    # Apply adaptive thresholding for better pupil detection
    _, threshold_eye = cv2.threshold(gray_eye, 70, 255, cv2.THRESH_BINARY)
    
    # Divide eye into left and right portions
    h, w = threshold_eye.shape
    left_side_threshold = threshold_eye[0:h, 0:int(w / 2)]
    right_side_threshold = threshold_eye[0:h, int(w / 2):w]
    
    # Count white pixels
    left_white = cv2.countNonZero(left_side_threshold)
    right_white = cv2.countNonZero(right_side_threshold)
    
    # Calculate gaze ratio with safety check
    if left_white == 0 and right_white == 0:
        gaze_ratio = 1.0
    elif right_white == 0:
        gaze_ratio = 5.0  # Strong left gaze
    elif left_white == 0:
        gaze_ratio = 0.2  # Strong right gaze
    else:
        gaze_ratio = left_white / right_white
    
    return gaze_ratio

def detect_screen(frame):
    """Detect if a screen is present in the frame"""
    if not has_screen_detector:
        return False
    
    results = screen_detector(frame, verbose=False)[0]
    for box in results.boxes:
        if box.conf > 0.6:
            return True
    return False

def detect_reflections(frame, face_region):
    """Detect unnatural reflections that might indicate a screen"""
    if face_region.size == 0:
        return False
    
    # Convert to HSV for better highlight detection
    hsv = cv2.cvtColor(face_region, cv2.COLOR_BGR2HSV)
    
    # Extract the V channel (brightness)
    _, _, v = cv2.split(hsv)
    
    # Look for bright spots (potential reflections)
    _, bright_spots = cv2.threshold(v, REFLECTION_THRESHOLD, 255, cv2.THRESH_BINARY)
    
    # Count bright pixels
    bright_pixel_count = cv2.countNonZero(bright_spots)
    bright_pixel_ratio = bright_pixel_count / (face_region.shape[0] * face_region.shape[1])
    
    # If more than 10% of face has bright reflections, it might be a spoof
    return bright_pixel_ratio > 0.1

def save_capture(frame, success=True):
    """Save the captured frame to the appropriate folder"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    folder = "successful_kyc" if success else "failed_kyc"
    filename = f"{folder}/{timestamp}.jpg"
    cv2.imwrite(filename, frame)
    print(f"[INFO] Image saved to {filename}")
    return filename

# Define challenges - only keeping blink and open mouth
challenges = [
    {"name": "BLINK", "instruction": "Please blink your eyes", "duration": 5},
    {"name": "OPEN_MOUTH", "instruction": "Please open your mouth", "duration": 5}
]

# Use both challenges
selected_challenges = challenges

# Get facial landmark indexes for eyes and mouth
(lStart, lEnd) = face_utils.FACIAL_LANDMARKS_IDXS["left_eye"]
(rStart, rEnd) = face_utils.FACIAL_LANDMARKS_IDXS["right_eye"]
(mStart, mEnd) = face_utils.FACIAL_LANDMARKS_IDXS["mouth"]

# Counters and state variables
blink_counter = 0
start_time = time.time()
liveness_confirmed = False
spoofing_detected = False
current_challenge = 0
challenge_start_time = None
challenge_completed = False

# Frame counters for challenges
blink_frame_count = 0
open_mouth_frame_count = 0

# Program states
STATE_LIVENESS_CHECK = 0
STATE_COMPLETED = 1
STATE_CAPTURE_COUNTDOWN = 2
STATE_CAPTURED = 3
current_state = STATE_LIVENESS_CHECK

# Variable to store the frozen frame when spoofing is detected
frozen_frame = None
clean_frozen_frame = None
capture_start_time = None
capture_filename = None

print("[INFO] Starting video stream...")
print(f"[INFO] Selected challenges: {[c['name'] for c in selected_challenges]}")

while True:
    if not spoofing_detected:
        ret, frame = cap.read()
        if not ret:
            break
        frame = cv2.flip(frame, 1)
        # Store a clean copy of the frame without any text overlays
        clean_frame = frame.copy()
    else:
        # If spoofing is detected, use the frozen frame
        frame = frozen_frame.copy()
        # Use the clean frozen frame for saving
        clean_frame = clean_frozen_frame.copy()
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Check for screen spoofing (only check every few frames for speed)
    if not spoofing_detected and time.time() % 2 < 0.1 and has_screen_detector:  # Check roughly every 2 seconds
        if detect_screen(frame):
            spoofing_detected = True
            frozen_frame = frame.copy()  # Freeze the current frame
            clean_frozen_frame = clean_frame.copy()  # Store clean version
            cv2.putText(frame, "SPOOFING DETECTED: Screen Present", (10, 60), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            cv2.putText(frame, "KYC FAILED", (frame.shape[1]//2 - 100, frame.shape[0]//2), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)
            current_state = STATE_COMPLETED
            liveness_confirmed = False

    faces = detector(gray)
    
    if current_state == STATE_LIVENESS_CHECK and not spoofing_detected:
        # Challenge-Response Logic
        if current_challenge < len(selected_challenges):
            challenge = selected_challenges[current_challenge]
            
            # Initialize challenge timer if not started
            if challenge_start_time is None:
                challenge_start_time = time.time()
                challenge_completed = False
            
            # Calculate remaining time
            elapsed_time = time.time() - challenge_start_time
            remaining_time = max(0, challenge["duration"] - elapsed_time)
            
            # Display current challenge
            cv2.putText(frame, challenge["instruction"], (30, 30), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            cv2.putText(frame, f"Time: {remaining_time:.1f}s", (30, 60), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            
            if len(faces) == 1:
                face = faces[0]
                
                # Extract face region for reflection analysis
                x, y, w, h = face.left(), face.top(), face.width(), face.height()
                face_region = frame[y:y+h, x:x+w]
                
                # Check for unnatural reflections (only check occasionally for speed)
                if time.time() % 3 < 0.1:  # Check roughly every 3 seconds
                    if detect_reflections(frame, face_region):
                        spoofing_detected = True
                        frozen_frame = frame.copy()  # Freeze the current frame
                        clean_frozen_frame = clean_frame.copy()  # Store clean version
                        cv2.putText(frame, "SPOOFING DETECTED: Unnatural Reflections", (10, 90), 
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                        cv2.putText(frame, "KYC FAILED", (frame.shape[1]//2 - 100, frame.shape[0]//2), 
                                    cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)
                        current_state = STATE_COMPLETED
                        liveness_confirmed = False
                
                shape = predictor(gray, face)
                shape_np = face_utils.shape_to_np(shape)

                # Draw all 68 facial landmarks
                for (x, y) in shape_np:
                    cv2.circle(frame, (x, y), 2, (0, 255, 0), -1)
                
                # Draw eye and mouth regions
                leftEye = shape_np[lStart:lEnd]
                rightEye = shape_np[rStart:rEnd]
                mouth = shape_np[mStart:mEnd]
                
                leftEyeHull = cv2.convexHull(leftEye)
                rightEyeHull = cv2.convexHull(rightEye)
                mouthHull = cv2.convexHull(mouth)
                cv2.drawContours(frame, [leftEyeHull], -1, (0, 255, 0), 1)
                cv2.drawContours(frame, [rightEyeHull], -1, (0, 255, 0), 1)
                cv2.drawContours(frame, [mouthHull], -1, (0, 255, 0), 1)

                leftEAR = eye_aspect_ratio(leftEye)
                rightEAR = eye_aspect_ratio(rightEye)
                ear = (leftEAR + rightEAR) / 2.0

                mar = mouth_aspect_ratio(mouth)
                
                # Check if challenge is completed
                if challenge["name"] == "BLINK":
                    if ear < EYE_AR_THRESH:
                        blink_frame_count += 1
                    else:
                        blink_frame_count = 0
                    
                    if blink_frame_count >= EYE_AR_CONSEC_FRAMES:
                        challenge_completed = True
                
                elif challenge["name"] == "OPEN_MOUTH":
                    if mar > MOUTH_AR_THRESH:
                        open_mouth_frame_count += 1
                    else:
                        open_mouth_frame_count = 0
                    
                    if open_mouth_frame_count >= REQUIRED_FRAMES:
                        challenge_completed = True
            
            # Move to next challenge if completed or time expired
            if challenge_completed or remaining_time <= 0:
                if challenge_completed:
                    print(f"Challenge '{challenge['name']}' completed successfully!")
                    cv2.putText(frame, "CHALLENGE COMPLETED!", (30, 120), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                    current_challenge += 1  # Only advance to next challenge if completed successfully
                else:
                    print(f"Challenge '{challenge['name']}' failed.")
                    cv2.putText(frame, "CHALLENGE FAILED!", (30, 120), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    # Reset liveness check since a challenge failed
                    current_state = STATE_LIVENESS_CHECK
                    current_challenge = 0
                    challenge_start_time = None
                    challenge_completed = False
                    blink_frame_count = 0
                    open_mouth_frame_count = 0
                    print("Challenge failed. Resetting liveness detection for a new attempt.")
                
                # Display result for a moment
                cv2.imshow("Liveness Detection", frame)
                cv2.waitKey(500)  # Reduced to 500ms for faster response
                
                challenge_start_time = None
        else:
            # All challenges completed
            if spoofing_detected:
                cv2.putText(frame, "KYC FAILED", (30, 120), 
                            cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
                cv2.putText(frame, "SPOOFING DETECTED", (30, 160), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                # Reset challenges
                current_challenge = 0
                challenge_start_time = None
            else:
                liveness_confirmed = True
                current_state = STATE_COMPLETED
                print("[INFO] All challenges completed. Liveness confirmed!")
            
            # Start capture countdown
            current_state = STATE_CAPTURE_COUNTDOWN
            capture_start_time = time.time()
    
    elif current_state == STATE_COMPLETED:
        # Display completion message
        if spoofing_detected:
            cv2.putText(frame, "KYC FAILED", (frame.shape[1]//2 - 100, frame.shape[0]//2 - 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)
            cv2.putText(frame, "SPOOFING DETECTED", (frame.shape[1]//2 - 150, frame.shape[0]//2 + 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
        else:
            cv2.putText(frame, "LIVENESS CONFIRMED", (30, 120), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
            cv2.putText(frame, "KYC SUCCESSFUL", (30, 160), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
        
        cv2.putText(frame, "Press ESC to exit", (30, 200), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Start capture countdown if not already started
        if current_state != STATE_CAPTURE_COUNTDOWN and current_state != STATE_CAPTURED:
            current_state = STATE_CAPTURE_COUNTDOWN
            capture_start_time = time.time()
    
    elif current_state == STATE_CAPTURE_COUNTDOWN:
        # Display countdown for image capture
        elapsed_time = time.time() - capture_start_time
        remaining_time = max(0, CAPTURE_DELAY - elapsed_time)
        
        # Display countdown message
        cv2.putText(frame, f"Capturing image in {remaining_time:.1f}s", (30, 240), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Display completion message based on KYC result
        if spoofing_detected:
            cv2.putText(frame, "KYC FAILED", (frame.shape[1]//2 - 100, frame.shape[0]//2 - 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)
            cv2.putText(frame, "SPOOFING DETECTED", (frame.shape[1]//2 - 150, frame.shape[0]//2 + 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
        else:
            cv2.putText(frame, "LIVENESS CONFIRMED", (30, 120), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
            cv2.putText(frame, "KYC SUCCESSFUL", (30, 160), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
        
        # Capture image when countdown reaches zero
        if remaining_time <= 0:
            # Capture the clean frame without any text overlays
            capture_filename = save_capture(clean_frame, not spoofing_detected)
            current_state = STATE_CAPTURED
    
    elif current_state == STATE_CAPTURED:
        # Display capture confirmation
        if spoofing_detected:
            cv2.putText(frame, "KYC FAILED", (frame.shape[1]//2 - 100, frame.shape[0]//2 - 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3)
            cv2.putText(frame, "SPOOFING DETECTED", (frame.shape[1]//2 - 150, frame.shape[0]//2 + 50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 255), 2)
        else:
            cv2.putText(frame, "LIVENESS CONFIRMED", (30, 120), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
            cv2.putText(frame, "KYC SUCCESSFUL", (30, 160), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
        
        cv2.putText(frame, f"Image captured and saved to {capture_filename}", (30, 240), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.putText(frame, "Press ESC to exit", (30, 280), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

    # Display status
    status_text = "Liveness: "
    if spoofing_detected:
        status_text += "SPOOFING DETECTED"
        status_color = (0, 0, 255)  # Red
    elif liveness_confirmed:
        status_text += "CONFIRMED"
        status_color = (0, 255, 0)  # Green
    elif current_state == STATE_CAPTURE_COUNTDOWN or current_state == STATE_CAPTURED:
        status_text += "VERIFICATION COMPLETE"
        status_color = (255, 255, 255)  # White
    else:
        status_text += f"Challenge {current_challenge+1}/{len(selected_challenges)}"
        status_color = (255, 165, 0)  # Orange
        
    cv2.putText(frame, status_text, (10, frame.shape[0] - 20), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, status_color, 2)

    cv2.imshow("Liveness Detection", frame)

    if cv2.waitKey(1) == 27:  # ESC key
        break

cap.release()
cv2.destroyAllWindows()

