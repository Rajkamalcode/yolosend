import React, { useState, useEffect } from 'react';
import './FaceComparison.css';

const FaceComparison = ({ kycData, updateKycData, nextStep, prevStep }) => {
  const [extractedFace, setExtractedFace] = useState(null);
  const [comparisonResult, setComparisonResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Server URLs
  const faceServerUrl = 'http://10.9.52.21:5001';
  const compareUrl = `${faceServerUrl}/compare`;
  const dmsUrl = `${faceServerUrl}/get_dms_image`;
  
  // Extract face from Aadhaar on component mount
  useEffect(() => {
    if (kycData.aadhaarImage || kycData.maskedAadhaarDmsId) {
      extractFaceFromAadhaar();
    }
  }, [kycData.aadhaarImage, kycData.maskedAadhaarDmsId]);
  
  // Extract face from Aadhaar
  const extractFaceFromAadhaar = async () => {
    if (!kycData.aadhaarImage && !kycData.maskedAadhaarDmsId) {
      setError('No Aadhaar image available');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Determine the image source - either direct base64 or DMS ID
      let imageSource = kycData.aadhaarImage;
      
      // If we have a DMS ID, use that instead
      if (kycData.maskedAadhaarDmsId) {
        imageSource = `${dmsUrl}/${kycData.maskedAadhaarDmsId}`;
      }
      
      // Convert image to blob
      const response = await fetch(imageSource);
      if (!response.ok) {
        throw new Error(`Failed to fetch Aadhaar image: ${response.status} ${response.statusText}`);
      }
      
      const blob = await response.blob();
      
      const formData = new FormData();
      formData.append('image', blob, 'aadhaar.jpg');
      
      const result = await fetch('http://10.9.52.21:5000/process_aadhar', {
        method: 'POST',
        body: formData
      });
      
      if (!result.ok) {
        const errorData = await result.json().catch(() => null);
        throw new Error(errorData?.error || `Server error: ${result.status} ${result.statusText}`);
      }
      
      const imageBlob = await result.blob();
      const extractedFaceUrl = URL.createObjectURL(imageBlob);
      setExtractedFace(extractedFaceUrl);
      
      // Update KYC data
      updateKycData({
        extractedFaceImage: extractedFaceUrl
      });
      
      // Automatically compare faces if liveness image is available
      if (kycData.livenessImage || kycData.livenessImageDmsId) {
        compareFaces(extractedFaceUrl);
      }
      
    } catch (err) {
      setError(err.message || 'Failed to extract face from Aadhaar');
      console.error('Error extracting face:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Compare faces
  const compareFaces = async (extractedFaceUrl) => {
    if (!extractedFaceUrl) {
      setError('Extracted face image is required for comparison');
      return;
    }
    
    if (!kycData.livenessImage && !kycData.livenessImageDmsId) {
      setError('Liveness image is required for comparison');
      return;
    }
    
    setIsLoading(true);
    setError('');
    
    try {
      // Convert extracted face to blob
      const response1 = await fetch(extractedFaceUrl);
      const blob1 = await response1.blob();
      
      // Determine the liveness image source - either direct base64 or DMS ID
      let livenessImageSource = kycData.livenessImage;
      
      // If we have a DMS ID, use that instead
      if (kycData.livenessImageDmsId) {
        livenessImageSource = `${dmsUrl}/${kycData.livenessImageDmsId}`;
      }
      
      // Convert liveness image to blob
      const response2 = await fetch(livenessImageSource);
      if (!response2.ok) {
        throw new Error(`Failed to fetch liveness image: ${response2.status} ${response2.statusText}`);
      }
      
      const blob2 = await response2.blob();
      
      const formData = new FormData();
      formData.append('image1', blob1, 'aadhaar_face.jpg');
      formData.append('image2', blob2, 'liveness_face.jpg');
      
      const result = await fetch(compareUrl, {
        method: 'POST',
        body: formData
      });
      
      if (!result.ok) {
        const errorData = await result.json().catch(() => null);
        throw new Error(errorData?.error || `Server error: ${result.status} ${result.statusText}`);
      }
      
      const comparisonData = await result.json();
      
      // Process the comparison result
      const processedResult = {
        similarity: comparisonData.similarity || 0,
        match: (comparisonData.similarity || 0) >= 0.3,
        threshold: 0.3,
        status: comparisonData.status || 'success'
      };
      
      setComparisonResult(processedResult);
      console.log('Comparison result:', processedResult);
      
      // Update KYC data
      updateKycData({
        comparisonResult: processedResult
      });
      
    } catch (err) {
      setError(err.message || 'Failed to compare faces');
      console.error('Error comparing faces:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Handle continue to next step
  const handleContinue = () => {
    if (!comparisonResult) {
      setError('Face comparison is required before proceeding');
      return;
    }
    
    // Check if similarity is above threshold
    if (comparisonResult.similarity < 0.3) { // Adjust threshold as needed
      setError('Face similarity is too low to proceed. Please try again with clearer images.');
      return;
    }
    
    nextStep();
  };
  
  return (
    <div className="face-comparison">
      <h2>Face Comparison</h2>
      <p className="instructions">
        Comparing your live photo with the face extracted from your Aadhaar card, if Aadhar face is not visible, recapture.
      </p>
      
      {isLoading && (
        <div className="loading">
          <div className="spinner"></div>
          <p>Processing...</p>
        </div>
      )}
      
      {error && <div className="error-message">{error}</div>}
      
      <div className="comparison-container">
        <div className="face-item">
          <h3>Aadhaar Face</h3>
          {extractedFace ? (
            <img src={extractedFace} alt="Aadhaar Face" className="face-image" />
          ) : (
            <div className="placeholder">No face extracted</div>
          )}
        </div>
        
        <div className="face-item">
          <h3>Live Photo</h3>
          {kycData.livenessImage ? (
            <img src={kycData.livenessImage} alt="Live Photo" className="face-image" />
          ) : kycData.livenessImageDmsId ? (
            <img 
              src={`${dmsUrl}/${kycData.livenessImageDmsId}`} 
              alt="Live Photo" 
              className="face-image"
              onError={(e) => {
                console.error('Failed to load liveness image from DMS');
                e.target.src = 'placeholder-image.jpg'; // Fallback image
              }}
            />
          ) : (
            <div className="placeholder">No live photo</div>
          )}
        </div>
      </div>
      
      {comparisonResult && (
        <div className="comparison-results">
          <h3>Comparison Results</h3>
          <div className="result-item">
            <span className="result-label">Similarity Score:</span>
            <span className="result-value">{(comparisonResult.similarity * 100).toFixed(2)}%</span>
          </div>
          <div className="result-item">
            <span className="result-label">Match Status:</span>
            <span className={`result-value ${comparisonResult.match ? 'match' : 'no-match'}`}>
              {comparisonResult.match ? 'MATCH' : 'NO MATCH'}
            </span>
          </div>
        </div>
      )}
      
      <div className="controls">
        <button 
          className="compare-btn" 
          onClick={() => compareFaces(extractedFace)}
          disabled={!extractedFace || (!kycData.livenessImage && !kycData.livenessImageDmsId) || isLoading}
        >
          Compare Faces
        </button>
      </div>
      
      <div className="navigation-buttons">
        <button className="back-btn" onClick={prevStep}>
          Back
        </button>
        <button 
          className="continue-btn" 
          onClick={handleContinue}
          disabled={!comparisonResult || comparisonResult.similarity < 0.3}
        >
          Continue
        </button>
      </div>
    </div>
  );
};

export default FaceComparison;
