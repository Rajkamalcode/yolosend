import io
import os
import logging
from PIL import Image
from pymongo import MongoClient
import gridfs
from tqdm import tqdm
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("MongoDBUpload")

# Connect to MongoDB (adjust connection string as needed)
client = MongoClient("mongodb://bridgedevwrite:BridgedevWrite890@10.9.50.43:10050/")
db = client["chola_face_db"]
collection = db["face_images"]
fs = gridfs.GridFS(db)

# Path to the folder containing images
IMAGE_FOLDER = "faces"  # Replace with your actual image folder path

# Supported image extensions
SUPPORTED_EXTENSIONS = ('.jpg', '.jpeg', '.png')

logger.info(f"Uploading images from {IMAGE_FOLDER} to MongoDB...")

# Get list of image files
image_files = [
    f for f in os.listdir(IMAGE_FOLDER) 
    if os.path.isfile(os.path.join(IMAGE_FOLDER, f)) and 
    f.lower().endswith(SUPPORTED_EXTENSIONS)
]

# Find the highest existing UCIC ID in the database
highest_ucic = collection.find_one(sort=[("ucic_id", -1)])
if highest_ucic and "ucic_id" in highest_ucic:
    # Extract the numeric part from the UCIC ID (format: UCIC#00000123)
    match = re.search(r'UCIC#(\d+)', highest_ucic["ucic_id"])
    if match:
        counter = int(match.group(1)) + 1
    else:
        counter = 1
else:
    counter = 1

logger.info(f"Starting with UCIC ID counter: {counter}")

for image_file in tqdm(image_files, desc="Uploading Images"):
    try:
        # Extract name from filename (without extension)
        name = os.path.splitext(image_file)[0]
        
        # Load the image
        image_path = os.path.join(IMAGE_FOLDER, image_file)
        with Image.open(image_path) as image:

            if image.mode == 'RGBA':
                # Create a white background
                background = Image.new('RGB', image.size, (255, 255, 255))
                # Paste the image on the background using alpha as mask
                background.paste(image, mask=image.split()[3])
                image = background
            
            # Convert the image to JPEG bytes
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format="JPEG")
            img_bytes = img_byte_arr.getvalue()
        
        # Save image into GridFS
        image_id = fs.put(img_bytes, filename=image_file)
        
        # Generate incremental UCIC reference ID
        ucic_id = f"UCIC#{counter:08d}"
        counter += 1
        
        # Create a document with metadata and reference to the image
        document = {
            "ucic_id": ucic_id,
            "name": name,
            "image_id": image_id,
            "original_filename": image_file
        }
        
        # Insert the document into the collection
        collection.insert_one(document)
        logger.info(f"Inserted document for {name} with UCIC ID {ucic_id}")
    
    except Exception as e:
        logger.error(f"Error processing {image_file}: {str(e)}")

logger.info(f"Upload completed. Processed {len(image_files)} images.")
